"""Integration tests for SCRUM-71 - report recategorization."""

from copy import deepcopy
from types import SimpleNamespace

import pytest
from fastapi.testclient import TestClient

from app.main import app
from app.routers import rt_reports


REPORT_ID = "report_scrum71"
TENANT_A = "tenant_a"
TENANT_B = "tenant_b"
SUPERVISOR_ID = "supervisor_test"


class FakeCollection:
    def __init__(self, documents=None):
        self.documents = deepcopy(documents or [])

    @staticmethod
    def _matches(document, query):
        return all(document.get(key) == value for key, value in query.items())

    async def find_one(self, query, projection=None):
        for document in self.documents:
            if self._matches(document, query):
                return deepcopy(document)
        return None

    async def update_one(self, query, update):
        for document in self.documents:
            if self._matches(document, query):
                before = deepcopy(document)

                for key, value in update.get("$set", {}).items():
                    document[key] = value

                modified = int(document != before)
                return SimpleNamespace(modified_count=modified)

        return SimpleNamespace(modified_count=0)

    async def insert_one(self, document):
        self.documents.append(deepcopy(document))
        return SimpleNamespace(inserted_id="fake_id")


class FakeDB:
    def __init__(self, reports=None):
        self.collections = {
            "reports": FakeCollection(reports),
            "activity_log": FakeCollection(),
            "notifications": FakeCollection(),
        }

    def __getitem__(self, name):
        if name not in self.collections:
            self.collections[name] = FakeCollection()
        return self.collections[name]


def report_fixture(
    *,
    report_id=REPORT_ID,
    client_id=TENANT_A,
    category="Hallazgo",
    is_iap=False,
):
    return {
        "report_id": report_id,
        "client_id": client_id,
        "type": category,
        "is_iap": is_iap,
        "status": "open",
    }


@pytest.fixture
def fake_db():
    return FakeDB([report_fixture()])


@pytest.fixture
def client_factory(fake_db, monkeypatch):
    clients = []

    def _factory(
        *,
        role="supervisor",
        client_id=TENANT_A,
        user_id=SUPERVISOR_ID,
    ):
        app.dependency_overrides[rt_reports.get_db] = lambda: fake_db

        monkeypatch.setattr(
            rt_reports,
            "get_current_user",
            lambda credentials: {
                "user_id": user_id,
                "client_id": client_id,
                "role": role,
            },
        )

        client = TestClient(app)
        clients.append(client)
        return client

    yield _factory

    for client in clients:
        client.close()

    app.dependency_overrides.clear()


@pytest.mark.parametrize(
    ("category", "expected_iap"),
    [
        ("Acto Inseguro", False),
        ("Condición Insegura", False),
        ("Accidente", False),
        ("IAP", True),
    ],
)
def test_supervisor_can_use_all_allowed_categories(
    fake_db,
    client_factory,
    category,
    expected_iap,
):
    client = client_factory(role="supervisor")

    response = client.patch(
        f"/v1/reports/{REPORT_ID}/category",
        headers={"Authorization": "Bearer fake_token"},
        json={"type": category},
    )

    assert response.status_code == 200

    body = response.json()
    assert body["ok"] is True
    assert body["changed"] is True
    assert body["type"] == category
    assert body["is_iap"] is expected_iap

    saved = fake_db["reports"].documents[0]
    assert saved["type"] == category
    assert saved["is_iap"] is expected_iap


@pytest.mark.parametrize(
    "role",
    [
        "supervisor",
        "jefe_de_area",
        "jefe de area",
    ],
)
def test_allowed_roles_can_recategorize(client_factory, role):
    client = client_factory(role=role)

    response = client.patch(
        f"/v1/reports/{REPORT_ID}/category",
        headers={"Authorization": "Bearer fake_token"},
        json={"type": "Accidente"},
    )

    assert response.status_code == 200


@pytest.mark.parametrize(
    "role",
    [
        "worker",
        "usuario",
        "admin",
        "sso_manager",
    ],
)
def test_other_roles_cannot_recategorize(client_factory, role):
    client = client_factory(role=role)

    response = client.patch(
        f"/v1/reports/{REPORT_ID}/category",
        headers={"Authorization": "Bearer fake_token"},
        json={"type": "Accidente"},
    )

    assert response.status_code == 403
    assert response.json()["detail"] == (
        "No tiene permisos para recategorizar incidentes"
    )


def test_invalid_category_is_rejected(client_factory):
    client = client_factory()

    response = client.patch(
        f"/v1/reports/{REPORT_ID}/category",
        headers={"Authorization": "Bearer fake_token"},
        json={"type": "Categoría inventada"},
    )

    assert response.status_code == 422
    assert response.json()["detail"] == "Categoría de incidente no válida"


def test_report_from_another_tenant_is_not_accessible(client_factory):
    client = client_factory(client_id=TENANT_B)

    response = client.patch(
        f"/v1/reports/{REPORT_ID}/category",
        headers={"Authorization": "Bearer fake_token"},
        json={"type": "Accidente"},
    )

    assert response.status_code == 404
    assert response.json()["detail"] == "Reporte no encontrado"


def test_missing_report_returns_404(client_factory):
    client = client_factory()

    response = client.patch(
        "/v1/reports/report_missing/category",
        headers={"Authorization": "Bearer fake_token"},
        json={"type": "Accidente"},
    )

    assert response.status_code == 404


def test_iap_flag_is_removed_when_leaving_iap(monkeypatch):
    fake_db = FakeDB(
        [
            report_fixture(
                category="IAP",
                is_iap=True,
            )
        ]
    )

    app.dependency_overrides[rt_reports.get_db] = lambda: fake_db

    monkeypatch.setattr(
        rt_reports,
        "get_current_user",
        lambda credentials: {
            "user_id": SUPERVISOR_ID,
            "client_id": TENANT_A,
            "role": "supervisor",
        },
    )

    try:
        with TestClient(app) as client:
            response = client.patch(
                f"/v1/reports/{REPORT_ID}/category",
                headers={"Authorization": "Bearer fake_token"},
                json={"type": "Condición Insegura"},
            )

        assert response.status_code == 200
        assert response.json()["is_iap"] is False

        saved = fake_db["reports"].documents[0]
        assert saved["type"] == "Condición Insegura"
        assert saved["is_iap"] is False
    finally:
        app.dependency_overrides.clear()


def test_same_category_is_idempotent(monkeypatch):
    fake_db = FakeDB(
        [
            report_fixture(
                category="Acto Inseguro",
                is_iap=False,
            )
        ]
    )

    app.dependency_overrides[rt_reports.get_db] = lambda: fake_db

    monkeypatch.setattr(
        rt_reports,
        "get_current_user",
        lambda credentials: {
            "user_id": SUPERVISOR_ID,
            "client_id": TENANT_A,
            "role": "supervisor",
        },
    )

    try:
        with TestClient(app) as client:
            response = client.patch(
                f"/v1/reports/{REPORT_ID}/category",
                headers={"Authorization": "Bearer fake_token"},
                json={"type": "Acto Inseguro"},
            )

        assert response.status_code == 200
        assert response.json()["changed"] is False
        assert fake_db["activity_log"].documents == []
    finally:
        app.dependency_overrides.clear()


def test_real_change_creates_activity_log(fake_db, client_factory):
    client = client_factory(
        role="supervisor",
        user_id=SUPERVISOR_ID,
    )

    response = client.patch(
        f"/v1/reports/{REPORT_ID}/category",
        headers={"Authorization": "Bearer fake_token"},
        json={"type": "Accidente"},
    )

    assert response.status_code == 200

    logs = fake_db["activity_log"].documents
    assert len(logs) == 1

    entry = logs[0]
    assert entry["action"] == "recategorized"
    assert entry["report_id"] == REPORT_ID
    assert entry["client_id"] == TENANT_A
    assert entry["user_id"] == SUPERVISOR_ID
    assert "Accidente" in entry["detail"]
