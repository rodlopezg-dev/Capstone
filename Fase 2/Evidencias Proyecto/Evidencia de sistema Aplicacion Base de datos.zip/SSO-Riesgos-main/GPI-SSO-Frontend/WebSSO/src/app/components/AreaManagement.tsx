// Placeholder — área de gestión integrada en UserManagement.tsx (pestaña "Áreas Operativas")
export default function AreaManagement() {
  return null;
}
