import pytest


async def _configure_talk(
    db,
    talk_id,
    expected_user_ids,
):
    await db["talks"].insert_one({
        "talk_id": talk_id,
        "client_id": "empresa_a",
        "title": "Charla obligatoria",
        "month": "9",
        "year": "2026",
        "mandatory": True,
        "expected_user_ids": (
            expected_user_ids
        ),
    })


@pytest.mark.asyncio
async def test_comparison_uses_qr_user_ids_for_same_talk(
    api,
    db,
    auth_headers,
    seed,
):
    await _configure_talk(
        db,
        "talk_compare_qr",
        [
            "worker_a",
            "worker_a2",
        ],
    )

    await db["attendance"].insert_many([
        {
            "attendance_id": "att_qr_match",
            "client_id": "empresa_a",
            "talk_id": "talk_compare_qr",
            "source": "qr",
            "attended_user_ids": [
                "worker_a",
                "not_expected",
            ],
            "attendees": [
                "Ana Prueba",
                "Persona Externa",
            ],
        },
        {
            "attendance_id": "att_other_talk",
            "client_id": "empresa_a",
            "talk_id": "otra_charla",
            "source": "qr",
            "attended_user_ids": [
                "worker_a2",
            ],
            "attendees": [
                "Luis Prueba",
            ],
        },
        {
            "attendance_id": "att_other_tenant",
            "client_id": "empresa_b",
            "talk_id": "talk_compare_qr",
            "source": "qr",
            "attended_user_ids": [
                "worker_a2",
            ],
            "attendees": [
                "Luis Prueba",
            ],
        },
    ])

    response = await api.get(
        (
            "/v1/talks/"
            "talk_compare_qr/"
            "attendance-comparison"
        ),
        headers=auth_headers(role="admin"),
    )

    assert response.status_code == 200

    data = response.json()

    assert data["expected_user_ids"] == [
        "worker_a",
        "worker_a2",
    ]
    assert data["attended_user_ids"] == [
        "worker_a",
    ]


@pytest.mark.asyncio
async def test_comparison_matches_unique_manual_name(
    api,
    db,
    auth_headers,
    seed,
):
    await _configure_talk(
        db,
        "talk_compare_manual",
        [
            "worker_a",
            "worker_a2",
        ],
    )

    await db["attendance"].insert_one({
        "attendance_id": "att_manual",
        "client_id": "empresa_a",
        "talk_id": "talk_compare_manual",
        "attendees": [
            "  LÚIS   PRUEBA ",
        ],
    })

    response = await api.get(
        (
            "/v1/talks/"
            "talk_compare_manual/"
            "attendance-comparison"
        ),
        headers=auth_headers(role="admin"),
    )

    assert response.status_code == 200

    assert response.json()[
        "attended_user_ids"
    ] == [
        "worker_a2",
    ]


@pytest.mark.asyncio
async def test_comparison_does_not_match_ambiguous_manual_name(
    api,
    db,
    auth_headers,
    seed,
):
    await db["users"].insert_one({
        "user_id": "worker_ana_2",
        "client_id": "empresa_a",
        "status": "active",
        "role": "worker",
        "name": "Ana",
        "last_name": "Prueba",
    })

    await _configure_talk(
        db,
        "talk_compare_ambiguous",
        [
            "worker_a",
            "worker_ana_2",
        ],
    )

    await db["attendance"].insert_one({
        "attendance_id": "att_ambiguous",
        "client_id": "empresa_a",
        "talk_id": "talk_compare_ambiguous",
        "attendees": [
            "Ana Prueba",
        ],
    })

    response = await api.get(
        (
            "/v1/talks/"
            "talk_compare_ambiguous/"
            "attendance-comparison"
        ),
        headers=auth_headers(role="admin"),
    )

    assert response.status_code == 200
    assert response.json()[
        "attended_user_ids"
    ] == []


@pytest.mark.asyncio
async def test_comparison_ignores_manual_record_without_talk_id(
    api,
    db,
    auth_headers,
    seed,
):
    await _configure_talk(
        db,
        "talk_compare_unlinked",
        [
            "worker_a",
        ],
    )

    await db["attendance"].insert_one({
        "attendance_id": "att_unlinked",
        "client_id": "empresa_a",
        "talk_id": "",
        "attendees": [
            "Ana Prueba",
        ],
    })

    response = await api.get(
        (
            "/v1/talks/"
            "talk_compare_unlinked/"
            "attendance-comparison"
        ),
        headers=auth_headers(role="admin"),
    )

    assert response.status_code == 200
    assert response.json()[
        "attended_user_ids"
    ] == []


@pytest.mark.asyncio
async def test_comparison_does_not_use_qr_name_as_identity_fallback(
    api,
    db,
    auth_headers,
    seed,
):
    await _configure_talk(
        db,
        "talk_compare_qr_identity",
        [
            "worker_a",
        ],
    )

    await db["attendance"].insert_one({
        "attendance_id": "att_qr_other_user",
        "client_id": "empresa_a",
        "talk_id": "talk_compare_qr_identity",
        "source": "qr",
        "attended_user_ids": [
            "someone_else",
        ],
        "attendees": [
            "Ana Prueba",
        ],
    })

    response = await api.get(
        (
            "/v1/talks/"
            "talk_compare_qr_identity/"
            "attendance-comparison"
        ),
        headers=auth_headers(role="admin"),
    )

    assert response.status_code == 200
    assert response.json()[
        "attended_user_ids"
    ] == []
