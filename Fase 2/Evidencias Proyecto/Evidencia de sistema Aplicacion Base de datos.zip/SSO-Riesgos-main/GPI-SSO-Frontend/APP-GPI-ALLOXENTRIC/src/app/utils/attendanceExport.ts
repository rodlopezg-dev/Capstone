export type AttendanceExportFormat = 'pdf' | 'xlsx';

export function buildAttendanceExportUrl(
  baseUrl: string,
  format: AttendanceExportFormat,
  month: string,
  year: string,
): string {
  const params = new URLSearchParams();

  if (month) {
    params.set('month', month);
  }

  if (year) {
    params.set('year', year);
  }

  const query = params.toString();

  return (
    `${baseUrl}/v1/attendance/export/${format}` +
    (query ? `?${query}` : '')
  );
}

export function resolveAttendanceExportFilename(
  contentDisposition: string | null,
  format: AttendanceExportFormat,
  month: string,
  year: string,
): string {
  const match = contentDisposition?.match(
    /filename="?([^";]+)"?/i,
  );

  if (match?.[1]) {
    return match[1];
  }

  const parts = ['asistencia'];

  if (year) {
    parts.push(year);
  }

  if (month) {
    parts.push(month.padStart(2, '0'));
  }

  return `${parts.join('_')}.${format}`;
}
