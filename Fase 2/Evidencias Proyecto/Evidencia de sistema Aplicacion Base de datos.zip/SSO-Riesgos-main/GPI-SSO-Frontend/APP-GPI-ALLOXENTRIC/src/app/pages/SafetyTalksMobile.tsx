import {
  authenticatedFetch,
  getToken,
} from '../api/client';

import { useState, useEffect, useRef } from 'react';
import { Capacitor } from '@capacitor/core';
import { motion, AnimatePresence } from 'motion/react';
import {
  Camera,
  ChevronLeft,
  Download,
  Image as ImageIcon,
  Loader2,
  Plus,
  ScanLine,
  Users,
  X,
} from 'lucide-react';

import {
  pickFromGallery,
  takePhoto,
} from '../plugins/CapacitorBridge';
import {
  dataUrlToImageFile,
} from '../utils/imageFiles';
import {
  findAttendanceSheet,
  localAttendanceDate,
  validateAttendanceSheet,
} from '../utils/attendanceSheet';
import {
  fetchAttendanceSheetBlob,
} from '../api/talkAttendance';
import { Bar, BarChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import AttendancePeriodSummary from '../components/AttendancePeriodSummary';
import AttendanceImagePreview from '../components/AttendanceImagePreview';
import {
  buildAttendanceExportUrl,
  resolveAttendanceExportFilename,
  type AttendanceExportFormat,
} from '../utils/attendanceExport';
import {
  buildAbsentWorkersUrl,
  getAbsentWorkerDisplayName,
  getAbsenceStatusMessage,
  type AbsentWorker,
  type AbsentWorkersResponse,
} from '../utils/attendanceAbsences';
import { canManageTalkAttendance } from '../utils/talkPermissions';


import {
  filterAttendanceWorkers,
  isWorkerDistinguishable,
  normalizeAttendanceSearch,
  type AttendanceWorker,
} from '../utils/filterAttendanceWorkers';

import {
  listAttendanceCandidates,
  requestAttendanceOcrPreview,
} from '../api/talkAttendance';

import type {
  PreviewWorker
} from '../components/AttendanceImagePreview';


const TALKS_API =
  import.meta.env.VITE_TALKS_API_URL ||
  import.meta.env.VITE_REPORTS_API_URL?.replace('reports', 'talks') ||
  (window.location.origin + '/api/talks');

type Talk = {
  talk_id: string;
  title: string;
  month: string;
  year: string;
  mandatory?: boolean;
  file_id?: string;
  file_url?: string;
  file_name: string;
  created_at: string;
};

type Attendance = {
  attendance_id: string;
  talk_id?: string;
  source?: string;
  topic: string;
  date: string;
  area: string;
  attendees: string[];
  attended_user_ids?: string[];
  feedback: string;
  file_id?: string;
  file_url?: string;
  file_name?: string;
  file_content_type?: string;
  file_size?: number;
};

type AttendanceAreaStat = {
  area: string;
  active_workers: number;
  attendance_count: number;
  attendance_percentage: number;
};

type AttendanceMonthStat = {
  year: string;
  month: string;
  active_workers: number;
  attendance_count: number;
  attendance_percentage: number;
};


type Props = {
  onBack: () => void;
  userRole: string;
  users: AttendanceWorker[];
};


const MONTHS = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
const EMPTY_RECOGNIZED_WORKERS: [] = [];
export default function SafetyTalksMobile({ onBack, userRole, users }: Props) {
  const [attendanceUsers, setAttendanceUsers] =
    useState<AttendanceWorker[]>(users);
  const [talks, setTalks] = useState<Talk[]>([]);
  const [attendance, setAttendance] = useState<Attendance[]>([]);
  const [loading, setLoading] = useState(true);
  const [downloadError, setDownloadError] = useState('');
  const [downloadingId, setDownloadingId] = useState<string | null>(null);
  const [month, setMonth] = useState(String(new Date().getMonth() + 1));
  const [year, setYear] = useState(String(new Date().getFullYear()));
  const [showAttForm, setShowAttForm] = useState(false);
  const [attTopic, setAttTopic] = useState('');
  const [attDate, setAttDate] = useState(localAttendanceDate());
  const [attArea, setAttArea] = useState('');
  const [attSelectedIds, setAttSelectedIds] = useState<string[]>([]);
  const [attSearch, setAttSearch] = useState('');
  const [attFeedback, setAttFeedback] = useState('');
  const [tab, setTab] = useState<'talks' | 'attendance'>('talks');
  const [areaStats, setAreaStats] = useState<AttendanceAreaStat[]>([]);
  const [monthlyStats, setMonthlyStats] = useState<AttendanceMonthStat[]>([]);
  const [statsLoading, setStatsLoading] = useState(false);
  const [statsError, setStatsError] = useState('');
  const [exportingFormat, setExportingFormat] =
    useState<AttendanceExportFormat | null>(null);
  const [exportError, setExportError] = useState('');
  const [absentTalk, setAbsentTalk] = useState<Talk | null>(null);
  const [absentResult, setAbsentResult] =
    useState<AbsentWorkersResponse | null>(null);
  const [absentWorkersLoading, setAbsentWorkersLoading] =
    useState(false);
  const [absentWorkersError, setAbsentWorkersError] =
    useState('');
  const recognitionRequestIdRef = useRef(0);

  const [sheetTalk, setSheetTalk] = useState<Talk | null>(null);
  const [sheetBusy, setSheetBusy] = useState(false);
  const [previewSheet, setPreviewSheet] = useState<{ talk: Talk; file: File } | null>(null);
  const [ocrWorkers, setOcrWorkers] =
    useState<PreviewWorker[]>([]);

  const [ocrProcessing, setOcrProcessing] = useState(false);

  const [ocrError, setOcrError] = useState('');
  const [sheetError, setSheetError] = useState('');
  const [viewingSheet, setViewingSheet] = useState<{
    title: string;
    url: string;
  } | null>(null);

  useEffect(() => {
    let cancelled = false;

    const loadAttendanceUsers = async () => {
      try {
        const candidates = await listAttendanceCandidates(TALKS_API);

        if (!cancelled) {
          setAttendanceUsers(candidates);
        }
      } catch {
        if (!cancelled) {
          setAttendanceUsers([]);
        }
      }
    };

    void loadAttendanceUsers();

    return () => {
      cancelled = true;
    };
  }, []);

  const sheetFileInputRef = useRef<HTMLInputElement | null>(null);
  const sheetObjectUrlRef = useRef<string | null>(null);

  // --- INICIO: ESCANEO QR DE ASISTENCIA ---
  const [showQrScanner, setShowQrScanner] = useState(false);
  const [qrTalk, setQrTalk] = useState<Talk | null>(null);
  const [qrMessage, setQrMessage] = useState('');
  // --- INICIO: VISUALIZACION QR PARA RESPONSABLES ---
  const [displayQr, setDisplayQr] = useState<{ title: string; image: string } | null>(null);
  const [displayQrError, setDisplayQrError] = useState('');
  const displayQrOpenRef = useRef(false);
  const displayQrRefreshTimerRef = useRef<number | null>(null);
  const normalizedRole = (userRole || '').toLowerCase().replace(/_/g, ' ').normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();
  const canDisplayQr = ['admin', 'supervisor', 'jefe de area'].includes(normalizedRole);
  const closeDisplayQr = () => {
    displayQrOpenRef.current = false;
    if (displayQrRefreshTimerRef.current !== null) window.clearTimeout(displayQrRefreshTimerRef.current);
    displayQrRefreshTimerRef.current = null;
    setDisplayQr(null);
  };
  const openDisplayQr = async (talk: Talk, refresh = false) => {
    if (displayQrRefreshTimerRef.current !== null) window.clearTimeout(displayQrRefreshTimerRef.current);
    displayQrOpenRef.current = true;
    if (!refresh) setDisplayQr({ title: talk.title, image: '' });
    setDisplayQrError('');
    try {
      const response = await authenticatedFetch(TALKS_API + '/v1/talks/' + encodeURIComponent(talk.talk_id) + '/qr', { headers });
      const data = await response.json();
      if (!response.ok) throw new Error(data.detail || 'No se pudo obtener el QR.');
      if (!displayQrOpenRef.current) return;
      setDisplayQr(current => current ? { ...current, image: data.image } : null);
      // Renueva el QR después de expirar sólo mientras el modal siga abierto.
      const refreshDelay = Math.max(new Date(data.expires_at).getTime() - Date.now() + 250, 1000);
      displayQrRefreshTimerRef.current = window.setTimeout(() => {
        if (displayQrOpenRef.current) void openDisplayQr(talk, true);
      }, refreshDelay);
    } catch (error) {
      setDisplayQrError(error instanceof Error ? error.message : 'No se pudo obtener el QR.');
    }
  };
  // --- FIN: VISUALIZACION QR PARA RESPONSABLES ---
  const scannerVideoRef = useRef<HTMLVideoElement | null>(null);
  const scannerStreamRef = useRef<MediaStream | null>(null);
  const scannerFrameRef = useRef<number | null>(null);

  const stopQrScanner = () => {
    if (scannerFrameRef.current !== null) cancelAnimationFrame(scannerFrameRef.current);
    scannerFrameRef.current = null;
    scannerStreamRef.current?.getTracks().forEach(track => track.stop());
    scannerStreamRef.current = null;
  };

  const closeQrScanner = () => {
    stopQrScanner();
    setShowQrScanner(false);
    setQrTalk(null);
  };

  const submitQrAttendance = async (rawValue: string, talkId: string) => {
    const response = await authenticatedFetch(TALKS_API + '/v1/attendance/scan', {
      method: 'POST',
      headers: { ...headers, 'Content-Type': 'application/json' },
      body: JSON.stringify({ payload: rawValue, talk_id: talkId }),
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.detail || 'No se pudo registrar la asistencia.');
    setQrMessage(data.message || 'Asistencia registrada correctamente.');
    stopQrScanner();
    await fetchAttendance();
  };

  const openQrScanner = (talk: Talk) => {
    setQrTalk(talk);
    setQrMessage('');
    setShowQrScanner(true);
    window.setTimeout(async () => {
      const BarcodeDetectorApi = (window as any).BarcodeDetector;
      if (!BarcodeDetectorApi || !navigator.mediaDevices?.getUserMedia || !scannerVideoRef.current) {
        setQrMessage('El escaneo QR no está disponible en este navegador. Abre la aplicación desde un teléfono compatible.');
        return;
      }
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' } }, audio: false });
        scannerStreamRef.current = stream;
        const video = scannerVideoRef.current;
        video.srcObject = stream;
        await video.play();
        const detector = new BarcodeDetectorApi({ formats: ['qr_code'] });
        const scanFrame = async () => {
          if (!scannerVideoRef.current || !scannerStreamRef.current) return;
          const [result] = await detector.detect(scannerVideoRef.current);
          if (result?.rawValue) {
            try {
              await submitQrAttendance(result.rawValue, talk.talk_id);
            } catch (error) {
              stopQrScanner();
              setQrMessage(error instanceof Error ? error.message : 'No se pudo registrar la asistencia.');
            }
            return;
          }
          scannerFrameRef.current = requestAnimationFrame(scanFrame);
        };
        scannerFrameRef.current = requestAnimationFrame(scanFrame);
      } catch {
        setQrMessage('No fue posible acceder a la cámara. Revisa los permisos del dispositivo.');
      }
    }, 0);
  };

  useEffect(() => () => {
    stopQrScanner();

    if (displayQrRefreshTimerRef.current !== null) {
      window.clearTimeout(
        displayQrRefreshTimerRef.current,
      );
    }

    if (sheetObjectUrlRef.current) {
      URL.revokeObjectURL(
        sheetObjectUrlRef.current,
      );
      sheetObjectUrlRef.current = null;
    }
  }, []);
  // --- FIN: ESCANEO QR DE ASISTENCIA ---

  const token = getToken() ?? '';
  const headers: HeadersInit = {};
  const isManager = canManageTalkAttendance(userRole);
  const currentUserId = (() => {
    try {
      const encodedPayload = token.split('.')[1];
      const normalizedPayload = encodedPayload.replace(/-/g, '+').replace(/_/g, '/');
      const paddedPayload = normalizedPayload.padEnd(Math.ceil(normalizedPayload.length / 4) * 4, '=');
      const payload = JSON.parse(atob(paddedPayload));
      return payload.sub || payload.user_id || '';
    } catch {
      return '';
    }
  })();
  const hasEnteredTalk = (talkId: string) => attendance.some(record =>
    record.source === 'qr' &&
    record.talk_id === talkId &&
    Boolean(currentUserId) &&
    record.attended_user_ids?.includes(currentUserId)
  );




  const analyzeAttendanceSheet = async (
    talk: Talk,
    file: File,
    requestId: number
  ) => {
    try {
      const result = await requestAttendanceOcrPreview(
        TALKS_API,
        talk.talk_id,
        file
      );

      // Ignorar resultados de solicitudes antiguas.
      if (recognitionRequestIdRef.current !== requestId) {
        return;
      }

      setOcrWorkers(
        result.recognized_workers.map(worker => ({
          localId: worker.local_id,
          name: worker.name || 'Nombre no legible',
          email: worker.email,

          // El OCR no confirma identidades.
          userId: null,
        }))
      );
    } catch (error) {
      if (recognitionRequestIdRef.current !== requestId) {
        return;
      }

      setOcrError(
        error instanceof Error
          ? error.message
          : 'No fue posible procesar la fotografía.'
      );
    } finally {
      if (recognitionRequestIdRef.current === requestId) {
        setOcrProcessing(false);
      }
    }
  };



  const downloadTalk = async (talk: Talk) => {
    setDownloadError('');
    setDownloadingId(talk.talk_id);

    try {
      if (talk.file_id) {
        const response = await authenticatedFetch(
          TALKS_API + '/v1/talks/' + encodeURIComponent(talk.talk_id) + '/file',
          { headers },
        );

        if (!response.ok) {
          throw new Error('Archivo no disponible.');
        }

        const blob = await response.blob();
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');

        link.href = url;
        link.download = talk.file_name || 'archivo';

        document.body.appendChild(link);
        link.click();
        link.remove();

        window.setTimeout(() => {
          URL.revokeObjectURL(url);
        }, 60_000);

        return;
      }

      if (talk.file_url) {
        const link = document.createElement('a');

        link.href = talk.file_url;
        link.download = talk.file_name || 'archivo';

        document.body.appendChild(link);
        link.click();
        link.remove();

        return;
      }

      throw new Error('Archivo no disponible.');
    } catch {
      setDownloadError('No se pudo descargar el archivo. Intenta nuevamente.');
    } finally {
      setDownloadingId(null);
    }
  };

  const fetchTalks = async () => {
    try {
      const res = await authenticatedFetch(TALKS_API + '/v1/talks?month=' + month + '&year=' + year, { headers });
      if (res.ok) setTalks(await res.json());
    } catch (e) { console.error(e); }
  };

  const fetchAttendance = async () => {
    try {
      const res = await authenticatedFetch(TALKS_API + '/v1/attendance', { headers });
      if (res.ok) setAttendance(await res.json());
    } catch (e) { console.error(e); }
  };

  const fetchAttendanceStats = async () => {
    setStatsLoading(true);
    setStatsError('');

    try {
      const [areasResponse, monthsResponse] = await Promise.all([
        authenticatedFetch(TALKS_API + '/v1/attendance/stats/areas', { headers }),
        authenticatedFetch(
          TALKS_API + '/v1/attendance/stats/months?year=' + encodeURIComponent(year),
          { headers },
        ),
      ]);

      if (!areasResponse.ok || !monthsResponse.ok) {
        throw new Error('No se pudieron cargar las estadísticas de asistencia.');
      }

      const [areasData, monthsData] = await Promise.all([
        areasResponse.json(),
        monthsResponse.json(),
      ]);

      setAreaStats(
        Array.isArray(areasData)
          ? areasData
          : [],
      );

      setMonthlyStats(
        Array.isArray(monthsData)
          ? monthsData
          : [],
      );
    } catch (error) {
      console.error(error);
      setAreaStats([]);
      setMonthlyStats([]);
      setStatsError('No se pudieron cargar las estadísticas de asistencia.');
    } finally {
      setStatsLoading(false);
    }
  };

  useEffect(() => {
    setLoading(true);

    const requests = [
      fetchTalks(),
      fetchAttendance(),
    ];

    if (isManager) {
      requests.push(fetchAttendanceStats());
    }

    Promise.all(requests).finally(
      () => setLoading(false)
    );
  }, [month, year, isManager]);

  const closeAbsentWorkers = () => {
    setAbsentTalk(null);
    setAbsentResult(null);
    setAbsentWorkersError('');
    setAbsentWorkersLoading(false);
  };

  const openAbsentWorkers = async (talk: Talk) => {
    setAbsentTalk(talk);
    setAbsentResult(null);
    setAbsentWorkersError('');
    setAbsentWorkersLoading(true);

    try {
      const response = await authenticatedFetch(
        buildAbsentWorkersUrl(
          TALKS_API,
          talk.talk_id,
        ),
        { headers },
      );

      const data = await response
        .json()
        .catch(() => ({}));

      if (!response.ok) {
        throw new Error(
          data.detail ||
          'No se pudo obtener el listado de ausentes.',
        );
      }

      setAbsentResult(
        data as AbsentWorkersResponse,
      );
    } catch (error) {
      console.error(error);

      setAbsentWorkersError(
        error instanceof Error
          ? error.message
          : 'No se pudo obtener el listado de ausentes.',
      );
    } finally {
      setAbsentWorkersLoading(false);
    }
  };

  const downloadAttendanceExport = async (
    format: AttendanceExportFormat,
  ) => {
    setExportingFormat(format);
    setExportError('');

    try {
      const response = await authenticatedFetch(
        buildAttendanceExportUrl(
          TALKS_API,
          format,
          month,
          year,
        ),
        { headers },
      );

      if (!response.ok) {
        const data = await response
          .json()
          .catch(() => ({}));

        throw new Error(
          data.detail ||
          'No se pudo generar la exportación.',
        );
      }

      const blob = await response.blob();

      const filename =
        resolveAttendanceExportFilename(
          response.headers.get(
            'Content-Disposition'
          ),
          format,
          month,
          year,
        );

      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');

      link.href = url;
      link.download = filename;

      document.body.appendChild(link);
      link.click();
      link.remove();

      window.setTimeout(() => {
        URL.revokeObjectURL(url);
      }, 60_000);
    } catch (error) {
      console.error(error);

      setExportError(
        error instanceof Error
          ? error.message
          : 'No se pudo generar la exportación.',
      );
    } finally {
      setExportingFormat(null);
    }
  };

  const getAttendanceSheet = (
    talkId: string,
  ): Attendance | null => (
    findAttendanceSheet(
      attendance,
      talkId,
    )
  );

  const closeAttendanceSheetViewer = () => {
    if (sheetObjectUrlRef.current) {
      URL.revokeObjectURL(sheetObjectUrlRef.current);
      sheetObjectUrlRef.current = null;
    }

    setViewingSheet(null);
  };


  const prepareAttendancePreview = (talk: Talk, file: File) => {
    // 1. Validar la fotografía.
    const validationError = validateAttendanceSheet(file);

    if (validationError) {
      setSheetError(validationError);
      return;
    }

    // 2. Limpiar errores anteriores.
    setSheetError('');

    // 3. Reiniciar los resultados del OCR anterior.
    setOcrWorkers([]);
    setOcrError('');

    // 4. Cerrar la ventana de selección de fotografía.
    setSheetTalk(null);

    // 5. Abrir la vista previa y analizar automáticamente la fotografía.
    setPreviewSheet({ talk, file });
    const requestId = recognitionRequestIdRef.current + 1;
    recognitionRequestIdRef.current = requestId;
    setOcrProcessing(true);
    void analyzeAttendanceSheet(talk, file, requestId);
  };


  const handleAttendanceCamera = async () => {
    if (!sheetTalk || sheetBusy) return;

    setSheetBusy(true);
    setSheetError('');

    try {
      const dataUrl = await takePhoto();

      if (!dataUrl) return;

      const file = dataUrlToImageFile(
        dataUrl,
        `asistencia-${sheetTalk.talk_id}-${Date.now()}`,
      );

      setSheetBusy(false);
      prepareAttendancePreview(sheetTalk, file);
    } catch {
      setSheetError(
        'No fue posible obtener la fotografía.',
      );
    } finally {
      setSheetBusy(false);
    }
  };

  const handleAttendanceGallery = async () => {
    if (!sheetTalk || sheetBusy) return;

    if (!Capacitor.isNativePlatform()) {
      sheetFileInputRef.current?.click();
      return;
    }

    setSheetBusy(true);
    setSheetError('');

    try {
      const dataUrl = await pickFromGallery();

      if (!dataUrl) return;

      const file = dataUrlToImageFile(
        dataUrl,
        `asistencia-${sheetTalk.talk_id}-${Date.now()}`,
      );

      setSheetBusy(false);
      prepareAttendancePreview(sheetTalk, file);
    } catch {
      setSheetError(
        'No fue posible seleccionar la fotografía.',
      );
    } finally {
      setSheetBusy(false);
    }
  };

  const handleAttendanceBrowserFile = async (
    event: React.ChangeEvent<HTMLInputElement>,
  ) => {
    const file = event.target.files?.[0];

    event.target.value = '';

    if (!file || !sheetTalk) return;

    prepareAttendancePreview(sheetTalk, file);
  };

  const openAttendanceSheet = async (
    record: Attendance,
  ) => {
    setSheetError('');

    try {
      if (record.file_url) {
        setViewingSheet({
          title: record.topic || 'Hoja de asistencia',
          url: record.file_url,
        });
        return;
      }

      const blob = await fetchAttendanceSheetBlob(
        TALKS_API,
        record.attendance_id,
      );
      const url = URL.createObjectURL(blob);

      if (sheetObjectUrlRef.current) {
        URL.revokeObjectURL(sheetObjectUrlRef.current);
      }

      sheetObjectUrlRef.current = url;

      setViewingSheet({
        title: record.topic || 'Hoja de asistencia',
        url,
      });
    } catch (error) {
      setSheetError(
        error instanceof Error
          ? error.message
          : 'No se pudo abrir la hoja de asistencia.',
      );
    }
  };


  // Obtener los trabajadores seleccionados a partir
  // de sus identificadores internos.
  const selectedManualUsers = attSelectedIds
    .map(id => attendanceUsers.find(user => user.id === id))
    .filter(
      (user): user is AttendanceWorker =>
        user !== undefined
    );

  // Utilizar la búsqueda compartida.
  // Los IDs seleccionados quedan excluidos.
  const filteredUsers = filterAttendanceWorkers(
    attendanceUsers,
    attSearch,
    attSelectedIds
  );

  // El endpoint manual actual envía nombres.
  // Bloquear registros cuyo nombre completo no sea
  // suficiente para identificar a una sola persona.
  const hasAmbiguousManualNames =
    selectedManualUsers.some(selected =>
      attendanceUsers.some(
        user =>
          user.id !== selected.id &&
          normalizeAttendanceSearch(user.name) ===
          normalizeAttendanceSearch(selected.name)
      )
    );

  const canSubmitManualAttendance =
    Boolean(attTopic && attDate) &&
    attSelectedIds.length > 0 &&
    selectedManualUsers.length === attSelectedIds.length &&
    !hasAmbiguousManualNames &&
    selectedManualUsers.every(user =>
      isWorkerDistinguishable(user, users)
    );

  // Registro manual mediante contrato existente.
  const handleSubmitAttendance = async () => {
    if (!canSubmitManualAttendance) return;

    const fd = new FormData();

    fd.append('topic', attTopic);
    fd.append('date', attDate);
    fd.append('area', attArea);

    // Compatibilidad temporal con el backend actual.
    fd.append(
      'attendees',
      selectedManualUsers
        .map(user => user.name)
        .join(',')
    );

    fd.append('feedback', attFeedback);

    const response = await authenticatedFetch(
      TALKS_API + '/v1/attendance',
      {
        method: 'POST',
        headers,
        body: fd,
      }
    );

    if (!response.ok) {
      throw new Error(
        'No se pudo registrar la asistencia.'
      );
    }

    setShowAttForm(false);
    setAttTopic('');
    setAttSelectedIds([]);
    setAttSearch('');
    setAttFeedback('');

    await fetchAttendance();
  };



  const selectedMonthStat = monthlyStats.find(
    stat =>
      stat.year === year &&
      Number(stat.month) === Number(month)
  );

  const selectedMonthName =
    MONTHS[Number(month) - 1] || month;

  const monthlyChartData = monthlyStats.map(
    stat => ({
      ...stat,
      monthLabel:
        MONTHS[Number(stat.month) - 1]?.slice(0, 3) ||
        stat.month,
    })
  );

  return (
    <motion.div initial={{ x: 300, opacity: 0 }} animate={{ x: 0, opacity: 1 }} exit={{ x: 300, opacity: 0 }} className="min-h-screen pb-20">
      <div className="p-4">
        <div className="flex items-center gap-3 mb-4">
          <button onClick={onBack} className="p-2 themed-card rounded-lg"><ChevronLeft size={20} /></button>
          <h1 className="text-xl font-bold">Dialogos de Seguridad</h1>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-4">
          <button onClick={() => setTab('talks')} className={"flex-1 py-2 rounded-lg text-sm font-medium " + (tab === 'talks' ? 'bg-[#00E5FF] text-[#0B1E36]' : 'themed-card border')}>
            Charlas
          </button>
          {isManager && (
            <button onClick={() => setTab('attendance')} className={"flex-1 py-2 rounded-lg text-sm font-medium " + (tab === 'attendance' ? 'bg-[#00E5FF] text-[#0B1E36]' : 'themed-card border')}>
              Asistencia
            </button>
          )}
        </div>

        {tab === 'talks' && (
          <>
            <div className="flex gap-2 mb-4">
              <select value={month} onChange={e => setMonth(e.target.value)} className="flex-1 px-3 py-2 themed-card border rounded-lg text-sm">
                {MONTHS.map((m, i) => <option key={i} value={String(i + 1)}>{m}</option>)}
              </select>
              <select value={year} onChange={e => setYear(e.target.value)} className="px-3 py-2 themed-card border rounded-lg text-sm">
                {[2025, 2026, 2027].map(y => <option key={y} value={String(y)}>{y}</option>)}
              </select>
            </div>
            {downloadError && <p role="alert" className="mb-3 text-sm text-red-400">{downloadError}</p>}
            {loading ? <p className="text-center themed-text-secondary py-8">Cargando...</p> : talks.length === 0 ? (
              <p className="text-center themed-text-secondary py-8">No hay charlas para este periodo</p>
            ) : (
              <div className="space-y-2">
                {talks.map(talk => (
                  <div key={talk.talk_id} className="themed-card border rounded-xl p-4 flex items-center justify-between">
                    <div className="flex-1">
                      <p className="font-medium text-sm">{talk.title}</p>
                      <p className="text-xs themed-text-secondary">{talk.file_name || 'Sin archivo'}</p>
                    </div>
                    {/* --- INICIO: ACCION DE ESCANEO QR DE ASISTENCIA --- */}
                    <div className="flex items-center gap-2">
                      {(talk.file_id || talk.file_url) && (
                        <button type="button" onClick={() => downloadTalk(talk)} disabled={downloadingId === talk.talk_id} aria-label={'Descargar archivo de ' + talk.title} className="p-2 bg-[#00E5FF]/20 text-[#00E5FF] rounded-lg disabled:opacity-50">
                          <Download size={18} />
                        </button>
                      )}
                      {isManager && (() => {
                        const sheet = getAttendanceSheet(talk.talk_id);

                        return sheet ? (
                          <button
                            type="button"
                            onClick={() => void openAttendanceSheet(sheet)}
                            aria-label={'Ver hoja de asistencia de ' + talk.title}
                            title="Ver hoja de asistencia"
                            className="p-2 bg-[#4CAF50]/20 text-[#4CAF50] rounded-lg"
                          >
                            <ImageIcon size={18} />
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={() => {
                              setSheetError('');
                              setSheetTalk(talk);
                            }}
                            aria-label={'Adjuntar hoja de asistencia a ' + talk.title}
                            title="Adjuntar hoja de asistencia"
                            className="p-2 bg-[#00E5FF]/20 text-[#00E5FF] rounded-lg"
                          >
                            <Camera size={18} />
                          </button>
                        );
                      })()}
                      {isManager && talk.mandatory && (
                        <button
                          type="button"
                          onClick={() => openAbsentWorkers(talk)}
                          aria-label={'Ver trabajadores ausentes de ' + talk.title}
                          title="Ver trabajadores ausentes"
                          className="p-2 bg-[#FF9800]/20 text-[#FF9800] rounded-lg"
                        >
                          <Users size={18} />
                        </button>
                      )}
                      {canDisplayQr ? (
                        <button type="button" onClick={() => openDisplayQr(talk)} aria-label={'Ver QR de ' + talk.title} className="p-2 bg-[#00E5FF] text-[#0B1E36] rounded-lg">
                          QR
                        </button>
                      ) : hasEnteredTalk(talk.talk_id) ? (
                        <span className="px-3 py-2 text-sm font-medium text-[#00E5FF]">Ingresado</span>
                      ) : (
                        <button type="button" onClick={() => openQrScanner(talk)} aria-label={'Escanear QR para registrar asistencia en ' + talk.title} className="p-2 bg-[#00E5FF] text-[#0B1E36] rounded-lg">
                          <ScanLine size={18} />
                        </button>
                      )}
                    </div>
                    {/* --- FIN: ACCION DE ESCANEO QR DE ASISTENCIA --- */}
                  </div>
                ))}
              </div>
            )}
          </>
        )}

        {tab === 'attendance' && isManager && (
          <>
            <div className="themed-card border rounded-xl p-4 mb-4">
              <div className="mb-3">
                <p className="font-medium text-sm">
                  Período del reporte
                </p>
                <p className="text-xs themed-text-secondary">
                  Selecciona el mes y año para consultar y exportar la asistencia.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <select
                  value={month}
                  onChange={event => setMonth(event.target.value)}
                  className="w-full px-3 py-2 themed-card border rounded-lg text-sm"
                  aria-label="Mes de asistencia"
                >
                  {MONTHS.map((label, index) => (
                    <option
                      key={label}
                      value={String(index + 1)}
                    >
                      {label}
                    </option>
                  ))}
                </select>

                <select
                  value={year}
                  onChange={event => setYear(event.target.value)}
                  className="w-full px-3 py-2 themed-card border rounded-lg text-sm"
                  aria-label="Año de asistencia"
                >
                  {[2025, 2026, 2027].map(value => (
                    <option
                      key={value}
                      value={String(value)}
                    >
                      {value}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2 mt-3">
                <button
                  type="button"
                  onClick={() => downloadAttendanceExport('pdf')}
                  disabled={exportingFormat !== null}
                  className="py-2 px-3 bg-[#00E5FF]/20 text-[#00E5FF] rounded-lg text-sm font-medium disabled:opacity-50"
                >
                  {exportingFormat === 'pdf'
                    ? 'Generando PDF...'
                    : 'Descargar PDF'}
                </button>

                <button
                  type="button"
                  onClick={() => downloadAttendanceExport('xlsx')}
                  disabled={exportingFormat !== null}
                  className="py-2 px-3 bg-[#00E5FF]/20 text-[#00E5FF] rounded-lg text-sm font-medium disabled:opacity-50"
                >
                  {exportingFormat === 'xlsx'
                    ? 'Generando Excel...'
                    : 'Descargar Excel'}
                </button>
              </div>

              {exportError && (
                <p
                  role="alert"
                  className="text-sm text-red-400 mt-3"
                >
                  {exportError}
                </p>
              )}
            </div>

            <div className="space-y-4 mb-4">
              <div className="grid grid-cols-2 gap-2">
                <AttendancePeriodSummary
                  monthName={selectedMonthName}
                  year={year}
                  stat={selectedMonthStat}
                  loading={statsLoading}
                  error={Boolean(statsError)}
                />

                <div className="themed-card border rounded-xl p-4">
                  <p className="text-xs themed-text-secondary">
                    Año consultado
                  </p>
                  <p className="text-2xl font-bold mt-1">
                    {year}
                  </p>
                  <p className="text-xs themed-text-secondary mt-1">
                    {monthlyStats.length} meses con registros
                  </p>
                </div>
              </div>

              {statsError && (
                <p
                  role="alert"
                  className="themed-card border rounded-xl p-3 text-sm text-red-400"
                >
                  {statsError}
                </p>
              )}

              {statsLoading ? (
                <div className="themed-card border rounded-xl p-4">
                  <p
                    role="status"
                    className="text-sm themed-text-secondary text-center"
                  >
                    Cargando estadísticas...
                  </p>
                </div>
              ) : (
                <>
                  {areaStats.length > 0 && (
                    <div className="themed-card border rounded-xl p-4">
                      <div className="mb-4">
                        <p className="font-medium text-sm">
                          Cobertura por área
                        </p>
                        <p className="text-xs themed-text-secondary">
                          Cobertura acumulada de trabajadores con asistencia identificada
                        </p>
                      </div>

                      <div className="space-y-4">
                        {areaStats.map(stat => (
                          <div key={stat.area}>
                            <div className="flex items-center justify-between gap-3 mb-1">
                              <span className="text-sm truncate">
                                {stat.area}
                              </span>
                              <span className="text-sm font-medium text-[#00E5FF]">
                                {stat.attendance_percentage}%
                              </span>
                            </div>

                            <div className="h-2 rounded-full bg-white/10 overflow-hidden">
                              <div
                                className="h-full rounded-full bg-[#00E5FF]"
                                style={{
                                  width: `${stat.attendance_percentage}%`,
                                }}
                              />
                            </div>

                            <p className="text-xs themed-text-secondary mt-1">
                              {stat.attendance_count} de {stat.active_workers} trabajadores
                            </p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {monthlyChartData.length === 0 && !statsError && (
                    <div className="themed-card border rounded-xl p-4">
                      <p
                        role="status"
                        className="text-sm themed-text-secondary text-center"
                      >
                        No hay registros de asistencia para el año {year}.
                      </p>
                    </div>
                  )}

                  {monthlyChartData.length > 0 && (
                    <div className="themed-card border rounded-xl p-4">
                      <div className="mb-4">
                        <p className="font-medium text-sm">
                          Cobertura mensual
                        </p>
                        <p className="text-xs themed-text-secondary">
                          Porcentaje de trabajadores con asistencia por mes durante {year}
                        </p>
                      </div>

                      <div className="h-52 w-full">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart
                            data={monthlyChartData}
                            margin={{
                              top: 8,
                              right: 4,
                              left: -12,
                              bottom: 0,
                            }}
                          >
                            <XAxis
                              dataKey="monthLabel"
                              tickLine={false}
                              axisLine={false}
                              fontSize={11}
                            />
                            <YAxis
                              domain={[0, 100]}
                              tickLine={false}
                              axisLine={false}
                              width={44}
                              fontSize={11}
                              tickFormatter={value => `${value}%`}
                            />
                            <Tooltip
                              formatter={value => [
                                `${Number(value).toFixed(2)}%`,
                                'Cobertura',
                              ]}
                              contentStyle={{
                                backgroundColor: '#0B1E36',
                                border: '1px solid rgba(255,255,255,0.15)',
                                borderRadius: '8px',
                              }}
                              labelStyle={{
                                color: '#ffffff',
                              }}
                            />
                            <Bar
                              dataKey="attendance_percentage"
                              name="Cobertura"
                              fill="#00E5FF"
                              radius={[4, 4, 0, 0]}
                            />
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>

            <button onClick={() => setShowAttForm(true)} className="w-full py-3 bg-[#00E5FF]/20 text-[#00E5FF] rounded-xl text-sm font-medium mb-4 flex items-center justify-center gap-2">
              <Plus size={18} /> Registrar asistencia
            </button>
            {attendance.length === 0 ? (
              <p className="text-center themed-text-secondary py-8">No hay registros de asistencia</p>
            ) : (
              <div className="space-y-2">
                {attendance.map(att => (
                  <div key={att.attendance_id} className="themed-card border rounded-xl p-4">
                    <div className="flex justify-between items-start mb-2">
                      <p className="font-medium text-sm">{att.topic}</p>
                      <span className="text-xs bg-[#00E5FF]/20 text-[#00E5FF] px-2 py-0.5 rounded">{att.attendees?.length || 0}</span>
                    </div>
                    <p className="text-xs themed-text-secondary">{new Date(att.date).toLocaleDateString('es-CL')} | {att.area || 'Todas'}</p>
                    {att.attendees?.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-2">
                        {att.attendees.map((n, i) => <span key={i} className="text-xs themed-card px-2 py-0.5 rounded-full border">{n}</span>)}
                      </div>
                    )}
                    {att.feedback && <p className="text-xs themed-text-secondary mt-2 italic">{att.feedback}</p>}
                  </div>
                ))}
              </div>
            )}
          </>
        )}
      </div>

      {/* Modal registrar asistencia */}
      <AnimatePresence>
        <input
          ref={sheetFileInputRef}
          type="file"
          accept="image/jpeg,image/png,image/webp"
          className="hidden"
          onChange={event => void handleAttendanceBrowserFile(event)}
        />

        <AnimatePresence>
          {sheetTalk && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 themed-modal-backdrop z-50 flex items-end justify-center"
              onClick={() => {
                if (!sheetBusy) {
                  setSheetTalk(null);
                  setSheetError('');
                }
              }}
            >
              <motion.div
                initial={{ y: 80 }}
                animate={{ y: 0 }}
                exit={{ y: 80 }}
                className="themed-card w-full max-w-lg rounded-t-2xl p-5"
                onClick={event => event.stopPropagation()}
              >
                <div className="flex items-center justify-between gap-3 mb-4">
                  <div className="min-w-0">
                    <h2 className="font-bold">
                      Hoja de asistencia
                    </h2>
                    <p className="text-sm themed-text-secondary truncate">
                      {sheetTalk.title}
                    </p>
                  </div>

                  <button
                    type="button"
                    disabled={sheetBusy}
                    onClick={() => {
                      setSheetTalk(null);
                      setSheetError('');
                    }}
                    className="p-2 themed-btn-inactive rounded-lg disabled:opacity-50"
                    aria-label="Cerrar"
                  >
                    <X size={20} />
                  </button>
                </div>

                {sheetError && (
                  <p
                    role="alert"
                    className="mb-4 text-sm text-red-400"
                  >
                    {sheetError}
                  </p>
                )}

                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => void handleAttendanceCamera()}
                    disabled={sheetBusy}
                    className="py-3 px-3 bg-[#00E5FF] text-[#0B1E36] rounded-xl font-medium flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {sheetBusy
                      ? <Loader2 size={18} className="animate-spin" />
                      : <Camera size={18} />}
                    Cámara
                  </button>

                  <button
                    type="button"
                    onClick={() => void handleAttendanceGallery()}
                    disabled={sheetBusy}
                    className="py-3 px-3 themed-btn-inactive border rounded-xl font-medium flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    <ImageIcon size={18} />
                    Galería
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}


          {previewSheet && (
            <AttendanceImagePreview
              file={previewSheet.file}
              talkTitle={previewSheet.talk.title}
              recognizedWorkers={ocrWorkers}
              registeredWorkers={attendanceUsers}
              processing={ocrProcessing}
              processingError={ocrError}
              onClose={() => setPreviewSheet(null)}
            />
          )}


          {viewingSheet && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 themed-modal-backdrop z-50 flex items-center justify-center p-4"
              onClick={closeAttendanceSheetViewer}
            >
              <motion.div
                initial={{ scale: 0.96 }}
                animate={{ scale: 1 }}
                exit={{ scale: 0.96 }}
                className="themed-card w-full max-w-2xl rounded-2xl p-4"
                onClick={event => event.stopPropagation()}
              >
                <div className="flex items-center justify-between gap-3 mb-3">
                  <h2 className="font-bold truncate">
                    {viewingSheet.title}
                  </h2>

                  <button
                    type="button"
                    onClick={closeAttendanceSheetViewer}
                    className="p-2 themed-btn-inactive rounded-lg"
                    aria-label="Cerrar hoja de asistencia"
                  >
                    <X size={20} />
                  </button>
                </div>

                <img
                  src={viewingSheet.url}
                  alt="Hoja de asistencia"
                  className="w-full max-h-[70vh] object-contain rounded-xl"
                />
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {showAttForm && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 z-50 flex items-end" onClick={() => setShowAttForm(false)}>
            <motion.div initial={{ y: 300 }} animate={{ y: 0 }} exit={{ y: 300 }}
              className="w-full max-h-[85vh] overflow-y-auto themed-card rounded-t-2xl p-5" onClick={e => e.stopPropagation()}>
              <div className="flex justify-between items-center mb-4">
                <h3 className="font-bold text-lg">Registrar asistencia</h3>
                <button onClick={() => setShowAttForm(false)}><X size={20} /></button>
              </div>
              <div className="space-y-3">
                <select value={attTopic} onChange={e => setAttTopic(e.target.value)} className="w-full px-3 py-2 themed-card border rounded-lg text-sm">
                  <option value="">Seleccionar charla...</option>
                  {talks.map(t => <option key={t.talk_id} value={t.title}>{t.title}</option>)}
                </select>
                <div className="grid grid-cols-2 gap-2">
                  <input type="date" value={attDate} onChange={e => setAttDate(e.target.value)} className="px-3 py-2 themed-card border rounded-lg text-sm" />
                  <input value={attArea} onChange={e => setAttArea(e.target.value)} placeholder="Area" className="px-3 py-2 themed-card border rounded-lg text-sm" />
                </div>

                {/* Búsqueda y selección de trabajadores */}
                <div className="space-y-2">
                  <p className="text-xs themed-text-secondary">
                    Asistentes ({attSelectedIds.length})
                  </p>

                  {/* Campo de búsqueda */}
                  <input
                    type="search"
                    value={attSearch}
                    onChange={event =>
                      setAttSearch(event.target.value)
                    }
                    placeholder="Buscar por nombre, apellido o correo..."
                    className="w-full px-3 py-2 themed-card border rounded-lg text-sm"
                  />

                  {/* Resultados disponibles */}
                  {attSearch.trim() && (
                    <div className="themed-card border rounded-lg max-h-40 overflow-y-auto">
                      {filteredUsers.length > 0 ? (
                        filteredUsers.map(user => {
                          const selectable = isWorkerDistinguishable(
                            user,
                            users
                          );

                          return (
                            <button
                              key={user.id}
                              type="button"
                              disabled={!selectable}
                              onClick={() => {
                                setAttSelectedIds(current =>
                                  current.includes(user.id)
                                    ? current
                                    : [...current, user.id]
                                );

                                setAttSearch('');
                              }}
                              className="w-full text-left px-3 py-2 border-b last:border-0 hover:bg-white/5 disabled:opacity-40"
                            >
                              {/* Nombre completo */}
                              <span className="block text-sm font-medium">
                                {user.name}
                              </span>

                              {/* Correo en tamaño menor */}
                              <span className="block text-xs themed-text-secondary mt-0.5 break-all">
                                {user.email || 'Correo no disponible'}
                              </span>

                              {!selectable && (
                                <span className="block text-xs text-amber-400 mt-1">
                                  Identidad ambigua: requiere revisión
                                </span>
                              )}
                            </button>
                          );
                        })
                      ) : (
                        <p className="p-3 text-xs themed-text-secondary">
                          No se encontraron trabajadores.
                        </p>
                      )}
                    </div>
                  )}

                  {/* Trabajadores ya seleccionados */}
                  {selectedManualUsers.length > 0 && (
                    <div className="space-y-2">
                      {selectedManualUsers.map(user => (
                        <div
                          key={user.id}
                          className="flex items-center gap-2 themed-card border rounded-lg p-2"
                        >
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium">
                              {user.name}
                            </p>

                            <p className="text-xs themed-text-secondary break-all">
                              {user.email || 'Correo no disponible'}
                            </p>
                          </div>

                          {/* Quitar trabajador por ID */}
                          <button
                            type="button"
                            aria-label={`Quitar ${user.name}`}
                            onClick={() =>
                              setAttSelectedIds(current =>
                                current.filter(id => id !== user.id)
                              )
                            }
                            className="p-2 themed-btn-inactive rounded-lg"
                          >
                            <X size={16} />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Advertencia de registros ambiguos */}
                  {hasAmbiguousManualNames && (
                    <p
                      role="alert"
                      className="text-xs text-amber-400"
                    >
                      Existen trabajadores con el mismo nombre
                      completo. Se distinguen por correo e ID,
                      pero el registro definitivo requiere
                      soporte de identificadores en la API.
                    </p>
                  )}
                </div>

                <textarea value={attFeedback} onChange={e => setAttFeedback(e.target.value)} rows={2} placeholder="Retroalimentacion..." className="w-full px-3 py-2 themed-card border rounded-lg text-sm resize-none" />
                <button onClick={handleSubmitAttendance} disabled={!attTopic || !attDate}
                  className="w-full py-3 bg-[#00E5FF] text-[#0B1E36] rounded-xl font-medium disabled:opacity-50">
                  Registrar
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* --- INICIO: LISTADO DE TRABAJADORES AUSENTES --- */}
      {absentTalk && (
        <div
          className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4"
          onClick={closeAbsentWorkers}
        >
          <div
            role="dialog"
            aria-modal="true"
            aria-label={'Trabajadores ausentes de ' + absentTalk.title}
            className="w-full max-w-sm max-h-[80vh] overflow-y-auto themed-card rounded-2xl p-5"
            onClick={event => event.stopPropagation()}
          >
            <div className="flex items-start justify-between gap-3 mb-4">
              <div>
                <h3 className="font-bold text-lg">
                  Trabajadores ausentes
                </h3>
                <p className="text-xs themed-text-secondary mt-1">
                  {absentTalk.title}
                </p>
              </div>

              <button
                type="button"
                onClick={closeAbsentWorkers}
                aria-label="Cerrar listado de trabajadores ausentes"
              >
                <X size={20} />
              </button>
            </div>

            {absentWorkersLoading && (
              <p
                role="status"
                className="text-sm themed-text-secondary text-center py-6"
              >
                Cargando trabajadores ausentes...
              </p>
            )}

            {absentWorkersError && (
              <p
                role="alert"
                className="text-sm text-red-400 themed-card border rounded-xl p-3"
              >
                {absentWorkersError}
              </p>
            )}

            {!absentWorkersLoading &&
              !absentWorkersError &&
              absentResult && (
                <div>
                  {absentResult.absence_status ===
                    'absences_found' ? (
                    <>
                      <p className="text-sm themed-text-secondary mb-3">
                        {absentResult.absent_workers.length}{' '}
                        trabajadores sin asistencia
                      </p>

                      <div className="space-y-2">
                        {absentResult.absent_workers.map(
                          (worker: AbsentWorker) => (
                            <div
                              key={worker.user_id}
                              className="themed-card border rounded-xl p-3"
                            >
                              <p className="text-sm font-medium">
                                {getAbsentWorkerDisplayName(worker)}
                              </p>

                              {worker.email && (
                                <p className="text-xs themed-text-secondary mt-1">
                                  {worker.email}
                                </p>
                              )}
                            </div>
                          ),
                        )}
                      </div>
                    </>
                  ) : (
                    <p
                      role="status"
                      className="themed-card border rounded-xl p-4 text-sm themed-text-secondary text-center"
                    >
                      {getAbsenceStatusMessage(
                        absentResult,
                      )}
                    </p>
                  )}
                </div>
              )}

            <button
              type="button"
              onClick={closeAbsentWorkers}
              className="w-full mt-4 py-3 themed-card border rounded-xl text-sm font-medium"
            >
              Cerrar
            </button>
          </div>
        </div>
      )}
      {/* --- FIN: LISTADO DE TRABAJADORES AUSENTES --- */}

      {/* --- INICIO: VENTANA DE ESCANEO QR DE ASISTENCIA --- */}
      {/* --- INICIO: VENTANA DE VISUALIZACION QR --- */}
      {displayQr && (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4" onClick={closeDisplayQr}>
          <div role="dialog" aria-modal="true" aria-label="QR de asistencia" className="w-full max-w-sm themed-card rounded-2xl p-5" onClick={event => event.stopPropagation()}>
            <h3 className="font-bold text-lg mb-4">{displayQr.title}</h3>
            {displayQrError ? <p role="alert">{displayQrError}</p> : displayQr.image ? <img src={displayQr.image} alt={'QR de asistencia de ' + displayQr.title} className="w-full bg-white" /> : <p role="status">Cargando QR...</p>}
            <button type="button" autoFocus onClick={closeDisplayQr} className="w-full mt-4 py-3 themed-card border rounded-xl">Cerrar</button>
          </div>
        </div>
      )}
      {/* --- FIN: VENTANA DE VISUALIZACION QR --- */}
      <AnimatePresence>
        {showQrScanner && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-black/70 z-50 flex items-end" onClick={closeQrScanner}>
            <motion.div initial={{ y: 300 }} animate={{ y: 0 }} exit={{ y: 300 }} className="w-full themed-card rounded-t-2xl p-5" onClick={event => event.stopPropagation()}>
              <div className="flex justify-between items-center mb-4">
                <div>
                  <h3 className="font-bold text-lg">Escanear código QR</h3>
                  <p className="text-xs themed-text-secondary">{qrTalk?.title}</p>
                </div>
                <button type="button" onClick={closeQrScanner} aria-label="Cerrar escáner QR"><X size={20} /></button>
              </div>
              {!qrMessage && <video ref={scannerVideoRef} className="w-full aspect-square rounded-xl bg-black object-cover" muted playsInline />}
              {qrMessage && <p role="status" className="themed-card border rounded-xl p-4 text-sm text-center">{qrMessage}</p>}
              <button type="button" onClick={closeQrScanner} className="w-full mt-4 py-3 themed-card border rounded-xl text-sm font-medium">Cerrar</button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
      {/* --- FIN: VENTANA DE ESCANEO QR DE ASISTENCIA --- */}
    </motion.div>
  );
}