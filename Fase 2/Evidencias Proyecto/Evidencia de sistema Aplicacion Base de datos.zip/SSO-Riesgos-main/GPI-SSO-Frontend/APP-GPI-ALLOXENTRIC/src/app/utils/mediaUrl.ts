const LOCAL_EVIDENCE_HOSTS = new Set([
  'localhost',
  '127.0.0.1',
  '0.0.0.0',
  '::1',
]);

const LOCAL_EVIDENCE_PREFIXES = [
  '/local-evidence/',
  '/local-report-evidence/',
];

function isLocalEvidencePath(
  pathname: string,
): boolean {
  return LOCAL_EVIDENCE_PREFIXES.some(
    prefix => pathname.startsWith(prefix),
  );
}

export function resolveLocalEvidenceUrl(
  mediaUrl: string,
  apiUrl?: string,
): string {
  if (!apiUrl) {
    return mediaUrl;
  }

  try {
    const apiOrigin = new URL(apiUrl).origin;

    if (isLocalEvidencePath(mediaUrl)) {
      return `${apiOrigin}${mediaUrl}`;
    }

    const parsedMediaUrl = new URL(mediaUrl);

    if (
      LOCAL_EVIDENCE_HOSTS.has(parsedMediaUrl.hostname)
      && isLocalEvidencePath(parsedMediaUrl.pathname)
    ) {
      return (
        `${apiOrigin}${parsedMediaUrl.pathname}`
        + `${parsedMediaUrl.search}${parsedMediaUrl.hash}`
      );
    }

    return mediaUrl;
  } catch {
    return mediaUrl;
  }
}
