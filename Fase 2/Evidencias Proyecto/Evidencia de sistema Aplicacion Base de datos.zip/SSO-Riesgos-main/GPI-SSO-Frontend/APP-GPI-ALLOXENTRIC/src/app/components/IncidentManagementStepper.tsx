import { Fragment } from 'react';
import { Check } from 'lucide-react';

import {
  INCIDENT_MANAGEMENT_STAGES,
  getIncidentManagementStageIndex,
  isIncidentManagementStageAccessible,
  type IncidentManagementStageId,
  type IncidentManagementStageState,
} from '../utils/incidentManagementStages';

interface IncidentManagementStepperProps {
  activeStage: IncidentManagementStageId;
  state: IncidentManagementStageState;
  onStageChange: (
    stage: IncidentManagementStageId,
  ) => void;
}

export default function IncidentManagementStepper({
  activeStage,
  state,
  onStageChange,
}: IncidentManagementStepperProps) {
  const activeIndex =
    getIncidentManagementStageIndex(activeStage);

  const activeDefinition =
    INCIDENT_MANAGEMENT_STAGES[activeIndex]
    ?? INCIDENT_MANAGEMENT_STAGES[0];

  return (
    <div
      className="themed-card border rounded-2xl p-4"
      aria-label="Etapas de gestión del reporte"
    >
      <div className="flex items-center w-full">
        {INCIDENT_MANAGEMENT_STAGES.map(
          (stage, index) => {
            const accessible =
              isIncidentManagementStageAccessible(
                state,
                stage.id,
              );

            const completed =
              index <= state.completedThroughIndex;

            const active =
              stage.id === activeStage;

            return (
              <Fragment key={stage.id}>
                <button
                  type="button"
                  aria-label={`Etapa ${index + 1}: ${stage.label}`}
                  aria-current={
                    active ? 'step' : undefined
                  }
                  title={stage.label}
                  disabled={!accessible}
                  onClick={() => {
                    if (accessible) {
                      onStageChange(stage.id);
                    }
                  }}
                  className={
                    'w-8 h-8 rounded-full '
                    + 'flex items-center justify-center '
                    + 'text-xs font-bold flex-shrink-0 '
                    + 'transition-all disabled:cursor-not-allowed '
                    + (!accessible ? 'opacity-35 ' : '')
                  }
                  style={{
                    background: completed
                      ? '#16A34A'
                      : active
                        ? '#00E5FF'
                        : 'transparent',
                    color:
                      completed || active
                        ? active && !completed
                          ? '#0B1E36'
                          : '#FFFFFF'
                        : 'var(--theme-text)',
                    border: active
                      ? '2px solid #00E5FF'
                      : completed
                        ? '2px solid #16A34A'
                        : '1px solid rgba(126,138,148,0.5)',
                  }}
                >
                  {completed
                    ? <Check size={16} />
                    : index + 1}
                </button>

                {index
                  < INCIDENT_MANAGEMENT_STAGES.length - 1
                  && (
                    <div
                      aria-hidden="true"
                      className="h-0.5 flex-1 mx-1"
                      style={{
                        background:
                          index
                          < state.completedThroughIndex
                            ? '#16A34A'
                            : 'rgba(126,138,148,0.35)',
                      }}
                    />
                  )}
              </Fragment>
            );
          },
        )}
      </div>

      <div className="text-center mt-3">
        <p className="text-xs themed-text-tertiary">
          Etapa {activeIndex + 1} de{' '}
          {INCIDENT_MANAGEMENT_STAGES.length}
        </p>

        <p className="text-sm font-semibold mt-0.5">
          {activeDefinition.label}
        </p>

        {state.readOnly && (
          <p className="text-xs themed-text-secondary mt-1">
            Modo solo lectura
          </p>
        )}
      </div>
    </div>
  );
}
