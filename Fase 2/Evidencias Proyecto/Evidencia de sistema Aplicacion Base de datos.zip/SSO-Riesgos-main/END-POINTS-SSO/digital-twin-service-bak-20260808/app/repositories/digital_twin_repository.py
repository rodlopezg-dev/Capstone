class DigitalTwinRepository:
    def __init__(self, db):
        self.twins = db["digital_twins"]

    async def get_floor_plan(self, client_id):
        doc = await self.twins.find_one({"client_id": client_id, "type": "floor_plan"})
        if doc:
            doc.pop("_id", None)
        return doc

    async def save_floor_plan(self, client_id, plan_data):
        plan_data["client_id"] = client_id
        plan_data["type"] = "floor_plan"
        await self.twins.update_one(
            {"client_id": client_id, "type": "floor_plan"},
            {"$set": plan_data},
            upsert=True
        )
        return True

    async def get_zones(self, client_id):
        results = []
        async for doc in self.twins.find({"client_id": client_id, "type": "zone"}):
            doc.pop("_id", None)
            results.append(doc)
        return results

    async def save_zone(self, client_id, zone_data):
        zone_data["client_id"] = client_id
        zone_data["type"] = "zone"
        zone_id = zone_data.get("zone_id", zone_data.get("name", ""))
        await self.twins.update_one(
            {"client_id": client_id, "type": "zone", "zone_id": zone_id},
            {"$set": zone_data},
            upsert=True
        )
        return True

    async def delete_zone(self, client_id, zone_id):
        await self.twins.delete_one({"client_id": client_id, "type": "zone", "zone_id": zone_id})
