import { describe, expect, it } from 'vitest';

import {
  addDaysToDateInput,
  formatDateInput,
  getDeadlineRange,
  getDaysUntilDeadline,
} from './incidentDeadline';

describe('incident deadline - SCRUM-76', () => {
  const today = new Date(
    2026,
    8,
    14,
    12,
    0,
    0
  );

  it('formats dates for HTML date inputs', () => {
    expect(
      formatDateInput(
        new Date(2026, 8, 14, 12, 0, 0)
      )
    ).toBe('2026-09-14');
  });

  it('adds days to a base date', () => {
    expect(
      addDaysToDateInput(today, 3)
    ).toBe('2026-09-17');

    expect(
      addDaysToDateInput(today, 30)
    ).toBe('2026-10-14');
  });

  it('creates the 3 to 30 day range', () => {
    expect(getDeadlineRange(today)).toEqual({
      min: '2026-09-17',
      max: '2026-10-14',
    });
  });

  it('calculates days remaining', () => {
    expect(
      getDaysUntilDeadline(
        '2026-09-20',
        today
      )
    ).toBe(6);
  });

  it('returns zero for today', () => {
    expect(
      getDaysUntilDeadline(
        '2026-09-14',
        today
      )
    ).toBe(0);
  });

  it('returns null for an empty deadline', () => {
    expect(
      getDaysUntilDeadline('', today)
    ).toBeNull();
  });
});
