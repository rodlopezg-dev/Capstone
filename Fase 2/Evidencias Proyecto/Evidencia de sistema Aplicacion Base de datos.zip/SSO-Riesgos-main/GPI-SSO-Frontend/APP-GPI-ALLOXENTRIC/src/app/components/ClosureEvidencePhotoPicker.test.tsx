import { describe, expect, it } from 'vitest';
import { renderToStaticMarkup } from 'react-dom/server';

import ClosureEvidencePhotoPicker, {
  dataUrlToImageFile,
} from './ClosureEvidencePhotoPicker';

describe('ClosureEvidencePhotoPicker - SCRUM-83', () => {
  it('renders camera and gallery actions', () => {
    const html = renderToStaticMarkup(
      <ClosureEvidencePhotoPicker
        file={null}
        onChange={() => undefined}
      />
    );

    expect(html).toContain('Tomar foto');
    expect(html).toContain('Elegir foto');
  });

  it('accepts supported image formats', () => {
    const html = renderToStaticMarkup(
      <ClosureEvidencePhotoPicker
        file={null}
        onChange={() => undefined}
      />
    );

    expect(html).toContain(
      'accept="image/jpeg,image/png,image/webp"'
    );
  });

  it('converts JPEG data URL to File', () => {
    const file = dataUrlToImageFile(
      'data:image/jpeg;base64,AAECAw==',
      'captura',
    );

    expect(file.name).toBe('captura.jpg');
    expect(file.type).toBe('image/jpeg');
    expect(file.size).toBe(4);
  });

  it('rejects unsupported data URLs', () => {
    expect(() =>
      dataUrlToImageFile(
        'data:application/pdf;base64,AA==',
      )
    ).toThrow('Formato de imagen no soportado');
  });

  it('can disable photo actions', () => {
    const html = renderToStaticMarkup(
      <ClosureEvidencePhotoPicker
        file={null}
        onChange={() => undefined}
        disabled
      />
    );

    expect(
      (html.match(/disabled/g) || []).length
    ).toBeGreaterThanOrEqual(2);
  });
});
