import { describe, expect, it } from 'vitest';
import {
  buildLocalNotificationStorageKey,
  parseLocalNotificationState,
  reconcileLocalNotificationState,
  type LocalNotificationItem,
} from './localNotificationState';

const item = (
  id: string,
  enabled = true,
): LocalNotificationItem => ({
  id,
  title: `Notificación ${id}`,
  description: `Descripción ${id}`,
  enabled,
});

describe('localNotificationState - SCRUM-130', () => {
  it('separa la persistencia por cliente y usuario', () => {
    expect(
      buildLocalNotificationStorageKey('cliente_a', 'usuario_1', 'reports'),
    ).not.toBe(
      buildLocalNotificationStorageKey('cliente_a', 'usuario_2', 'reports'),
    );

    expect(
      buildLocalNotificationStorageKey('cliente_a', 'usuario_1', 'reports'),
    ).not.toBe(
      buildLocalNotificationStorageKey('cliente_b', 'usuario_1', 'reports'),
    );
  });

  it('separa la persistencia de reportes y alertas', () => {
    expect(
      buildLocalNotificationStorageKey(
        'cliente_a',
        'usuario_1',
        'reports',
      ),
    ).not.toBe(
      buildLocalNotificationStorageKey(
        'cliente_a',
        'usuario_1',
        'alerts',
      ),
    );
  });

  it('toma la primera carga histórica como baseline sin notificar', () => {
    const result = reconcileLocalNotificationState(
      null,
      [item('notif_1'), item('notif_2')],
    );

    expect(result.newItems).toEqual([]);
    expect(result.nextState.initialized).toBe(true);
    expect(result.nextState.seenIds).toEqual([
      'notif_1',
      'notif_2',
    ]);
  });

  it('permite un baseline inicial vacío', () => {
    const baseline = reconcileLocalNotificationState(
      null,
      [],
    );

    expect(baseline.newItems).toEqual([]);
    expect(baseline.nextState.seenIds).toEqual([]);

    const next = reconcileLocalNotificationState(
      baseline.nextState,
      [item('notif_1')],
    );

    expect(next.newItems.map(i => i.id)).toEqual([
      'notif_1',
    ]);
  });

  it('no vuelve a emitir IDs ya procesados', () => {
    const state = {
      initialized: true as const,
      seenIds: ['notif_1'],
    };

    const result = reconcileLocalNotificationState(
      state,
      [item('notif_1')],
    );

    expect(result.newItems).toEqual([]);
  });

  it('detecta únicamente IDs nuevos después del baseline', () => {
    const state = {
      initialized: true as const,
      seenIds: ['notif_1', 'notif_2'],
    };

    const result = reconcileLocalNotificationState(
      state,
      [
        item('notif_3'),
        item('notif_2'),
        item('notif_1'),
      ],
    );

    expect(result.newItems.map(i => i.id)).toEqual([
      'notif_3',
    ]);

    expect(result.nextState.seenIds).toContain('notif_1');
    expect(result.nextState.seenIds).toContain('notif_2');
    expect(result.nextState.seenIds).toContain('notif_3');
  });

  it('conserva IDs históricos aunque desaparezcan temporalmente', () => {
    const state = {
      initialized: true as const,
      seenIds: ['notif_1'],
    };

    const withoutItem = reconcileLocalNotificationState(
      state,
      [],
    );

    const returned = reconcileLocalNotificationState(
      withoutItem.nextState,
      [item('notif_1')],
    );

    expect(returned.newItems).toEqual([]);
  });

  it('registra como visto un elemento deshabilitado sin notificarlo', () => {
    const state = {
      initialized: true as const,
      seenIds: [],
    };

    const disabled = reconcileLocalNotificationState(
      state,
      [item('notif_1', false)],
    );

    expect(disabled.newItems).toEqual([]);
    expect(disabled.nextState.seenIds).toContain('notif_1');

    const enabledLater = reconcileLocalNotificationState(
      disabled.nextState,
      [item('notif_1', true)],
    );

    expect(enabledLater.newItems).toEqual([]);
  });

  it('conserva todos los IDs cuando llegan mas de cinco eventos nuevos', () => {
    const state = {
      initialized: true as const,
      seenIds: ['notif_0'],
    };

    const result = reconcileLocalNotificationState(
      state,
      [
        item('notif_1'),
        item('notif_2'),
        item('notif_3'),
        item('notif_4'),
        item('notif_5'),
        item('notif_6'),
      ],
    );

    expect(result.newItems.map(i => i.id)).toEqual([
      'notif_1',
      'notif_2',
      'notif_3',
      'notif_4',
      'notif_5',
      'notif_6',
    ]);

    expect(result.nextState.seenIds).toEqual(
      expect.arrayContaining([
        'notif_0',
        'notif_1',
        'notif_2',
        'notif_3',
        'notif_4',
        'notif_5',
        'notif_6',
      ]),
    );
  });

  it('ignora almacenamiento corrupto', () => {
    expect(
      parseLocalNotificationState('{esto-no-es-json'),
    ).toBeNull();
  });
});
