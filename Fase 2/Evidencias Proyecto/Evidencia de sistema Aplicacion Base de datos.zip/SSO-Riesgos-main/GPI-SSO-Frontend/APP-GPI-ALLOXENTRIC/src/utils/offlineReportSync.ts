import {
  createReportWithPhoto,
  isReportNetworkError,
  type ReportCreatePayload,
} from '../app/api/reports';

import {
  countPendingReports,
  deletePendingReport,
  getPendingReports,
  savePendingReport,
  updatePendingReport,
  type PendingReport,
} from './offlineQueue';

import {
  getNetworkConnected,
} from './networkStatus';

export interface OfflineSyncResult {
  attempted: number;
  synced: number;
  failed: number;
  remaining: number;
}

export interface OfflineSyncDependencies {
  getPendingReports:
    typeof getPendingReports;
  deletePendingReport:
    typeof deletePendingReport;
  updatePendingReport:
    typeof updatePendingReport;
  countPendingReports:
    typeof countPendingReports;
  createReportWithPhoto:
    typeof createReportWithPhoto;
}

const defaultDependencies:
  OfflineSyncDependencies = {
    getPendingReports,
    deletePendingReport,
    updatePendingReport,
    countPendingReports,
    createReportWithPhoto,
  };

const inFlightSyncs = new Map<
  string,
  Promise<OfflineSyncResult>
>();

function ownerKey(
  clientId: string,
  userId: string,
): string {
  return `${clientId}\u0000${userId}`;
}

function errorMessage(error: unknown): string {
  return error instanceof Error
    ? error.message
    : String(error);
}

export function fileToDataUrl(
  file: File,
): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = () => {
      if (typeof reader.result === 'string') {
        resolve(reader.result);
      } else {
        reject(
          new Error(
            'No fue posible serializar la evidencia',
          ),
        );
      }
    };

    reader.onerror = () => {
      reject(
        reader.error
        || new Error(
          'No fue posible leer la evidencia',
        ),
      );
    };

    reader.readAsDataURL(file);
  });
}

export function dataUrlToFile(
  dataUrl: string,
  filename: string,
  contentType?: string | null,
): File {
  const separator = dataUrl.indexOf(',');

  if (separator < 0) {
    throw new Error(
      'Evidencia offline inválida',
    );
  }

  const metadata = dataUrl.slice(
    0,
    separator,
  );
  const encoded = dataUrl.slice(
    separator + 1,
  );

  const base64 =
    metadata.includes(';base64');

  const detectedType =
    /^data:([^;,]+)/.exec(metadata)?.[1];

  const binary = base64
    ? atob(encoded)
    : decodeURIComponent(encoded);

  const bytes = new Uint8Array(
    binary.length,
  );

  for (
    let index = 0;
    index < binary.length;
    index += 1
  ) {
    bytes[index] = binary.charCodeAt(index);
  }

  return new File(
    [bytes],
    filename,
    {
      type:
        contentType
        || detectedType
        || 'application/octet-stream',
    },
  );
}

export interface ReportSubmissionInput {
  clientId: string;
  userId: string;
  payload: ReportCreatePayload;
  photoFile?: File | null;
  shift: string;
  idempotencyKey: string;
}

export type ReportSubmissionResult =
  | {
      status: 'sent';
      reportId: string;
    }
  | {
      status: 'queued';
      pendingCount: number;
    };

export interface OfflineSubmissionDependencies {
  getNetworkConnected:
    () => Promise<boolean>;
  createReportWithPhoto:
    typeof createReportWithPhoto;
  savePendingReport:
    typeof savePendingReport;
  countPendingReports:
    typeof countPendingReports;
  fileToDataUrl:
    (file: File) => Promise<string>;
}

async function queueReportSubmission(
  input: ReportSubmissionInput,
  dependencies:
    OfflineSubmissionDependencies,
): Promise<ReportSubmissionResult> {
  const photoBase64 =
    input.photoFile
      ? await dependencies.fileToDataUrl(
          input.photoFile,
        )
      : null;

  await dependencies.savePendingReport({
    clientId: input.clientId,
    userId: input.userId,
    idempotencyKey:
      input.idempotencyKey,
    payload: input.payload,
    photoBase64,
    photoName:
      input.photoFile?.name ?? null,
    photoType:
      input.photoFile?.type ?? null,
    shift: input.shift,
    createdAt:
      new Date().toISOString(),
    attempts: 0,
  });

  const pendingCount =
    await dependencies.countPendingReports(
      input.clientId,
      input.userId,
    );

  return {
    status: 'queued',
    pendingCount,
  };
}

export async function submitReportWithOfflineFallback(
  input: ReportSubmissionInput,
  dependencies?:
    OfflineSubmissionDependencies,
): Promise<ReportSubmissionResult> {
  const resolved:
    OfflineSubmissionDependencies =
      dependencies ?? {
        getNetworkConnected,
        createReportWithPhoto,
        savePendingReport,
        countPendingReports,
        fileToDataUrl,
      };

  const connected =
    await resolved.getNetworkConnected();

  if (!connected) {
    return queueReportSubmission(
      input,
      resolved,
    );
  }

  try {
    const reportId =
      await resolved.createReportWithPhoto(
        input.payload,
        input.photoFile ?? undefined,
        input.shift,
        input.userId,
        input.idempotencyKey,
      );

    return {
      status: 'sent',
      reportId,
    };
  } catch (error) {
    if (!isReportNetworkError(error)) {
      throw error;
    }

    return queueReportSubmission(
      input,
      resolved,
    );
  }
}


async function runPendingReportSync(
  clientId: string,
  userId: string,
  dependencies:
    OfflineSyncDependencies,
): Promise<OfflineSyncResult> {
  const pending =
    await dependencies.getPendingReports(
      clientId,
      userId,
    );

  let synced = 0;
  let failed = 0;

  for (const item of pending) {
    if (item.localId == null) {
      failed += 1;
      continue;
    }

    try {
      const photoFile =
        item.photoBase64
          ? dataUrlToFile(
              item.photoBase64,
              item.photoName || 'evidencia.jpg',
              item.photoType,
            )
          : undefined;

      await dependencies.createReportWithPhoto(
        item.payload,
        photoFile,
        item.shift,
        userId,
        item.idempotencyKey,
      );

      await dependencies.deletePendingReport(
        item.localId,
      );

      synced += 1;
    } catch (error) {
      failed += 1;

      await dependencies.updatePendingReport(
        item.localId,
        {
          attempts:
            (item.attempts || 0) + 1,
          lastAttemptAt:
            new Date().toISOString(),
          lastError:
            errorMessage(error),
        },
      );
    }
  }

  const remaining =
    await dependencies.countPendingReports(
      clientId,
      userId,
    );

  return {
    attempted: pending.length,
    synced,
    failed,
    remaining,
  };
}

export function syncPendingReports(
  clientId: string,
  userId: string,
  dependencies:
    OfflineSyncDependencies =
      defaultDependencies,
): Promise<OfflineSyncResult> {
  const key = ownerKey(
    clientId,
    userId,
  );

  const existing =
    inFlightSyncs.get(key);

  if (existing) {
    return existing;
  }

  const operation =
    runPendingReportSync(
      clientId,
      userId,
      dependencies,
    );

  inFlightSyncs.set(
    key,
    operation,
  );

  const clearInFlight = () => {
    if (
      inFlightSyncs.get(key)
      === operation
    ) {
      inFlightSyncs.delete(key);
    }
  };

  void operation.then(
    clearInFlight,
    clearInFlight,
  );

  return operation;
}
