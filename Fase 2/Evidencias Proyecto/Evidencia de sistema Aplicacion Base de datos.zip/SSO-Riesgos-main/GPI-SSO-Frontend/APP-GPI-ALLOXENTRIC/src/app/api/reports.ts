import {
  authenticatedFetch,
} from './client';

const REPORTS_API = import.meta.env.VITE_REPORTS_API_URL || 'http://localhost:8102';

export type ReportStatus =
  | 'sent'
  | 'open'
  | 'reviewing'
  | 'assigned'
  | 'en_proceso'
  | 'pending_closure'
  | 'closed';

export interface ReportTimeline {
  sent?: string;
  open?: string;
  reviewing?: string;
  assigned?: string;
  en_proceso?: string;
  pending_closure?: string;
  closed?: string;
}

export interface Report {
  report_id: string;
  area_id: string;
  type: string;
  status: ReportStatus;
  is_iap: boolean;
  description: string;
  created_at: string;
  evidences?: string[];
  timeline?: ReportTimeline;
  feedback?: string;
  reported_by?: string;
  worker_type?: string;
  assigned_to?: string;
  causes?: string[];
  probable_consequence?: string;
  analysis?: string;
}

export interface ReportCreatePayload {
  area_id: string;
  type: string;
  is_iap: boolean;
  description: string;
  causes: string[];
  shift: string;
  worker_type?: string;
  evidences?: string[];
}

export function listenReports(
  clientId: string,
  userId: string,
  onData: (reports: Report[]) => void,
  onError: (err: Error) => void
) {
  const fetchReports = async () => {
    try {
      const res = await authenticatedFetch(
        REPORTS_API + '/v1/reports',
      );
      if (!res.ok) throw new Error('Error ' + res.status);
      const data = await res.json();
      onData(Array.isArray(data) ? (data as Report[]) : []);
    } catch (err) {
      onError(err as Error);
    }
  };
  fetchReports();
  const interval = setInterval(fetchReports, 30000);
  return () => clearInterval(interval);
}

export class ReportNetworkError extends Error {
  constructor(
    message = 'No fue posible conectar con el servicio de reportes',
    options?: ErrorOptions,
  ) {
    super(message, options);
    this.name = 'ReportNetworkError';
  }
}

export class ReportRequestError extends Error {
  readonly status: number;

  constructor(
    status: number,
    message: string,
  ) {
    super(message);
    this.name = 'ReportRequestError';
    this.status = status;
  }
}

export function isReportNetworkError(
  error: unknown,
): error is ReportNetworkError {
  return error instanceof ReportNetworkError;
}

export function createReportIdempotencyKey(): string {
  if (
    typeof globalThis.crypto !== 'undefined'
    && typeof globalThis.crypto.randomUUID === 'function'
  ) {
    return globalThis.crypto.randomUUID();
  }

  return [
    Date.now().toString(36),
    Math.random().toString(36).slice(2),
    Math.random().toString(36).slice(2),
  ].join('-');
}

export const REPORT_CREATE_TIMEOUT_MS = 12_000;

function isAbortError(
  error: unknown,
): boolean {
  return (
    error instanceof Error
    && error.name === 'AbortError'
  );
}

export async function createReportWithPhoto(
  payload: ReportCreatePayload,
  photoFile?: File | null,
  shift?: string,
  userId?: string,
  idempotencyKey?: string,
): Promise<string> {
  const formData = new FormData();

  formData.append('area_id', payload.area_id);
  formData.append('type', payload.type);
  formData.append('is_iap', String(payload.is_iap));
  formData.append('description', payload.description);
  formData.append(
    'shift',
    payload.shift || shift || 'Día',
  );
  formData.append(
    'causes',
    JSON.stringify(payload.causes || []),
  );

  if (payload.worker_type) {
    formData.append(
      'worker_type',
      payload.worker_type,
    );
  }

  if (photoFile) {
    formData.append('file', photoFile);
  }

  const headers = new Headers();

  if (idempotencyKey) {
    headers.set(
      'Idempotency-Key',
      idempotencyKey,
    );
  }

  const controller =
    new AbortController();

  let timeoutId:
    ReturnType<typeof setTimeout>
    | undefined;

  const timeout =
    new Promise<Response>(
      (_resolve, reject) => {
        timeoutId = globalThis.setTimeout(
          () => {
            reject(
              new ReportNetworkError(
                'El envío del reporte superó el tiempo de espera',
              ),
            );

            controller.abort();
          },
          REPORT_CREATE_TIMEOUT_MS,
        );
      },
    );

  let res: Response;

  try {
    const request =
      authenticatedFetch(
        REPORTS_API + '/v1/reports',
        {
          method: 'POST',
          headers,
          body: formData,
          signal: controller.signal,
        },
      );

    res = await Promise.race([
      request,
      timeout,
    ]);
  } catch (error) {
    if (
      error instanceof ReportNetworkError
    ) {
      throw error;
    }

    if (
      error instanceof TypeError
      || isAbortError(error)
    ) {
      throw new ReportNetworkError(
        'No fue posible conectar con el servicio de reportes',
        { cause: error },
      );
    }

    throw error;
  } finally {
    if (timeoutId !== undefined) {
      globalThis.clearTimeout(
        timeoutId,
      );
    }
  }

  if (!res.ok) {
    const err = await res.text();

    throw new ReportRequestError(
      res.status,
      err || 'Error al crear reporte',
    );
  }

  const data = await res.json();
  return data.report_id;
}


export interface ClosureEvidenceUpload {
  url: string;
  filename: string;
  content_type: string;
  size: number;
  uploaded_by: string;
  uploaded_at: string;
}

export async function uploadClosureEvidence(
  reportId: string,
  file: File,
  reportsApi: string = REPORTS_API,
): Promise<ClosureEvidenceUpload> {
  const formData = new FormData();
  formData.append('file', file);

  const res = await authenticatedFetch(
    reportsApi
      + '/v1/reports/'
      + reportId
      + '/closure-evidence/upload',
    {
      method: 'POST',
      body: formData,
    },
  );

  const data = await res
    .json()
    .catch(() => ({}));

  if (!res.ok) {
    throw new Error(
      data.detail
        || 'No fue posible cargar la evidencia',
    );
  }

  return data.evidence_upload as ClosureEvidenceUpload;
}

export async function associateClosureEvidence(
  reportId: string,
  evidence: ClosureEvidenceUpload,
  reportsApi: string = REPORTS_API,
): Promise<ClosureEvidenceUpload> {
  const res = await authenticatedFetch(
    reportsApi
      + '/v1/reports/'
      + reportId
      + '/closure-evidence',
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(evidence),
    },
  );

  const data = await res
    .json()
    .catch(() => ({}));

  if (!res.ok) {
    throw new Error(
      data.detail
        || 'No fue posible asociar la evidencia',
    );
  }

  return data.closure_evidence as ClosureEvidenceUpload;
}
