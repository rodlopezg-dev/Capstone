import pytest


async def _create_talk(
    db,
    talk_id,
    expected_user_ids,
):
    await db["talks"].insert_one({
        "talk_id": talk_id,
        "client_id": "empresa_a",
        "title": "Charla obligatoria",
        "month": "9",
        "year": "2026",
        "mandatory": True,
        "expected_user_ids": expected_user_ids,
    })


@pytest.mark.asyncio
async def test_absence_state_found(
    api,
    db,
    auth_headers,
    seed,
):
    await _create_talk(
        db,
        "talk_state_found",
        ["worker_a"],
    )

    response = await api.get(
        "/v1/talks/talk_state_found/absent-workers",
        headers=auth_headers(role="admin"),
    )

    assert response.status_code == 200
    assert response.json()["absence_status"] == (
        "absences_found"
    )


@pytest.mark.asyncio
async def test_absence_state_no_absences(
    api,
    db,
    auth_headers,
    seed,
):
    await _create_talk(
        db,
        "talk_state_complete",
        ["worker_a"],
    )

    await db["attendance"].insert_one({
        "attendance_id": "att_state_complete",
        "client_id": "empresa_a",
        "talk_id": "talk_state_complete",
        "source": "qr",
        "attended_user_ids": ["worker_a"],
        "attendees": ["Ana Prueba"],
    })

    response = await api.get(
        "/v1/talks/talk_state_complete/absent-workers",
        headers=auth_headers(role="admin"),
    )

    assert response.status_code == 200
    assert response.json()["absence_status"] == (
        "no_absences"
    )


@pytest.mark.asyncio
async def test_absence_state_no_expected_workers(
    api,
    db,
    auth_headers,
    seed,
):
    await _create_talk(
        db,
        "talk_state_empty",
        [],
    )

    response = await api.get(
        "/v1/talks/talk_state_empty/absent-workers",
        headers=auth_headers(role="admin"),
    )

    assert response.status_code == 200

    data = response.json()

    assert data["expected_workers_configured"] is True
    assert data["absence_status"] == (
        "no_expected_workers"
    )


@pytest.mark.asyncio
async def test_legacy_talk_has_insufficient_data(
    api,
    auth_headers,
    seed,
):
    response = await api.get(
        "/v1/talks/talk_a/absent-workers",
        headers=auth_headers(role="admin"),
    )

    assert response.status_code == 200

    data = response.json()

    assert data["expected_workers_configured"] is False
    assert data["absence_status"] == (
        "insufficient_data"
    )


@pytest.mark.asyncio
async def test_missing_expected_worker_has_insufficient_data(
    api,
    db,
    auth_headers,
    seed,
):
    await _create_talk(
        db,
        "talk_state_missing",
        [
            "worker_a",
            "missing_worker",
        ],
    )

    response = await api.get(
        "/v1/talks/talk_state_missing/absent-workers",
        headers=auth_headers(role="admin"),
    )

    assert response.status_code == 200

    data = response.json()

    assert data["missing_expected_user_ids"] == [
        "missing_worker",
    ]

    assert data["absence_status"] == (
        "insufficient_data"
    )
