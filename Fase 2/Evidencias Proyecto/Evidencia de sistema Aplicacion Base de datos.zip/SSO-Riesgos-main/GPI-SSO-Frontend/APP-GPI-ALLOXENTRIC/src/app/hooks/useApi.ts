import { useState, useEffect, useCallback } from 'react';
import { ApiError } from '../api/client';

// ─── useApi ───────────────────────────────────────────────────────────────────
// Hook genérico para llamadas a la API.
// Uso:
//   const { data, loading, error, refetch } = useApi(() => getReports());

interface UseApiState<T> {
  data:     T | null;
  loading:  boolean;
  error:    string | null;
  refetch:  () => void;
}

export function useApi<T>(
  fn: () => Promise<T>,
  deps: any[] = [],
): UseApiState<T> {
  const [data, setData]       = useState<T | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState<string | null>(null);
  const [tick, setTick]       = useState(0);

  const refetch = useCallback(() => setTick(t => t + 1), []);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);

    fn()
      .then(result => { if (!cancelled) { setData(result); setLoading(false); } })
      .catch(err   => {
        if (!cancelled) {
          setError(err instanceof ApiError ? err.message : 'Error de conexión');
          setLoading(false);
        }
      });

    return () => { cancelled = true; };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tick, ...deps]);

  return { data, loading, error, refetch };
}

// ─── useMutation ─────────────────────────────────────────────────────────────
// Hook para acciones que modifican datos (POST, PATCH, etc).
// Uso:
//   const { mutate, loading, error } = useMutation((payload) => createReport(payload));

interface UseMutationState<TArgs, TResult> {
  mutate:  (args: TArgs) => Promise<TResult>;
  loading: boolean;
  error:   string | null;
}

export function useMutation<TArgs, TResult>(
  fn: (args: TArgs) => Promise<TResult>,
): UseMutationState<TArgs, TResult> {
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState<string | null>(null);

  const mutate = useCallback(async (args: TArgs): Promise<TResult> => {
    setLoading(true);
    setError(null);
    try {
      const result = await fn(args);
      return result;
    } catch (err) {
      const msg = err instanceof ApiError ? err.message : 'Error de conexión';
      setError(msg);
      throw err;
    } finally {
      setLoading(false);
    }
  }, [fn]);

  return { mutate, loading, error };
}
