import base64
import os
from time import perf_counter

import jwt
import pytest

from app.routers import rt_talks


@pytest.mark.asyncio
async def test_generation_signs_token_and_creates_session(
    api, db, seed, auth_headers, monkeypatch
):
    captured = []
    original_make = rt_talks.qrcode.make

    def capture_payload(data, *args, **kwargs):
        captured.append(data)
        return original_make(data, *args, **kwargs)

    # Captura el contenido antes de convertirlo en imagen.
    # La generación real del SVG sigue ejecutándose.
    monkeypatch.setattr(rt_talks.qrcode, "make", capture_payload)

    headers = auth_headers("admin_a", role="admin")
    claims_list = []

    for _ in range(2):
        response = await api.get("/v1/talks/talk_a/qr", headers=headers)
        assert response.status_code == 200, response.text

        data = response.json()
        assert data["talk_id"] == "talk_a"
        assert data["image"].startswith("data:image/svg+xml;base64,")
        assert data["expires_at"]
        assert b"<svg" in base64.b64decode(data["image"].split(",", 1)[1])

        claims = jwt.decode(
            captured[-1],
            os.environ["QR_SIGNING_SECRET"],
            algorithms=["HS256"],
        )
        claims_list.append(claims)

        assert claims["type"] == "sso-talk-attendance"
        assert claims["version"] == 2
        assert claims["client_id"] == "empresa_a"
        assert claims["talk_id"] == "talk_a"
        assert claims["exp"] - claims["iat"] == 15 * 60

        session = await db["talk_qr_sessions"].find_one({
            "jti": claims["jti"]
        })
        assert session is not None
        assert session["active"] is True
        assert session["created_by"] == "admin_a"
        assert session["client_id"] == "empresa_a"
        assert int(session["expires_at"].timestamp()) == claims["exp"]

    assert claims_list[0]["jti"] != claims_list[1]["jti"]

    # El token realmente generado también debe permitir registrar asistencia.
    response = await api.post(
        "/v1/attendance/scan",
        headers=auth_headers(),
        json={"payload": captured[0], "talk_id": "talk_a"},
    )
    assert response.status_code == 200, response.text
    assert response.json()["registered"] is True
    assert response.json()["message"]


@pytest.mark.asyncio
async def test_scan_duplicate_and_second_user(
    api, db, auth_headers, qr_token
):
    token = await qr_token()

    for user_id, expected in [
        ("worker_a", True),
        ("worker_a", False),
        ("worker_a2", True),
    ]:
        response = await api.post(
            "/v1/attendance/scan",
            headers=auth_headers(user_id),
            json={"payload": token, "talk_id": "talk_a"},
        )
        assert response.status_code == 200, response.text
        assert response.json()["registered"] is expected

    record = await db["attendance"].find_one({"source": "qr"})
    assert set(record["attendees"]) == {"Ana Prueba", "Luis Prueba"}
    assert len(record["attendance_entries"]) == 2


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "case, expected_status",
    [
        ("other_tenant", 403),
        ("inactive_user", 403),
        ("invalid_qr", 400),
        ("wrong_signature", 400),
        ("expired", 410),
        ("revoked", 410),
        ("missing_session", 410),
        ("missing_talk", 404),
        ("different_talk", 400),
        ("no_authentication", 401),
    ],
)
async def test_scan_rejections(
    api, db, auth_headers, qr_token, case, expected_status
):
    token = await qr_token(
        expired=case == "expired",
        active=case != "revoked",
    )
    headers = auth_headers()
    selected_talk = "talk_a"

    if case == "other_tenant":
        headers = auth_headers("worker_b", "empresa_b")
    elif case == "inactive_user":
        headers = auth_headers("inactive_a", role="admin")
    elif case == "invalid_qr":
        token = "esto-no-es-un-jwt"
    elif case == "wrong_signature":
        claims = jwt.decode(
            token,
            os.environ["QR_SIGNING_SECRET"],
            algorithms=["HS256"],
        )
        token = jwt.encode(claims, "otra-clave-de-pruebas-" * 3, algorithm="HS256")
    elif case == "missing_session":
        await db["talk_qr_sessions"].delete_many({})
    elif case == "missing_talk":
        await db["talks"].delete_one({"talk_id": "talk_a"})
    elif case == "different_talk":
        selected_talk = "otra_charla"
    elif case == "no_authentication":
        headers = {}

    response = await api.post(
        "/v1/attendance/scan",
        headers=headers,
        json={"payload": token, "talk_id": selected_talk},
    )

    assert response.status_code == expected_status, response.text

    # El cliente móvil muestra este detalle como feedback del escaneo fallido.
    assert response.json()["detail"]

    assert await db["attendance"].count_documents({}) == 0


@pytest.mark.asyncio
@pytest.mark.performance
async def test_valid_qr_scan_completes_in_less_than_two_seconds(
    api, auth_headers, qr_token
):
    token = await qr_token()

    started_at = perf_counter()
    response = await api.post(
        "/v1/attendance/scan",
        headers=auth_headers(),
        json={"payload": token, "talk_id": "talk_a"},
    )
    elapsed_seconds = perf_counter() - started_at

    assert response.status_code == 200, response.text
    assert response.json()["registered"] is True
    assert elapsed_seconds < 2, f"El escaneo tardó {elapsed_seconds:.3f} s"


@pytest.mark.asyncio
async def test_worker_cannot_generate_qr(api, db, seed, auth_headers):
    response = await api.get(
        "/v1/talks/talk_a/qr",
        headers=auth_headers(),
    )

    assert response.status_code == 403
    assert await db["talk_qr_sessions"].count_documents({}) == 0


@pytest.mark.asyncio
@pytest.mark.parametrize("method", ["patch", "delete"])
async def test_talk_with_attendance_cannot_be_modified_or_deleted(
    api, db, seed, auth_headers, method
):
    await db["attendance"].insert_one({
        "attendance_id": "att_qr_locked",
        "client_id": "empresa_a",
        "talk_id": "talk_a",
        "source": "qr",
        "attendees": ["Ana Prueba"],
    })
    headers = auth_headers("admin_a", role="admin")

    if method == "patch":
        response = await api.patch(
            "/v1/talks/talk_a",
            headers=headers,
            data={"title": "Título modificado"},
        )
    else:
        response = await api.delete("/v1/talks/talk_a", headers=headers)

    assert response.status_code == 409, response.text
    assert response.json()["detail"] == "La charla ya tiene asistencia registrada y no puede modificarse ni eliminarse."
    assert await db["talks"].find_one({"talk_id": "talk_a"}) is not None
