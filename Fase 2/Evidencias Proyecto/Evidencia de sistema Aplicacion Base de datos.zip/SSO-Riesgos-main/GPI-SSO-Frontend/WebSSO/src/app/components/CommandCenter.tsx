import { HelpTooltip } from './HelpTooltip';
import { useState, useEffect } from 'react';
import { TrendingUp, TrendingDown, Minus, AlertTriangle, RefreshCw } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

// ─── CONFIG ───────────────────────────────────────────────────────────────────

const REPORTS_API      = import.meta.env.VITE_REPORTS_API_URL || 'http://localhost:8001';
const STORAGE_KEY_PLAN  = 'sso_floor_plan';
const STORAGE_KEY_ZONES = 'sso_zones';

interface SavedZone {
  id: number; name: string; process: string; color: string;
  x: number; y: number; width: number; height: number;
}

// ─── TIPOS ────────────────────────────────────────────────────────────────────

interface Report {
  report_id:   string;
  area_id:     string;
  type:        string;
  is_iap:      boolean;
  description: string;
  shift:       string;
  status:      string;
  reported_by: string;
  created_at:  string;
  evidences?:  string[];
}

// ─── HELPERS ─────────────────────────────────────────────────────────────────

const getZoneColor = (score: number) => {
  if (score >= 70) return 'rgb(239, 68, 68)';
  if (score >= 40) return 'rgb(245, 158, 11)';
  return 'rgb(16, 185, 129)';
};

const getZoneGlow = (score: number) => {
  if (score >= 70) return 'var(--risk-high-glow)';
  if (score >= 40) return 'var(--risk-medium-glow)';
  return 'var(--risk-low-glow)';
};

// Calcular score de riesgo de una zona basado en sus reportes
function calcZoneScore(reports: Report[]): number {
  if (reports.length === 0) return 0;
  let score = 0;
  for (const r of reports) {
    const hoursOld = (Date.now() - new Date(r.created_at).getTime()) / 3600000;
    const base = r.is_iap ? 20 : 10;
    const recency = hoursOld < 24 ? 1.5 : hoursOld < 72 ? 1.2 : 1;
    const open = r.status !== 'closed' ? 1.3 : 0.5;
    score += base * recency * open;
  }
  return Math.min(100, Math.round(score));
}

// Posiciones fijas para las zonas en el mapa
const ZONE_POSITIONS: Record<string, { x: number; y: number; width: number; height: number }> = {
  'Línea 1':        { x: 5,  y: 10, width: 25, height: 20 },
  'Línea 2':        { x: 35, y: 10, width: 25, height: 20 },
  'Línea 3':        { x: 65, y: 10, width: 28, height: 20 },
  'Bodega Química': { x: 5,  y: 40, width: 22, height: 25 },
  'Zona de Carga':  { x: 33, y: 40, width: 25, height: 25 },
  'Área de Corte':  { x: 64, y: 40, width: 28, height: 25 },
  'Calderas':       { x: 5,  y: 73, width: 22, height: 20 },
  'Almacén Principal': { x: 33, y: 73, width: 25, height: 20 },
  'Oficinas':       { x: 64, y: 73, width: 28, height: 20 },
};

function getPosition(areaName: string, index: number) {
  if (ZONE_POSITIONS[areaName]) return ZONE_POSITIONS[areaName];
  // posición dinámica si no está en el mapa
  const col = index % 3;
  const row = Math.floor(index / 3);
  return { x: 5 + col * 32, y: 10 + row * 32, width: 25, height: 20 };
}

// ─── COMPONENTE ───────────────────────────────────────────────────────────────

type CommandCenterProps = {
  onNavigateToIncidents?: (areaFilter: string) => void;
  userRole?: string;
  userAssignedAreas?: string[];
  userAssignedZones?: string[];
};

export default function CommandCenter({ onNavigateToIncidents, userRole, userAssignedAreas, userAssignedZones }: CommandCenterProps) {
  // Jefe de área: solo ve sus áreas asignadas
  const isAreaManager = userRole === 'jefe de area' || userRole === 'jefe de área';
  const isSupervisor = userRole === 'supervisor';
  const zoneFilter = isSupervisor && userAssignedZones && userAssignedZones.length > 0
    ? userAssignedZones.map(z => z.trim().toLowerCase())
    : null;
  const areaFilter = (isAreaManager || isSupervisor) && userAssignedAreas && userAssignedAreas.length > 0
    ? userAssignedAreas.map(a => a.trim().toLowerCase())
    : null; // null = sin restricción (admin/sso_manager ven todo)
  const [reports, setReports]         = useState<Report[]>([]);
  const [loading, setLoading]         = useState(true);
  const [period, setPeriod]           = useState('7D');
  const [hoveredZone, setHoveredZone] = useState<string | null>(null);
  const [expandedKPI, setExpandedKPI] = useState<string | null>(null);

  // Plano y zonas desde el Gemelo Digital (guardados en localStorage)
  const [floorPlan]   = useState<string | null>(() => {
    try { return localStorage.getItem(STORAGE_KEY_PLAN); } catch { return null; }
  });
  const [savedZones]  = useState<SavedZone[]>(() => {
    try { const s = localStorage.getItem(STORAGE_KEY_ZONES); return s ? JSON.parse(s) : []; } catch { return []; }
  });

  // ── Cargar reportes ────────────────────────────────────────────────────────
  const fetchReports = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('sso_token') ?? '';
      const res = await fetch(`${REPORTS_API}/v1/admin/reports`, {
      headers: { 'Authorization': `Bearer ${token}` }
      });
      if (!res.ok) throw new Error();
      setReports(await res.json());
    } catch {
      console.error('No se pudo cargar reportes');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchReports(); }, []);

  // Filtrar por período de tiempo
  const periodReports = reports.filter(r => {
    const date = new Date(r.created_at);
    const now = new Date();
    const diffDays = (now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24);
    return period === '1D' ? diffDays <= 1 : period === '7D' ? diffDays <= 7 : diffDays <= 30;
  });

  // Filtrar por área asignada si es jefe de área
  const filteredReports = zoneFilter
    ? periodReports.filter(r => zoneFilter.includes(((r as any).zone_id || '').trim().toLowerCase()))
    : areaFilter
      ? periodReports.filter(r => areaFilter.includes((r.area_id || '').trim().toLowerCase()))
      : periodReports;

  // ── Calcular KPIs reales ───────────────────────────────────────────────────
  const totalReports  = filteredReports.length;
  const activeIAP     = filteredReports.filter(r => r.is_iap && r.status !== 'closed').length;
  const closedReports = filteredReports.filter(r => r.status === 'closed').length;
  const openReports   = filteredReports.filter(r => r.status !== 'closed').length;

  // Agrupar reportes por zona
  const reportsByZone: Record<string, Report[]> = {};
  for (const r of filteredReports) {
    if (!reportsByZone[r.area_id]) reportsByZone[r.area_id] = [];
    reportsByZone[r.area_id].push(r);
  }

  // Zonas para el mapa: usar posiciones del Gemelo Digital si existen,
  // si no, calcular posición automática basada en reportes
  const getZonePosition = (name: string, index: number) => {
    const saved = savedZones.find(z => z.name === name);
    if (saved) return { x: saved.x, y: saved.y, width: saved.width, height: saved.height };
    return getPosition(name, index);
  };

  const zones = Object.entries(reportsByZone).map(([name, zoneReports], idx) => {
    const score = calcZoneScore(zoneReports);
    const pos   = getZonePosition(name, idx);
    const open  = zoneReports.filter(r => r.status !== 'closed').length;
    return { name, score, open, total: zoneReports.length, ...pos };
  }).sort((a, b) => b.score - a.score);

  const criticalZones = zones.filter(z => z.score >= 70).length;
  const globalScore   = zones.length > 0
    ? Math.round(zones.reduce((s, z) => s + z.score, 0) / zones.length)
    : 0;

  const kpis = [
    { id: 'reports', label: 'Total Reportes',  value: totalReports,  change: openReports  > 0 ? 12 : 0  },
    { id: 'iap',     label: 'IAP Activos',      value: activeIAP,     change: activeIAP    > 0 ? -3 : 0  },
    { id: 'score',   label: 'Score Global',     value: globalScore,   change: globalScore  > 50 ? 8 : -5 },
    { id: 'zones',   label: 'Zonas Críticas',   value: criticalZones, change: criticalZones > 0 ? 1 : 0  },
  ];

  // Tendencia: reportes por día de la última semana
  // DESPUÉS — trendData usa el período seleccionado
const days = period === '1D' ? 1 : period === '7D' ? 7 : 30;

const trendData = Array.from({ length: days }, (_, i) => {
  const date = new Date();
  date.setDate(date.getDate() - (days - 1 - i));
  const dayStr = days === 1
    ? date.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })
    : date.toLocaleDateString('es-ES', { weekday: days <= 7 ? 'short' : undefined, day: '2-digit', month: days > 7 ? 'short' : undefined });
  const dayReports = reports.filter(r => {
    const d = new Date(r.created_at);
    return days === 1
      ? d.toDateString() === date.toDateString() && d.getHours() === date.getHours()
      : d.toDateString() === date.toDateString();
  });
  const score = calcZoneScore(dayReports);
  return { id: `day-${i}`, day: dayStr, score };
});

  const topRiskZones = zones.slice(0, 5);

  const getKPIDetail = (id: string) => {
    switch (id) {
      case 'reports':
        return filteredReports.map(r => ({
          id: r.report_id?.slice(-8).toUpperCase(),
          area: r.area_id,
          type: r.type,
          status: r.status,
          date: new Date(r.created_at).toLocaleDateString('es-ES'),
        }));
      case 'iap':
        return filteredReports.filter(r => r.is_iap && r.status !== 'closed').map(r => ({
          id: r.report_id?.slice(-8).toUpperCase(),
          area: r.area_id,
          type: r.type,
          status: r.status,
          date: new Date(r.created_at).toLocaleDateString('es-ES'),
        }));
      case 'score':
        return zones.map(z => ({ name: z.name, score: z.score, open: z.open, total: z.total }));
      case 'zones':
        return zones.filter(z => z.score >= 70).map(z => ({ name: z.name, score: z.score, open: z.open, total: z.total }));
      default:
        return [];
    }
  };

  // ─── RENDER ───────────────────────────────────────────────────────────────

  return (
    <div className="h-full p-6 overflow-auto">
      {/* Header */}
      <div className="mb-6 flex items-start justify-between pr-32">
        <div>
          <h1 className="text-4xl mb-2 tracking-tight"
            style={{ fontFamily: 'var(--font-display)', fontWeight: 700 }}>
            COMMAND CENTER
          </h1>
          <HelpTooltip steps={[
      { icon: '📊', title: 'KPIs en tiempo real', description: 'Los 4 indicadores superiores muestran Total Reportes, IAP Activos, Score Global y Zonas Críticas. Se actualizan al presionar "Actualizar".' },
      { icon: '🗺️', title: 'Mapa de Calor Interactivo', description: 'Visualiza las zonas de la planta con colores según nivel de riesgo: verde (bajo), amarillo (medio) y rojo (alto). Haz clic en una zona para ver sus incidentes.' },
      { icon: '⏱️', title: 'Filtro de período', description: 'Cambia la vista del mapa entre 1D (último día), 7D (última semana) o 30D (último mes) con los botones sobre el mapa.' },
      { icon: '🚨', title: 'Áreas Críticas', description: 'El panel derecho lista las zonas con mayor nivel de riesgo ordenadas por score. Haz clic en una para ir directamente a sus incidentes.' },
    ]} />
          <p className="text-muted-foreground">Visión consolidada del estado de riesgos de la planta</p>
        </div>
        <button onClick={fetchReports}
          className="flex items-center gap-2 px-4 py-2 bg-secondary text-secondary-foreground rounded-lg hover:bg-secondary/80 transition-all">
          <RefreshCw size={16} className={loading ? 'animate-spin' : ''} />
          Actualizar
        </button>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {kpis.map((kpi) => (
          <div key={kpi.id}
            onClick={() => setExpandedKPI(expandedKPI === kpi.id ? null : kpi.id)}
            className="bg-card border border-border rounded-lg p-5 hover:border-primary/50 transition-all cursor-pointer">
            <div className="text-sm text-muted-foreground mb-1">{kpi.label}</div>
            <div className="text-3xl mb-2" style={{ fontFamily: 'var(--font-mono)', fontWeight: 600 }}>
              {loading ? '...' : kpi.value}
            </div>
            <div className="flex items-center gap-2 text-xs">
              {kpi.change > 0
                ? <span className="flex items-center gap-1 text-risk-high"><TrendingUp size={14} />+{kpi.change}%</span>
                : kpi.change < 0
                  ? <span className="flex items-center gap-1 text-risk-low"><TrendingDown size={14} />{kpi.change}%</span>
                  : <span className="flex items-center gap-1 text-muted-foreground"><Minus size={14} />0%</span>}
              <span className="text-muted-foreground">vs período anterior</span>
            </div>
          </div>
        ))}
      </div>

      {expandedKPI && (
        <div className="bg-card border border-primary/50 rounded-lg p-6 mb-6 animate-in fade-in">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold" style={{ fontFamily: 'var(--font-display)' }}>
              {kpis.find(k => k.id === expandedKPI)?.label} — Detalle
            </h3>
            <button onClick={() => setExpandedKPI(null)}
              className="text-muted-foreground hover:text-foreground text-sm">✕ Cerrar</button>
          </div>
          {(expandedKPI === 'reports' || expandedKPI === 'iap') && (
            <div className="overflow-x-auto max-h-64 overflow-y-auto">
              <table className="w-full text-sm">
                <thead><tr className="border-b border-border text-muted-foreground">
                  <th className="text-left py-2 px-3">ID</th>
                  <th className="text-left py-2 px-3">Área</th>
                  <th className="text-left py-2 px-3">Tipo</th>
                  <th className="text-left py-2 px-3">Estado</th>
                  <th className="text-left py-2 px-3">Fecha</th>
                </tr></thead>
                <tbody>{getKPIDetail(expandedKPI).map((r: any, i: number) => (
                  <tr key={i} className="border-b border-border/30 hover:bg-secondary/30">
                    <td className="py-2 px-3 font-mono text-xs">{r.id}</td>
                    <td className="py-2 px-3">{r.area}</td>
                    <td className="py-2 px-3">{r.type}</td>
                    <td className="py-2 px-3">{r.status}</td>
                    <td className="py-2 px-3">{r.date}</td>
                  </tr>
                ))}</tbody>
              </table>
            </div>
          )}
          {(expandedKPI === 'score' || expandedKPI === 'zones') && (<>
            <p className="text-xs text-muted-foreground mb-3 p-3 bg-primary/10 border border-primary/20 rounded-lg">Score por zona: 20 pts por IAP, 10 pts por reporte normal. Multiplicador de recencia (x1.5 recientes) y estado (x1.3 abiertos, x0.5 cerrados). Rango: 0-39 Bajo, 40-69 Medio, 70-100 Alto. Score Global = promedio de areas.</p>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {getKPIDetail(expandedKPI).map((z: any, i: number) => (
                <div key={i} className="flex items-center justify-between p-3 bg-secondary/30 rounded-lg">
                  <div>
                    <span className="font-medium">{z.name}</span>
                    <span className="text-xs text-muted-foreground ml-2">{z.open} abiertos de {z.total}</span>
                  </div>
                  <span className="font-mono font-semibold" style={{ color: z.score >= 70 ? 'rgb(239,68,68)' : z.score >= 40 ? 'rgb(245,158,11)' : 'rgb(16,185,129)' }}>
                    {z.score}
                  </span>
                </div>
              ))}
            </div>
          </>)}
          {getKPIDetail(expandedKPI).length === 0 && (
            <p className="text-muted-foreground text-sm py-4 text-center">Sin datos para este período</p>
          )}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Heat Map */}
        <div className="lg:col-span-2">
          <div className="bg-card border border-border rounded-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl" style={{ fontFamily: 'var(--font-display)', fontWeight: 600 }}>
                MAPA DE CALOR INTERACTIVO
              </h2>
              <div className="flex gap-2">
                {['1D', '7D', '30D'].map((p) => (
                  <button key={p} onClick={() => setPeriod(p)}
                    className={`px-3 py-1 text-xs rounded transition-all ${
                      period === p
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
                    }`}
                    style={{ fontFamily: 'var(--font-mono)' }}>
                    {p}
                  </button>
                ))}
              </div>
            </div>

            {/* Plant Layout */}
            <div className="relative bg-secondary/30 rounded-lg aspect-[4/3] border border-border/50 overflow-hidden">

              {/* Plano de fondo desde Gemelo Digital */}
              {floorPlan && (
                <img src={floorPlan} alt="Plano de planta"
                  className="absolute inset-0 w-full h-full object-contain opacity-40 pointer-events-none" />
              )}

              <div className="absolute inset-0 opacity-20"
                style={{
                  backgroundImage: 'linear-gradient(rgba(148, 163, 184, 0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(148, 163, 184, 0.1) 1px, transparent 1px)',
                  backgroundSize: '20px 20px',
                }} />

              {loading && (
                <div className="absolute inset-0 flex items-center justify-center text-muted-foreground">
                  <RefreshCw size={32} className="animate-spin opacity-50" />
                </div>
              )}

              {!loading && zones.length === 0 && (
                <div className="absolute inset-0 flex items-center justify-center text-muted-foreground text-sm">
                  No hay zonas con reportes aún
                </div>
              )}

              {!loading && zones.map((zone) => (
                <div key={zone.name}
                  className="absolute cursor-pointer transition-all duration-300"
                  style={{ left: `${zone.x}%`, top: `${zone.y}%`, width: `${zone.width}%`, height: `${zone.height}%` }}
                  onMouseEnter={() => setHoveredZone(zone.name)}
                  onMouseLeave={() => setHoveredZone(null)}
                  onClick={() => onNavigateToIncidents?.(zone.name)}>
                  <div className="w-full h-full rounded border-2 transition-all duration-300 flex items-center justify-center"
                    style={{
                      backgroundColor: `${getZoneColor(zone.score)}33`,
                      borderColor: getZoneColor(zone.score),
                      boxShadow: hoveredZone === zone.name
                        ? `0 0 20px ${getZoneGlow(zone.score)}, inset 0 0 20px ${getZoneGlow(zone.score)}`
                        : `0 0 10px ${getZoneGlow(zone.score)}`,
                    }}>
                    <span className="text-[10px] font-bold text-center px-1 leading-tight"
                      style={{ color: getZoneColor(zone.score) }}>
                      {zone.name}
                    </span>
                  </div>

                  {hoveredZone === zone.name && (
                    <div className="absolute top-full left-1/2 -translate-x-1/2 mt-2 z-10 bg-popover border border-border rounded-lg p-3 shadow-xl min-w-[200px]">
                      <div className="font-medium mb-1">{zone.name}</div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">Score de Riesgo</span>
                        <span className="font-mono font-semibold" style={{ color: getZoneColor(zone.score) }}>
                          {zone.score}
                        </span>
                      </div>
                      <div className="text-xs text-muted-foreground mt-1">
                        {zone.open} reportes abiertos de {zone.total} total
                      </div>
                      <div className="text-xs text-muted-foreground mt-1">
                        {zone.score >= 70 && '⚠️ Requiere atención inmediata'}
                        {zone.score >= 40 && zone.score < 70 && '⚡ Monitorear y planificar'}
                        {zone.score < 40 && '✓ Situación controlada'}
                      </div>
                      <div className="text-xs text-primary mt-2 font-medium">👆 Clic para ver incidentes</div>
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* Legend */}
            <div className="flex items-center justify-center gap-6 mt-4 text-sm">
              {[
                { color: 'rgb(239, 68, 68)',  label: 'Alto (70-100)' },
                { color: 'rgb(245, 158, 11)', label: 'Medio (40-69)' },
                { color: 'rgb(16, 185, 129)', label: 'Bajo (0-39)'   },
              ].map(({ color, label }) => (
                <div key={label} className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded" style={{ backgroundColor: color }} />
                  <span>{label}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Trend Chart */}
          <div className="bg-card border border-border rounded-lg p-6 mt-6">
            <h2 className="text-xl mb-4" style={{ fontFamily: 'var(--font-display)', fontWeight: 600 }}>
              EVOLUCIÓN DE RIESGO GLOBAL
            </h2>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={trendData} id="risk-trend-chart">
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(148, 163, 184, 0.2)" />
                <XAxis dataKey="day" stroke="#94a3b8"
                  style={{ fontSize: '12px', fontFamily: 'var(--font-mono)' }}
                  allowDuplicatedCategory={false} />
                <YAxis stroke="#94a3b8"
                  style={{ fontSize: '12px', fontFamily: 'var(--font-mono)' }} />
                <Tooltip contentStyle={{
                  backgroundColor: '#1f2937',
                  border: '1px solid rgba(148, 163, 184, 0.2)',
                  borderRadius: '8px',
                }} />
                <Line type="monotone" dataKey="score" stroke="#00E5FF" strokeWidth={2}
                  dot={{ fill: '#00E5FF', r: 4 }} activeDot={{ r: 6 }} isAnimationActive={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Top Risk Areas */}
        <div className="bg-card border border-border rounded-lg p-6">
          <div className="flex items-center gap-2 mb-4">
            <AlertTriangle size={20} className="text-risk-high" />
            <h2 className="text-xl" style={{ fontFamily: 'var(--font-display)', fontWeight: 600 }}>
              ÁREAS CRÍTICAS
            </h2>
          </div>

          {loading && (
            <div className="text-center py-8 text-muted-foreground">
              <RefreshCw size={24} className="animate-spin mx-auto mb-2 opacity-50" />
              Cargando...
            </div>
          )}

          {!loading && topRiskZones.length === 0 && (
            <div className="text-center py-8 text-muted-foreground text-sm">
              No hay zonas con reportes aún
            </div>
          )}

          <div className="space-y-3">
            {!loading && topRiskZones.map((zone, idx) => (
              <div key={zone.name}
                className="p-4 bg-secondary/50 rounded-lg border border-border/50 hover:border-primary/50 transition-all cursor-pointer"
                onClick={() => onNavigateToIncidents?.(zone.name)}>
                <div className="flex items-start gap-3 mb-2">
                  <div className="text-xl font-mono font-bold text-muted-foreground">#{idx + 1}</div>
                  <div>
                    <div className="font-medium">{zone.name}</div>
                    <div className="text-xs text-muted-foreground mt-1">
                      {zone.score >= 70 ? 'Riesgo Alto' : zone.score >= 40 ? 'Riesgo Medio' : 'Riesgo Bajo'}
                      {' · '}{zone.open} abiertos
                    </div>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <div className="w-full bg-secondary rounded-full h-2 mr-3">
                    <div className="h-2 rounded-full transition-all"
                      style={{ width: `${zone.score}%`, backgroundColor: getZoneColor(zone.score) }} />
                  </div>
                  <span className="font-mono font-semibold text-lg shrink-0"
                    style={{ color: getZoneColor(zone.score) }}>
                    {zone.score}
                  </span>
                </div>
                <div className="flex items-center justify-end gap-1 text-xs mt-2">
                  {zone.score >= 70
                    ? <span className="flex items-center gap-1 text-risk-high"><TrendingUp size={12} />Subiendo</span>
                    : zone.score >= 40
                      ? <span className="flex items-center gap-1 text-muted-foreground"><Minus size={12} />Estable</span>
                      : <span className="flex items-center gap-1 text-risk-low"><TrendingDown size={12} />Bajando</span>}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}