const SUPPORTED_IMAGE_TYPES = [
  'image/jpeg',
  'image/png',
  'image/webp',
];

function extensionForMime(mime: string): string {
  switch (mime.toLowerCase()) {
    case 'image/png':
      return 'png';
    case 'image/webp':
      return 'webp';
    default:
      return 'jpg';
  }
}

export function dataUrlToImageFile(
  dataUrl: string,
  baseName = 'imagen',
): File {
  const match =
    /^data:(image\/(?:jpeg|png|webp));base64,([\s\S]+)$/i.exec(
      dataUrl,
    );

  if (!match) {
    throw new Error('Formato de imagen no soportado');
  }

  const mime = match[1].toLowerCase();
  const binary = atob(match[2]);

  const bytes = Uint8Array.from(
    binary,
    character => character.charCodeAt(0),
  );

  const extension = extensionForMime(mime);

  return new File(
    [bytes],
    `${baseName}.${extension}`,
    { type: mime },
  );
}

export function isSupportedImageType(
  mime: string,
): boolean {
  return SUPPORTED_IMAGE_TYPES.includes(mime);
}
