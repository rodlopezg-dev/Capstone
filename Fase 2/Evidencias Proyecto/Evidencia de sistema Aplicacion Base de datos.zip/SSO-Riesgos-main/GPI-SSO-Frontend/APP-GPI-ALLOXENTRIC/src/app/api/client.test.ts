import {
  beforeEach,
  describe,
  expect,
  it,
  vi,
} from 'vitest';

import {
  AUTH_SESSION_INVALIDATED_EVENT,
  authenticatedFetch,
  getRefreshToken,
  getToken,
  setRefreshToken,
  setToken,
} from './client';

class MemoryStorage
  implements Storage {
  private data =
    new Map<string, string>();

  get length() {
    return this.data.size;
  }

  clear() {
    this.data.clear();
  }

  getItem(
    key: string,
  ): string | null {
    return (
      this.data.get(key) ??
      null
    );
  }

  key(
    index: number,
  ): string | null {
    return (
      Array.from(
        this.data.keys(),
      )[index] ??
      null
    );
  }

  removeItem(
    key: string,
  ) {
    this.data.delete(key);
  }

  setItem(
    key: string,
    value: string,
  ) {
    this.data.set(
      key,
      value,
    );
  }
}

function jsonResponse(
  body: unknown,
  status = 200,
): Response {
  return new Response(
    JSON.stringify(body),
    {
      status,
      headers: {
        'Content-Type':
          'application/json',
      },
    },
  );
}

describe(
  'authenticatedFetch - SCRUM-135',
  () => {
    beforeEach(() => {
      vi.restoreAllMocks();

      vi.stubGlobal(
        'localStorage',
        new MemoryStorage(),
      );

      localStorage.setItem(
        'vigia_session',
        JSON.stringify({
          user: {
            user_id: 'user-a',
          },
        }),
      );
    });

    it(
      'refreshes once after 401 and retries with the new access token',
      async () => {
        setToken('expired-access');
        setRefreshToken(
          'valid-refresh',
        );

        const fetchMock =
          vi.fn()
            .mockResolvedValueOnce(
              jsonResponse(
                {
                  detail:
                    'Unauthorized',
                },
                401,
              ),
            )
            .mockResolvedValueOnce(
              jsonResponse({
                access_token:
                  'new-access',
                refresh_token:
                  'valid-refresh',
              }),
            )
            .mockResolvedValueOnce(
              jsonResponse({
                ok: true,
              }),
            );

        vi.stubGlobal(
          'fetch',
          fetchMock,
        );

        const response =
          await authenticatedFetch(
            'https://api.test/resource',
          );

        expect(
          response.status,
        ).toBe(200);

        expect(
          fetchMock,
        ).toHaveBeenCalledTimes(3);

        expect(
          fetchMock.mock.calls[1][0],
        ).toContain(
          '/v1/auth/refresh',
        );

        expect(
          getToken(),
        ).toBe('new-access');

        expect(
          getRefreshToken(),
        ).toBe(
          'valid-refresh',
        );

        const retryHeaders =
          new Headers(
            fetchMock
              .mock
              .calls[2][1]
              ?.headers,
          );

        expect(
          retryHeaders.get(
            'Authorization',
          ),
        ).toBe(
          'Bearer new-access',
        );
      },
    );

    it(
      'clears auth state when refresh is rejected',
      async () => {
        setToken('expired-access');
        setRefreshToken(
          'expired-refresh',
        );

        vi.stubGlobal(
          'fetch',
          vi.fn()
            .mockResolvedValueOnce(
              jsonResponse(
                {},
                401,
              ),
            )
            .mockResolvedValueOnce(
              jsonResponse(
                {},
                401,
              ),
            ),
        );

        const response =
          await authenticatedFetch(
            'https://api.test/resource',
          );

        expect(
          response.status,
        ).toBe(401);

        expect(
          getToken(),
        ).toBeNull();

        expect(
          getRefreshToken(),
        ).toBeNull();

        expect(
          localStorage.getItem(
            'vigia_session',
          ),
        ).toBeNull();
      },
    );

    it.each([401, 403])(
      'removes administrative session state after refresh rejection %i',
      async refreshStatus => {
        setToken('expired-admin-access');
        setRefreshToken('old-admin-refresh');
        const dispatchEvent = vi.fn();
        vi.stubGlobal('window', { dispatchEvent });
        const fetchMock = vi.fn()
          .mockResolvedValueOnce(jsonResponse({}, 401))
          .mockResolvedValueOnce(jsonResponse({}, refreshStatus));
        vi.stubGlobal('fetch', fetchMock);

        const response = await authenticatedFetch('https://api.test/admin');

        expect(response.status).toBe(401);
        expect(getToken()).toBeNull();
        expect(getRefreshToken()).toBeNull();
        expect(localStorage.getItem('vigia_session')).toBeNull();
        expect(fetchMock).toHaveBeenCalledTimes(2);
        expect(dispatchEvent).toHaveBeenCalledOnce();
        expect(dispatchEvent.mock.calls[0][0].type).toBe(AUTH_SESSION_INVALIDATED_EVENT);
        vi.unstubAllGlobals();
      },
    );

    it(
      'does not refresh or logout on 403',
      async () => {
        setToken('valid-access');
        setRefreshToken(
          'valid-refresh',
        );

        const fetchMock =
          vi.fn()
            .mockResolvedValueOnce(
              jsonResponse(
                {},
                403,
              ),
            );

        vi.stubGlobal(
          'fetch',
          fetchMock,
        );

        const response =
          await authenticatedFetch(
            'https://api.test/resource',
          );

        expect(
          response.status,
        ).toBe(403);

        expect(
          fetchMock,
        ).toHaveBeenCalledTimes(1);

        expect(
          getToken(),
        ).toBe(
          'valid-access',
        );

        expect(
          localStorage.getItem(
            'vigia_session',
          ),
        ).not.toBeNull();
      },
    );

    it(
      'does not clear the session on a network error',
      async () => {
        setToken('valid-access');
        setRefreshToken(
          'valid-refresh',
        );

        vi.stubGlobal(
          'fetch',
          vi.fn()
            .mockRejectedValueOnce(
              new TypeError(
                'Failed to fetch',
              ),
            ),
        );

        await expect(
          authenticatedFetch(
            'https://api.test/resource',
          ),
        ).rejects.toThrow(
          'Failed to fetch',
        );

        expect(
          getToken(),
        ).toBe(
          'valid-access',
        );

        expect(
          getRefreshToken(),
        ).toBe(
          'valid-refresh',
        );

        expect(
          localStorage.getItem(
            'vigia_session',
          ),
        ).not.toBeNull();
      },
    );

    it(
      'invalidates a stored session when neither access nor refresh token exists',
      async () => {
        const fetchMock =
          vi.fn()
            .mockResolvedValueOnce(
              jsonResponse(
                {},
                401,
              ),
            );

        vi.stubGlobal(
          'fetch',
          fetchMock,
        );

        const response =
          await authenticatedFetch(
            'https://api.test/resource',
          );

        expect(
          response.status,
        ).toBe(401);

        expect(
          fetchMock,
        ).toHaveBeenCalledTimes(1);

        expect(
          getToken(),
        ).toBeNull();

        expect(
          getRefreshToken(),
        ).toBeNull();

        expect(
          localStorage.getItem(
            'vigia_session',
          ),
        ).toBeNull();
      },
    );

    it(
      'uses a single refresh for concurrent 401 responses',
      async () => {
        setToken('expired-access');
        setRefreshToken(
          'valid-refresh',
        );

        const fetchMock =
          vi.fn(
            async (
              input:
                RequestInfo | URL,
              options?:
                RequestInit,
            ) => {
              const url =
                String(input);

              if (
                url.includes(
                  '/v1/auth/refresh',
                )
              ) {
                return jsonResponse({
                  access_token:
                    'new-access',
                  refresh_token:
                    'valid-refresh',
                });
              }

              const headers =
                new Headers(
                  options?.headers,
                );

              if (
                headers.get(
                  'Authorization',
                ) ===
                'Bearer expired-access'
              ) {
                return jsonResponse(
                  {},
                  401,
                );
              }

              return jsonResponse({
                ok: true,
              });
            },
          );

        vi.stubGlobal(
          'fetch',
          fetchMock,
        );

        const responses =
          await Promise.all([
            authenticatedFetch(
              'https://api.test/a',
            ),
            authenticatedFetch(
              'https://api.test/b',
            ),
          ]);

        expect(
          responses.map(
            response =>
              response.status,
          ),
        ).toEqual(
          [200, 200],
        );

        const refreshCalls =
          fetchMock.mock.calls.filter(
            call =>
              String(call[0])
                .includes(
                  '/v1/auth/refresh',
                ),
          );

        expect(
          refreshCalls,
        ).toHaveLength(1);

        expect(
          getToken(),
        ).toBe('new-access');
      },
    );

    it(
      'keeps the session when refresh is temporarily unavailable',
      async () => {
        setToken('expired-access');
        setRefreshToken(
          'valid-refresh',
        );

        vi.stubGlobal(
          'fetch',
          vi.fn()
            .mockResolvedValueOnce(
              jsonResponse(
                {},
                401,
              ),
            )
            .mockResolvedValueOnce(
              jsonResponse(
                {},
                500,
              ),
            ),
        );

        const response =
          await authenticatedFetch(
            'https://api.test/resource',
          );

        expect(
          response.status,
        ).toBe(401);

        expect(
          getToken(),
        ).toBe(
          'expired-access',
        );

        expect(
          getRefreshToken(),
        ).toBe(
          'valid-refresh',
        );

        expect(
          localStorage.getItem(
            'vigia_session',
          ),
        ).not.toBeNull();
      },
    );

    it(
      'can recover when the access token is missing but refresh exists',
      async () => {
        setRefreshToken(
          'valid-refresh',
        );

        const fetchMock =
          vi.fn()
            .mockResolvedValueOnce(
              jsonResponse(
                {},
                401,
              ),
            )
            .mockResolvedValueOnce(
              jsonResponse({
                access_token:
                  'recovered-access',
                refresh_token:
                  'valid-refresh',
              }),
            )
            .mockResolvedValueOnce(
              jsonResponse({
                ok: true,
              }),
            );

        vi.stubGlobal(
          'fetch',
          fetchMock,
        );

        const response =
          await authenticatedFetch(
            'https://api.test/resource',
          );

        expect(
          response.status,
        ).toBe(200);

        expect(
          getToken(),
        ).toBe(
          'recovered-access',
        );
      },
    );
  },
);
