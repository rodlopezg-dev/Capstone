import pytest

from app.services import azure_blob_service


@pytest.mark.asyncio
async def test_upload_image_uses_tenant_scoped_path(
    monkeypatch,
):
    captured = {}

    def fake_sync_upload(
        file_bytes,
        blob_name,
        content_type="image/jpeg",
    ):
        captured["file_bytes"] = file_bytes
        captured["blob_name"] = blob_name
        captured["content_type"] = content_type

        return f"https://example.test/{blob_name}"

    monkeypatch.setattr(
        azure_blob_service,
        "_sync_upload",
        fake_sync_upload,
    )

    result = await azure_blob_service.upload_image(
        b"test-image",
        "tenant-a",
        "17",
    )

    assert captured["file_bytes"] == b"test-image"
    assert captured["blob_name"] == (
        "reports/tenant-a/17/evidence.jpg"
    )
    assert captured["content_type"] == "image/jpeg"

    assert result == (
        "https://example.test/"
        "reports/tenant-a/17/evidence.jpg"
    )


@pytest.mark.asyncio
async def test_same_report_id_is_isolated_between_tenants(
    monkeypatch,
):
    blob_names = []

    def fake_sync_upload(
        file_bytes,
        blob_name,
        content_type="image/jpeg",
    ):
        blob_names.append(blob_name)
        return f"https://example.test/{blob_name}"

    monkeypatch.setattr(
        azure_blob_service,
        "_sync_upload",
        fake_sync_upload,
    )

    await azure_blob_service.upload_image(
        b"tenant-a-image",
        "tenant-a",
        "1",
    )

    await azure_blob_service.upload_image(
        b"tenant-b-image",
        "tenant-b",
        "1",
    )

    assert blob_names == [
        "reports/tenant-a/1/evidence.jpg",
        "reports/tenant-b/1/evidence.jpg",
    ]

    assert len(set(blob_names)) == 2


def test_auto_created_container_is_private(
    monkeypatch,
):
    created = {}

    class FakeBlobClient:
        def upload_blob(
            self,
            *args,
            **kwargs,
        ):
            created["upload"] = True

    class FakeContainerClient:
        def create_container(
            self,
            *args,
            **kwargs,
        ):
            created["args"] = args
            created["kwargs"] = kwargs

        def get_blob_client(
            self,
            blob_name,
        ):
            created["blob_name"] = blob_name
            return FakeBlobClient()

    class FakeBlobService:
        @classmethod
        def from_connection_string(
            cls,
            connection_string,
        ):
            created["connection_string"] = (
                connection_string
            )
            return cls()

        def get_container_client(
            self,
            container_name,
        ):
            created["container"] = (
                container_name
            )
            return FakeContainerClient()

    monkeypatch.setattr(
        azure_blob_service,
        "BlobServiceClient",
        FakeBlobService,
    )

    monkeypatch.setattr(
        azure_blob_service,
        "AZURE_STORAGE_AUTO_CREATE_CONTAINER",
        True,
    )

    monkeypatch.setattr(
        azure_blob_service,
        "BLOB_BASE_URL",
        "/local-report-evidence",
    )

    result = azure_blob_service._sync_upload(
        b"image",
        "reports/tenant-a/1/evidence.jpg",
    )

    assert created["args"] == ()
    assert created["kwargs"] == {}
    assert created["upload"] is True

    assert result == (
        "/local-report-evidence/"
        "reports/tenant-a/1/evidence.jpg"
    )


def test_generate_read_url_uses_read_only_sas(
    monkeypatch,
):
    captured = {}

    monkeypatch.setattr(
        azure_blob_service,
        "AZURE_CONN_STR",
        (
            "AccountName=testaccount;"
            "AccountKey=test-secret==;"
        ),
    )

    monkeypatch.setattr(
        azure_blob_service,
        "AZURE_CONTAINER",
        "sso-report-evidence",
    )

    monkeypatch.setattr(
        azure_blob_service,
        "BLOB_BASE_URL",
        "/local-report-evidence",
    )

    def fake_generate_blob_sas(
        **kwargs,
    ):
        captured.update(kwargs)
        return "sp=r&sig=test"

    monkeypatch.setattr(
        azure_blob_service,
        "generate_blob_sas",
        fake_generate_blob_sas,
    )

    reference = (
        "/local-report-evidence/"
        "reports/tenant-a/1/evidence.jpg"
    )

    result = azure_blob_service.generate_read_url(
        reference,
        "tenant-a",
        "1",
    )

    assert result == (
        reference
        + "?sp=r&sig=test"
    )

    assert captured["account_name"] == (
        "testaccount"
    )

    assert captured["container_name"] == (
        "sso-report-evidence"
    )

    assert captured["blob_name"] == (
        "reports/tenant-a/1/evidence.jpg"
    )

    assert captured["permission"].read is True


def test_generate_read_url_preserves_legacy_reference(
    monkeypatch,
):
    monkeypatch.setattr(
        azure_blob_service,
        "BLOB_BASE_URL",
        "/local-report-evidence",
    )

    legacy = (
        "/local-evidence/"
        "reports/1/evidence.jpg"
    )

    assert azure_blob_service.generate_read_url(
        legacy,
        "tenant-a",
        "1",
    ) == legacy


def test_generate_read_url_rejects_other_tenant_path(
    monkeypatch,
):
    monkeypatch.setattr(
        azure_blob_service,
        "BLOB_BASE_URL",
        "/local-report-evidence",
    )

    foreign = (
        "/local-report-evidence/"
        "reports/tenant-b/1/evidence.jpg"
    )

    assert azure_blob_service.generate_read_url(
        foreign,
        "tenant-a",
        "1",
    ) == foreign


def test_sign_report_evidence_urls_does_not_mutate_source(
    monkeypatch,
):
    monkeypatch.setattr(
        azure_blob_service,
        "BLOB_BASE_URL",
        "/local-report-evidence",
    )

    def fake_generate_read_url(
        reference,
        client_id,
        report_id,
    ):
        return reference + "?signed=true"

    monkeypatch.setattr(
        azure_blob_service,
        "generate_read_url",
        fake_generate_read_url,
    )

    stable_image = (
        "/local-report-evidence/"
        "reports/tenant-a/1/evidence.jpg"
    )

    stable_closure = (
        "/local-report-evidence/"
        "reports/tenant-a/1/"
        "closure-evidence/test.pdf"
    )

    report = {
        "client_id": "tenant-a",
        "report_id": "1",
        "image_url": stable_image,
        "evidences": [
            stable_image,
        ],
        "closure_evidence": {
            "url": stable_closure,
            "filename": "test.pdf",
        },
    }

    signed = (
        azure_blob_service
        .sign_report_evidence_urls(report)
    )

    assert report["image_url"] == stable_image
    assert report["evidences"] == [
        stable_image,
    ]
    assert (
        report["closure_evidence"]["url"]
        == stable_closure
    )

    assert signed["image_url"] == (
        stable_image + "?signed=true"
    )

    assert signed["evidences"] == [
        stable_image + "?signed=true",
    ]

    assert (
        signed["closure_evidence"]["url"]
        == stable_closure + "?signed=true"
    )
