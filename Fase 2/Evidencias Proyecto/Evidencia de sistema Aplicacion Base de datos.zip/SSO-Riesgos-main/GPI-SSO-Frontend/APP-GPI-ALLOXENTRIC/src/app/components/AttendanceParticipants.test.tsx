import { describe, expect, it } from 'vitest';
import { renderToStaticMarkup } from 'react-dom/server';
import AttendanceParticipants from './AttendanceParticipants';

describe('attendance participant list', () => {
  const participants = [
    { name: 'Ana', method: 'qr' as const, registeredAt: '2026-10-07T14:30:00Z' },
    { name: 'Luis', method: 'manual' as const },
  ];
  it('renders icon-only filters with accessible names and selected state', () => {
    const html = renderToStaticMarkup(
      <AttendanceParticipants
        participants={participants}
        filters={['manual']}
        onFiltersChange={() => {}}
      />,
    );
    expect(html).toContain('aria-label="Registro manual"');
    expect(html).toContain('aria-pressed="true"');
    expect(html).toContain('aria-label="Hoja de asistencia"');
    expect(html).toContain('<svg');
  });
  it('updates visible rows consistently with the selected filter', () => {
    const html = renderToStaticMarkup(
      <AttendanceParticipants
        participants={participants}
        filters={['qr']}
        onFiltersChange={() => {}}
      />,
    );
    expect(html).toContain('Ana');
    expect(html).not.toContain('Luis');
    expect(html).toContain('dateTime="2026-10-07T14:30:00Z"');
  });
  it('shows an empty filter without changing the total', () => {
    const html = renderToStaticMarkup(
      <AttendanceParticipants
        participants={participants}
        filters={['sheet']}
        onFiltersChange={() => {}}
      />,
    );
    expect(html).toContain('No hay participantes con esta forma de registro.');
  });
});
