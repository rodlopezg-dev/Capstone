import {
  beforeEach,
  describe,
  expect,
  it,
  vi,
} from 'vitest';

import {
  apiFetch,
  clearAuthTokens,
  setRefreshToken,
  setToken,
} from './client';

import {
  login,
  logout,
  restoreSession,
} from './auth';

import {
  getUserProfile,
} from './users';

vi.mock('./client', () => ({
  apiFetch: vi.fn(),
  authenticatedFetch: vi.fn().mockResolvedValue({
    ok: true,
    json: async () => [],
  }),
  setToken: vi.fn(),
  setRefreshToken: vi.fn(),
  clearAuthTokens: vi.fn(),
}));

vi.mock('./users', () => ({
  getUserProfile: vi.fn(),
}));

const apiFetchMock =
  vi.mocked(apiFetch) as any;

const setTokenMock =
  vi.mocked(setToken);

const setRefreshTokenMock =
  vi.mocked(setRefreshToken);

const clearAuthTokensMock =
  vi.mocked(clearAuthTokens);

const getUserProfileMock =
  vi.mocked(getUserProfile);

const loginResponse = (
  userId: string,
) => ({
  access_token:
    `access-${userId}`,
  refresh_token:
    `refresh-${userId}`,
  token_type: 'bearer',
  user_id: userId,
  role: 'worker',
  areas: ['Linea 1'],
  area: 'Linea 1',
});

const meResponse = (
  userId: string,
  clientId: string,
) => ({
  user_id: userId,
  client_id: clientId,
  role: 'worker',
  areas: ['Linea 1'],
  area: 'Linea 1',
});

describe(
  'auth multi-tenant - SCRUM-132',
  () => {
    beforeEach(() => {
      vi.clearAllMocks();

      getUserProfileMock.mockResolvedValue({
        user_id: 'profile_user',
        client_id: 'profile_tenant',
        name: 'Nombre Persistido',
        last_name: 'Apellido Persistido',
        email: 'persistido@demo.com',
        role: 'worker',
        assigned_areas: ['Linea 1'],
        status: 'active',
      });

      vi.stubGlobal(
        'fetch',
        vi.fn().mockResolvedValue({
          ok: true,
          json: async () => [],
        }),
      );
    });

    it.each([
      [
        'cliente_prueba_123',
        'usuario@demo.com',
        'user_a',
      ],
      [
        'cliente_prueba_b_123',
        'usuariob@demo.com',
        'user_b',
      ],
    ])(
      'sends the selected tenant for %s',
      async (
        clientId,
        email,
        userId,
      ) => {
        apiFetchMock
          .mockResolvedValueOnce(
            loginResponse(userId),
          )
          .mockResolvedValueOnce(
            meResponse(
              userId,
              clientId,
            ),
          );

        const result = await login(
          clientId,
          email,
          '123456',
        );

        expect(
          apiFetchMock,
        ).toHaveBeenNthCalledWith(
          1,
          '/v1/auth/login',
          expect.objectContaining({
            method: 'POST',
            base: 'auth',
          }),
        );

        const options =
          apiFetchMock.mock.calls[0][1];

        const body = JSON.parse(
          options.body,
        );

        expect(body).toEqual({
          client_id: clientId,
          email,
          password: '123456',
        });

        expect(
          result.user.client_id,
        ).toBe(clientId);
      },
    );

    it(
      'uses /me as the tenant source of truth',
      async () => {
        apiFetchMock
          .mockResolvedValueOnce(
            loginResponse('user_a'),
          )
          .mockResolvedValueOnce(
            meResponse(
              'user_a',
              'tenant_validated_by_backend',
            ),
          );

        const result = await login(
          'tenant_requested',
          'usuario@demo.com',
          '123456',
        );

        expect(
          result.user.client_id,
        ).toBe(
          'tenant_validated_by_backend',
        );
      },
    );

    it(
      'uses persisted name and last name from users-service',
      async () => {
        apiFetchMock
          .mockResolvedValueOnce(
            loginResponse('user_a'),
          )
          .mockResolvedValueOnce(
            meResponse(
              'user_a',
              'cliente_prueba_123',
            ),
          );

        getUserProfileMock.mockResolvedValueOnce({
          user_id: 'user_a',
          client_id: 'cliente_prueba_123',
          name: 'Nombre Real',
          last_name: 'Apellido Real',
          profile_photo_url:
            '/local-evidence/profiles/cliente_prueba_123/user_a/avatar.png',
          email: 'usuario@demo.com',
          role: 'worker',
          assigned_areas: ['Linea 1'],
          status: 'active',
        });

        const result = await login(
          'cliente_prueba_123',
          'usuario@demo.com',
          '123456',
        );

        expect(
          getUserProfileMock,
        ).toHaveBeenCalledTimes(1);

        expect(result.user.name).toBe(
          'Nombre Real',
        );

        expect(
          result.user.profile_photo_url,
        ).toBe(
          '/local-evidence/profiles/cliente_prueba_123/user_a/avatar.png',
        );

        expect(
          result.user.last_name,
        ).toBe(
          'Apellido Real',
        );
      },
    );

    it(
      'does not create a session when the tenant login fails',
      async () => {
        apiFetchMock
          .mockRejectedValueOnce(
            new Error(
              'Invalid credentials',
            ),
          );

        await expect(
          login(
            'tenant_incorrecto',
            'usuario@demo.com',
            '123456',
          ),
        ).rejects.toThrow(
          'Invalid credentials',
        );

        expect(
          setTokenMock,
        ).not.toHaveBeenCalled();
      },
    );

    it(
      'clears the token if /me cannot validate the session',
      async () => {
        apiFetchMock
          .mockResolvedValueOnce(
            loginResponse('user_a'),
          )
          .mockRejectedValueOnce(
            new Error(
              'Invalid session',
            ),
          );

        await expect(
          login(
            'cliente_prueba_123',
            'usuario@demo.com',
            '123456',
          ),
        ).rejects.toThrow(
          'Invalid session',
        );

        expect(
          setTokenMock,
        ).toHaveBeenCalledWith(
          'access-user_a',
        );

        expect(
          clearAuthTokensMock,
        ).toHaveBeenCalledTimes(1);
      },
    );

    it(
      'supports tenant A logout followed by tenant B login',
      async () => {
        apiFetchMock
          .mockResolvedValueOnce(
            loginResponse('user_a'),
          )
          .mockResolvedValueOnce(
            meResponse(
              'user_a',
              'cliente_prueba_123',
            ),
          )
          .mockResolvedValueOnce(
            loginResponse('user_b'),
          )
          .mockResolvedValueOnce(
            meResponse(
              'user_b',
              'cliente_prueba_b_123',
            ),
          );

        const a = await login(
          'cliente_prueba_123',
          'usuario@demo.com',
          '123456',
        );

        expect(
          a.user.client_id,
        ).toBe(
          'cliente_prueba_123',
        );

        await logout();

        const b = await login(
          'cliente_prueba_b_123',
          'usuariob@demo.com',
          '123456',
        );

        expect(
          b.user.client_id,
        ).toBe(
          'cliente_prueba_b_123',
        );

        expect(
          clearAuthTokensMock,
        ).toHaveBeenCalled();

        expect(
          setTokenMock,
        ).toHaveBeenNthCalledWith(
          1,
          'access-user_a',
        );

        expect(
          setTokenMock,
        ).toHaveBeenNthCalledWith(
          2,
          'access-user_b',
        );
      },
    );

    it(
      'restores identity and tenant from backend validation',
      async () => {
        apiFetchMock
          .mockResolvedValueOnce(
            meResponse(
              'restored_user',
              'restored_tenant',
            ),
          );

        getUserProfileMock
          .mockResolvedValueOnce({
            user_id:
              'restored_user',
            client_id:
              'restored_tenant',
            name:
              'Usuario Restaurado',
            last_name:
              'Backend',
            profile_photo_url:
              '/local-evidence/profile.jpg',
            email:
              'restored@demo.com',
            role:
              'worker',
            assigned_areas:
              ['Linea 1'],
            status:
              'active',
          });

        const restored =
          await restoreSession();

        expect(
          restored.user_id,
        ).toBe(
          'restored_user',
        );

        expect(
          restored.client_id,
        ).toBe(
          'restored_tenant',
        );

        expect(
          restored.name,
        ).toBe(
          'Usuario Restaurado',
        );

        expect(
          restored.profile_photo_url,
        ).toBe(
          '/local-evidence/profile.jpg',
        );
      },
    );

    it(
      'rejects an empty organization before calling the backend',
      async () => {
        await expect(
          login(
            '   ',
            'usuario@demo.com',
            '123456',
          ),
        ).rejects.toThrow(
          'ORGANIZATION_REQUIRED',
        );

        expect(
          apiFetchMock,
        ).not.toHaveBeenCalled();
      },
    );
  },
);
