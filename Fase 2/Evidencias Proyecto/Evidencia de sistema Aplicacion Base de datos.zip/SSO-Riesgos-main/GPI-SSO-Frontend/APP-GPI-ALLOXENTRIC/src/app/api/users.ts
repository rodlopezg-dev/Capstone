import { apiFetch } from './client';

export async function listTenantUsers(): Promise<UserProfile[]> {
  return apiFetch<UserProfile[]>('/v1/admin/users/', { base: 'users' });
}

export interface UserProfile {
  user_id: string;
  name: string;
  last_name?: string | null;
  email: string;
  role: string;
  assigned_areas: string[];
  client_id: string;
  status: string;
  profile_photo_url?: string | null;
}

export interface UserProfileUpdate {
  name?: string;
  last_name?: string;
}

export async function getUserProfile(): Promise<UserProfile> {
  return apiFetch<UserProfile>(
    '/v1/users/me',
    {
      base: 'users',
    },
  );
}

export async function updateUserProfile(
  payload: UserProfileUpdate,
): Promise<UserProfile> {
  return apiFetch<UserProfile>(
    '/v1/users/me',
    {
      method: 'PATCH',
      base: 'users',
      body: JSON.stringify(payload),
    },
  );
}

export async function updateUserProfilePhoto(
  file: File,
): Promise<UserProfile> {
  const form = new FormData();

  form.append(
    'file',
    file,
    file.name,
  );

  return apiFetch<UserProfile>(
    '/v1/users/me/photo',
    {
      method: 'PUT',
      base: 'users',
      body: form,
    },
  );
}
