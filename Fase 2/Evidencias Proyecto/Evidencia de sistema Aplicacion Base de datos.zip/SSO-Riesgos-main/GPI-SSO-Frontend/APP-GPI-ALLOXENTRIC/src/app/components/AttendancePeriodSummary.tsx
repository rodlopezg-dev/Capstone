type AttendancePeriodStat = {
  active_workers: number;
  attendance_count: number;
  attendance_percentage: number;
};

type Props = {
  monthName: string;
  year: string;
  stat?: AttendancePeriodStat;
  loading?: boolean;
  error?: boolean;
};

export default function AttendancePeriodSummary({
  monthName,
  year,
  stat,
  loading = false,
  error = false,
}: Props) {
  return (
    <div className="themed-card border rounded-xl p-4">
      <p className="text-xs themed-text-secondary">
        Cobertura {monthName} {year}
      </p>

      {loading ? (
        <p
          role="status"
          className="text-sm themed-text-secondary mt-2"
        >
          Cargando estadísticas del período...
        </p>
      ) : error ? (
        <p
          role="alert"
          className="text-sm text-red-400 mt-2"
        >
          No fue posible obtener las estadísticas del período.
        </p>
      ) : !stat ? (
        <p
          role="status"
          className="text-sm themed-text-secondary mt-2"
        >
          No hay registros de asistencia para este período.
        </p>
      ) : (
        <>
          <p className="text-2xl font-bold text-[#00E5FF] mt-1">
            {stat.attendance_percentage}%
          </p>

          <p className="text-xs themed-text-secondary mt-1">
            {stat.attendance_count} de {stat.active_workers} trabajadores
          </p>
        </>
      )}
    </div>
  );
}
