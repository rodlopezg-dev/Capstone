import io
import os

import pytest
import pytesseract
from azure.core.exceptions import ResourceNotFoundError
from azure.storage.blob.aio import BlobServiceClient
from PIL import Image

import app.repositories.rep_talks as repo_module
from app.repositories.rep_talks import TalksRepository


def _png_bytes():
    image = Image.new(
        "RGB",
        (32, 16),
        "white",
    )
    buffer = io.BytesIO()
    image.save(
        buffer,
        format="PNG",
    )
    return buffer.getvalue()


async def _list_test_blobs(prefix: str):
    connection_string = os.environ[
        "AZURE_STORAGE_CONNECTION_STRING"
    ]
    container_name = os.environ[
        "AZURE_STORAGE_CONTAINER"
    ]

    async with BlobServiceClient.from_connection_string(
        connection_string
    ) as service:
        container = service.get_container_client(
            container_name
        )

        try:
            blobs = set()
            async for blob in container.list_blobs(
                name_starts_with=prefix
            ):
                blobs.add(blob.name)
            return blobs
        except ResourceNotFoundError:
            return set()


@pytest.mark.asyncio
async def test_ocr_matches_only_active_users_in_same_tenant(
    db,
    seed,
    monkeypatch,
):
    monkeypatch.setattr(
        repo_module.pytesseract,
        "image_to_string",
        lambda image, lang: (
            "Ana Prueba\n"
            "Beatriz Prueba\n"
            "Persona Desconocida\n"
        ),
    )

    result = await TalksRepository(
        db
    ).extract_names_from_image(
        "empresa_a",
        _png_bytes(),
    )

    assert result == [
        {
            "name": "Ana Prueba",
            "matched": True,
            "user_id": "worker_a",
        },
        {
            "name": "Beatriz Prueba",
            "matched": False,
            "user_id": None,
        },
        {
            "name": "Persona Desconocida",
            "matched": False,
            "user_id": None,
        },
    ]


@pytest.mark.asyncio
async def test_ocr_endpoint_uploads_real_blob_and_stores_only_metadata(
    api,
    db,
    seed,
    auth_headers,
    monkeypatch,
):
    monkeypatch.setattr(
        repo_module.pytesseract,
        "image_to_string",
        lambda image, lang: (
            "Ana Prueba\n"
            "Persona Desconocida\n"
        ),
    )

    response = await api.post(
        "/v1/attendance/ocr",
        data={
            "talk_id": "talk_a",
        },
        files={
            "file": (
                "hoja asistencia.png",
                _png_bytes(),
                "image/png",
            ),
        },
        headers=auth_headers(
            user_id="admin_a",
            role="admin",
        ),
    )

    assert response.status_code == 200
    body = response.json()

    assert body["ok"] is True
    assert body["talk_id"] == "talk_a"
    assert body["file_name"] == "hoja asistencia.png"

    document = await db[
        "attendance_scans"
    ].find_one(
        {
            "scan_id": body["scan_id"],
            "client_id": "empresa_a",
        }
    )

    assert document is not None
    assert document["storage"]["provider"] == "azure_blob"
    assert document["storage"]["container"] == (
        "attendance-scans-test"
    )
    assert document["storage"]["blob_name"].startswith(
        "empresa_a/talk_a/"
    )
    assert document["content_type"] == "image/png"
    assert document["size_bytes"] > 0
    assert document["matched_count"] == 1

    forbidden_keys = {
        "image_content",
        "image_data",
        "base64",
        "file_url",
        "blob_url",
    }
    assert forbidden_keys.isdisjoint(
        document.keys()
    )

    blobs = await _list_test_blobs(
        "empresa_a/talk_a/"
    )

    assert document[
        "storage"
    ]["blob_name"] in blobs


@pytest.mark.asyncio
async def test_ocr_rejects_cross_tenant_talk(
    api,
    seed,
    auth_headers,
):
    response = await api.post(
        "/v1/attendance/ocr",
        data={
            "talk_id": "talk_a",
        },
        files={
            "file": (
                "scan.png",
                _png_bytes(),
                "image/png",
            ),
        },
        headers=auth_headers(
            user_id="admin_b",
            client_id="empresa_b",
            role="admin",
        ),
    )

    assert response.status_code == 404


@pytest.mark.asyncio
async def test_ocr_rejects_worker_role(
    api,
    seed,
    auth_headers,
):
    response = await api.post(
        "/v1/attendance/ocr",
        data={
            "talk_id": "talk_a",
        },
        files={
            "file": (
                "scan.png",
                _png_bytes(),
                "image/png",
            ),
        },
        headers=auth_headers(
            role="worker",
        ),
    )

    assert response.status_code == 403


@pytest.mark.asyncio
async def test_ocr_rejects_inactive_privileged_user(
    api,
    seed,
    auth_headers,
):
    response = await api.post(
        "/v1/attendance/ocr",
        data={
            "talk_id": "talk_a",
        },
        files={
            "file": (
                "scan.png",
                _png_bytes(),
                "image/png",
            ),
        },
        headers=auth_headers(
            user_id="inactive_a",
            role="admin",
        ),
    )

    assert response.status_code == 403


@pytest.mark.asyncio
async def test_ocr_rejects_invalid_image_before_blob_upload(
    api,
    seed,
    auth_headers,
):
    before = await _list_test_blobs(
        "empresa_a/talk_a/"
    )

    response = await api.post(
        "/v1/attendance/ocr",
        data={
            "talk_id": "talk_a",
        },
        files={
            "file": (
                "scan.png",
                b"not-an-image",
                "image/png",
            ),
        },
        headers=auth_headers(
            user_id="admin_a",
            role="admin",
        ),
    )

    assert response.status_code == 422

    after = await _list_test_blobs(
        "empresa_a/talk_a/"
    )

    assert after == before


@pytest.mark.asyncio
async def test_ocr_deletes_blob_when_metadata_persistence_fails(
    api,
    seed,
    auth_headers,
    monkeypatch,
):
    monkeypatch.setattr(
        repo_module.pytesseract,
        "image_to_string",
        lambda image, lang: "Ana Prueba",
    )

    async def fail_metadata(*args, **kwargs):
        raise RuntimeError(
            "simulated metadata failure"
        )

    monkeypatch.setattr(
        TalksRepository,
        "create_attendance_scan",
        fail_metadata,
    )

    before = await _list_test_blobs(
        "empresa_a/talk_a/"
    )

    response = await api.post(
        "/v1/attendance/ocr",
        data={
            "talk_id": "talk_a",
        },
        files={
            "file": (
                "scan.png",
                _png_bytes(),
                "image/png",
            ),
        },
        headers=auth_headers(
            user_id="admin_a",
            role="admin",
        ),
    )

    assert response.status_code == 500
    assert response.json()["detail"] == (
        "No fue posible guardar el resultado del OCR."
    )

    after = await _list_test_blobs(
        "empresa_a/talk_a/"
    )

    assert after == before


def test_tesseract_spanish_language_is_installed():
    languages = pytesseract.get_languages(
        config="",
    )
    assert "spa" in languages
