import { HelpTooltip } from './HelpTooltip';
import CreateReportModal from './CreateReportModal';
import { useState, useEffect } from 'react';
import { Search, AlertCircle } from 'lucide-react';
import html2pdf from 'html2pdf.js';

// ─── TIPOS ────────────────────────────────────────────────────────────────────

interface Incident {
  id:          string; // ID real e interno del documento en Firestore (Ej: '36S40VW3')
  report_id:   string; // ID de despliegue o contrato
  area_id:     string;
  zone_id?:    string;
  closure_evidence?: string;
  type:        string;
  is_iap:      boolean;
  description: string;
  shift:       string;
  status:      string;
  reported_by: string;
  created_at:  string;
  evidences?:  string[];
  feedback?:   string;
  client_id?:  string;
}

// ─── CONFIG ───────────────────────────────────────────────────────────────────

const REPORTS_API = import.meta.env.VITE_REPORTS_API_URL || 'http://localhost:8001';
const USERS_API = window.location.origin + '/api/users/v1/admin/users/';

interface SupervisorOption {
  user_id: string;
  name: string;
  last_name?: string;
  assigned_areas?: string[];
}
const CLIENT_ID   = import.meta.env.VITE_CLIENT_ID || 'cliente_prueba_123';


// ─── FIRESTORE RAW TYPE ───────────────────────────────────────────────────────
interface FirestoreTimestamp { seconds: number; toDate?: () => Date; }
interface RawIncident {
  report_id?: string; area_id?: string; type?: string; is_iap?: boolean;
  description?: string; shift?: string; status?: string; reported_by?: string;
  created_at?: string | FirestoreTimestamp; evidences?: string[];
  feedback?: string; client_id?: string;
}
// ─── HELPERS ──────────────────────────────────────────────────────────────────

function mapStatus(status: string): string {
  const map: Record<string, string> = {
    open:            'Pendiente',
    reviewing:       'En Revisión',
    assigned:        'En Revisión',
    en_proceso:      'En Proceso',
    pending_closure: 'Petición de Cierre',
    closed:          'Cerrado',
  };
  return map[status] ?? 'En Revisión';
}

function incidentCode(inc: any): string {
  const d = new Date(inc?.created_at);
  const year = isNaN(d.getTime()) ? new Date().getFullYear() : d.getFullYear();
  const seq = inc?.seq_id ?? (Number(inc?.report_id) || Number(inc?.id) || 0);
  return `INC-${year}-${String(seq).padStart(4, '0')}`;
}

function getSLA(inc: any): 'ok' | 'warning' | 'critical' | 'none' {
  if (inc.status === 'closed') return 'ok';
  if (!inc.deadline) return 'none';
  const dl = new Date(inc.deadline + 'T12:00:00');
  const now = new Date(); now.setHours(12, 0, 0, 0);
  const days = Math.round((dl.getTime() - now.getTime()) / 86400000);
  if (days < 0) return 'critical';
  if (days <= 3) return 'warning';
  return 'ok';
}

const statusColors: Record<string, string> = {
  'Pendiente':          'bg-pink-500/20 text-pink-400 border-pink-500/50',
  'En Revisión':        'bg-yellow-500/20 text-yellow-400 border-yellow-500/50',
  'En Proceso':         'bg-orange-500/20 text-orange-400 border-orange-500/50',
  'Petición de Cierre': 'bg-blue-500/20 text-blue-400 border-blue-500/50',
  'Cerrado':            'bg-green-500/20 text-[#16A34A] border-green-500/50',
};

const slaColors = { ok: 'bg-[#16A34A]', warning: 'bg-[#E8941A]', critical: 'bg-[#D72631]', none: 'bg-gray-500' };

// ─── COMPONENTE ───────────────────────────────────────────────────────────────

type Props = { initialAreaFilter?: string; userRole?: string; userArea?: string; userAssignedAreas?: string[]; userAssignedZones?: string[]; userId?: string };
export default function IncidentManagement({ initialAreaFilter, userRole, userArea, userAssignedAreas, userAssignedZones, userId }: Props) {
  const [incidents, setIncidents]               = useState<Incident[]>([]);
  const [loading, setLoading]                   = useState(true);
  const [error, setError]                       = useState<string | null>(null);
  const [filter, setFilter]                     = useState('all');
  const [searchTerm, setSearchTerm]             = useState(initialAreaFilter || '');
  const [selectedIncident, setSelectedIncident] = useState<Incident | null>(null);
  const [updatingStatus, setUpdatingStatus]     = useState(false);
  const [feedbackText, setFeedbackText]         = useState('');
  const [analysisText, setAnalysisText] = useState('');
  const [deadline, setDeadline] = useState('');
  const [exportingPdf, setExportingPdf] = useState(false);
  const [showRecategorize, setShowRecategorize] = useState(false);
  const [newCategory, setNewCategory] = useState('');
  const [controlMeasure, setControlMeasure] = useState<string[]>([]);
  const [customMeasure, setCustomMeasure] = useState('');
  const [supervisorCauses, setSupervisorCauses] = useState<string[]>([]);
  const [consequences, setConsequences] = useState<string[]>([]);
  const [showConsequencesDropdown, setShowConsequencesDropdown] = useState(false);
  const [causeSearch, setCauseSearch] = useState('');
  const [pendingType, setPendingType] = useState('');
  const [lightboxImg, setLightboxImg] = useState<string | null>(null);
  const [showCauseDropdown, setShowCauseDropdown] = useState(false);
  const [filterArea, setFilterArea] = useState('');
  const [filterType, setFilterType] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [filterIAP, setFilterIAP] = useState('');
  const [dynamicAreas, setDynamicAreas] = useState<string[]>([]);
  const [fullAreas, setFullAreas] = useState<{name: string, jefe?: string, zone_details?: {name: string, responsable: string, email: string}[]}[]>([]);
  const [showCreateModal, setShowCreateModal] = useState(false);

  const [showMeasureDropdown, setShowMeasureDropdown] = useState(false);
  const [customMeasureText, setCustomMeasureText] = useState('');
  const CONSEQUENCES = [
  'Atrapamiento o aprisionamiento',
  'Atropellos',
  'Aplastamiento',
  'Caida de personas a distinto nivel',
  'Colision o choques',
  'Contacto/Exposicion con sustancias peligrosas o no peligrosas',
  'Contactos electricos directos o indirectos',
  'Contacto con elementos cortantes o punzantes',
  'Exposicion a gases o vapores',
  'Caida de objetos en manipulacion',
  'Contacto con superficies/fluidos calientes',
  'Exposicion a Ruido',
  'Estres termico',
  'Proyeccion de fragmentos/particulas/fluidos',
  'Derrames de productos quimicos o sustancias peligrosas',
  'Contacto con animales y/o insectos',
  'Caida de personas a mismo nivel',
  'Contactos termicos con superficies frias',
  'Exposicion a radiacion UV',
  'Golpes por o contra',
  'Pisada sobre objetos o superficies irregulares',
  'Sobreesfuerzos por manipulacion de cargas',
    'Incendio'
];

const PRECURSORS = [
    'No observar el entorno antes o durante la tarea.',
    'Ingresar a un area sin autorizacion.',
    'No respetar barreras, senalizacion o zonas demarcadas.',
    'Ubicarse en linea de fuego.',
    'Transitar bajo carga suspendida.',
    'Intervenir equipo en movimiento.',
    'No aplicar bloqueo o prueba de energia cero.',
    'Operar equipo movil sin autorizacion.',
    'Operar a velocidad inadecuada.',
    'Trasladar carga inestable o mal estibada.',
    'Usar herramientas o equipos defectuosos.',
    'Usar celular u otro distractor durante la tarea.',
    'No usar EPP requerido.',
    'Usar EPP inadecuado o en mal estado.',
    'Ejecutar trabajo critico sin permiso autorizado.',
    'No coordinar trabajos simultaneos.',
    'Realizar maniobra de izaje sin planificacion o segregacion.',
    'Realizar trabajo en caliente sin controlar combustibles.',
    'Usar andamio, plataforma o escala sin verificar condicion.',
    'Dejar materiales o herramientas con riesgo de caida.',
    'Desviarse del procedimiento o pauta de trabajo.',
    'No informar cambios en la tarea o condicion del area.',
    'Manipular quimicos o fluidos sin controles definidos.',
    'Usar aire comprimido sobre el cuerpo o hacia otra persona.',
    'Otra conducta subestandar.',
  ];

  const CONTROL_MEASURES = [
    'Elaborar y capacitar en procedimiento o instructivo',
    'Actualizar y capacitar en procedimiento o instructivo',
    'Reinstruir en procedimiento o instructivo',
    'Aplicar medida disciplinaria segun reglamento',
    'Corregir o reparar condicion fisica insegura',
    'Instalar o mejorar senalizacion o demarcacion',
    'Implementar barrera fisica o control de ingenieria',
    'Reemplazar equipo, herramienta o EPP defectuoso',
    'Realizar mantencion correctiva o preventiva',
    'Reforzar supervision o acompanamiento en terreno',
    'Derivar a comite paritario o prevencion de riesgos',
    'Otra medida de control',
  ];
  // Roles del sistema (prevencionista, analista, sso_manager = admin)
  const isAdmin = ['sso_manager', 'admin', 'analyst', 'analista', 'prevencion de riesgos', 'prevención de riesgos', 'prevencionista'].includes(userRole?.toLowerCase() || '');
  const isJefeArea = ['jefe de area', 'jefe de área', 'supervisor'].includes(userRole?.toLowerCase() || '');
  const isUsuario = userRole?.toLowerCase() === 'usuario';
  const isSupervisor = userRole?.toLowerCase() === 'supervisor';
  const isAnalyst = false;
  const canManage = isJefeArea || isAdmin;
  const canEditAnalysis = isJefeArea || isAdmin;
  const canRecategorize = isJefeArea || isAdmin;
  const canChangeStatus = isJefeArea || isAdmin;
  const etapaCierre = ['en_proceso', 'pending_closure', 'closed'].includes(selectedIncident?.status || '')
    || (pendingType || selectedIncident?.type) === 'Condicion Insegura';
  const canClose = (isAdmin || (pendingType || selectedIncident?.type) === 'Condicion Insegura') && etapaCierre;
  const canRequestClosure = isJefeArea && etapaCierre && selectedIncident?.status !== 'pending_closure';


  // Cargar supervisores (jefes de área) al abrir modal
  useEffect(() => {
    if (!selectedIncident) return;
    const fetchSupervisors = async () => {
      setLoadingSupervisors(true);
      try {
        const token = localStorage.getItem('sso_token') ?? '';
        const res = await fetch(USERS_API, {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const users = await res.json();
          const jefes = users.filter((u: any) =>
            u.role?.toLowerCase() === 'jefe de area' ||
            u.role?.toLowerCase() === 'jefe de área'
          );
          setSupervisors(jefes);
        }
      } catch (e) {
        console.error('Error cargando supervisores:', e);
      } finally {
        setLoadingSupervisors(false);
      }
    };
    fetchSupervisors();
  }, [selectedIncident]);

  const [closureEvidence, setClosureEvidence] = useState<File | null>(null);
  const [closureEvidencePreview, setClosureEvidencePreview] = useState<string | null>(null);
  const [supervisors, setSupervisors] = useState<SupervisorOption[]>([]);
  const [assignedSupervisor, setAssignedSupervisor] = useState('');
  const [showReassign, setShowReassign] = useState(false);
  const [reassignJustification, setReassignJustification] = useState('');
  const [loadingSupervisors, setLoadingSupervisors] = useState(false);

  const reloadReports = async () => {
    try {
      const token = localStorage.getItem('sso_token');
      const res = await fetch(REPORTS_API + '/v1/admin/reports', {
        headers: { 'Authorization': 'Bearer ' + token }
      });
      if (!res.ok) return;
      const data = await res.json();
      const parsed = data.map((d: any) => ({
        ...d, id: d.report_id || d.id, report_id: d.report_id || d.id,
        created_at: d.created_at || new Date().toISOString()
      })) as Incident[];
      parsed.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
      setIncidents(parsed);
    } catch (e) { console.error(e); }
  };

  // ── Cargar áreas desde API
  useEffect(() => {
    const fetchAreas = async () => {
      try {
        const token = localStorage.getItem('sso_token');
        const res = await fetch((import.meta.env.VITE_AREAS_API_URL || 'http://localhost:8107') + '/v1/areas/', {
          headers: { 'Authorization': 'Bearer ' + token }
        });
        if (res.ok) {
          const data = await res.json();
          const areasData = Array.isArray(data) ? data : data.data || [];
          setDynamicAreas(areasData.map((a: any) => a.name));
          setFullAreas(areasData.map((a: any) => ({name: a.name, jefe: a.jefe || '', zone_details: a.zone_details || []})));
        }
      } catch (e) { console.error('Error cargando áreas:', e); }
    };
    fetchAreas();
  }, []);

  // ── Listener en tiempo real corregido (Inyección de IDs y normalización) ───
  useEffect(() => {
    setLoading(true);
    const fetchIncidents = async () => {
      try {
        const token = localStorage.getItem('sso_token');
        const res = await fetch(REPORTS_API + '/v1/admin/reports', {
          headers: { 'Authorization': 'Bearer ' + token }
        });
        if (!res.ok) throw new Error('Error ' + res.status);
        const data = await res.json();
        const parsed = data.map((d: any) => ({
          ...d,
          id: d.report_id || d.id,
          report_id: d.report_id || d.id,
          created_at: d.created_at || new Date().toISOString()
        })) as Incident[];
        parsed.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
        setIncidents(parsed);
        setLoading(false);
        setError(null);
      } catch (err) {
        console.error(err);
        setError('No se pudo cargar incidentes.');
        setLoading(false);
      }
    };
    fetchIncidents();
  }, []);

  const replaceClosureEvidence = async (incident: Incident, b64: string) => {
    const targetId = incident.id || incident.report_id;
    const token = localStorage.getItem('sso_token') ?? '';
    await fetch(`${REPORTS_API}/v1/reports/${targetId}/status`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
      body: JSON.stringify({ status: incident.status, closure_evidence: b64 }),
    });
    setSelectedIncident(prev => prev ? { ...prev, closure_evidence: b64 } : prev);
    setIncidents(prev => prev.map(i => (i.id || i.report_id) === targetId ? { ...i, closure_evidence: b64 } : i));
  };

  const handleUpdateStatus = async (incident: Incident, newStatus: string) => {
    if (!incident) return;
    setUpdatingStatus(true);
    
    const targetId = incident.id || incident.report_id;

    try {
      const token = localStorage.getItem('sso_token') ?? '';
      const response = await fetch(`${REPORTS_API}/v1/reports/${targetId}/status`, {
        method:  'PATCH',
        headers: {
          'Content-Type':  'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({ status: newStatus, feedback: feedbackText, analysis: analysisText, causes: supervisorCauses, consequences: consequences, control_measures: controlMeasure, deadline: deadline, type: pendingType || selectedIncident?.type, is_iap: (pendingType || selectedIncident?.type) === 'IAP', closure_evidence: closureEvidencePreview || '' }),
      });

      if (!response.ok) {
        throw new Error(`Error en servidor: ${response.status}`);
      }

      // Recargar reportes
      reloadReports();
      // Si es reviewing o assigned (cambios automáticos), no cerrar modal ni mostrar popup
      if (newStatus === 'reviewing' || newStatus === 'assigned' || newStatus === 'pending_validation') {
        setIncidents(prev => prev.map(i => (i.id || i.report_id) === targetId ? { ...i, status: newStatus } : i));
        if (selectedIncident) setSelectedIncident({ ...selectedIncident, status: newStatus });
      } else {
        // Cerrar modal y mostrar éxito solo para cambios manuales
        setSelectedIncident(null);
        setAnalysisText(''); setDeadline(''); setControlMeasure([]); setShowMeasureDropdown(false); setCustomMeasureText(''); setAssignedSupervisor(''); setClosureEvidence(null); setClosureEvidencePreview(null);
        const labels: Record<string,string> = {en_proceso: 'En Proceso', pending_closure: 'Petición de Cierre', closed: 'Cerrado'};
        await import('sweetalert2').then(m => m.default.fire({
          icon: 'success',
          title: 'Estado actualizado',
          text: 'El incidente pasó a ' + (labels[newStatus] || newStatus) + ' exitosamente.',
          confirmButtonColor: '#00E5FF',
          background: '#0B1E36',
          color: '#fff',
        }));
      }
    } catch (err) {
      console.error("Error al actualizar estado y feedback:", err);
      alert('Error al actualizar el estado del reporte. Verifica la conexión con la API.');
    } finally {
      setUpdatingStatus(false);
    }
  };
  // Auto-avance de estado cuando se cumplen condiciones
  useEffect(() => {
    if (!selectedIncident || !canEditAnalysis) return;
    
    // reviewing → assigned: cuando se completan análisis + plazo + medida
    if (selectedIncident.status === 'reviewing' && analysisText && deadline && controlMeasure.length > 0) {
      handleUpdateStatus(selectedIncident, 'assigned');
    }
  }, [analysisText, deadline, controlMeasure]);

  useEffect(() => {
    if (!selectedIncident || !canEditAnalysis) return;
    
    // assigned → pending_validation: cuando se sube evidencia
    if (selectedIncident.status === 'assigned' && closureEvidence) {
      handleUpdateStatus(selectedIncident, 'pending_validation');
    }
  }, [closureEvidence]);

  // ── Filtros Modificados Únicamente para Manejo de Roles Estrictos ──────────
  const filteredIncidents = incidents.filter((inc) => {
    const sla = getSLA(inc);
    
    const incidentArea = inc.area_id?.trim().toLowerCase() || '';

    // Filtrado por rol
    if (isUsuario) {
      if (inc.reported_by !== userId) return false;
    } else if (isJefeArea) {
      const zonas = (userAssignedZones || []).map(z => z.trim().toLowerCase());
      if (isSupervisor && zonas.length > 0) {
        // El supervisor ve solo las zonas que tiene a cargo
        const incidentZone = inc.zone_id?.trim().toLowerCase() || '';
        if (!zonas.includes(incidentZone)) return false;
      } else {
        const areas = userAssignedAreas && userAssignedAreas.length > 0
          ? userAssignedAreas.map(a => a.trim().toLowerCase())
          : [];
        if (areas.length > 0 && !areas.includes(incidentArea)) return false;
      }
    }
    // Admin ve todo — sin filtro

    const matchesFilter =
      filter === 'all'    ||
      (filter === 'pending' && inc.status !== 'closed') ||
      (filter === 'iap'     && inc.is_iap) ||
      (filter === 'overdue' && sla === 'critical');

    const matchesSearch =
      inc.id?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      inc.report_id?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      inc.area_id?.toLowerCase().includes(searchTerm.toLowerCase())   ||
      inc.zone_id?.toLowerCase().includes(searchTerm.toLowerCase())   ||
      inc.description?.toLowerCase().includes(searchTerm.toLowerCase());

    const matchArea = !filterArea || inc.area_id === filterArea;
    const matchStatus = !filterStatus || inc.status === filterStatus;
    const matchIAP = !filterIAP || (filterIAP === 'iap' ? inc.is_iap : !inc.is_iap);
    return matchesFilter && matchesSearch && matchArea && matchStatus && matchIAP;
  });

  const stats = {
    total:   filteredIncidents.length,
    pending: filteredIncidents.filter(i => i.status !== 'closed').length,
    iap:     filteredIncidents.filter(i => i.is_iap).length,
    overdue: filteredIncidents.filter(i => getSLA(i) === 'critical').length,
  };


  // Resumen por área
  const areaStats = Object.entries(
    filteredIncidents.reduce((acc: Record<string, { active: number; overdue: number; closed: number; total: number }>, inc) => {
      const area = inc.area_id || 'Sin área';
      if (!acc[area]) acc[area] = { active: 0, overdue: 0, closed: 0, total: 0 };
      acc[area].total++;
      if (inc.status === 'closed') acc[area].closed++;
      else {
        acc[area].active++;
        if (getSLA(inc) === 'critical') acc[area].overdue++;
      }
      return acc;
    }, {})
  ).sort((a, b) => b[1].active - a[1].active);

  const [showAreaStats, setShowAreaStats] = useState(false);

  const exportToWord = (incident: Incident) => {
    const statusTimeline = [
      { estado: 'Enviado', desc: 'El reporte fue recibido por el sistema' },
      { estado: 'En Revision', desc: 'Un analista de riesgos esta evaluando el hallazgo' },
      { estado: 'Accion Asignada', desc: 'Se definio una accion correctiva y responsable' },
      { estado: 'Pendiente Validacion', desc: 'El supervisor solicito validacion de cierre' },
      { estado: 'Cerrado', desc: 'La accion correctiva fue completada' },
    ];
    const currentStatus = mapStatus(incident.status);
    const html = `
      <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word">
      <head><meta charset="utf-8"><title>Reporte ${incident.id}</title>
      <style>
        body { font-family: Calibri, Arial; margin: 40px; color: #333; }
        h1 { color: #0B1E36; border-bottom: 3px solid #00E5FF; padding-bottom: 10px; }
        h2 { color: #0B1E36; margin-top: 30px; border-bottom: 1px solid #ccc; padding-bottom: 5px; }
        table { border-collapse: collapse; width: 100%; margin: 15px 0; }
        td, th { border: 1px solid #ddd; padding: 10px; text-align: left; }
        th { background: #0B1E36; color: white; }
        .badge { display: inline-block; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: bold; }
        .active { background: #00E5FF; color: #0B1E36; }
        .inactive { background: #eee; color: #999; }
        .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
        .info-item { padding: 8px; background: #f5f5f5; border-radius: 4px; }
        .info-label { font-size: 11px; color: #666; }
        .info-value { font-weight: bold; }
        .timeline { margin: 20px 0; }
        .timeline-item { padding: 12px 20px; border-left: 3px solid #ddd; margin-left: 10px; margin-bottom: 5px; }
        .timeline-item.done { border-left-color: #16A34A; }
        .timeline-item.current { border-left-color: #00E5FF; background: #f0feff; }
        .footer { margin-top: 40px; padding-top: 15px; border-top: 1px solid #ccc; font-size: 11px; color: #999; }
      </style></head>
      <body>
        <h1>Reporte de Hallazgo #${incident.id?.slice(-8).toUpperCase()}</h1>
        <p><em>Vigia Industrial - Sistema Integral de Gestion de Riesgos</em></p>

        <h2>Informacion del Reporte</h2>
        <table>
          <tr><th>Campo</th><th>Valor</th></tr>
          <tr><td>ID</td><td>${incident.id?.slice(-8).toUpperCase()}</td></tr>
          <tr><td>Area</td><td>${incident.area_id}</td></tr>
          <tr><td>Tipo</td><td>${incident.type}</td></tr>
          <tr><td>IAP</td><td>${incident.is_iap ? 'Si - Alto Potencial' : 'No'}</td></tr>
          <tr><td>Estado actual</td><td>${currentStatus}</td></tr>
          <tr><td>Descripcion</td><td>${incident.description || 'Sin descripcion'}</td></tr>
          <tr><td>Fecha de creacion</td><td>${new Date(incident.created_at).toLocaleDateString('es-CL')}</td></tr>
        </table>

        ${incident.causes && incident.causes.length > 0 ? '<h2>Causas Asociadas</h2><ul>' + incident.causes.map((ca: string) => '<li>' + ca + '</li>').join('') + '</ul>' : ''}

        <h2>Timeline de Estado</h2>
        <div class="timeline">
          ${statusTimeline.map(s => {
            const idx = statusTimeline.findIndex(x => x.estado === currentStatus);
            const thisIdx = statusTimeline.indexOf(s);
            const cls = thisIdx < idx ? 'done' : thisIdx === idx ? 'current' : '';
            return '<div class="timeline-item ' + cls + '"><strong>' + s.estado + '</strong><br><span style="font-size:12px;color:#666">' + s.desc + '</span></div>';
          }).join('')}
        </div>

        <h2>Evidencia Fotografica</h2>
        ${incident.evidences?.[0] ? '<p><em>Imagen disponible en el sistema digital</em></p>' : '<p>Sin evidencia adjunta</p>'}

        <div class="footer">
          <p>Documento generado automaticamente por Vigia Industrial el ${new Date().toLocaleDateString('es-CL')} a las ${new Date().toLocaleTimeString('es-CL')}</p>
          <p>Este documento es una representacion del estado del reporte al momento de la exportacion.</p>
        </div>
      </body></html>
    `;
    const blob = new Blob([html], { type: 'application/msword' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'Reporte_' + (incident.id?.slice(-8).toUpperCase() || 'SIN_ID') + '.doc';
    a.click();
    URL.revokeObjectURL(url);
  };

  const toBase64 = async (url: string): Promise<string> => {
    try {
      const res = await fetch(url);
      const blob = await res.blob();
      return new Promise((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result as string);
        reader.readAsDataURL(blob);
      });
    } catch { return ''; }
  };

  const exportToPdf = async (incident: Incident) => {
    if (exportingPdf) return;
    setExportingPdf(true);
    try {
    const currentStatus = mapStatus(incident.status);
    const causesStr = (incident.causes || []).join(', ') || 'Sin asignar';
    const allUrls = incident.evidences?.length ? incident.evidences : incident.image_url ? [incident.image_url] : [];
    const imgBase64List: string[] = [];
    for (const url of allUrls) {
      try { const proxyUrl = url.includes('ssoevidencias.blob.core.windows.net') ? url.replace('https://ssoevidencias.blob.core.windows.net/sso-evidencias/', window.location.origin + '/api/evidence/') : url; const b = await toBase64(proxyUrl); if (b) imgBase64List.push(b); } catch(e) {}
    }
    const measuresStr = (incident.control_measures || []).join(', ') || 'Sin asignar';
    const html = `
      <div style="font-family: Calibri, Arial; padding: 20px; color: #333; font-size: 12px;">
        <h1 style="color: #0B1E36; border-bottom: 3px solid #00E5FF; padding-bottom: 10px;">
          Reporte de Hallazgo INC-${new Date(incident.created_at).getFullYear()}-${String(incident.seq_id || '0000').padStart(4, '0')}
        </h1>
        <p><em>Vigia Industrial - Sistema Integral de Gestion de Riesgos</em></p>

        <h2 style="color: #0B1E36; margin-top: 15px; font-size: 14px;">1. Datos del Reporte</h2>
        <table style="border-collapse: collapse; width: 100%; margin: 5px 0; page-break-inside: avoid;">
          <tr><th style="border: 1px solid #ddd; padding: 5px 8px; background: #0B1E36; font-size: 11px; color: white; text-align: left; width: 35%;">Campo</th>
              <th style="border: 1px solid #ddd; padding: 5px 8px; background: #0B1E36; font-size: 11px; color: white; text-align: left;">Valor</th></tr>
          <tr><td style="border: 1px solid #ddd; padding: 5px 8px; font-size: 11px;">ID</td><td style="border: 1px solid #ddd; padding: 5px 8px; font-size: 11px;">INC-${new Date(incident.created_at).getFullYear()}-${String(incident.seq_id || '0000').padStart(4, '0')}</td></tr>
          <tr><td style="border: 1px solid #ddd; padding: 5px 8px; font-size: 11px;">Area</td><td style="border: 1px solid #ddd; padding: 5px 8px; font-size: 11px;">${incident.area_id}</td></tr>
          <tr><td style="border: 1px solid #ddd; padding: 5px 8px; font-size: 11px;">Zona</td><td style="border: 1px solid #ddd; padding: 5px 8px; font-size: 11px;">${incident.zone_id || 'Sin zona'}</td></tr>
          <tr><td style="border: 1px solid #ddd; padding: 5px 8px; font-size: 11px;">Tipo</td><td style="border: 1px solid #ddd; padding: 5px 8px; font-size: 11px;">${incident.type}</td></tr>
          <tr><td style="border: 1px solid #ddd; padding: 5px 8px; font-size: 11px;">IAP</td><td style="border: 1px solid #ddd; padding: 5px 8px; font-size: 11px;">${incident.is_iap ? 'Si - Alto Potencial' : 'No'}</td></tr>
          <tr><td style="border: 1px solid #ddd; padding: 5px 8px; font-size: 11px;">Estado</td><td style="border: 1px solid #ddd; padding: 5px 8px; font-size: 11px;">${currentStatus}</td></tr>
          <tr><td style="border: 1px solid #ddd; padding: 5px 8px; font-size: 11px;">Fecha reporte</td><td style="border: 1px solid #ddd; padding: 5px 8px; font-size: 11px;">${new Date(incident.created_at).toLocaleDateString('es-CL')}</td></tr>
          <tr><td style="border: 1px solid #ddd; padding: 5px 8px; font-size: 11px;">Reportado por</td><td style="border: 1px solid #ddd; padding: 5px 8px; font-size: 11px;">${incident.reported_by || 'Sin dato'}</td></tr>
        </table>

        <div style="height: 20px;"></div>
        <h2 style="color: #0B1E36; font-size: 14px; margin: 0; padding: 0;">2. Descripcion</h2>
        <div style="height: 15px;"></div>
        <div style="background: #f5f5f5; padding: 12px; border-radius: 6px; line-height: 1.6; font-size: 11px;">${incident.description || 'Sin descripcion'}</div>
        <div style="height: 20px;"></div>
        ${imgBase64List.length ? '<div style="height: 20px;"></div><h2 style="color: #0B1E36; font-size: 14px; margin: 0;">Evidencia fotografica (' + imgBase64List.length + ' foto(s))</h2><div style="height: 20px;"></div>' + imgBase64List.map(b => '<img src="' + b + '" style="max-width: 60%; max-height: 120px; border: 1px solid #ddd; border-radius: 6px; display: block; page-break-inside: avoid; break-inside: avoid;" /><div style="height: 20px;"></div>').join('') : ''}

        <div style="page-break-inside: avoid;">
        <h2 style="color: #0B1E36; margin-top: 15px; font-size: 14px;">3. Analisis</h2>
        <table style="border-collapse: collapse; width: 100%; margin: 5px 0; page-break-inside: avoid;">
          <tr><th style="border: 1px solid #ddd; padding: 5px 8px; background: #0B1E36; font-size: 11px; color: white; text-align: left; width: 35%;">Campo</th>
              <th style="border: 1px solid #ddd; padding: 5px 8px; background: #0B1E36; font-size: 11px; color: white; text-align: left;">Valor</th></tr>
          <tr><td style="border: 1px solid #ddd; padding: 5px 8px; font-size: 11px;">Consecuencia probable</td><td style="border: 1px solid #ddd; padding: 5px 8px; font-size: 11px;">${incident.consequences?.length ? incident.consequences.join('; ') : 'Sin registro'}</td></tr>
          <tr><td style="border: 1px solid #ddd; padding: 5px 8px; font-size: 11px;">Causas / Precursores</td><td style="border: 1px solid #ddd; padding: 5px 8px; font-size: 11px;">${causesStr}</td></tr>
          <tr><td style="border: 1px solid #ddd; padding: 5px 8px; font-size: 11px;">Analisis del supervisor</td><td style="border: 1px solid #ddd; padding: 5px 8px; font-size: 11px;">${incident.analysis || 'Sin analisis'}</td></tr>
          <tr><td style="border: 1px solid #ddd; padding: 5px 8px; font-size: 11px;">Medidas de control</td><td style="border: 1px solid #ddd; padding: 5px 8px; font-size: 11px;">${measuresStr}</td></tr>
          <tr><td style="border: 1px solid #ddd; padding: 5px 8px; font-size: 11px;">Plazo medida de control</td><td style="border: 1px solid #ddd; padding: 5px 8px; font-size: 11px;">${incident.deadline || 'Sin plazo'}</td></tr>
          <tr><td style="border: 1px solid #ddd; padding: 5px 8px; font-size: 11px;">Feedback al usuario que reporta</td><td style="border: 1px solid #ddd; padding: 5px 8px; font-size: 11px;">${incident.feedback || 'Sin feedback'}</td></tr>
        </table>
        </div>

        ${incident.closure_evidence ? '<div style="height: 20px;"></div><h2 style="color: #0B1E36; font-size: 14px; margin: 0;">Evidencia de cierre</h2><div style="height: 20px;"></div><img src="' + incident.closure_evidence + '" style="max-width: 60%; max-height: 120px; border: 1px solid #ddd; border-radius: 6px; display: block; page-break-inside: avoid; break-inside: avoid;" /><div style="height: 20px;"></div>' : ''}

        <div style="margin-top: 40px; padding-top: 15px; border-top: 1px solid #ccc; font-size: 11px; color: #999;">
          <p>Documento generado por Vigia Industrial el ${new Date().toLocaleDateString('es-CL')} a las ${new Date().toLocaleTimeString('es-CL')}</p>
        </div>
      </div>
    `;
    const container = document.createElement('div');
    container.style.width = '210mm';
    container.style.padding = '15mm';
    container.style.boxSizing = 'border-box';
    container.innerHTML = html;
    document.body.appendChild(container);
    await html2pdf().set({
      margin: [10, 10, 10, 10],
      filename: 'Reporte_' + (incident.id?.slice(-8).toUpperCase() || 'SIN_ID') + '.pdf',
      html2canvas: { scale: 2, useCORS: true },
      jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' },
      pagebreak: { mode: ['css', 'legacy'], avoid: ['img', 'table'] }
    }).from(container).save();
    document.body.removeChild(container);
    } finally { setExportingPdf(false); }
  };

  return (
    <div className="h-full p-6 overflow-auto">
      <div className="mb-6">
        <h1 className="text-4xl mb-2 tracking-tight"
          style={{ fontFamily: 'var(--font-display)', fontWeight: 700 }}>
          GESTIÓN DE INCIDENTES
        </h1>
        <HelpTooltip steps={[
      { icon: '📋', title: 'Lista de incidentes', description: 'Muestra todos los incidentes registrados desde la app móvil. Cada tarjeta tiene el área, tipo de riesgo, estado actual y si es IAP (Incidente de Alto Potencial).' },
      { icon: '🔍', title: 'Filtros rápidos', description: 'Usa los botones Todos, Pendientes, IAP y Vencidos para filtrar la lista. Los incidentes vencidos son los que superaron la fecha de plazo de la medida de control y siguen abiertos.' },
      { icon: '✏️', title: 'Gestionar un incidente', description: 'Haz clic en cualquier incidente para abrir su detalle. Desde ahí puedes cambiar el estado (En Revisión, Asignado, Cerrado) y agregar feedback.' },
      { icon: '⚠️', title: 'IAP — Alto Potencial', description: 'Los incidentes marcados con IAP requieren atención prioritaria. Se destacan con badge rojo y aparecen en el filtro IAP.' },
    ]} />
        <div className="flex items-center gap-4">
          <p className="text-muted-foreground">
            Ciclo de vida completo de hallazgos reportados
            <span className="ml-2 text-xs text-[#16A34A]">● En tiempo real</span>
          </p>
          <button onClick={() => setShowCreateModal(true)}
            className="px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:bg-primary/90 transition-all">
            + Nuevo Reporte
          </button>
        </div>
      </div>

      {error && (
        <div className="mb-4 p-4 bg-[#D72631]/20 border border-[#D72631]/50 rounded-lg text-[#D72631] flex items-center gap-2">
          <AlertCircle size={18} />{error}
        </div>
      )}

      {/* Tarjetas Estadísticas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        {[
          { label: 'Total Incidentes',     value: stats.total,   color: '' },
          { label: 'Activos (sin cerrar)', value: stats.pending, color: 'text-[#E8941A]' },
          { label: 'Alto Potencial (IAP)', value: stats.iap,     color: 'text-[#D72631]' },
          { label: 'Vencidos',             value: stats.overdue, color: 'text-[#D72631]' },
        ].map(({ label, value, color }) => (
          <div key={label} className="bg-card border border-border rounded-lg p-4">
            <div className="text-sm text-muted-foreground mb-1">{label}</div>
            <div className={`text-3xl font-mono font-semibold ${color}`}>
              {loading ? '...' : value}
            </div>
          </div>
        ))}
      </div>

      {/* Resumen por área */}
      <div className="mb-6">
        <button onClick={() => setShowAreaStats(!showAreaStats)}
          className="text-sm text-primary hover:text-primary/80 flex items-center gap-1 mb-2">
          {showAreaStats ? '▼' : '▶'} Resumen por area ({areaStats.length} areas)
        </button>
        {showAreaStats && (
          <div className="bg-card border border-border rounded-lg overflow-hidden">
            <table className="w-full text-sm">
              <thead><tr className="bg-secondary/50 text-muted-foreground">
                <th className="text-left py-2 px-4">Donde ocurrió</th>
                <th className="text-center py-2 px-4">Activos</th>
                <th className="text-center py-2 px-4">Vencidos</th>
                <th className="text-center py-2 px-4">Cerrados</th>
                <th className="text-center py-2 px-4">Total</th>
              </tr></thead>
              <tbody>{areaStats.map(([area, s]) => (
                <tr key={area} className="border-t border-border/30 hover:bg-secondary/20 cursor-pointer" onClick={() => { setFilterArea(area); setShowAreaStats(false); }}>
                  <td className="py-2 px-4 font-medium">{area}</td>
                  <td className="py-2 px-4 text-center text-[#E8941A]">{(s as any).active}</td>
                  <td className="py-2 px-4 text-center text-[#D72631]">{(s as any).overdue}</td>
                  <td className="py-2 px-4 text-center text-[#16A34A]">{(s as any).closed}</td>
                  <td className="py-2 px-4 text-center">{(s as any).total}</td>
                </tr>
              ))}</tbody>
            </table>
          </div>
        )}
      </div>

      <div className="bg-card border border-border rounded-lg p-6">
        {/* Filtros de Navegación */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={18} />
            <input type="text" placeholder="Buscar por ID, donde ocurrió o descripción..."
              value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-secondary border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary" />
          </div>
          <div className="flex gap-2 mt-2">
            <select value={filterArea} onChange={e => setFilterArea(e.target.value)}
              className="flex-1 px-3 py-2 bg-secondary border border-border rounded-lg text-sm">
              <option value="">Todos los lugares</option>
              {dynamicAreas.map(a => <option key={a} value={a}>{a}</option>)}
            </select>
            <select value={filterStatus} onChange={e => setFilterStatus(e.target.value)}
              className="flex-1 px-3 py-2 bg-secondary border border-border rounded-lg text-sm">
              <option value="">Todos los estados</option>
              <option value="open">Abierto</option>
              <option value="en_proceso">En Proceso</option>
              <option value="closed">Cerrado</option>
            </select>
            <select value={filterIAP} onChange={e => setFilterIAP(e.target.value)}
              className="flex-1 px-3 py-2 bg-secondary border border-border rounded-lg text-sm">
              <option value="">IAP: Todos</option>
              <option value="iap">Solo IAP</option>
              <option value="no_iap">Sin IAP</option>
            </select>
          </div>
          <div className="flex gap-2 flex-wrap">
            {[
              { id: 'all',     label: 'Todos' },
              { id: 'pending', label: 'Activos' },
              { id: 'iap',     label: 'IAP' },
              { id: 'overdue', label: 'Vencidos' },
            ].map((f) => (
              <button key={f.id} onClick={() => setFilter(filter === f.id ? 'all' : f.id)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  filter === f.id
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
                }`}>
                {f.label}
              </button>
            ))}
          </div>
        </div>

        {/* Tabla descriptiva */}
        {loading ? (
          <div className="text-center py-12 text-muted-foreground">Cargando incidentes...</div>
        ) : filteredIncidents.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">No hay incidentes que mostrar.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border">
                  {['ID', 'Donde ocurrió', 'Tipo', 'IAP', 'Estado', 'Plazo', 'Acciones'].map(h => (
                    <th key={h} className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filteredIncidents.map((inc) => (
                  <tr key={inc.id}
                    className="border-b border-border/50 hover:bg-secondary/30 transition-colors cursor-pointer">
                    <td className="py-4 px-4">
                      <span className="font-mono text-xs">{incidentCode(inc)}</span>
                    </td>
                    <td className="py-4 px-4 text-sm"><span className="font-medium">{inc.zone_id || inc.area_id}</span>{inc.zone_id && <span className="block text-xs text-muted-foreground">{inc.area_id}</span>}</td>
                    <td className="py-4 px-4 text-sm">{inc.type}</td>
                    <td className="py-4 px-4">
                      {inc.is_iap && (
                        <span className="px-2 py-1 bg-[#D72631]/20 text-[#D72631] border border-[#D72631]/50 rounded text-xs font-medium">IAP</span>
                      )}
                    </td>
                    <td className="py-4 px-4">
                      <span className={`px-2 py-1 rounded border text-xs font-medium ${statusColors[mapStatus(inc.status)] ?? ''}`}>
                        {mapStatus(inc.status)}
                      </span>
                    </td>
                    <td className="py-4 px-4">
                      <div className={`w-3 h-3 rounded-full ${slaColors[getSLA(inc)]}`} />
                    </td>
                    <td className="py-4 px-4">
                      {/* Usuario y analista: solo lectura */}
                      {(isUsuario || isAnalyst) ? (
                        <button onClick={() => {
                          setSelectedIncident(inc);
                          setFeedbackText(inc.feedback ?? '');
                          setAnalysisText(inc.analysis ?? '');
                          setSupervisorCauses(inc.causes ?? []);
                          setControlMeasure(inc.control_measures ?? []);
                          setConsequences(inc.consequences ?? []);
                          setDeadline(inc.deadline ?? '');
                          setPendingType(inc.type ?? '');
                        }}
                         className="px-3 py-1 bg-secondary text-muted-foreground rounded text-xs hover:bg-secondary/80 transition-all">
                          Ver detalle
                        </button>
                      ) : (
                      <button onClick={() => {
                          setSelectedIncident(inc);
                          setFeedbackText(inc.feedback ?? '');
                          setAnalysisText(inc.analysis ?? '');
                          setSupervisorCauses(inc.causes ?? []);
                          setControlMeasure(inc.control_measures ?? []);
                          setConsequences(inc.consequences ?? []);
                          setDeadline(inc.deadline ?? '');
                          setPendingType(inc.type ?? '');
                          if (inc.status === 'open' && canManage) {
                            handleUpdateStatus(inc, 'reviewing');
                          }
                        }}
                         className="px-3 py-1 bg-primary/20 text-primary rounded text-xs hover:bg-primary/30 transition-all">
                          Gestionar
                      </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Lightbox para evidencia */}
      {lightboxImg && (
        <div className="fixed inset-0 bg-black/80 z-[60] flex items-center justify-center p-4" onClick={() => setLightboxImg(null)}>
          <img src={lightboxImg} alt="evidencia ampliada" className="max-w-full max-h-[90vh] object-contain rounded-lg" />
          <button onClick={() => setLightboxImg(null)} className="absolute top-4 right-4 text-white text-2xl bg-black/50 rounded-full w-10 h-10 flex items-center justify-center hover:bg-black/70">✕</button>
        </div>
      )}

      {/* Modal de Control Operativo */}
      {selectedIncident && (isUsuario || isAnalyst) && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4" onClick={() => setSelectedIncident(null)}>
          <div className="bg-card border border-border rounded-xl w-full max-w-3xl max-h-[95vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-bold">Detalle del Reporte</h2>
                <button onClick={() => setSelectedIncident(null)} className="text-muted-foreground hover:text-foreground text-xl">✕</button>
              </div>

              <div className="grid grid-cols-2 gap-3 mb-4">
                <div className="p-3 bg-secondary/50 rounded-lg">
                  <p className="text-xs text-muted-foreground">ID</p>
                  <p className="text-sm font-medium">{selectedIncident.id}</p>
                </div>
                <div className="p-3 bg-secondary/50 rounded-lg">
                  <p className="text-xs text-muted-foreground">Estado</p>
                  <p className="text-sm font-medium">{mapStatus(selectedIncident.status)}</p>
                </div>
                <div className="p-3 bg-secondary/50 rounded-lg">
                  <p className="text-xs text-muted-foreground">Donde ocurrió</p>
                  <p className="text-sm font-medium">{selectedIncident.zone_id || selectedIncident.area_id}</p>
                  {selectedIncident.zone_id && <p className="text-xs text-muted-foreground">({selectedIncident.area_id})</p>}
                </div>
                <div className="p-3 bg-secondary/50 rounded-lg">
                  <p className="text-xs text-muted-foreground">Tipo</p>
                  <p className="text-sm font-medium">{selectedIncident.type}</p>
                </div>
                <div className="p-3 bg-secondary/50 rounded-lg">
                  <p className="text-xs text-muted-foreground">Fecha</p>
                  <p className="text-sm font-medium">{selectedIncident.created_at ? new Date(selectedIncident.created_at).toLocaleDateString('es-CL') : ''}</p>
                </div>
                <div className="p-3 bg-secondary/50 rounded-lg">
                  <p className="text-xs text-muted-foreground">IAP</p>
                  <p className="text-sm font-medium">{selectedIncident.is_iap ? 'Sí' : 'No'}</p>
                </div>
              </div>

              {selectedIncident.description && (
                <div className="mb-4 p-3 bg-secondary/50 rounded-lg">
                  <p className="text-xs text-muted-foreground mb-1">Descripción</p>
                  <p className="text-sm">{selectedIncident.description}</p>
                </div>
              )}

              {(selectedIncident.evidences?.length ? selectedIncident.evidences : selectedIncident.image_url ? [selectedIncident.image_url] : []).length > 0 && (
                <div className="mb-4">
                  <p className="text-xs text-muted-foreground mb-1">Evidencia ({(selectedIncident.evidences?.length || 1)} foto(s))</p>
                  <div className="flex gap-2 overflow-x-auto">
                    {(selectedIncident.evidences?.length ? selectedIncident.evidences : [selectedIncident.image_url]).map((url, i) => (
                      <img key={i} src={url} alt={"evidencia " + i} className="w-32 h-32 object-cover rounded-lg border border-border cursor-pointer hover:opacity-80 flex-shrink-0" onClick={() => setLightboxImg(url)} />
                    ))}
                  </div>
                </div>
              )}

              {selectedIncident.feedback && (
                <div className="mb-4 p-4 bg-primary/10 border border-primary/30 rounded-lg">
                  <p className="text-xs text-muted-foreground mb-1 font-semibold">💬 Feedback del Supervisor</p>
                  <p className="text-sm">{selectedIncident.feedback}</p>
                </div>
              )}

              {selectedIncident.analysis && (
                <div className="mb-4 p-3 bg-secondary/50 rounded-lg">
                  <p className="text-xs text-muted-foreground mb-1">Análisis</p>
                  <p className="text-sm">{selectedIncident.analysis}</p>
                </div>
              )}

              {selectedIncident.deadline && (
                <div className="mb-4 p-3 bg-secondary/50 rounded-lg">
                  <p className="text-xs text-muted-foreground mb-1">Plazo medida de control</p>
                  <p className="text-sm font-medium text-primary">{new Date(selectedIncident.deadline).toLocaleDateString('es-CL')}</p>
                </div>
              )}

              <button onClick={() => setSelectedIncident(null)} className="w-full py-2 bg-secondary border border-border rounded-lg text-sm hover:bg-secondary/80">
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}

      {selectedIncident && !isUsuario && !isAnalyst && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4" onClick={() => { setSelectedIncident(null); setShowRecategorize(false); setAnalysisText(''); setDeadline(''); setControlMeasure([]); setShowMeasureDropdown(false); setCustomMeasureText(''); setAssignedSupervisor(''); setClosureEvidence(null); setClosureEvidencePreview(null); setConsequences([]); }}>
          <div className="bg-card border border-border rounded-xl w-full max-w-3xl max-h-[95vh] overflow-y-auto" onClick={e => e.stopPropagation()}>

            {/* Header */}
            <div className="sticky top-0 bg-card border-b border-border p-4 flex items-center justify-between rounded-t-xl z-10">
              <h2 className="text-lg font-bold">Gestionar reporte</h2>

              <span className="px-2 py-1 bg-primary/20 text-primary rounded text-xs font-mono">
                ID: INC-{new Date(selectedIncident.created_at).getFullYear()}-{String(selectedIncident.seq_id || selectedIncident.report_id?.slice(-4) || '0000').padStart(4, '0')}
              </span>
            </div>

            <div className="p-5 space-y-1">

            {/* ══════════ SECCIÓN 1: GESTIÓN ══════════ */}
            <div className="border border-border rounded-lg p-4 mb-4">
              <h3 className="text-sm font-semibold text-primary mb-3 flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-xs font-bold text-primary">1</span>
                Gestión
              </h3>

              <div className="grid grid-cols-3 gap-3 mb-3">
                <div>
                  <span className="text-xs text-muted-foreground">Donde ocurrió</span>
                  <p className="text-sm font-medium">{selectedIncident.area_id}</p>
                </div>
                <div>
                  <span className="text-xs text-muted-foreground">Fecha</span>
                  <p className="text-sm font-medium">{new Date(selectedIncident.created_at).toLocaleDateString('es-CL')}</p>
                </div>
                <div>
                  <span className="text-xs text-muted-foreground">Tipo</span>
                  <p className="text-sm font-medium">{selectedIncident.type} {selectedIncident.is_iap && <span className="ml-1 px-1.5 py-0.5 bg-[#D72631]/20 text-[#D72631] text-xs rounded">IAP</span>}</p>
                </div>
              </div>

              <div className="mb-3">
                <span className="text-xs text-muted-foreground">Descripción</span>
                <p className="text-sm mt-1 bg-secondary p-2 rounded">{selectedIncident.description}</p>
              </div>

              {(selectedIncident.evidences?.length ? selectedIncident.evidences : selectedIncident.image_url ? [selectedIncident.image_url] : []).length > 0 && (
                <div className="mb-3">
                  <span className="text-xs text-muted-foreground">Evidencia ({(selectedIncident.evidences?.length || 1)} foto(s))</span>
                  <div className="flex gap-2 mt-1 overflow-x-auto">
                    {(selectedIncident.evidences?.length ? selectedIncident.evidences : [selectedIncident.image_url]).map((url, i) => (
                      <img key={i} src={url} alt={"evidencia " + i} className="w-32 h-32 object-cover rounded-lg border border-border cursor-pointer hover:opacity-80 flex-shrink-0" onClick={() => setLightboxImg(url)} />
                    ))}
                  </div>
                </div>
              )}

              <div>
                <span className="text-xs text-muted-foreground block mb-1">Supervisor responsable</span>
                <select value={selectedIncident.assigned_to || 'auto'}
                  onChange={e => {/* handled by existing logic */}}
                  className="w-full px-3 py-2 bg-secondary border border-border rounded-lg text-sm">
                  <option value="auto">{(() => { const a = fullAreas.find(x => x.name === selectedIncident.area_id); const zd = a?.zone_details?.find(z => z.name === (selectedIncident.zone_id || '')); return zd?.responsable ? zd.responsable + " (" + (selectedIncident.zone_id || selectedIncident.area_id) + ")" : a?.jefe ? a.jefe + " (" + selectedIncident.area_id + ")" : selectedIncident.area_id; })()}</option>
                </select>
              </div>
            </div>

            {/* ══════════ SECCIÓN 2: ANÁLISIS ══════════ */}
            <div className="border border-border rounded-lg p-4 mb-4">
              <h3 className="text-sm font-semibold text-primary mb-3 flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-xs font-bold text-primary">2</span>
                Análisis
              </h3>

              {/* Recategorizar */}
              <div className="mb-3">
                <label className="text-xs text-muted-foreground block mb-1">Recategorizar hallazgo</label>
                <select
                  value={pendingType || selectedIncident.type}
                  onChange={e => setPendingType(e.target.value)}
                  className="w-full px-3 py-2 bg-secondary border border-border rounded-lg text-sm">
                    <option value="Condicion Insegura">Condicion Insegura (derivar a cierre)</option>
                    <option value="Acto Inseguro">Accion Insegura</option>
                    <option value="Accidente">Accidente</option>
                    <option value="IAP">IAP</option>
                </select>
              </div>

              {/* Consecuencia probable */}
              <div className="mb-3">
                <label className="text-xs text-muted-foreground block mb-1">Consecuencia probable</label>
                <div className="flex flex-wrap gap-1 mb-2">
                  {consequences.map((c, i) => (
                    <span key={i} className="px-2 py-1 bg-[#D72631]/20 text-[#D72631] text-xs rounded-full flex items-center gap-1">
                      {c} <button onClick={() => setConsequences(prev => prev.filter((_, idx) => idx !== i))} className="text-[#D72631]/60 hover:text-[#D72631]">×</button>
                    </span>
                  ))}
                </div>
                <button onClick={() => setShowConsequencesDropdown(!showConsequencesDropdown)}
                  className="w-full px-3 py-2 bg-secondary border border-border rounded-lg text-sm text-left flex justify-between items-center">
                  <span>{consequences.length ? consequences.length + ' consecuencia(s) probable(s)' : 'Seleccionar consecuencias...'}</span>
                  <span>{showConsequencesDropdown ? '▲' : '▼'}</span>
                </button>
                {showConsequencesDropdown && (
                  <div className="mt-1 max-h-40 overflow-y-auto border border-border rounded-lg bg-card">
                    {CONSEQUENCES.map(c => (
                      <label key={c} className="flex items-center gap-2 px-3 py-2 hover:bg-primary/10 cursor-pointer text-sm">
                        <input type="checkbox" checked={consequences.includes(c)}
                          onChange={e => {
                            if (e.target.checked) setConsequences(prev => [...prev, c]);
                            else setConsequences(prev => prev.filter(x => x !== c));
                          }} className="rounded border-border" />
                        {c}
                      </label>
                    ))}
                  </div>
                )}
              </div>

              {/* Causas / Precursores */}
              <div className="mb-3">
                <label className="text-xs text-muted-foreground block mb-1">Causas / Precursores</label>
                <div className="flex flex-wrap gap-1 mb-2">
                  {supervisorCauses.map((c, i) => (
                    <span key={i} className="px-2 py-1 bg-primary/20 text-primary text-xs rounded-full flex items-center gap-1">
                      {c} <button onClick={() => setSupervisorCauses(prev => prev.filter((_, idx) => idx !== i))} className="text-primary/60 hover:text-primary">×</button>
                    </span>
                  ))}
                </div>
                <input value={causeSearch} onChange={e => { setCauseSearch(e.target.value); setShowCauseDropdown(true); }}
                  onFocus={() => setShowCauseDropdown(true)}
                  onBlur={() => setTimeout(() => setShowCauseDropdown(false), 200)}
                  placeholder="Buscar precursor..."
                  className="w-full px-3 py-2 bg-secondary border border-border rounded-lg text-sm" />
                {showCauseDropdown && (
                  <div className="mt-1 max-h-32 overflow-y-auto border border-border rounded-lg bg-card">
                    {PRECURSORS.filter(ca => !supervisorCauses.includes(ca)).filter(ca => ca.toLowerCase().includes(causeSearch.toLowerCase())).map(ca => (
                      <div key={ca} onClick={() => { setSupervisorCauses(prev => [...prev, ca]); setCauseSearch(''); }}
                        className="px-3 py-2 text-sm hover:bg-primary/10 cursor-pointer">{ca}</div>
                    ))}
                  </div>
                )}
              </div>


              {/* Análisis del supervisor */}
              <div className="mb-3">
                <label className="text-xs text-muted-foreground block mb-1">Análisis del supervisor</label>
                <textarea value={analysisText} onChange={e => setAnalysisText(e.target.value)}
                  placeholder="Causas raíz, factores contribuyentes, antecedentes..."
                  rows={3}
                  className="w-full px-3 py-2 bg-secondary border border-border rounded-lg text-sm resize-none" />
              </div>

              {/* Medidas de control */}
              <div className="mb-3">
                <label className="text-xs text-muted-foreground block mb-1">Medidas de control</label>
                <div className="flex flex-wrap gap-1 mb-2">
                  {controlMeasure.map((m, i) => (
                    <span key={i} className="px-2 py-1 bg-primary/20 text-primary text-xs rounded-full flex items-center gap-1 max-w-[200px] truncate">
                      {m} <button onClick={() => setControlMeasure(prev => prev.filter((_, idx) => idx !== i))} className="text-primary/60 hover:text-primary flex-shrink-0">×</button>
                    </span>
                  ))}
                </div>
                <button onClick={() => setShowMeasureDropdown(!showMeasureDropdown)}
                  className="w-full px-3 py-2 bg-secondary border border-border rounded-lg text-sm text-left flex justify-between items-center">
                  <span>{controlMeasure.length ? controlMeasure.length + ' medida(s) seleccionada(s)' : 'Seleccionar medidas...'}</span>
                  <span>{showMeasureDropdown ? '▲' : '▼'}</span>
                </button>
                {showMeasureDropdown && (
                  <div className="mt-1 max-h-40 overflow-y-auto border border-border rounded-lg bg-card">
                    {CONTROL_MEASURES.map(m => (
                      <label key={m} className="flex items-center gap-2 px-3 py-2 hover:bg-primary/10 cursor-pointer text-sm">
                        <input type="checkbox" checked={controlMeasure.includes(m)}
                          onChange={e => {
                            if (e.target.checked) setControlMeasure(prev => [...prev, m]);
                            else setControlMeasure(prev => prev.filter(x => x !== m));
                          }} className="rounded border-border" />
                        {m}
                      </label>
                    ))}
                  </div>
                )}
              </div>

              {controlMeasure.includes('Otra medida de control') && (
                <div className="mt-2 flex gap-2 mb-3">
                  <input type="text" value={customMeasure} onChange={e => setCustomMeasure(e.target.value)}
                    placeholder="Escribir medida de control..."
                    className="flex-1 px-3 py-2 bg-secondary border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary" />
                  <button onClick={() => { if (customMeasure.trim()) { setControlMeasure(prev => [...prev.filter(x => x !== 'Otra medida de control'), customMeasure.trim()]); setCustomMeasure(''); } }}
                    className="px-3 py-2 bg-primary text-primary-foreground rounded-lg text-sm">Agregar</button>
                </div>
              )}              {/* Plazo */}
              <div className="mb-3">
                <label className="text-xs text-muted-foreground block mb-1">Plazo para medida de control</label>
                <input type="date" value={deadline} style={{colorScheme: "dark"}} onChange={e => setDeadline(e.target.value)}
                  className="w-full px-3 py-2 bg-secondary border border-border rounded-lg text-sm" />
              </div>

              {/* Feedback */}
              <div className="mb-3">
                <label className="text-xs text-muted-foreground block mb-1">Feedback al usuario que reporta</label>
                <textarea value={feedbackText} onChange={e => setFeedbackText(e.target.value)}
                  placeholder="Escribe un comentario para el trabajador..."
                  rows={2}
                  className="w-full px-3 py-2 bg-secondary border border-border rounded-lg text-sm resize-none" />
              </div>

              {/* Botón a proceso */}
              <div className="flex items-start gap-2 mb-3 p-2 bg-secondary/50 rounded-lg">
                <span className="text-muted-foreground text-sm">ℹ️</span>
                <p className="text-xs text-muted-foreground">{!analysisText ? 'Falta: análisis del supervisor' : !deadline ? 'Falta: plazo para medida de control' : !controlMeasure.length ? 'Falta: medidas de control' : 'Campos completos — puedes cambiar el estado'}</p>
              </div>
              <button
                disabled={updatingStatus || !analysisText || !deadline || !controlMeasure.length}
                onClick={() => handleUpdateStatus(selectedIncident, 'en_proceso')}
                className={"w-full py-3 rounded-lg text-sm font-medium transition-all " + (analysisText && deadline && controlMeasure.length > 0 ? "bg-primary text-primary-foreground hover:bg-primary/90" : "bg-secondary border border-border text-muted-foreground cursor-not-allowed opacity-50")}>
                Cambiar incidente a proceso
              </button>
            </div>

            {/* ══════════ SECCIÓN 3: CIERRE ══════════ */}
            {(selectedIncident as any).timeline?.pending_closure && (
              <div className="mb-3 p-3 bg-blue-500/10 border border-blue-500/30 rounded-lg text-sm">
                <span className="text-xs text-muted-foreground block">Cierre solicitado el</span>
                <span className="font-medium text-blue-400">{new Date((selectedIncident as any).timeline.pending_closure).toLocaleString('es-CL')}</span>
                {selectedIncident.deadline && (
                  <span className="ml-3 text-xs">{new Date((selectedIncident as any).timeline.pending_closure) <= new Date(selectedIncident.deadline + 'T23:59:59') ? '✅ Dentro del plazo' : '⚠️ Fuera del plazo'}</span>
                )}
              </div>
            )}
            {selectedIncident.closure_evidence && (
              <div className="mb-4 p-4 bg-secondary/50 rounded-lg">
                <p className="text-xs text-muted-foreground mb-2 font-semibold">📸 Evidencia de cierre (subida por supervisor/jefe)</p>
                {selectedIncident.closure_evidence.startsWith('data:application/pdf') ? (
                  <a href={selectedIncident.closure_evidence} download="evidencia_cierre.pdf" className="flex items-center gap-2 p-3 bg-secondary border border-border rounded-lg text-sm text-primary hover:bg-secondary/80">
                    📄 Evidencia PDF — clic para descargar
                  </a>
                ) : (
                  <img src={selectedIncident.closure_evidence} alt="evidencia cierre" className="w-full h-48 object-cover rounded-lg border border-border cursor-pointer hover:opacity-80" onClick={() => setLightboxImg(selectedIncident.closure_evidence!)} />
                )}
                {selectedIncident.status !== 'closed' && (
                  <label className="inline-block mt-2 text-xs text-primary cursor-pointer hover:underline">
                    Cambiar foto
                    <input type="file" accept="image/*" className="hidden" onChange={e => {
                      const file = e.target.files?.[0]; if (!file) return;
                      const r = new FileReader(); r.onloadend = () => replaceClosureEvidence(selectedIncident, r.result as string); r.readAsDataURL(file);
                    }} />
                  </label>
                )}
              </div>
            )}
            {etapaCierre && (
            <div className="border border-border rounded-lg p-4 mb-4">
              <h3 className="text-sm font-semibold text-primary mb-3 flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-xs font-bold text-primary">3</span>
                Cierre
              </h3>

              <label className="text-xs text-muted-foreground block mb-2">Evidencia de cierre (foto o documento)</label>
              <label className="w-full flex flex-col items-center gap-1 p-4 rounded-lg cursor-pointer bg-secondary border border-dashed border-border hover:border-primary transition-colors">
                <span className="text-primary text-sm">Toca para seleccionar</span>
                <span className="text-xs text-muted-foreground">JPG, PNG o PDF — Máx 10 MB</span>
                <input type="file" accept="image/*,.pdf" className="hidden" onChange={e => {
                  const file = e.target.files?.[0];
                  if (file) {
                    setClosureEvidence(file);
                    if (file.type.startsWith('image/')) {
                      const reader = new FileReader();
                      reader.onloadend = () => setClosureEvidencePreview(reader.result as string);
                      reader.readAsDataURL(file);
                    } else {
                      setClosureEvidencePreview(null);
                    }
                  }
                }} />
              </label>
              {closureEvidencePreview && (
                <img src={closureEvidencePreview} alt="preview cierre" className="w-full h-24 object-cover rounded-lg mt-2 border border-border cursor-pointer hover:opacity-80 transition-opacity" onClick={() => setLightboxImg(closureEvidencePreview)} />
              )}
              {closureEvidence && !closureEvidencePreview && (
                <p className="text-xs text-primary mt-2">{closureEvidence.name}</p>
              )}
            </div>
            )}

            {/* ══════════ SECCIÓN 4: ESTADO ══════════ */}
            <div className="border border-border rounded-lg p-4 mb-4">
              <h3 className="text-sm font-semibold text-primary mb-3 flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-xs font-bold text-primary">4</span>
                Estado
              </h3>

              {deadline && (
                <div className="mb-3 p-2 bg-primary/10 border border-primary/20 rounded-lg">
                  <span className="text-xs text-muted-foreground">Plazo medida de control</span>
                  <p className="text-sm font-medium text-primary">{new Date(deadline).toLocaleDateString('es-CL')}</p>
                </div>
              )}

              {canRequestClosure && (
                <button
                  disabled={updatingStatus}
                  onClick={() => handleUpdateStatus(selectedIncident, 'pending_closure')}
                  className={"w-full py-3 rounded-lg text-sm font-medium transition-all " + (!updatingStatus ? "bg-[#E8941A]/20 border border-[#E8941A]/50 text-[#E8941A] hover:bg-[#E8941A]/30" : "bg-secondary border border-border text-muted-foreground cursor-not-allowed opacity-50")}>
                  {!closureEvidence ? '📋 Solicitar cierre (requiere evidencia)' : (updatingStatus ? 'Actualizando...' : '📋 Solicitar cierre')}
                </button>
              )}

              {canClose && (
                <button
                  disabled={updatingStatus}
                  onClick={() => handleUpdateStatus(selectedIncident, 'closed')}
                  className={"w-full py-3 rounded-lg text-sm font-medium transition-all " + (!updatingStatus ? "bg-green-500/20 border border-green-500/50 text-[#16A34A] hover:bg-[#16A34A]/30" : "bg-secondary border border-border text-muted-foreground cursor-not-allowed opacity-50")}>
                  {updatingStatus ? 'Actualizando...' : '✅ Aprobar cierre'}
                </button>
              )}
            </div>

            {/* ══════════ FOOTER ══════════ */}
            <div className="grid grid-cols-2 gap-2">
              <button onClick={() => exportToPdf(selectedIncident)} disabled={exportingPdf}
                className="py-2 bg-[#00E5FF]/20 border border-[#00E5FF]/50 text-[#00E5FF] rounded-lg text-sm hover:bg-[#00E5FF]/30 transition-all font-medium disabled:opacity-50 disabled:cursor-wait">
                {exportingPdf ? '⏳ Generando...' : '📄 Exportar PDF'}
              </button>
              <button onClick={() => { setSelectedIncident(null); setShowRecategorize(false); setAnalysisText(''); setDeadline(''); setControlMeasure([]); setShowMeasureDropdown(false); setCustomMeasureText(''); setAssignedSupervisor(''); setClosureEvidence(null); setClosureEvidencePreview(null); setConsequences([]); }}
                className="py-2 bg-secondary border border-border rounded-lg text-sm hover:bg-secondary/80 transition-all">
                ✕ Cancelar
              </button>
            </div>

            </div>
          </div>
        </div>
      )}
      {showCreateModal && (
        <CreateReportModal
          onClose={() => setShowCreateModal(false)}
          onCreated={reloadReports}
          userAssignedAreas={userAssignedAreas}
        />
      )}
    </div>
  );
}