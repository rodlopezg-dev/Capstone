import os
from dotenv import load_dotenv
load_dotenv()

class Settings:
    JWT_SECRET: str = os.getenv("JWT_SECRET", "")
    JWT_ALGORITHM: str = "HS256"
    INTERNAL_API_KEY: str = os.getenv("INTERNAL_API_KEY", "")
    MONGO_URI: str = os.getenv("MONGO_URI", "mongodb://localhost:27017")
    MONGO_DB: str = os.getenv("MONGO_DB", "sso_riesgo")
    app_version: str = "1.0.0"
    app_name: str = "workers-service"
    sso_environment: str = os.getenv("SSO_ENVIRONMENT", "development")

settings = Settings()

def get_settings():
    return settings
