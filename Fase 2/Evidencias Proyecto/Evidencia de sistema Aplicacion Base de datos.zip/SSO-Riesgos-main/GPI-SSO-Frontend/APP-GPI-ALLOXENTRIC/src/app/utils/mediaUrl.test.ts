import {
  describe,
  expect,
  it,
} from 'vitest';

import {
  resolveLocalEvidenceUrl,
} from './mediaUrl';

describe('media URL resolution', () => {
  it('resolves local evidence against API origin', () => {
    expect(
      resolveLocalEvidenceUrl(
        '/local-evidence/profiles/client/user/avatar.jpg',
        'https://desktop.example:8443/api/users',
      ),
    ).toBe(
      'https://desktop.example:8443/local-evidence/profiles/client/user/avatar.jpg',
    );
  });

  it('keeps relative local evidence when API URL is missing', () => {
    expect(
      resolveLocalEvidenceUrl(
        '/local-evidence/profiles/avatar.jpg',
      ),
    ).toBe(
      '/local-evidence/profiles/avatar.jpg',
    );
  });

  it('rebases absolute localhost evidence against API origin', () => {
    expect(
      resolveLocalEvidenceUrl(
        'https://localhost/local-evidence/reports/client/22/closure.jpg',
        'https://desktop.example:8443/api/reports',
      ),
    ).toBe(
      'https://desktop.example:8443/local-evidence/reports/client/22/closure.jpg',
    );
  });

  it('rebases loopback evidence preserving query and hash', () => {
    expect(
      resolveLocalEvidenceUrl(
        'http://127.0.0.1:8102/local-evidence/reports/22/cierre.pdf?download=1#file',
        'https://desktop.example:8443/api/reports',
      ),
    ).toBe(
      'https://desktop.example:8443/local-evidence/reports/22/cierre.pdf?download=1#file',
    );
  });

  it('keeps absolute Azure URL unchanged', () => {
    const url =
      'https://storage.example/container/avatar.jpg';

    expect(
      resolveLocalEvidenceUrl(
        url,
        'https://desktop.example/api/users',
      ),
    ).toBe(url);
  });

  it('keeps data URL unchanged', () => {
    const url =
      'data:image/jpeg;base64,aG9sYQ==';

    expect(
      resolveLocalEvidenceUrl(
        url,
        'https://desktop.example/api/users',
      ),
    ).toBe(url);
  });

  it('keeps blob URL unchanged', () => {
    const url =
      'blob:https://desktop.example/abc';

    expect(
      resolveLocalEvidenceUrl(
        url,
        'https://desktop.example/api/users',
      ),
    ).toBe(url);
  });

  it('falls back safely for invalid API URL', () => {
    expect(
      resolveLocalEvidenceUrl(
        '/local-evidence/profile.jpg',
        'not-a-valid-url',
      ),
    ).toBe(
      '/local-evidence/profile.jpg',
    );
  });
});

describe('private report evidence URL resolution', () => {
  it('resolves private report evidence against API origin', () => {
    expect(
      resolveLocalEvidenceUrl(
        '/local-report-evidence/reports/client-a/1/evidence.jpg?sp=r&sig=test',
        'https://desktop.example:8443/api/reports',
      ),
    ).toBe(
      'https://desktop.example:8443'
        + '/local-report-evidence/reports/client-a/1/evidence.jpg'
        + '?sp=r&sig=test',
    );
  });
});
