import { describe, expect, it } from 'vitest';

import {
  CONTROL_MEASURE_OPTIONS,
  toggleControlMeasure,
} from './incidentControlMeasures';

describe('incident control measures - SCRUM-75', () => {
  it('contains the 12 predefined measures from the reference dashboard', () => {
    expect(CONTROL_MEASURE_OPTIONS).toHaveLength(12);

    expect(CONTROL_MEASURE_OPTIONS).toEqual([
      'Elaborar y capacitar en procedimiento o instructivo',
      'Actualizar y capacitar en procedimiento o instructivo',
      'Reinstruir en procedimiento o instructivo',
      'Aplicar medida disciplinaria segun reglamento',
      'Corregir o reparar condicion fisica insegura',
      'Instalar o mejorar senalizacion o demarcacion',
      'Implementar barrera fisica o control de ingenieria',
      'Reemplazar equipo, herramienta o EPP defectuoso',
      'Realizar mantencion correctiva o preventiva',
      'Reforzar supervision o acompanamiento en terreno',
      'Derivar a comite paritario o prevencion de riesgos',
      'Otra medida de control',
    ]);
  });

  it('adds a measure', () => {
    expect(
      toggleControlMeasure(
        [],
        'Reinstruir en procedimiento o instructivo'
      )
    ).toEqual([
      'Reinstruir en procedimiento o instructivo',
    ]);
  });

  it('supports multiple selected measures', () => {
    expect(
      toggleControlMeasure(
        ['Reinstruir en procedimiento o instructivo'],
        'Implementar barrera fisica o control de ingenieria'
      )
    ).toEqual([
      'Reinstruir en procedimiento o instructivo',
      'Implementar barrera fisica o control de ingenieria',
    ]);
  });

  it('removes an already selected measure', () => {
    expect(
      toggleControlMeasure(
        [
          'Reinstruir en procedimiento o instructivo',
          'Otra medida de control',
        ],
        'Reinstruir en procedimiento o instructivo'
      )
    ).toEqual([
      'Otra medida de control',
    ]);
  });

  it('does not mutate the original array', () => {
    const original = [
      'Reinstruir en procedimiento o instructivo',
    ];

    toggleControlMeasure(
      original,
      'Otra medida de control'
    );

    expect(original).toEqual([
      'Reinstruir en procedimiento o instructivo',
    ]);
  });
});
