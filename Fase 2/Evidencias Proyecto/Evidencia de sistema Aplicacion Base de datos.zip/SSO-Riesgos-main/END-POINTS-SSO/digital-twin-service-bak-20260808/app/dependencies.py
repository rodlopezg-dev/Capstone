import os
import jwt
from fastapi import HTTPException, Security, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from motor.motor_asyncio import AsyncIOMotorClient
from typing import Callable
from pydantic import BaseModel

MONGO_URI = os.getenv("MONGO_URI", "mongodb://admin-dev-spot:admin-dev-spot-!!-2026@mongo-db:27017/?authSource=admin")
MONGO_DB = os.getenv("MONGO_DB", "sso_riesgo")
JWT_SECRET = os.getenv("JWT_SECRET", "")
JWT_ALGORITHM = os.getenv("JWT_ALGORITHM", "HS256")

_db_client = None
security = HTTPBearer()

class CurrentUser(BaseModel):
    id: str
    role: str
    client_id: str

def get_db():
    global _db_client
    if _db_client is None:
        client = AsyncIOMotorClient(MONGO_URI)
        _db_client = client[MONGO_DB]
    return _db_client

async def get_current_user(credentials: HTTPAuthorizationCredentials = Security(security)) -> CurrentUser:
    token = credentials.credentials
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        return CurrentUser(id=payload.get("sub"), role=payload.get("role"), client_id=payload.get("client_id"))
    except jwt.PyJWTError:
        raise HTTPException(status_code=401, detail="Token requerido")

def verify_role(*allowed_roles: str) -> Callable:
    def role_checker(current_user: CurrentUser = Depends(get_current_user)):
        if current_user.role not in allowed_roles:
            raise HTTPException(status_code=403, detail="Rol insuficiente.")
        return current_user
    return role_checker
