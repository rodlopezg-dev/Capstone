from datetime import datetime, timezone
import ulid as ulid_lib

class AreaRepository:
    def __init__(self, db):
        self.areas = db["areas"]

    async def get_all(self, client_id):
        results = []
        async for doc in self.areas.find({"client_id": client_id}):
            doc["id"] = str(doc.pop("_id"))
            results.append(doc)
        return results

    async def get_by_id(self, client_id, area_id):
        doc = await self.areas.find_one({"_id": area_id, "client_id": client_id})
        if not doc:
            doc = await self.areas.find_one({"name": area_id, "client_id": client_id})
        if doc:
            doc["id"] = str(doc.pop("_id"))
        return doc

    async def create(self, client_id, area_data):
        area_data["client_id"] = client_id
        result = await self.areas.insert_one(area_data)
        area_data["id"] = str(result.inserted_id)
        area_data.pop("_id", None)
        return area_data

    async def update(self, client_id, area_id, update_data):
        await self.areas.update_one(
            {"name": area_id, "client_id": client_id},
            {"$set": update_data}
        )

    async def delete(self, client_id, area_id):
        await self.areas.delete_one({"name": area_id, "client_id": client_id})
