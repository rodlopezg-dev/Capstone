# EP-04 / TT-18 — correcciones de la revisión previa a commits

Fecha: 2026-10-08. Base: `main` en `95a2d92` con los cambios locales de TT-17/TT-18 preservados. Antecedentes: `ep04-tt18-revision.md`, `ep04-tt18-implementacion.md` y `ep04-tt18-permisos.md`. No se hizo staging, commit, push, merge ni despliegue.

## Estado de H1–H5 y cambios por ticket

| Hallazgo / ticket | Evidencia antes | Cambio y evidencia después | Estado |
| --- | --- | --- | --- |
| **H1 / SCRUM-360** | `auth-service/app/routers/auth.py` copiaba `role`, `client_id` y áreas directamente del refresh; el estado activo solo se verificaba en login. Los nuevos tests de baja, degradación, cambio de ámbitos/tenant y caída de Users Service fallaron antes de implementar la consulta. | `auth-service/app/services/auth_service.py:124-170` verifica el refresh y consulta por `sub` + `client_id`; exige documento activo y compara identidad, rol y ámbitos actuales con la sesión. Si cambiaron, `TokenInvalidError` (401) exige login nuevo. El access nuevo se construye desde el documento actual. `auth-service/app/repositories/user_api_repo.py:61-85` usa `X-Internal-Token` y falla cerrado con 503 ante indisponibilidad. `users-service/app/routers/internal.py:28-45` agrega `POST /v1/internal/users/by-id` bajo la dependencia interna autenticada existente (`:9-13`), con proyección sin contraseña. | Corregido para **renovación**; no revoca de inmediato access tokens ya emitidos. |
| **H2 / SCRUM-362** | `GET /v1/admin/users/` autorizaba el literal `jefe de area` y `get_all_users(client_id)` devolvía todo el tenant sin comprobar área. | `users-service/app/routers/users.py:15-20` permite solo `admin` y `sso_manager`; `jefe de area`, `jefe_de_area` y `supervisor` reciben 403 antes del servicio/repositorio. `test_ep04_security_contract.py` comprueba denegación sin llamada al listado y que admin/manager reciben solo el `client_id` firmado. `verify_role` pasó a dependencia `async` para poder ejecutar este contrato ASGI sin el bloqueo del ejecutor de hilos observado en el entorno; la política de otras rutas no cambió. | Corregido para listado global; no se inventó filtro por área. |
| **H3 / SCRUM-355** | FastAPI transformaba `talk_id=""` de `Form(None)` en `None`, de modo que un campo explícito vacío entraba como registro legacy. | `talks-service/app/routers/rt_talks.py:1105-1132` comprueba presencia en `Request.form()` después de JWT/RBAC y antes de acceder al repositorio. Semántica: **campo omitido** = manual legacy permitido sin archivo; `""` o espacios = 422; ID existente del tenant = permitido; ID inexistente o de otro tenant = mismo 404. Sin ID no se permite archivo. La matriz ASGI prueba las seis variantes con/sin archivo y que los rechazos no llaman a Blob ni a `create_attendance`. | Corregido en handler; sin prueba Mongo/Blob real por restricción. |
| **H4 / SCRUM-337** | La adaptación de integración cambiaba el claim a `admin` pero mantenía `supervisor_a`/`worker_b`; incluso dos llamadas posicionales en `test_attendance_stats.py` conservaban esa incoherencia. | `talks-service/tests/conftest.py:87-170` siembra identidades `admin_a`/`admin_b` y roles explícitos; el helper emite `type=access` y selecciona un sujeto coherente con rol/tenant. Las pruebas con ID explícito usan administradores del tenant correspondiente; se actualizaron las expectativas `created_by`. Una inspección AST de todas las llamadas con ID literal a `auth_headers` encontró **cero** discordancias restantes. Los casos de claims obsoletos están separados en `auth-service/tests/test_jwt_contract.py`; el usuario `inactive_a` queda como prueba expresa de inactividad. | Fixtures corregidos y 106 casos recopilados; ejecución de integración pendiente por escritura Mongo. |
| **H5 / móvil** | El cliente ya eliminaba tokens y `vigia_session` ante 401/403 de `/refresh`, y `App.tsx` escuchaba `vigia:session-invalidated` para limpiar `userRole` y pantallas; faltaba una regresión específica de privilegios administrativos. | `src/app/api/client.test.ts` añade casos 401 y 403: borra access/refresh/sesión, no reintenta la operación y emite el evento que escucha `App.tsx:586-597`. No se modificó código de producción móvil. La pantalla de charlas sigue mostrando gestión solo para `admin`/`sso_manager`; el flujo manual omite `talk_id` y el de hoja envía un ID. | Comportamiento de rechazo verificado en pruebas de cliente; no hubo prueba visual/E2E de App. |

### Contratos y decisiones técnicas

- La ruta interna existente `/v1/internal/users/by-email` ya usaba `X-Internal-Token` desde Auth Service. La nueva consulta por ID reutiliza esa autenticación y filtra por **ambos** `user_id` y `client_id`; una solicitud sin cabecera o con cabecera incorrecta no consulta la colección. No se añadió una ruta interna pública ni se cambió `.env`.
- Se exige igualdad de rol, tenant, `assigned_areas` (o `areas` legacy) y `area` entre refresh y documento actual. Una reordenación de la lista de áreas también exige login nuevo; se prioriza denegar ante ambigüedad. Si Users Service no responde, no se emite access y se devuelve 503 para distinguir una indisponibilidad de credencial inválida. Una cuenta desactivada, eliminada, movida de tenant o degradada recibe 401.
- Los consumidores siguen aceptando temporalmente access JWT antiguos **sin** `type`; refresh y tipos desconocidos siguen rechazados como access. La revalidación de `/refresh` no invalida access ya emitidos: estos conservan los privilegios firmados hasta `exp`, salvo que cada consumidor consulte estado/revocación, mecanismo que no existe en este alcance.
- El frontend móvil no llama `GET /v1/admin/users/`; `App.tsx` pasa `users={[]}` a `SafetyTalksMobile`. El alias `jefe de area` que antes abría el listado ahora recibe 403, al igual que `jefe_de_area` y `supervisor`. Los nombres de rol `admin` y `sso_manager` se conservan como contrato de este endpoint.
- Los clientes actuales respaldan la semántica de H3: `SafetyTalksMobile.tsx` omite `talk_id` en el formulario manual; `uploadAttendanceSheetRequest` siempre agrega un `talkId` para adjuntar hoja. Ninguno requiere un campo explícito vacío. La excepción legacy se limita a omisión comprobada.

## Archivos modificados en esta revisión correctiva

**Auth / H1:** `END-POINTS-SSO/auth-service/app/repositories/user_api_repo.py`, `app/routers/auth.py`, `app/services/auth_service.py`, `tests/test_jwt_contract.py`; `END-POINTS-SSO/users-service/app/routers/internal.py`.

**Users / H2:** `END-POINTS-SSO/users-service/app/dependencies.py`, `app/routers/users.py`, nuevo `tests/test_ep04_security_contract.py` (también cubre el contrato interno de H1).

**Talks / H3-H4:** `END-POINTS-SSO/talks-service/app/routers/rt_talks.py`, `tests/unit/test_attendance_access_contract.py`, `tests/conftest.py`; `tests/integration/test_{absence_tenant_isolation,absent_workers_functional,attendance_export_pdf,attendance_export_xlsx,attendance_sheet,attendance_stats,expected_workers,ocr_attendance,qr_attendance_router,talk_attachments}.py`. Los otros archivos de integración ya modificados en TT-18 se mantuvieron sin reescribirlos.

**Móvil / H5:** `GPI-SSO-Frontend/APP-GPI-ALLOXENTRIC/src/app/api/client.test.ts`. **Documentación:** este informe. Se conservaron los cambios anteriores de TT-17 en `attendance_export.py`, los hunks de cobertura en `rep_talks.py` y sus pruebas, así como las auditorías previas.

## Validación ejecutada

| Prueba | Resultado | Aislamiento |
| --- | --- | --- |
| `auth-service`: `python -m unittest discover -s tests -p 'test_*.py' -q` | **10 tests, OK** | Repositorio falso y `httpx.MockTransport`; sin red real. |
| `users-service`: `python -m unittest discover -s tests -p 'test_*.py' -q` | **18 tests, OK** | ASGI con DB/servicio simulados; sin Mongo. |
| `talks-service`: `pytest tests/unit -q` | **227 passed** | `TEST_MONGO_URI` y DB ficticias para importación; ninguna fixture de escritura. |
| Contrato JWT `END-POINTS-SSO/tests/jwt_consumer_contract.py` | **13 casos × 8 consumidores, todos pasaron** | Secret/internal key ficticios por proceso; sin DB. |
| Móvil: `npm test -- --run` | **34 archivos, 261 tests passed** | Sin API ni almacenamiento remoto. |
| `talks-service`: `pytest tests/integration --collect-only -q` | **106 tests recopilados, 0 ejecutados** | No se llamó fixture Mongo. |
| `git diff --check` | **exit 0** | Sin staging. |

La primera ejecución roja de los tests nuevos confirmó que refresh no consultaba al usuario y que `talk_id=""` producía 200. La prueba ASGI de Users se detuvo inicialmente en una dependencia síncrona ejecutada en un hilo; al pasar `verify_role` a `async`, los 18 tests de Users finalizaron. Una prueba de hoja válida necesitó simular también la consulta de duplicado; ese fallo era de preparación del doble, no del handler. No se ejecutaron pruebas que escriban Mongo ni pruebas contra Azure/Azurite real.

## Riesgos y pendientes

1. **Revocación inmediata de access:** fuera de este cambio. Un access vigente mantiene su rol firmado hasta vencer, incluso después de baja o degradación. La corrección H1 impide prolongarlo mediante refresh. Si se exige corte inmediato, hace falta un mecanismo de revocación/versión o consulta activa en cada consumidor, con diseño y costo propios.
2. **Disponibilidad de Users Service:** una caída devuelve 503 y no emite access. El móvil conserva estado local ante 5xx transitorios; las APIs rechazarán el access vencido, pero la pantalla puede conservar controles visuales hasta recuperar conectividad o cerrar sesión. No se confunde 503 con credencial revocada.
3. **Integración:** los 106 tests se recopilaron, pero no se ejecutaron por su escritura en Mongo. Por tanto, los cambios de fixtures, el nuevo endpoint interno con Mongo real y los flujos de adjuntos/QR/OCR no tienen validación de integración en esta fase.
4. **Ámbitos de supervisor/jefe:** siguen denegados en operaciones administrativas hasta contar con fuente persistida verificable. El listado global de Users no les ofrece un bypass.
5. **Legacy JWT y datos:** se conserva access sin `type` durante la transición aprobada; falta criterio de retirada. H3 preserva solo la omisión comprobada de `talk_id`; clientes externos no inventariados que envíen `""` deberán adaptarse.

## Propuesta actualizada de commits A–D

| Commit | Contenido sugerido |
| --- | --- |
| **A. TT-17 estadísticas/exportaciones** | `talks-service/app/attendance_export.py`, `tests/unit/test_attendance_consistency.py`, `test_attendance_projection.py`; en `app/repositories/rep_talks.py` **solo** los hunks de proyección `source`, cobertura y fallback manual/QR (todos salvo `list_own_attendance`). |
| **B. TT-18 JWT y SCRUM-360** | Emisión/validación JWT de auth y consumidores; `auth-service/app/repositories/user_api_repo.py`, `app/routers/auth.py`, `app/services/auth_service.py`, `tests/test_jwt_contract.py`; `users-service/app/routers/internal.py`; `END-POINTS-SSO/tests/jwt_consumer_contract.py`. |
| **C. TT-18 RBAC, H2-H4** | `talks-service/app/routers/rt_talks.py`, hunk `list_own_attendance` de `rep_talks.py`, pruebas ASGI e integración de talks, `tests/conftest.py`; `users-service/app/{dependencies.py,routers/users.py}`; frontend `SafetyTalksMobile.tsx` y `utils/talkPermissions*`. Los cambios de H3 en el handler y los fixtures coherentes van aquí. |
| **D. Documentación y pruebas complementarias** | Los informes `docs/ep04-*.md`, incluido este; `users-service/tests/test_ep04_security_contract.py` (combina H1/H2) y `APP-GPI-ALLOXENTRIC/src/app/api/client.test.ts` para H5. Si se exige que cada commit pase pruebas aisladas, dividir el nuevo test combinado por ticket antes de staging, o incluir sus casos H1/H2 en B/C mediante selección revisada. |

`rep_talks.py` sigue siendo mixto: A recibe los hunks de TT-17 y C solo `list_own_attendance`. No se preparó ningún índice ni se creó ningún commit.
