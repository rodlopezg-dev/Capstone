# TT-13 — Validación integral final de EP-03

## 1. Objetivo

Consolidar la validación final de EP-03 — Implementar gestión de
incidentes desde la aplicación móvil — sobre una versión integrada en
`main`.

La validación cubre el ciclo completo de gestión de reportes,
permisos por rol, notificaciones, persistencia, evidencias, timeline y
aislamiento multicliente.

## 2. Versión validada

Versión final validada:

- Rama: `main`
- Commit: `eebfead`
- PR de correcciones E2E: #14
- PR de formato de timestamps: #15

La rama `main` se encontraba limpia y sincronizada con
`origin/main` durante las validaciones finales.

## 3. Componentes validados

### Aplicación móvil

- React
- TypeScript
- Vite
- Capacitor
- Android

### Backend

- Reports Service
- API Edge / Nginx
- Auth Service
- Users Service como dependencia de gestión de perfiles

### Dispositivos físicos utilizados

- Samsung SM-F761B
  - Android 16
  - API 36

- Motorola Edge 30 Neo
  - Android 14
  - API 34

Adicionalmente, RNF-05 dispone de validación previa documentada para
Android 8 / API 26 en:

`docs/validation/RNF-05-android8-api26.md`

## 4. Resultado de suites automatizadas

### Frontend móvil

Resultado final:

- 33 archivos de tests aprobados.
- 248 tests aprobados.
- 0 tests fallidos.

La regresión específica de permisos, notificaciones y timeline obtuvo:

- 5 archivos aprobados.
- 91 tests aprobados.

La suite específica del timeline obtuvo:

- 12 tests aprobados.

### Reports Service

Resultado:

- 124 tests aprobados.
- 0 tests fallidos.

Pruebas específicas de aislamiento multicliente:

- 12 escenarios cross-tenant aprobados.
- Cobertura de Tenant A → Tenant B.
- Cobertura de Tenant B → Tenant A.

También se validaron específicamente:

- cambios de estado;
- análisis;
- recategorización;
- asociación de evidencia de cierre;
- carga de evidencia de cierre;
- listado administrativo;
- exportación CSV.

## 5. Build y ejecución

### Frontend

Vite construyó correctamente la aplicación.

Se mantiene únicamente el warning no bloqueante por tamaño de chunk
superior a 500 kB.

### Capacitor

`sync android` completado correctamente.

Se detectaron y sincronizaron 11 plugins Capacitor.

### Android

Gradle completó correctamente:

`BUILD SUCCESSFUL`

La APK debug fue instalada y ejecutada correctamente en dispositivos
físicos.

No se detectaron durante las regresiones finales:

- `FATAL EXCEPTION`;
- `SIGSEGV`;
- `SyntaxError`;
- `ReferenceError`;
- errores JavaScript fatales.

## 6. Flujo E2E validado

Se validó el ciclo:

`open → en_proceso → pending_closure → closed`

El flujo funcional cubrió:

1. creación del reporte;
2. revisión inicial;
3. análisis;
4. tratamiento;
5. solicitud de cierre;
6. asociación de evidencia de cierre;
7. validación;
8. cierre;
9. consulta posterior desde Mis Reportes.

Los datos ingresados en análisis y tratamiento permanecieron
persistidos durante las transiciones.

La evidencia de cierre permaneció disponible al volver a abrir el
reporte.

## 7. Gating de etapas

Se verificó que las etapas de gestión se habilitan de acuerdo con el
estado persistido del reporte.

Comportamiento validado:

- `open`
  - Revisión inicial disponible.
  - Análisis disponible.
  - Tratamiento bloqueado.

- `en_proceso`
  - Tratamiento disponible.

- Tratamiento completo
  - Etapa 3 queda marcada como completada.
  - Solicitud de cierre queda disponible.

- `pending_closure`
  - Validación de cierre disponible.

- `closed`
  - Flujo final presentado como cerrado.

## 8. Permisos por rol

La matriz de permisos fue validada tanto automáticamente como durante
el flujo integrado.

### Supervisor / Jefe de área

Pueden:

- realizar análisis;
- recategorizar;
- pasar de `open` a `en_proceso`;
- completar tratamiento;
- solicitar cierre.

No pueden aprobar el cierre final.

### Admin / SSO Manager

Pueden aprobar:

`pending_closure → closed`

No pueden ejecutar las transiciones reservadas al supervisor cuando
el flujo no corresponde.

### Worker / Usuario

No puede ejecutar acciones de gestión reservadas a perfiles gestores.

Los intentos no autorizados son rechazados por backend.

## 9. Notificaciones

Se validó físicamente:

- notificación de confirmación al autor después de crear un reporte;
- notificación posterior al supervisor por nuevo reporte;
- polling de notificaciones;
- ausencia de reemisión del historial como nuevas notificaciones.

Las pruebas automatizadas también verifican baseline e idempotencia
de notificaciones procesadas.

## 10. Mis Reportes y timeline

El timeline final fue validado en dispositivo físico.

Para un reporte cerrado se muestran correctamente los hitos:

- Reporte enviado.
- Revisión inicial.
- Análisis.
- Tratamiento.
- Cierre en validación.
- Cerrado.

Los hitos derivados sin timestamp persistido no inventan una fecha.

Los timestamps persistidos se presentan en formato local legible:

`DD-MM-YYYY HH:mm`

Ejemplo validado:

`30-09-2026 19:23`

No se muestran timestamps ISO crudos al usuario.

## 11. Evidencia de cierre

Se corrigió y validó la resolución de URLs de evidencia.

Las referencias de `/local-evidence/` ya no intentan abrirse contra
`localhost` dentro del dispositivo móvil.

La evidencia puede ser consultada después del cierre y al reabrir el
reporte.

## 12. Aislamiento multicliente

La validación automatizada y la validación live contra API Edge
confirmaron aislamiento bidireccional.

### Datos utilizados

Tenant A:

`cliente_prueba_123`

Tenant B:

`cliente_prueba_b_123`

### Validación live

Se utilizó:

- reporte A: `24`;
- reporte B creado para la prueba: `1`.

Resultados:

| Operación | Resultado |
| --- | --- |
| GET propio Tenant A | 200 |
| GET propio Tenant B | 200 |
| GET Tenant A → reporte Tenant B | 404 |
| GET Tenant B → reporte Tenant A | 404 |
| PATCH Tenant A → reporte Tenant B | 404 |
| PATCH Tenant B → reporte Tenant A | 404 |
| Estado reporte A después de prueba | sin cambios |
| Estado reporte B después de prueba | sin cambios |

El backend responde `404 Reporte no encontrado` para accesos
cross-tenant, evitando además revelar la existencia de recursos de
otro cliente.

Los listados administrativos también quedaron aislados:

- Tenant A visualizó únicamente registros de Tenant A.
- Tenant B visualizó únicamente registros de Tenant B.

## 13. Defectos detectados durante TT-13

Durante la ejecución integral se encontraron cuatro defectos.

### SCRUM-322

**Problema**

Las etapas futuras podían quedar disponibles antes de que el estado
persistido del reporte permitiera avanzar.

**Resultado**

Corregido y validado.

### SCRUM-323

**Problema**

La evidencia de cierre podía intentar resolverse mediante
`https://localhost/local-evidence/...` desde Android.

**Resultado**

Corregido y validado.

### SCRUM-324

**Problema**

La etapa Tratamiento no quedaba marcada como completada al avanzar a
Solicitud de cierre.

**Resultado**

Corregido y validado.

### SCRUM-325

**Problema**

El timeline mostraba timestamps ISO crudos.

**Resultado**

Corregido y validado.

## 14. Pull Requests de corrección

### PR #14

`fix: corregir bloqueadores E2E de gestión de reportes [TT-13]`

Incluyó:

- SCRUM-322;
- SCRUM-323;
- SCRUM-324.

Merge commit:

`5de8100`

### PR #15

`fix(mobile): formatear timestamps del timeline [SCRUM-325]`

Merge commit:

`eebfead`

## 15. Observaciones no bloqueantes

Durante las pruebas se mantienen algunas advertencias técnicas que no
afectan el funcionamiento validado de EP-03:

- warning de Vite por chunk superior a 500 kB;
- APIs de configuración Pydantic con advertencias de deprecación;
- uso heredado de `datetime.utcnow()` en una ruta del Reports Service;
- advertencias Gradle sobre funcionalidades que deberán actualizarse
  antes de una futura migración mayor de Gradle.

Estas observaciones corresponden a deuda técnica y no representan
defectos funcionales bloqueantes para EP-03.

## 16. Evaluación de criterios de aceptación TT-13

| # | Criterio | Resultado |
| --- | --- | --- |
| 1 | `main` contiene las implementaciones aprobadas | Aprobado |
| 2 | Frontend móvil y Reports Service construyen correctamente | Aprobado |
| 3 | Suites automatizadas relevantes | Aprobado |
| 4 | Flujo `open → en_proceso → pending_closure → closed` | Aprobado |
| 5 | Persistencia de análisis y tratamiento | Aprobado |
| 6 | Evidencia de cierre disponible al reabrir | Aprobado |
| 7 | Notificaciones sin duplicados históricos | Aprobado |
| 8 | Restricciones por rol | Aprobado |
| 9 | Aislamiento Tenant A / Tenant B | Aprobado |
| 10 | Mis Reportes / timeline final | Aprobado |
| 11 | Sin errores inesperados de red o JavaScript | Aprobado |
| 12 | Resultado y recomendación documentados | Aprobado |

## 17. Recomendación de cierre

**Resultado final: APROBADO.**

No quedan defectos funcionales bloqueantes conocidos dentro del
alcance validado por TT-13.

Los defectos encontrados durante la regresión integral fueron
corregidos, integrados a `main` y revalidados.

Por lo tanto, una vez integrada esta evidencia documental:

1. ST-229 puede pasar a **Finalizado**.
2. TT-13 puede pasar a **Finalizado**.
3. EP-03 está en condiciones de pasar a **Finalizado**.
