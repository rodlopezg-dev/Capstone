# TT-21 — Aislamiento y seguridad de evidencias por tenant

## Contexto

TT-21 endurece el almacenamiento de evidencias de Reports Service para evitar colisiones entre tenants y reducir la exposición pública de archivos almacenados en Azure Blob Storage.

Rama:

`fix/tt21-tenant-evidence-storage`

Base:

`origin/main` en `4b19bbc`

## Implementación

### ST-268 — Aislamiento físico por tenant

Commit:

`8dac2bc fix(reports): isolate initial evidence storage by tenant`

El path de la evidencia inicial pasó de:

```text
reports/{report_id}/evidence.jpg
```

a:

```text
reports/{client_id}/{report_id}/evidence.jpg
```

Esto evita que dos tenants con el mismo `report_id` escriban sobre el mismo blob.

También se agregó cobertura unitaria para validar que Tenant A y Tenant B generan rutas físicas distintas.

### ST-269 — Contenedor privado y acceso temporal

Commit:

`8e082e2 fix(reports): secure evidence access with private blob storage`

Cambios principales:

- Reports Service utiliza un contenedor dedicado: `sso-report-evidence`.
- El contenedor se crea sin `public_access`.
- En DEV se utiliza `/local-report-evidence/`.
- Las referencias persistidas en MongoDB permanecen estables y sin SAS.
- Los SAS se generan únicamente al preparar respuestas HTTP autenticadas.
- Los SAS son de lectura.
- La firma valida `client_id` y `report_id`.
- Una ruta perteneciente a otro tenant no se firma.
- Las referencias históricas se mantienen sin modificación.
- El frontend mantiene el contrato existente de `evidences[]`, `image_url` y `closure_evidence.url`.
- El resolver frontend reconoce también `/local-report-evidence/`.

No se modificó el contenedor compartido utilizado por otros servicios.

### ST-270 — Pruebas multitenant y compatibilidad

Commit:

`c852328 test(reports): validate tenant evidence isolation`

Se agregó cobertura de integración para comprobar:

- Tenant A y Tenant B pueden utilizar el mismo `report_id`.
- Cada tenant recibe únicamente sus propias evidencias.
- `image_url`, `evidences[]` y `closure_evidence.url` se firman para el tenant correcto.
- No aparecen referencias del tenant contrario.
- MongoDB conserva referencias estables.
- Los SAS no se persisten.
- Las referencias históricas `/local-evidence/...` continúan funcionando.
- La asociación de evidencia de cierre rechaza referencias de otro tenant o reporte.

## Regresión final — ST-271

### Reports Service

```text
133 passed
6 warnings
```

Los warnings corresponden a deuda técnica preexistente:

- Pydantic `Field(..., example=...)`.
- `datetime.utcnow()`.

No se detectaron fallos de regresión.

### Tests críticos TT-21

```text
28 passed
3 warnings
```

Incluyen:

- Azure Blob.
- aislamiento multitenant.
- upload de evidencia de cierre.
- asociación de evidencia de cierre.

### Frontend

`mediaUrl.test.ts`:

```text
9 passed
```

Build Vite:

```text
OK
```

Se mantiene un warning conocido por chunk superior a 500 kB.

### Docker Compose

La primera ejecución de:

```text
docker compose -f docker-compose.local.yml config --quiet
```

no pudo interpolar el archivo porque la shell no tenía definidas variables obligatorias del entorno.

Se repitió la validación usando valores efímeros únicamente para interpolación, sin modificar `.env` ni iniciar contenedores.

Resultado:

```text
COMPOSE_EXIT=0
```

Las variables temporales no persistieron en la shell.

## Guardas de seguridad

Validaciones realizadas:

```text
public_access efectivo en reports-service
→ sin coincidencias

reports/{report_id}/evidence.jpg
→ sin coincidencias

nuevo namespace
→ reports/{client_id}/{report_id}/...

contenedor Reports
→ sso-report-evidence

ruta DEV
→ /local-report-evidence/
```

## Compatibilidad

No se realizó migración destructiva de blobs históricos.

Las referencias históricas continúan almacenadas y entregadas con su valor original cuando no pertenecen al nuevo namespace privado de Reports.

Los nuevos SAS se generan solamente en tiempo de respuesta y nunca se almacenan en MongoDB.

## Archivos modificados por TT-21

- `END-POINTS-SSO/reports-service/app/routers/rt_reports.py`
- `END-POINTS-SSO/reports-service/app/services/azure_blob_service.py`
- `END-POINTS-SSO/reports-service/app/services/srv_reports.py`
- `END-POINTS-SSO/reports-service/pyproject.toml`
- `END-POINTS-SSO/reports-service/tests/integration/test_report_closure_evidence_association.py`
- `END-POINTS-SSO/reports-service/tests/integration/test_report_tenant_isolation.py`
- `END-POINTS-SSO/reports-service/tests/unit/test_azure_blob_service.py`
- `GPI-SSO-Frontend/APP-GPI-ALLOXENTRIC/src/app/utils/mediaUrl.test.ts`
- `GPI-SSO-Frontend/APP-GPI-ALLOXENTRIC/src/app/utils/mediaUrl.ts`
- `docker-compose.local.yml`
- `docker/local/nginx.conf`

Además se agrega este documento de validación.

## Resultado

TT-21 queda técnicamente validada:

- aislamiento físico de evidencias por tenant;
- almacenamiento privado para nuevas evidencias de Reports;
- acceso temporal mediante SAS;
- compatibilidad con referencias históricas;
- ausencia de SAS persistidos;
- regresión backend y frontend aprobada;
- configuración Docker Compose válida;
- working tree limpio antes de generar esta evidencia.

No se modificó la base de datos ni archivos `.env`.
