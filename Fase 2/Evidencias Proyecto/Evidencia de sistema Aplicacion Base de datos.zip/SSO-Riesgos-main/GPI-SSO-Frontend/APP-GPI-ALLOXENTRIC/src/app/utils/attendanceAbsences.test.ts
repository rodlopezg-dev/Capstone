import { describe, expect, it } from 'vitest';
import {
  buildAbsentWorkersUrl,
  getAbsentWorkerDisplayName,
  getAbsenceStatusMessage,
  type AbsentWorkersResponse,
} from './attendanceAbsences';

describe('attendanceAbsences - SCRUM-123', () => {
  it('builds the absent workers endpoint', () => {
    expect(
      buildAbsentWorkersUrl(
        'https://example.test/api/talks',
        'talk_123',
      ),
    ).toBe(
      'https://example.test/api/talks/v1/talks/talk_123/absent-workers',
    );
  });

  it('removes trailing slash from the API base URL', () => {
    expect(
      buildAbsentWorkersUrl(
        'https://example.test/api/talks/',
        'talk_123',
      ),
    ).toBe(
      'https://example.test/api/talks/v1/talks/talk_123/absent-workers',
    );
  });

  it('encodes the talk identifier', () => {
    expect(
      buildAbsentWorkersUrl(
        'https://example.test/api/talks',
        'talk / especial',
      ),
    ).toContain(
      '/talk%20%2F%20especial/absent-workers',
    );
  });

  it('formats the worker full name', () => {
    expect(
      getAbsentWorkerDisplayName({
        user_id: 'worker_a',
        name: 'Ana',
        last_name: 'Prueba',
      }),
    ).toBe('Ana Prueba');
  });

  it('uses email when the worker has no name', () => {
    expect(
      getAbsentWorkerDisplayName({
        user_id: 'worker_a',
        email: 'ana@example.test',
      }),
    ).toBe('ana@example.test');
  });

  it('uses user_id as the final fallback', () => {
    expect(
      getAbsentWorkerDisplayName({
        user_id: 'worker_a',
      }),
    ).toBe('worker_a');
  });
});


const buildResult = (
  absence_status: AbsentWorkersResponse['absence_status'],
): AbsentWorkersResponse => ({
  talk_id: 'talk_123',
  title: 'Charla obligatoria',
  mandatory: true,
  expected_user_ids: [],
  resolved_expected_user_ids: [],
  missing_expected_user_ids: [],
  attended_user_ids: [],
  absent_user_ids: [],
  absent_workers: [],
  absence_status,
});

describe('attendanceAbsences states - SCRUM-124', () => {
  it('reports when there are no absences', () => {
    expect(
      getAbsenceStatusMessage(
        buildResult('no_absences'),
      ),
    ).toBe(
      'No hay inasistencias registradas para esta charla.',
    );
  });

  it('reports when there are no associated workers', () => {
    expect(
      getAbsenceStatusMessage(
        buildResult('no_expected_workers'),
      ),
    ).toBe(
      'La charla no tiene trabajadores asociados.',
    );
  });

  it('reports insufficient information', () => {
    expect(
      getAbsenceStatusMessage(
        buildResult('insufficient_data'),
      ),
    ).toBe(
      'No es posible generar el listado porque ' +
      'no hay información suficiente.',
    );
  });

  it('does not replace a normal absence list', () => {
    expect(
      getAbsenceStatusMessage(
        buildResult('absences_found'),
      ),
    ).toBeNull();
  });
});
