import os
import jwt
from fastapi import HTTPException, Security, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from motor.motor_asyncio import AsyncIOMotorClient, AsyncIOMotorDatabase
from typing import Callable
from pydantic import BaseModel

MONGO_URI = os.getenv("MONGO_URI")
MONGO_DB = os.getenv("MONGO_DB", "sso_riesgo")
JWT_SECRET = os.getenv("JWT_SECRET", "")
JWT_ALGORITHM = os.getenv("JWT_ALGORITHM", "HS256")

_db_client = None
security = HTTPBearer(auto_error=False)

class CurrentUser(BaseModel):
    id: str
    role: str
    client_id: str

def get_db() -> AsyncIOMotorDatabase:
    global _db_client
    if _db_client is None:
        client = AsyncIOMotorClient(MONGO_URI)
        _db_client = client[MONGO_DB]
    return _db_client

async def get_current_user(credentials: HTTPAuthorizationCredentials | None = Security(security)) -> CurrentUser:
    if credentials is None:
        raise HTTPException(status_code=401, detail="Token requerido")
    try:
        payload = jwt.decode(credentials.credentials, JWT_SECRET, algorithms=[JWT_ALGORITHM], options={"require": ["exp"]})
    except jwt.PyJWTError as exc:
        raise HTTPException(status_code=401, detail="Token requerido") from exc
    if ("type" in payload and payload["type"] != "access") or any(
        not isinstance(payload.get(claim), str) or not payload[claim].strip()
        for claim in ("sub", "role", "client_id")
    ):
        raise HTTPException(status_code=401, detail="Token requerido")
    return CurrentUser(id=payload["sub"], role=payload["role"], client_id=payload["client_id"])

def verify_role(*allowed_roles: str) -> Callable:
    def role_checker(current_user: CurrentUser = Depends(get_current_user)):
        if current_user.role not in allowed_roles:
            raise HTTPException(status_code=403, detail="Rol insuficiente.")
        return current_user
    return role_checker
