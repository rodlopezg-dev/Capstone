import { useEffect, useRef, useState } from 'react';
import { Capacitor } from '@capacitor/core';

import {
  pickFromGallery,
  takePhoto,
} from '../plugins/CapacitorBridge';
import {
  dataUrlToImageFile,
  isSupportedImageType,
} from '../utils/imageFiles';

export {
  dataUrlToImageFile,
} from '../utils/imageFiles';

interface Props {
  file: File | null;
  onChange: (file: File | null) => void;
  disabled?: boolean;
}


export default function ClosureEvidencePhotoPicker({
  file,
  onChange,
  disabled = false,
}: Props) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [previewUrl, setPreviewUrl] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const selectedImageFile = (
    file && isSupportedImageType(file.type)
  )
    ? file
    : null;

  useEffect(() => {
    if (!selectedImageFile) {
      setPreviewUrl('');
    }
  }, [selectedImageFile]);

  const applyNativePhoto = (
    dataUrl: string,
    source: 'camera' | 'gallery',
  ) => {
    const fileName = source === 'camera'
      ? `evidencia-camara-${Date.now()}`
      : `evidencia-galeria-${Date.now()}`;

    const imageFile = dataUrlToImageFile(
      dataUrl,
      fileName,
    );

    setPreviewUrl(dataUrl);
    setError('');
    onChange(imageFile);
  };

  const handleTakePhoto = async () => {
    if (disabled || busy) return;

    setBusy(true);
    setError('');

    try {
      const dataUrl = await takePhoto();

      // Cancelar la cámara no se considera un error.
      if (!dataUrl) return;

      applyNativePhoto(dataUrl, 'camera');
    } catch {
      setError(
        'No fue posible obtener la fotografía.',
      );
    } finally {
      setBusy(false);
    }
  };

  const handleChoosePhoto = async () => {
    if (disabled || busy) return;

    if (!Capacitor.isNativePlatform()) {
      fileInputRef.current?.click();
      return;
    }

    setBusy(true);
    setError('');

    try {
      const dataUrl = await pickFromGallery();

      // Cancelar la galería no altera la selección actual.
      if (!dataUrl) return;

      applyNativePhoto(dataUrl, 'gallery');
    } catch {
      setError(
        'No fue posible seleccionar la fotografía.',
      );
    } finally {
      setBusy(false);
    }
  };

  const handleBrowserFile = (
    event: React.ChangeEvent<HTMLInputElement>,
  ) => {
    const selectedFile = event.target.files?.[0];

    if (!selectedFile) return;

    if (!isSupportedImageType(selectedFile.type)) {
      setError(
        'Formato no permitido. Usa JPG, PNG o WEBP.',
      );
      event.target.value = '';
      return;
    }

    const reader = new FileReader();

    reader.onload = () => {
      if (typeof reader.result !== 'string') {
        setError(
          'No fue posible generar la vista previa.',
        );
        return;
      }

      setPreviewUrl(reader.result);
      setError('');
      onChange(selectedFile);
    };

    reader.onerror = () => {
      setError(
        'No fue posible leer la fotografía.',
      );
    };

    reader.readAsDataURL(selectedFile);
  };

  return (
    <div className="space-y-3">
      <div>
        <p className="text-sm font-medium mb-1">
          Evidencia de cierre
        </p>

        <p
          className="text-xs"
          style={{ color: '#aaa' }}
        >
          Toma una fotografía o selecciona una imagen existente.
        </p>
      </div>

      <div className="grid grid-cols-2 gap-2">
        <button
          type="button"
          onClick={handleTakePhoto}
          disabled={disabled || busy}
          className="w-full py-3 px-3 rounded-xl text-sm font-medium"
          style={{
            background: '#00E5FF20',
            border: '1px solid rgba(0,229,255,0.3)',
            color: '#00E5FF',
          }}
        >
          📷 Tomar foto
        </button>

        <button
          type="button"
          onClick={handleChoosePhoto}
          disabled={disabled || busy}
          className="w-full py-3 px-3 rounded-xl text-sm font-medium"
          style={{
            background: '#0B2E36',
            border: '1px solid rgba(0,229,255,0.3)',
            color: '#00E5FF',
          }}
        >
          🖼 Elegir foto
        </button>
      </div>

      <input
        ref={fileInputRef}
        type="file"
        accept="image/jpeg,image/png,image/webp"
        className="hidden"
        disabled={disabled || busy}
        onChange={handleBrowserFile}
      />

      {busy && (
        <p
          className="text-xs"
          style={{ color: '#aaa' }}
        >
          Abriendo selector de imagen...
        </p>
      )}

      {error && (
        <p
          className="text-xs"
          style={{ color: '#D72631' }}
        >
          {error}
        </p>
      )}

      {selectedImageFile && (
        <div className="space-y-2">
          <p
            className="text-xs"
            style={{ color: '#00E5FF' }}
          >
            Fotografía seleccionada: {selectedImageFile.name}
          </p>

          {previewUrl && (
            <>
              <p
                className="text-xs"
                style={{ color: '#aaa' }}
              >
                Vista previa — aún no guardada
              </p>

              <img
                src={previewUrl}
                alt="Vista previa de evidencia de cierre"
                className="w-full h-48 object-cover rounded-xl"
              />
            </>
          )}
        </div>
      )}
    </div>
  );
}
