import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routers import rt_reports

app = FastAPI(title="SSO Reports Service")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://sso-dashboard.alloxentric.com", "https://sso-app.alloxentric.com", "http://localhost:5173", "http://localhost:5174", "http://localhost", "https://localhost", "capacitor://localhost"] + [origin.strip() for origin in os.getenv("CORS_ORIGINS", "").split(",") if origin.strip()],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(rt_reports.router)

@app.get("/")
def root():
    return {"status": "ok"}

@app.get("/health", tags=["System"])
def health_check():
    return {"status": "ok", "service": "reports-service"}