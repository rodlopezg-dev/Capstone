import pytest

from app.repositories.rep_talks import TalksRepository
from app.routers import rt_talks


@pytest.mark.asyncio
async def test_export_records_filters_period_and_tenant(
    db,
):
    await db["talks"].insert_many([
        {
            "talk_id": "talk_sep_a",
            "client_id": "empresa_a",
            "title": "EPP Septiembre",
            "month": "9",
            "year": "2026",
        },
        {
            "talk_id": "talk_oct_a",
            "client_id": "empresa_a",
            "title": "EPP Octubre",
            "month": "10",
            "year": "2026",
        },
        {
            "talk_id": "talk_sep_b",
            "client_id": "empresa_b",
            "title": "Otra empresa",
            "month": "9",
            "year": "2026",
        },
    ])

    await db["attendance"].insert_many([
        {
            "attendance_id": "att_sep_a",
            "client_id": "empresa_a",
            "talk_id": "talk_sep_a",
            "topic": "Tema legacy",
            "date": "2026-10-01",
            "area": "Planta",
            "attendees": ["Ana Prueba"],
            "feedback": "Correcto",
            "created_at": "2026-09-20T10:00:00+00:00",
        },
        {
            "attendance_id": "att_oct_a",
            "client_id": "empresa_a",
            "talk_id": "talk_oct_a",
            "topic": "Octubre",
            "date": "2026-10-10",
            "area": "Planta",
            "attendees": ["Luis Prueba"],
            "feedback": "",
            "created_at": "2026-10-10T10:00:00+00:00",
        },
        {
            "attendance_id": "att_sep_b",
            "client_id": "empresa_b",
            "talk_id": "talk_sep_b",
            "topic": "Otra empresa",
            "date": "2026-09-10",
            "area": "Planta",
            "attendees": ["Externo"],
            "feedback": "",
            "created_at": "2026-09-10T10:00:00+00:00",
        },
    ])

    records = await TalksRepository(
        db
    ).list_attendance_for_export(
        "empresa_a",
        month="9",
        year="2026",
    )

    assert [
        item["attendance_id"]
        for item in records
    ] == ["att_sep_a"]

    assert records[0]["talk_title"] == (
        "EPP Septiembre"
    )
    assert records[0]["export_period_month"] == "9"
    assert records[0]["export_period_year"] == "2026"


@pytest.mark.asyncio
async def test_export_records_uses_date_for_legacy_attendance(
    db,
):
    await db["attendance"].insert_one({
        "attendance_id": "att_legacy",
        "client_id": "empresa_a",
        "talk_id": "",
        "topic": "Legacy",
        "date": "2026-09-27",
        "area": "Bodega",
        "attendees": ["Ana Prueba"],
        "feedback": "",
        "created_at": "2026-09-27T10:00:00+00:00",
    })

    records = await TalksRepository(
        db
    ).list_attendance_for_export(
        "empresa_a",
        month="9",
        year="2026",
    )

    assert len(records) == 1
    assert records[0]["attendance_id"] == "att_legacy"


@pytest.mark.asyncio
async def test_export_pdf_returns_downloadable_pdf(
    api,
    db,
    auth_headers,
):
    await db["talks"].insert_one({
        "talk_id": "talk_pdf",
        "client_id": "empresa_a",
        "title": "Uso de EPP",
        "month": "9",
        "year": "2026",
    })

    await db["attendance"].insert_one({
        "attendance_id": "att_pdf",
        "client_id": "empresa_a",
        "talk_id": "talk_pdf",
        "topic": "Uso de EPP",
        "date": "2026-09-27",
        "area": "Planta",
        "source": "qr",
        "attendees": [
            "Ana Prueba",
            "Luis Prueba",
        ],
        "feedback": "Sin observaciones",
        "created_at": "2026-09-27T10:00:00+00:00",
    })

    response = await api.get(
        "/v1/attendance/export/pdf"
        "?month=9&year=2026",
        headers=auth_headers(
            user_id="admin_a",
            role="admin",
        ),
    )

    assert response.status_code == 200
    assert response.content.startswith(
        b"%PDF"
    )
    assert (
        response.headers["content-type"]
        == "application/pdf"
    )
    assert (
        'filename="asistencia_2026_09.pdf"'
        in response.headers[
            "content-disposition"
        ]
    )


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("query", "detail"),
    [
        (
            "month=13&year=2026",
            "Mes inválido.",
        ),
        (
            "month=abc&year=2026",
            "Mes inválido.",
        ),
        (
            "month=9&year=dosmil",
            "Año inválido.",
        ),
    ],
)
async def test_export_pdf_rejects_invalid_period(
    api,
    auth_headers,
    query,
    detail,
):
    response = await api.get(
        f"/v1/attendance/export/pdf?{query}",
        headers=auth_headers(role="admin"),
    )

    assert response.status_code == 422
    assert response.json()["detail"] == detail


@pytest.mark.asyncio
async def test_export_pdf_returns_no_data_message(
    api,
    auth_headers,
):
    response = await api.get(
        "/v1/attendance/export/pdf"
        "?month=9&year=2026",
        headers=auth_headers(role="admin"),
    )

    assert response.status_code == 404
    assert response.json()["detail"] == (
        "No hay registros de asistencia para el período seleccionado."
    )


@pytest.mark.asyncio
async def test_export_pdf_handles_generation_failure(
    api,
    db,
    auth_headers,
    monkeypatch,
):
    await db["attendance"].insert_one({
        "attendance_id": "att_pdf_failure",
        "client_id": "empresa_a",
        "talk_id": "",
        "topic": "Prueba generación PDF",
        "date": "2026-09-27",
        "area": "Planta",
        "attendees": ["Ana Prueba"],
        "feedback": "",
        "created_at": "2026-09-27T10:00:00+00:00",
    })

    def fail_generation(*args, **kwargs):
        raise RuntimeError(
            "detalle interno que no debe exponerse"
        )

    monkeypatch.setattr(
        rt_talks,
        "build_attendance_pdf",
        fail_generation,
    )

    response = await api.get(
        "/v1/attendance/export/pdf"
        "?month=9&year=2026",
        headers=auth_headers(role="admin"),
    )

    assert response.status_code == 500
    assert response.json()["detail"] == (
        "No fue posible generar la exportación PDF."
    )
    assert (
        "detalle interno que no debe exponerse"
        not in response.text
    )
