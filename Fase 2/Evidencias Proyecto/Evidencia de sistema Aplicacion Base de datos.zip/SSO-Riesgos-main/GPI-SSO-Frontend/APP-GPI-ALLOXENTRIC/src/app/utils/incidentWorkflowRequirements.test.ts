import {
  describe,
  expect,
  it,
} from 'vitest';

import {
  getClosureTransitionMissingFields,
  getProcessTransitionMissingFields,
} from './incidentWorkflowRequirements';

const completeReport = {
  type: 'Condición Insegura',
  is_iap: false,
  causes: ['Procedimiento no aplicado'],
  probable_consequence: 'Caída',
  analysis: 'Se identificó la causa principal.',
  control_measures: ['Instalar señalización'],
  training: 'Capacitación realizada.',
  deadline: '2026-10-10',
  feedback: 'Trabajador informado.',
  closure_evidence: {
    url: '/closure.pdf',
  },
};

describe('incidentWorkflowRequirements - TT-16', () => {
  it('allows process transition when persisted analysis is complete', () => {
    expect(
      getProcessTransitionMissingFields(
        completeReport,
      ),
    ).toEqual([]);
  });

  it.each([
    ['type', ''],
    ['causes', []],
    ['probable_consequence', ''],
    ['analysis', ''],
  ])(
    'blocks process transition when %s is missing',
    (field, value) => {
      expect(
        getProcessTransitionMissingFields({
          ...completeReport,
          [field]: value,
        }),
      ).not.toEqual([]);
    },
  );

  it('accepts legacy IAP classification through is_iap', () => {
    expect(
      getProcessTransitionMissingFields({
        ...completeReport,
        type: 'Otro valor legacy',
        is_iap: true,
      }),
    ).toEqual([]);
  });

  it('allows closure request when persisted treatment is complete', () => {
    expect(
      getClosureTransitionMissingFields(
        completeReport,
      ),
    ).toEqual([]);
  });

  it.each([
    ['control_measures', []],
    ['training', ''],
    ['deadline', ''],
    ['feedback', ''],
    ['closure_evidence', undefined],
  ])(
    'blocks closure request when %s is missing',
    (field, value) => {
      expect(
        getClosureTransitionMissingFields({
          ...completeReport,
          [field]: value,
        }),
      ).not.toEqual([]);
    },
  );

  it('treats whitespace-only persisted text as incomplete', () => {
    expect(
      getProcessTransitionMissingFields({
        ...completeReport,
        analysis: '   ',
      }),
    ).toContain('análisis del supervisor');

    expect(
      getClosureTransitionMissingFields({
        ...completeReport,
        feedback: '   ',
      }),
    ).toContain('feedback al trabajador');
  });
});
