interface Props {
  file: File | null;
  onChange: (file: File | null) => void;
  disabled?: boolean;
}

export function isPdfEvidenceFile(file: File | null): boolean {
  if (!file) return false;

  return (
    file.type.toLowerCase() === 'application/pdf'
    || file.name.toLowerCase().endsWith('.pdf')
  );
}

export function formatEvidenceFileSize(bytes: number): string {
  if (bytes < 1024) {
    return `${bytes} B`;
  }

  const kilobytes = bytes / 1024;

  if (kilobytes < 1024) {
    return `${kilobytes.toFixed(1)} KB`;
  }

  return `${(kilobytes / 1024).toFixed(1)} MB`;
}

export default function ClosureEvidencePdfPicker({
  file,
  onChange,
  disabled = false,
}: Props) {
  const selectedPdf = isPdfEvidenceFile(file)
    ? file
    : null;

  const handleChange = (
    event: React.ChangeEvent<HTMLInputElement>,
  ) => {
    const selected = event.target.files?.[0];

    // Cancelar el selector conserva la evidencia anterior.
    if (!selected) return;

    if (!isPdfEvidenceFile(selected)) {
      event.target.value = '';
      return;
    }

    onChange(selected);

    // Permite seleccionar nuevamente el mismo documento.
    event.target.value = '';
  };

  return (
    <div className="space-y-2">
      <label
        className="w-full flex items-center justify-center gap-2 p-3 rounded-xl cursor-pointer"
        style={{
          background: '#0B2E36',
          border: '1px solid rgba(0,229,255,0.3)',
          color: '#00E5FF',
        }}
      >
        <input
          type="file"
          accept="application/pdf,.pdf"
          className="hidden"
          disabled={disabled}
          onChange={handleChange}
        />

        <span className="text-sm font-medium">
          📄 Elegir PDF
        </span>
      </label>

      {selectedPdf && (
        <div
          className="rounded-xl p-3"
          style={{
            background: 'rgba(0,229,255,0.08)',
            border: '1px solid rgba(0,229,255,0.2)',
          }}
        >
          <p
            className="text-xs font-medium break-all"
            style={{ color: '#00E5FF' }}
          >
            PDF seleccionado: {selectedPdf.name}
          </p>

          <p
            className="text-xs mt-1"
            style={{ color: '#aaa' }}
          >
            {formatEvidenceFileSize(selectedPdf.size)}
            {' · '}
            aún no guardado
          </p>
        </div>
      )}
    </div>
  );
}
