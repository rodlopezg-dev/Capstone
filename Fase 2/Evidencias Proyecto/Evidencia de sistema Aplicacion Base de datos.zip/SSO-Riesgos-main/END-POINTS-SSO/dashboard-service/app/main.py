from fastapi import FastAPI, HTTPException, Request, Response
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import os
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv
from app.routers import dashboard

load_dotenv()

app = FastAPI(
    title="Dashboard Service - SSO Alloxentric",
    description="Microservicio de Dashboard y Heat Map para la plataforma SSO",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://sso-dashboard.alloxentric.com", "https://sso-app.alloxentric.com", "http://localhost:5173", "http://localhost:5174", "http://localhost", "https://localhost", "capacitor://localhost"],  # En producción reemplazar por la URL del frontend
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(dashboard.router)


@app.get("/health", tags=["System"])
def health_check():
    return {"status": "ok", "service": "dashboard-service"}


# Proxy talks-service
import httpx

TALKS_URL = os.getenv("TALKS_SERVICE_URL", "http://sso-talks-service:8080")

# La web distribuida como bundle utiliza rutas relativas. El dashboard actúa
# como punto de entrada único para que el navegador no dependa de puertos
# internos ni de dominios externos durante el desarrollo local.
SERVICE_URLS = {
    "auth": os.getenv("AUTH_SERVICE_URL", "http://sso-auth:8080"),
    "users": os.getenv("USERS_SERVICE_URL", "http://sso-users:8080"),
    "workers": os.getenv("WORKERS_SERVICE_URL", "http://sso-workers:8080"),
    "reports": os.getenv("REPORTS_SERVICE_URL", "http://sso-reports:8080"),
    "alerts": os.getenv("ALERTS_SERVICE_URL", "http://sso-alerts:8080"),
    "areas": os.getenv("AREAS_SERVICE_URL", "http://sso-areas:8080"),
    "incidents": os.getenv("INCIDENTS_SERVICE_URL", "http://sso-incidents:8080"),
    "digital-twin": os.getenv("DIGITAL_TWIN_SERVICE_URL", "http://sso-digital-twin:8080"),
}


async def proxy_request(target_url: str, path: str, request: Request) -> Response:
    url = f"{target_url}/{path}"
    headers = {k: v for k, v in request.headers.items() if k.lower() not in ("host", "content-length")}
    body = await request.body()
    async with httpx.AsyncClient() as client:
        resp = await client.request(request.method, url, headers=headers, content=body, params=request.query_params, timeout=30)
    return Response(content=resp.content, status_code=resp.status_code, headers=dict(resp.headers))

@app.api_route("/api/talks/{path:path}", methods=["GET","POST","PUT","DELETE","PATCH"], tags=["Proxy"])
async def proxy_talks(path: str, request: Request):
    return await proxy_request(TALKS_URL, path, request)


@app.api_route("/api/{service}/{path:path}", methods=["GET", "POST", "PUT", "DELETE", "PATCH"], tags=["Proxy"])
async def proxy_service(service: str, path: str, request: Request):
    target_url = SERVICE_URLS.get(service)
    if target_url is None:
        raise HTTPException(status_code=404, detail="Servicio no disponible")
    return await proxy_request(target_url, path, request)

# Servir frontend estático
static_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "static")
if os.path.exists(static_dir):
    app.mount("/assets", StaticFiles(directory=os.path.join(static_dir, "assets")), name="assets")

    @app.get("/{full_path:path}", tags=["Frontend"])
    async def serve_frontend(full_path: str):
        file_path = os.path.join(static_dir, full_path)
        if os.path.isfile(file_path):
            return FileResponse(file_path)
        return FileResponse(os.path.join(static_dir, "index.html"))
