import {
  beforeEach,
  describe,
  expect,
  it,
  vi,
} from 'vitest';

import { apiFetch } from './client';

import {
  getUserProfile,
  updateUserProfile,
} from './users';

vi.mock('./client', () => ({
  apiFetch: vi.fn(),
}));

const apiFetchMock =
  vi.mocked(apiFetch) as any;

describe(
  'user profile API - SCRUM-133',
  () => {
    beforeEach(() => {
      vi.clearAllMocks();
    });

    it(
      'loads the authenticated user profile from users-service',
      async () => {
        apiFetchMock.mockResolvedValueOnce({
          user_id: 'usr_a',
          client_id: 'tenant_a',
          name: 'Rodrigo',
          last_name: 'Prueba',
        });

        await getUserProfile();

        expect(apiFetchMock).toHaveBeenCalledWith(
          '/v1/users/me',
          {
            base: 'users',
          },
        );
      },
    );

    it(
      'updates only self-service profile fields',
      async () => {
        apiFetchMock.mockResolvedValueOnce({
          user_id: 'usr_a',
          client_id: 'tenant_a',
          name: 'Nombre Nuevo',
          last_name: 'Apellido Nuevo',
        });

        await updateUserProfile({
          name: 'Nombre Nuevo',
          last_name: 'Apellido Nuevo',
        });

        expect(apiFetchMock).toHaveBeenCalledWith(
          '/v1/users/me',
          {
            method: 'PATCH',
            base: 'users',
            body: JSON.stringify({
              name: 'Nombre Nuevo',
              last_name: 'Apellido Nuevo',
            }),
          },
        );
      },
    );
  },
);
