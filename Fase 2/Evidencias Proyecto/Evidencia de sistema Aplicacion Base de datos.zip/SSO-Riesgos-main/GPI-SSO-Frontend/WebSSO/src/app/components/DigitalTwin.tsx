import { HelpTooltip } from './HelpTooltip';
import { useState, useCallback, useEffect } from 'react';
import { Upload, Square, Pentagon, MousePointer, Move, Trash2, Plus, X, CheckCircle, AlertCircle, Save, RefreshCw } from 'lucide-react';

// ─── CONFIG ───────────────────────────────────────────────────────────────────
const API_URL = import.meta.env.VITE_DIGITAL_TWIN_API_URL || 'http://localhost:8007';

function getToken(): string {
  return localStorage.getItem('sso_token') || '';
}

async function apiFetch<T>(path: string, options: RequestInit = {}): Promise<T> {
  const res = await fetch(`${API_URL}${path}`, {
    ...options,
    headers: {
      ...(options.body instanceof FormData ? {} : { 'Content-Type': 'application/json' }),
      Authorization: `Bearer ${getToken()}`,
      ...options.headers,
    },
  });
  if (!res.ok) throw new Error(`Error ${res.status}`);
  return res.json();
}

// ─── TIPOS ────────────────────────────────────────────────────────────────────

type PolygonPoint = { x: number; y: number };

type Zone = {
  id:       number;
  zone_id?: string;
  name:     string;
  process:  string;
  color:    string;
  x:        number;
  y:        number;
  width:    number;
  height:   number;
  polygon?: PolygonPoint[];
};

// ─── STORAGE KEYS (para CommandCenter) ───────────────────────────────────────
export const STORAGE_KEY_PLAN  = 'sso_floor_plan';
export const STORAGE_KEY_ZONES = 'sso_zones';

const tools = [
  { id: 'select',    label: 'Seleccionar', icon: MousePointer },
  { id: 'rectangle', label: 'Rectángulo',  icon: Square       },
  { id: 'polygon',   label: 'Polígono',    icon: Pentagon     },
  { id: 'move',      label: 'Mover',       icon: Move         },
  { id: 'delete',    label: 'Eliminar',    icon: Trash2       },
];

const colors = ['#00E5FF','#1A5276','#16A34A','#E8941A','#D72631','#2E6A93','#4DEDFF','#0097A8'];

// Convierte zona rectangular a polígono para el backend
function zoneToPolygon(zone: Zone): PolygonPoint[] {
  return [
    { x: zone.x,             y: zone.y              },
    { x: zone.x + zone.width, y: zone.y              },
    { x: zone.x + zone.width, y: zone.y + zone.height },
    { x: zone.x,             y: zone.y + zone.height },
  ];
}

// Convierte polígono del backend a zona rectangular
function polygonToZone(polygon: PolygonPoint[]): { x: number; y: number; width: number; height: number } {
  const xs = polygon.map(p => p.x);
  const ys = polygon.map(p => p.y);
  const x = Math.min(...xs);
  const y = Math.min(...ys);
  return { x, y, width: Math.max(...xs) - x, height: Math.max(...ys) - y };
}

export default function DigitalTwin() {
  const [zones, setZones]             = useState<Zone[]>([]);
  const [uploadedPlan, setUploadedPlan] = useState<string | null>(null);
  const [loading, setLoading]         = useState(true);
  const [saving, setSaving]           = useState(false);

  const [selectedTool, setSelectedTool]     = useState('select');
  const [selectedZone, setSelectedZone]     = useState<number | null>(null);
  const [hoveredZone, setHoveredZone]       = useState<number | null>(null);
  const [newZoneName, setNewZoneName]       = useState('');
  const [newZoneProcess, setNewZoneProcess] = useState('');
  const [newZoneColor, setNewZoneColor]     = useState('#00E5FF');
  const [apiAreas, setApiAreas] = useState<{name: string, zones: string[], jefe?: string}[]>([]);
  const [selectedArea, setSelectedArea] = useState('');
  const [uploadError, setUploadError]       = useState<string | null>(null);
  const [uploadSuccess, setUploadSuccess]   = useState(false);
  const [isDragging, setIsDragging]         = useState(false);
  const [saveSuccess, setSaveSuccess]       = useState(false);
  const [isDrawing, setIsDrawing]           = useState(false);
  const [drawStart, setDrawStart]           = useState<{ x: number; y: number } | null>(null);
  const [tempZone, setTempZone]             = useState<{ x: number; y: number; width: number; height: number } | null>(null);
  const [isMoving, setIsMoving]             = useState(false);
  const [moveStart, setMoveStart]           = useState<{ x: number; y: number; zoneX: number; zoneY: number } | null>(null);

  // ── Cargar datos desde el backend ─────────────────────────────────────────
  const fetchAreas = async () => {
    try {
      const res = await fetch(window.location.origin + '/api/areas/v1/areas/', {
        headers: { Authorization: 'Bearer ' + getToken() }
      });
      if (res.ok) {
        const data = await res.json();
        setApiAreas((Array.isArray(data) ? data : data.data || []).map((a: any) => ({name: a.name, zones: a.zones || [], jefe: a.jefe || ''})));
      }
    } catch (e) { console.error(e); }
  };

  const loadData = async () => {
    setLoading(true);
    try {
      // Cargar plano
      const planRes = await apiFetch<{ floor_plan_url: string | null; has_floor_plan: boolean }>('/v1/plant/floor-plan');
      if (planRes.has_floor_plan && planRes.floor_plan_url) {
        setUploadedPlan(planRes.floor_plan_url);
        localStorage.setItem(STORAGE_KEY_PLAN, planRes.floor_plan_url);
      }

      // Cargar zonas
      const zonesRes = await apiFetch<{ data: any[]; total: number }>('/v1/zones');
      const mapped: Zone[] = zonesRes.data.map((z, i) => {
        const rect = z.polygon ? polygonToZone(z.polygon) : { x: 10, y: 10, width: 20, height: 15 };
        return { id: i + 1, zone_id: z.zone_id, name: z.name, process: z.process, color: z.color, ...rect, polygon: z.polygon };
      });
      setZones(mapped);
      localStorage.setItem(STORAGE_KEY_ZONES, JSON.stringify(mapped));
    } catch (err) {
      console.error('Error cargando datos del gemelo digital:', err);
      // Fallback a localStorage
      try {
        const s = localStorage.getItem(STORAGE_KEY_ZONES);
        if (s) setZones(JSON.parse(s));
        const p = localStorage.getItem(STORAGE_KEY_PLAN);
        if (p) setUploadedPlan(p);
      } catch {}
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { loadData(); fetchAreas(); }, []);

  // ── Guardar todo al backend ────────────────────────────────────────────────
  const handleSave = async () => {
    setSaving(true);
    try {
      // Guardar zonas al backend
      for (const zone of zones) {
        const payload = {
          name:    zone.name,
          process: zone.process,
          color:   zone.color,
          polygon: zoneToPolygon(zone),
        };
        if (zone.zone_id) {
          // Actualizar zona existente
          await apiFetch(`/v1/zones/${zone.zone_id}`, { method: 'PATCH', body: JSON.stringify(payload) });
        } else {
          // Crear zona nueva
          const created = await apiFetch<any>('/v1/zones', { method: 'POST', body: JSON.stringify(payload) });
          zone.zone_id = created.zone_id;
        }
      }

      // Guardar en localStorage como backup para CommandCenter
      localStorage.setItem(STORAGE_KEY_ZONES, JSON.stringify(zones));
      if (uploadedPlan) localStorage.setItem(STORAGE_KEY_PLAN, uploadedPlan);

      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (err) {
      alert('Error al guardar. Intenta de nuevo.');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteZone = async () => {
    if (selectedZone === null) return;
    const zone = zones.find(z => z.id === selectedZone);
    if (zone?.zone_id) {
      try { await apiFetch(`/v1/zones/${zone.zone_id}`, { method: 'DELETE' }); } catch {}
    }
    setZones(zones.filter(z => z.id !== selectedZone));
    setSelectedZone(null);
  };

  const handleAddZone = () => {
    if (newZoneName && newZoneProcess) {
      const z: Zone = { id: Date.now(), name: newZoneName, process: newZoneProcess, color: newZoneColor, x: 10, y: 10, width: 20, height: 15 };
      setZones([...zones, z]); setNewZoneName(''); setNewZoneProcess(''); setSelectedZone(z.id);
    }
  };

  // ── Canvas handlers ────────────────────────────────────────────────────────
  const handleCanvasMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    if (selectedTool === 'select') return;
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    if (selectedTool === 'rectangle') { setIsDrawing(true); setDrawStart({ x, y }); setTempZone({ x, y, width: 0, height: 0 }); }
    else if (selectedTool === 'move' && selectedZone !== null) {
      const zone = zones.find(z => z.id === selectedZone);
      if (zone) { setIsMoving(true); setMoveStart({ x, y, zoneX: zone.x, zoneY: zone.y }); }
    }
  };

  const handleCanvasMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    if (isDrawing && drawStart) {
      const w = x - drawStart.x, h = y - drawStart.y;
      setTempZone({ x: w < 0 ? x : drawStart.x, y: h < 0 ? y : drawStart.y, width: Math.abs(w), height: Math.abs(h) });
    } else if (isMoving && moveStart && selectedZone !== null) {
      setZones(zones.map(z => z.id === selectedZone
        ? { ...z, x: Math.max(0, Math.min(100 - z.width, moveStart.zoneX + x - moveStart.x)), y: Math.max(0, Math.min(100 - z.height, moveStart.zoneY + y - moveStart.y)) }
        : z));
    }
  };

  const handleCanvasMouseUp = () => {
    if (isDrawing && tempZone && tempZone.width > 2 && tempZone.height > 2) {
      const z: Zone = { id: Date.now(), name: `Zona ${zones.length + 1}`, process: 'Sin asignar', color: colors[zones.length % colors.length], x: tempZone.x, y: tempZone.y, width: tempZone.width, height: tempZone.height };
      setZones([...zones, z]); setSelectedZone(z.id);
    }
    setIsDrawing(false); setDrawStart(null); setTempZone(null); setIsMoving(false); setMoveStart(null);
  };

  // ── Upload handlers ────────────────────────────────────────────────────────
  const validateFile = (file: File) => {
    const allowed = ['image/jpeg','image/png','image/jpg','application/pdf','image/vnd.dxf','application/dxf','application/dwg','image/x-dwg'];
    const ext = file.name.split('.').pop()?.toLowerCase();
    const allowedExts = ['jpg','jpeg','png','pdf','dxf','dwg'];
    if (!allowedExts.includes(ext || '')) return 'Formato no permitido. Se acepta JPG, PNG, PDF, DXF o DWG.';
    if (file.size > 20 * 1024 * 1024) return 'Archivo demasiado grande. Máximo 20 MB.';
    return null;
  };

  const handleFileSelect = async (file: File) => {
    setUploadError(null); setUploadSuccess(false);
    const err = validateFile(file);
    if (err) { setUploadError(err); return; }

    const ext = file.name.split('.').pop()?.toLowerCase();

    // Para DWG/DXF/PDF subir al backend para conversión
    if (['dwg','dxf','pdf'].includes(ext || '')) {
      try {
        const form = new FormData();
        form.append('file', file);
        const res = await apiFetch<{ floor_plan_url: string }>('/v1/plant/floor-plan', { method: 'POST', body: form });
        setUploadedPlan(res.floor_plan_url);
        localStorage.setItem(STORAGE_KEY_PLAN, res.floor_plan_url);
        setUploadSuccess(true);
        setTimeout(() => setUploadSuccess(false), 3000);
      } catch {
        setUploadError('Error al subir el archivo al servidor.');
      }
      return;
    }

    // Para imágenes normales, leer localmente y subir
    const reader = new FileReader();
    reader.onload = async e => {
      if (!e.target?.result) return;
      const dataUrl = e.target.result as string;
      setUploadedPlan(dataUrl);

      try {
        const form = new FormData();
        form.append('file', file);
        const res = await apiFetch<{ floor_plan_url: string }>('/v1/plant/floor-plan', { method: 'POST', body: form });
        setUploadedPlan(res.floor_plan_url);
        localStorage.setItem(STORAGE_KEY_PLAN, res.floor_plan_url);
      } catch {
        // Si falla el upload, al menos mostrar localmente
        localStorage.setItem(STORAGE_KEY_PLAN, dataUrl);
      }

      setUploadSuccess(true);
      setTimeout(() => setUploadSuccess(false), 3000);
    };
    reader.readAsDataURL(file);
  };

  const handleDrop     = useCallback((e: React.DragEvent) => { e.preventDefault(); setIsDragging(false); if (e.dataTransfer.files[0]) handleFileSelect(e.dataTransfer.files[0]); }, []);
  const handleDragOver  = useCallback((e: React.DragEvent) => { e.preventDefault(); setIsDragging(true); }, []);
  const handleDragLeave = useCallback(() => setIsDragging(false), []);
  const clearPlan = () => { setUploadedPlan(null); setUploadError(null); setUploadSuccess(false); localStorage.removeItem(STORAGE_KEY_PLAN); };

  const selectedZoneData = zones.find(z => z.id === selectedZone);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement;
      if (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA') return;
      if ((e.key === 'Delete' || e.key === 'Backspace') && selectedZone !== null) { e.preventDefault(); handleDeleteZone(); }
      else if (e.key === 'Escape') { setSelectedZone(null); setSelectedTool('select'); }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedZone, zones]);

  // ─── RENDER ───────────────────────────────────────────────────────────────

  return (
    <div className="h-full p-6 overflow-auto">
      <div className="mb-6 flex items-start justify-between pr-32">
        <div>
          <h1 className="text-4xl mb-2 tracking-tight" style={{ fontFamily: 'var(--font-display)', fontWeight: 700 }}>GEMELO DIGITAL</h1>
          <HelpTooltip steps={[
      { icon: '🏭', title: '¿Qué es el Gemelo Digital?', description: 'Es un plano interactivo de la planta donde puedes dibujar y nombrar zonas operativas. Estas zonas se usan en el mapa de calor del Command Center.' },
      { icon: '✏️', title: 'Herramientas de dibujo', description: 'Usa la barra de herramientas: Seleccionar para mover, Rectángulo o Polígono para crear zonas, Mover para reposicionar, y Eliminar para borrar zonas.' },
      { icon: '🎨', title: 'Personalizar zonas', description: 'Selecciona una zona del plano y asígnale un color y nombre desde el panel derecho. El color representa el tipo de área operativa.' },
      { icon: '💾', title: 'Guardar cambios', description: 'Presiona "Guardar" para persistir el plano en la base de datos. Los cambios se reflejan inmediatamente en el mapa de calor.' },
    ]} />
          <p className="text-muted-foreground">Configuración de representación digital de la planta</p>
        </div>
        <div className="flex gap-2 mt-1">
          <button onClick={loadData} className="flex items-center gap-2 px-4 py-2 bg-secondary text-secondary-foreground rounded-lg hover:bg-secondary/80">
            <RefreshCw size={16} className={loading ? 'animate-spin' : ''} />
          </button>
          <button onClick={handleSave} disabled={saving}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all ${saveSuccess ? 'bg-[#16A34A] text-white' : 'bg-primary text-primary-foreground hover:bg-primary/90'} disabled:opacity-50`}>
            {saving ? <RefreshCw size={16} className="animate-spin" /> : saveSuccess ? <CheckCircle size={16} /> : <Save size={16} />}
            {saving ? 'Guardando...' : saveSuccess ? '¡Guardado!' : 'Guardar'}
          </button>
        </div>
      </div>

      {saveSuccess && (
        <div className="mb-4 p-3 bg-[#16A34A]/20 border border-[#16A34A]/50 rounded-lg text-[#16A34A] text-sm flex items-center gap-2">
          <CheckCircle size={16} />
          Plano y zonas guardados en la nube. El Command Center los usará automáticamente.
        </div>
      )}

      {loading && (
        <div className="flex items-center justify-center py-12 text-muted-foreground gap-3">
          <RefreshCw size={24} className="animate-spin" />
          Cargando gemelo digital...
        </div>
      )}

      {!loading && (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <div className="lg:col-span-3 space-y-6">
            {/* Upload */}
            <div className="bg-card border border-border rounded-lg p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl" style={{ fontFamily: 'var(--font-display)', fontWeight: 600 }}>PLANO BASE</h2>
                {uploadedPlan && <button onClick={clearPlan} className="text-sm text-muted-foreground hover:text-destructive flex items-center gap-1"><X size={16} />Eliminar</button>}
              </div>
              {!uploadedPlan ? (
                <div onDrop={handleDrop} onDragOver={handleDragOver} onDragLeave={handleDragLeave}
                  className={`border-2 border-dashed rounded-lg p-12 text-center transition-all cursor-pointer ${isDragging ? 'border-primary bg-primary/10' : uploadError ? 'border-destructive bg-destructive/5' : 'border-border hover:border-primary/50'}`}>
                  <input type="file" id="plan-upload" accept=".jpg,.jpeg,.png,.pdf,.dxf,.dwg" onChange={e => e.target.files?.[0] && handleFileSelect(e.target.files[0])} className="hidden" />
                  <label htmlFor="plan-upload" className="cursor-pointer block">
                    {uploadError ? <AlertCircle className="mx-auto mb-4 text-destructive" size={48} /> : <Upload className="mx-auto mb-4 text-muted-foreground" size={48} />}
                    <p className={`mb-2 ${uploadError ? 'text-destructive' : 'text-muted-foreground'}`}>{uploadError || 'Arrastra y suelta tu plano aquí o haz clic para seleccionar'}</p>
                    <p className="text-sm text-muted-foreground">JPG, PNG, PDF, DXF o DWG — Máximo 20 MB</p>
                  </label>
                </div>
              ) : (
                <div className="relative bg-secondary/30 rounded-lg overflow-hidden">
                  <img src={uploadedPlan} alt="Plano" className="w-full h-auto" />
                  <div className="absolute top-2 right-2 px-3 py-1 bg-[#16A34A]/20 text-[#16A34A] rounded-full text-xs flex items-center gap-1"><CheckCircle size={14} />Plano cargado</div>
                </div>
              )}
            </div>

            {/* Editor */}
            <div className="bg-card border border-border rounded-lg p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl" style={{ fontFamily: 'var(--font-display)', fontWeight: 600 }}>EDITOR DE ZONAS</h2>
                <div className="flex gap-2">
                  {tools.map(tool => { const Icon = tool.icon; return (
                    <button key={tool.id} onClick={() => setSelectedTool(tool.id)} title={tool.label}
                      className={`p-2 rounded transition-all ${selectedTool === tool.id ? 'bg-primary text-primary-foreground' : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'}`}>
                      <Icon size={18} />
                    </button>
                  ); })}
                  {selectedZone !== null && (
                    <button onClick={handleDeleteZone} className="ml-2 p-2 rounded bg-destructive/20 text-destructive hover:bg-destructive/30"><Trash2 size={18} /></button>
                  )}
                </div>
              </div>

              <div className="relative bg-secondary/30 rounded-lg aspect-[4/3] border border-border overflow-hidden"
                onMouseDown={handleCanvasMouseDown} onMouseMove={handleCanvasMouseMove} onMouseUp={handleCanvasMouseUp} onMouseLeave={handleCanvasMouseUp}
                style={{ cursor: selectedTool === 'rectangle' ? 'crosshair' : selectedTool === 'move' ? 'move' : selectedTool === 'delete' ? 'not-allowed' : 'default' }}>

                {uploadedPlan && <img src={uploadedPlan} alt="fondo" className="absolute inset-0 w-full h-full object-contain opacity-70 pointer-events-none" />}
                <div className="absolute inset-0 opacity-10 pointer-events-none" style={{ backgroundImage: 'linear-gradient(rgba(255,255,255,0.1) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,0.1) 1px,transparent 1px)', backgroundSize: '20px 20px' }} />

                {zones.map(zone => (
                  <div key={zone.id}
                    className={`absolute ${isMoving && selectedZone === zone.id ? '' : 'transition-all duration-100'} ${['select','move','delete'].includes(selectedTool) ? 'cursor-pointer' : 'pointer-events-none'}`}
                    style={{ left: `${zone.x}%`, top: `${zone.y}%`, width: `${zone.width}%`, height: `${zone.height}%`, zIndex: isMoving && selectedZone === zone.id ? 10 : 1 }}
                    onClick={e => { 
  e.stopPropagation(); 
  if (selectedTool === 'delete') { 
    setSelectedZone(zone.id);
    setZones(prev => prev.filter(z => z.id !== zone.id));
    if (zone.zone_id) apiFetch(`/v1/zones/${zone.zone_id}`, { method: 'DELETE' }).catch(() => {});
  } else {
    setSelectedZone(zone.id);
  }
}}
                    onMouseDown={e => { e.stopPropagation(); if (selectedTool === 'move') { setSelectedZone(zone.id); const r = e.currentTarget.parentElement!.getBoundingClientRect(); setIsMoving(true); setMoveStart({ x: ((e.clientX - r.left) / r.width) * 100, y: ((e.clientY - r.top) / r.height) * 100, zoneX: zone.x, zoneY: zone.y }); } }}
                    onMouseEnter={() => setHoveredZone(zone.id)} onMouseLeave={() => setHoveredZone(null)}>
                    <div className="w-full h-full rounded border-2 transition-all"
                      style={{ backgroundColor: selectedTool === 'delete' && hoveredZone === zone.id ? '#D7263180' : `${zone.color}40`, borderColor: selectedTool === 'delete' && hoveredZone === zone.id ? '#D72631' : zone.color, boxShadow: selectedZone === zone.id || hoveredZone === zone.id ? `0 0 20px ${zone.color}80` : 'none', transform: isMoving && selectedZone === zone.id ? 'scale(1.02)' : 'scale(1)' }}>
                      <div className="p-2">
                        <div className="text-xs font-medium px-2 py-1 rounded" style={{ backgroundColor: zone.color, color: '#fff' }}>{zone.name}</div>
                      </div>
                    </div>
                  </div>
                ))}

                {isDrawing && tempZone && (
                  <div className="absolute border-2 border-dashed pointer-events-none" style={{ left: `${tempZone.x}%`, top: `${tempZone.y}%`, width: `${tempZone.width}%`, height: `${tempZone.height}%`, borderColor: colors[zones.length % colors.length], backgroundColor: `${colors[zones.length % colors.length]}20` }} />
                )}

                <div className="absolute bottom-4 left-4 right-4 bg-background/80 backdrop-blur-sm border border-border rounded px-3 py-2 text-xs text-muted-foreground pointer-events-none">
                  {selectedTool === 'select'    && 'Clic en una zona para seleccionarla'}
                  {selectedTool === 'rectangle' && 'Clic y arrastra para dibujar una zona'}
                  {selectedTool === 'move'      && (selectedZone ? 'Arrastra para mover' : 'Selecciona una zona primero')}
                  {selectedTool === 'delete'    && 'Clic en una zona para eliminarla'}
                  {selectedTool === 'polygon'   && 'Herramienta de polígono próximamente'}
                </div>
              </div>
            </div>

            {/* Properties */}
            {selectedZoneData && (
              <div className="bg-card border border-border rounded-lg p-6">
                <h2 className="text-xl mb-4" style={{ fontFamily: 'var(--font-display)', fontWeight: 600 }}>PROPIEDADES DE ZONA</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="text-sm text-muted-foreground mb-2 block">Área</label>
                    <select value={selectedZoneData.process} onChange={e => setZones(zones.map(z => z.id === selectedZone ? { ...z, process: e.target.value } : z))}
                      className="w-full px-3 py-2 bg-secondary border border-border rounded focus:outline-none focus:ring-2 focus:ring-primary">
                      <option value="">Seleccionar área...</option>
                      {apiAreas.map(a => <option key={a.name} value={a.name}>{a.name}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="text-sm text-muted-foreground mb-2 block">Zona</label>
                    <select value={selectedZoneData.name} onChange={e => setZones(zones.map(z => z.id === selectedZone ? { ...z, name: e.target.value } : z))}
                      className="w-full px-3 py-2 bg-secondary border border-border rounded focus:outline-none focus:ring-2 focus:ring-primary">
                      <option value="">Seleccionar zona...</option>
                      {(apiAreas.find(a => a.name === selectedZoneData.process)?.zones || []).map(z => <option key={z} value={z}>{z}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="text-sm text-muted-foreground mb-2 block">Color</label>
                    <div className="flex gap-2 flex-wrap">
                      {colors.map(color => (
                        <button key={color} onClick={() => setZones(zones.map(z => z.id === selectedZone ? { ...z, color } : z))}
                          className={`w-8 h-8 rounded border-2 ${selectedZoneData.color === color ? 'border-white scale-110' : 'border-transparent'}`}
                          style={{ backgroundColor: color }} />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Zones List */}
          <div>
            <div className="bg-card border border-border rounded-lg p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl" style={{ fontFamily: 'var(--font-display)', fontWeight: 600 }}>ZONAS</h2>
                <span className="text-sm font-mono px-3 py-1 bg-primary/20 text-primary rounded-full">{zones.length}</span>
              </div>
              <div className="space-y-2 mb-4">
                {zones.map(zone => (
                  <button key={zone.id} onClick={() => setSelectedZone(zone.id)}
                    className={`w-full p-3 rounded-lg text-left transition-all border ${selectedZone === zone.id ? 'bg-primary/20 border-primary' : 'bg-secondary/50 border-border hover:border-primary/50'}`}>
                    <div className="flex items-center gap-3 mb-1">
                      <div className="w-4 h-4 rounded" style={{ backgroundColor: zone.color }} />
                      <div className="font-medium text-sm">{zone.name}</div>
                    </div>
                    <div className="text-xs text-muted-foreground pl-7">{zone.process}</div>
                  </button>
                ))}
              </div>
              <div className="border-t border-border pt-4 space-y-3">
                <h3 className="text-sm font-medium text-muted-foreground">Agregar Nueva Zona</h3>
                <select value={selectedArea} onChange={e => { setSelectedArea(e.target.value); setNewZoneProcess(e.target.value); setNewZoneName(''); }}
                  className="w-full px-3 py-2 bg-secondary border border-border rounded text-sm focus:outline-none focus:ring-2 focus:ring-primary">
                  <option value="">Seleccionar área...</option>
                  {apiAreas.map(a => <option key={a.name} value={a.name}>{a.name} {a.jefe ? '(' + a.jefe + ')' : ''}</option>)}
                </select>
                {selectedArea && (
                  <select value={newZoneName} onChange={e => setNewZoneName(e.target.value)}
                    className="w-full px-3 py-2 bg-secondary border border-border rounded text-sm focus:outline-none focus:ring-2 focus:ring-primary">
                    <option value="">Seleccionar zona...</option>
                    {(apiAreas.find(a => a.name === selectedArea)?.zones || []).map(z => <option key={z} value={z}>{z}</option>)}
                    <option value="__custom">+ Crear zona personalizada</option>
                  </select>
                )}
                {newZoneName === '__custom' && (
                  <input type="text" placeholder="Nombre de zona personalizada" onChange={e => setNewZoneName(e.target.value)}
                    className="w-full px-3 py-2 bg-secondary border border-border rounded text-sm focus:outline-none focus:ring-2 focus:ring-primary" />
                )}
                <div className="flex gap-2">
                  {colors.slice(0, 4).map(color => (
                    <button key={color} onClick={() => setNewZoneColor(color)}
                      className={`w-8 h-8 rounded border-2 ${newZoneColor === color ? 'border-white scale-110' : 'border-transparent'}`}
                      style={{ backgroundColor: color }} />
                  ))}
                </div>
                <button onClick={handleAddZone}
                  className="w-full px-4 py-2 bg-primary text-primary-foreground rounded font-medium hover:bg-primary/90 flex items-center justify-center gap-2">
                  <Plus size={18} />Agregar Zona
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}