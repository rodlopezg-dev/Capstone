import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routers import alerts
from dotenv import load_dotenv

load_dotenv()

app = FastAPI(
    title="Alerts Service - SSO Alloxentric",
    description="Microservicio para el Centro de Alertas del sistema SSO",
    version="1.0.0",
)

# 1. Definimos explícitamente los orígenes permitidos
# Al quitar el "*", solucionamos el conflicto con allow_credentials=True
origins = [
    "https://gpi-websso.vercel.app", 
    "https://gpi-mobile.vercel.app",
    "http://localhost:5173",
        "http://localhost:5174",
        "http://localhost:5175",
        "http://localhost:5176",
    "http://localhost:3000",    
    "capacitor://localhost",
    "http://localhost", 
    "https://localhost",  # ← falta la coma aquí
    "null",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://sso-dashboard.alloxentric.com", "https://sso-app.alloxentric.com", "http://localhost:5173", "http://localhost:5174", "http://localhost", "capacitor://localhost"] + [origin.strip() for origin in os.getenv("CORS_ORIGINS", "").split(",") if origin.strip()],  # ← Pasamos la lista explícita aquí
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(alerts.router)


@app.get("/health", tags=["System"])
def health_check():
    return {"status": "ok", "service": "alerts-service"}