import { describe, expect, it } from 'vitest';

import {
  CAUSE_OPTIONS,
  filterCauseOptions,
  normalizeSearchText,
  toggleCauseSelection,
} from './incidentCauses';

describe('incident causes - SCRUM-72', () => {
  it('contains the predefined causes', () => {
    expect(CAUSE_OPTIONS).toEqual([
      'Falta de EPP',
      'No seguir procedimiento',
      'Distracción o falta de atención',
      'Fatiga o cansancio',
      'Falta de capacitación',
      'Herramienta o equipo defectuoso',
      'Condición del entorno',
      'Otra',
    ]);
  });

  it('returns all causes when search is empty', () => {
    expect(filterCauseOptions('')).toEqual([...CAUSE_OPTIONS]);
  });

  it('ignores case when searching', () => {
    expect(filterCauseOptions('EPP')).toEqual([
      'Falta de EPP',
    ]);

    expect(filterCauseOptions('fatiga')).toEqual([
      'Fatiga o cansancio',
    ]);
  });

  it('ignores accents when searching', () => {
    expect(filterCauseOptions('atencion')).toEqual([
      'Distracción o falta de atención',
    ]);

    expect(filterCauseOptions('capacitacion')).toEqual([
      'Falta de capacitación',
    ]);
  });

  it('trims the search text', () => {
    expect(filterCauseOptions('  entorno  ')).toEqual([
      'Condición del entorno',
    ]);
  });

  it('supports partial matches', () => {
    expect(filterCauseOptions('falta')).toEqual([
      'Falta de EPP',
      'Distracción o falta de atención',
      'Falta de capacitación',
    ]);
  });

  it('returns an empty array when there are no matches', () => {
    expect(filterCauseOptions('causa inexistente')).toEqual([]);
  });

  it('normalizes text consistently', () => {
    expect(normalizeSearchText('  CONDICIÓN  ')).toBe('condicion');
  });

  it('adds a cause when it is not selected', () => {
    expect(
      toggleCauseSelection(
        ['Falta de EPP'],
        'Fatiga o cansancio'
      )
    ).toEqual([
      'Falta de EPP',
      'Fatiga o cansancio',
    ]);
  });

  it('removes a cause when it is already selected', () => {
    expect(
      toggleCauseSelection(
        [
          'Falta de EPP',
          'Fatiga o cansancio',
        ],
        'Falta de EPP'
      )
    ).toEqual([
      'Fatiga o cansancio',
    ]);
  });

  it('does not mutate the original selection array', () => {
    const original = ['Falta de EPP'];

    toggleCauseSelection(
      original,
      'Fatiga o cansancio'
    );

    expect(original).toEqual(['Falta de EPP']);
  });
});
