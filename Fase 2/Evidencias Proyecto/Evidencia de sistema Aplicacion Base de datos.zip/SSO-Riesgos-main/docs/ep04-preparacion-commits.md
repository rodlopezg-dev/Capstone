# EP-04 / TT-17 y TT-18 — preparación de commits A–D

Fecha: 2026-10-08. Base verificada: `main` en `95a2d920f114ed06b4c89a3edfc40ba32adc03d6`. Se leyó `ep04-tt18-correcciones-revision.md` y se contrastó con el árbol de trabajo, el diff rastreado y los archivos nuevos. **Este documento es una propuesta de partición; no se modificó el índice ni se creó ningún commit.**

## Estado del árbol y comprobaciones de contrato

Antes de crear este informe: 34 archivos rastreados modificados, 15 archivos sin seguimiento y ningún cambio staged. El diff rastreado era de 519 inserciones y 244 eliminaciones en 34 archivos; los 15 nuevos no entran en esa cifra. No aparecen cambios de DB, migraciones, `.env` ni bundles compilados. Después de crear este informe habrá 16 archivos sin seguimiento. Todos los cambios pendientes quedan asignados a A–D más abajo.

| Contrato | Evidencia del código y pruebas | Resultado / límite |
| --- | --- | --- |
| Consulta interna por identidad | `users-service/app/routers/internal.py:9-13,28-45`: el router completo exige `X-Internal-Token`; `by-id` valida cadenas no vacías tras quitar espacios y consulta `users` con **`user_id` y `client_id`**. Proyecta rol, estado y ámbitos sin contraseña. `auth-service/app/repositories/user_api_repo.py:61-85` envía la clave interna. La prueba ASGI en `users-service/tests/test_ep04_security_contract.py:78-96` comprueba rechazo de clave ausente/errónea sin consulta y 404 para otro tenant. | Protegido y acotado al par identidad/tenant en el código revisado. No se validó contra Mongo real. |
| Renovación | `auth-service/app/services/auth_service.py:124-170` exige refresh válido, consulta el estado actual y deniega si la cuenta no está activa o si difieren `sub`, `client_id`, `role`, áreas o área. Crea el nuevo access desde el documento actual. `get_user_by_id` transforma indisponibilidad HTTP en 503, sin emitir access. `auth-service/tests/test_jwt_contract.py:101-173` cubre baja, rol/ámbito, tenant y caída del servicio. | No prolonga privilegios obsoletos mediante refresh. El cambio de tenant puede aparecer como 404 de la consulta en el tenant anterior y termina en 401. |
| JWT legacy | `AuthService.verify_token` y las dependencias consumidoras exigen `exp`, `sub`, `role`, `client_id`, rechazan refresh/tipos desconocidos y aceptan temporalmente **access sin `type`**. El login y refresh nuevos emiten `type=access`. | Compatibilidad conservada; falta criterio de retirada. |
| Listado global de Users | `users-service/app/routers/users.py:15-20` permite solo `admin`/`sso_manager` y pasa el `client_id` firmado. `test_ep04_security_contract.py:98-111` verifica 403 para jefe/supervisor/worker/analyst y ninguna llamada a `get_all_users`; administradores listan su tenant. | El método de listado/repositorio no se invoca en denegaciones. FastAPI puede resolver `get_user_service` y construir su repositorio antes de evaluar el rol; la prueba no demuestra ausencia de esa construcción. |
| `talk_id` manual | `talks-service/app/routers/rt_talks.py:1105-1132`: campo **omitido** permite formulario manual legacy sin archivo; `""` y espacios dan 422; ID existente del tenant permite continuar; inexistente y ajeno dan el mismo 404. Omitido con archivo da 422. `test_attendance_access_contract.py:274-312` cubre las seis variantes con y sin archivo y comprueba ausencia de `create_attendance`/Blob en rechazos. El móvil omite el campo en registro manual (`SafetyTalksMobile.tsx:711-717`) y lo envía al adjuntar hoja (`talkAttendance.ts:31-35`). | Compatibilidad legacy limitada a omisión comprobada; clientes externos que envíen vacío deberán adaptarse. No se probó almacenamiento real. |
| Fixtures | `talks-service/tests/conftest.py:87-170` emite `type=access` y usa identidades coherentes con rol y tenant; los cambios de integración sustituyen sujetos worker/supervisor por administradores cuando la acción requiere administración. Los casos de claims desactualizados permanecen separados en Auth. Una inspección AST de llamadas con `user_id` literal conocido revisó 38 casos: cero discordancias literales de rol/tenant. | 106 casos de integración recopilados; ejecución bloqueada por restricción de escritura Mongo. La inspección estática no sustituye su ejecución. |

### Exposición residual de access

**El criterio de revocación inmediata de access sigue sin resolverse.** La fuente de configuración `auth-service/app/config.py:8` fija `ACCESS_TOKEN_EXPIRE_MINUTES = 30`, y tanto login (`auth_service.py:70-74`) como refresh (`:154-164`) usan ese valor. Con la configuración por defecto verificada, un access recién emitido dura **30 minutos**; tras una baja o degradación puede conservar los privilegios firmados durante el tiempo restante hasta `exp`. La consulta de Users en `/refresh` impide emitir uno nuevo, pero los consumidores no consultan estado/revocación en cada solicitud. `BaseSettings` permite una sobrescritura de entorno; no se inspeccionó `.env` ni el despliegue, así que 30 minutos es la duración real del **código/configuración por defecto revisados**, no una certificación del valor desplegado. Un diseño de revocación/versionado o introspección, su política de fallos y el retiro de JWT legacy quedan pendientes de decisión.

## Partición exacta propuesta

Las rutas de las tablas son relativas a la raíz del repositorio. Los encabezados `@@` corresponden a `git diff --unified=0` **actual**; pueden renumerarse después de aplicar A. Para los archivos nuevos, «archivo completo» significa todo su contenido sin seguimiento. La separación por hunk es una instrucción para una futura preparación revisada; **no se ejecutó `git add`**.

### A. TT-17 — estadísticas y exportaciones

Mensaje: `fix(talks): reconcile attendance coverage and export sources`

| Archivo | Hunks exactos |
| --- | --- |
| `END-POINTS-SSO/talks-service/app/attendance_export.py` | Todos: `@@ -29,0 +30,5 @@` (`_source_label`), `@@ -122,7 +127 @@` PDF y `@@ -321,7 +320 @@` Excel. |
| `END-POINTS-SSO/talks-service/app/repositories/rep_talks.py` | **Solo TT-17:** `@@ -770,2 +793,2 @@`, `@@ -774,3 +797,3 @@`, `@@ -854,0 +878 @@`, `@@ -873 +897,5 @@`, `@@ -898 +926 @@`, `@@ -899,0 +928,3 @@`, `@@ -964,3 +995,2 @@`, `@@ -1046,0 +1077 @@`, `@@ -1121,4 +1152,5 @@`, `@@ -1128 +1160 @@`, `@@ -1130,0 +1163,3 @@`. Son documentación de cobertura, proyección de `source`, manejo de IDs y exclusión del fallback nominativo para QR. **Excluir** el primer hunk `list_own_attendance`. |
| `END-POINTS-SSO/talks-service/tests/unit/test_attendance_consistency.py` | Archivo completo. |
| `END-POINTS-SSO/talks-service/tests/unit/test_attendance_projection.py` | Archivo completo. |

Dependencias: ninguna de B–D. Prueba mínima antes de fijar A: ambos tests unitarios nuevos y `git diff --check` sobre el parche A; para la serie completa, `pytest tests/unit -q` en Talks. Riesgos abiertos: los casos Mongo/PDF/Excel reales siguen sin ejecutarse; cobertura observada continúa distinta del cumplimiento de charlas obligatorias y debe leerse con `mandatory`/`expected_user_ids` según el informe TT-17.

### B. TT-18 — JWT, Auth y revalidación de refresh

Mensaje: `fix(auth): revalidate refresh identity and enforce access JWT`

| Archivo(s) | Hunks exactos |
| --- | --- |
| `END-POINTS-SSO/auth-service/app/dependencies.py`, `app/repositories/user_api_repo.py`, `app/routers/auth.py`, `app/services/auth_service.py` | Diff completo de cada archivo: 401 y claims, consulta interna, refresh desde identidad vigente, `type=access`. |
| `END-POINTS-SSO/users-service/app/routers/internal.py` | Diff completo: imports Pydantic y ruta `by-id` bajo el `X-Internal-Token` ya existente. |
| `END-POINTS-SSO/users-service/app/dependencies.py` | **Solo JWT:** `@@ -13 +13 @@`, `@@ -22,2 +22,3 @@`, `@@ -25,3 +26,7 @@`, `@@ -28,0 +34 @@`. Excluir `@@ -31 +37 @@` de `verify_role`, que va a C. |
| `END-POINTS-SSO/alerts-service/app/dependencies.py`, `areas-service/app/dependencies.py`, `dashboard-service/app/dependencies.py`, `digital-twin-service/app/dependencies.py`, `incidents-service/app/dep_incidents.py`, `reports-service/app/dep_reports.py`, `talks-service/app/dep_talks.py`, `workers-service/app/dependencies.py` | Diff completo de cada dependencia consumidora; JWT access/legacy y errores 401. |
| `END-POINTS-SSO/auth-service/tests/test_jwt_contract.py`, `END-POINTS-SSO/tests/jwt_consumer_contract.py` | Archivos completos. |

Dependencias: A no es requisito funcional para B, pero el orden A→B mantiene la historia solicitada. Pruebas: Auth `unittest` (10), contrato de 13 variantes en cada uno de ocho consumidores, y `git diff --check`. La prueba ASGI directa del `by-id` está en el archivo combinado de Users asignado a C y deberá aprobar cuando se aplique C. Riesgos abiertos: revocación de access, retiro de tokens legacy, configuración real del TTL y disponibilidad de Users Service (el fallo cierra refresh con 503). No se validó el nuevo endpoint con Mongo real.

### C. TT-18 — RBAC, Users y asistencia

Mensaje: `fix(attendance): enforce tenant RBAC and talk ownership`

| Archivo(s) | Hunks exactos |
| --- | --- |
| `END-POINTS-SSO/talks-service/app/routers/rt_talks.py` | Diff completo: roles, siete rutas administrativas y superficies adyacentes, GET propio, POST con pertenencia y semántica de `talk_id`, QR/OCR y adjuntos. |
| `END-POINTS-SSO/talks-service/app/repositories/rep_talks.py` | **Solo TT-18:** `@@ -639,0 +640,23 @@` (`list_own_attendance`). Los once hunks restantes van a A. |
| `END-POINTS-SSO/users-service/app/dependencies.py` | **Solo RBAC/ASGI:** `@@ -31 +37 @@` (`role_checker` asíncrono). Los cuatro hunks JWT van a B. |
| `END-POINTS-SSO/users-service/app/routers/users.py` | Diff completo, incluido `@@ -18,2 +18 @@` que retira el listado global de jefe de área. |
| `END-POINTS-SSO/talks-service/tests/conftest.py` | Diff completo: sujetos/roles/tenant coherentes y access explícito. |
| `END-POINTS-SSO/talks-service/tests/integration/test_absence_states.py`, `test_absence_tenant_isolation.py`, `test_absent_workers.py`, `test_absent_workers_functional.py`, `test_attendance_comparison.py`, `test_attendance_export_pdf.py`, `test_attendance_export_xlsx.py`, `test_attendance_sheet.py`, `test_attendance_stats.py`, `test_expected_workers.py`, `test_ocr_attendance.py`, `test_qr_attendance_router.py`, `test_talk_attachments.py` | Diff completo de cada uno de los 13 archivos bajo `tests/integration/`; ajustes de expectativas y fixtures, incluidos hunks de H4. |
| `END-POINTS-SSO/talks-service/tests/unit/test_attendance_access_contract.py`, `test_own_attendance.py`; `END-POINTS-SSO/users-service/tests/test_ep04_security_contract.py` | Archivos completos. El test de Users cubre tanto el endpoint interno de B como el listado de C; se coloca aquí porque B ya existe. |
| `GPI-SSO-Frontend/APP-GPI-ALLOXENTRIC/src/app/pages/SafetyTalksMobile.tsx`, `src/app/utils/talkPermissions.ts`, `src/app/utils/talkPermissions.test.ts` | Diff completo del componente y archivos nuevos completos; controles móviles alineados con roles backend. |

Dependencias: B debe existir para que el JWT firmado y `by-id` funcionen; A debe precederlo por el hunk mixto de repositorio. Pruebas: Talks `pytest tests/unit -q` (227), Users `unittest` (18, incluye 403 y consulta interna), móvil `npm test -- --run` (261), recopilación de integración (106) y `git diff --check`. Riesgos abiertos: supervisor/jefe continúan denegados donde no existe ámbito persistido verificable; 106 pruebas de integración no ejecutadas; los flujos QR/OCR/Blob y la construcción de repositorio previo al 403 no tuvieron verificación E2E.

### D. Documentación y pruebas complementarias

Mensaje: `test(ep04): record security regressions and audit evidence`

| Archivo(s) | Hunks exactos |
| --- | --- |
| `GPI-SSO-Frontend/APP-GPI-ALLOXENTRIC/src/app/api/client.test.ts` | Diff completo: `@@ -9,0 +10 @@` importa el evento y `@@ -238,0 +240,25 @@` prueba que refresh 401/403 limpia sesión administrativa y emite invalidación. |
| `docs/ep04-auditoria.md`, `docs/ep04-fase1-preparacion.md`, `docs/ep04-tt18-permisos.md`, `docs/ep04-tt18-implementacion.md`, `docs/ep04-tt18-revision.md`, `docs/ep04-tt18-correcciones-revision.md`, `docs/ep04-preparacion-commits.md` | Cada archivo nuevo completo. |

Dependencias: A, B y C, para que los informes reflejen el código y los resultados finales. Pruebas: móvil `npm test -- --run` (incluye los dos casos de refresh), suite segura completa de Auth/Users/Talks, contrato JWT de ocho consumidores y `git diff --check`. Riesgos abiertos: la UI `App.tsx` no tuvo prueba visual/E2E; ante 503 de Users el cliente conserva el estado local, aunque no obtiene un access nuevo. Persisten todos los límites de integración, revocación y configuración indicados arriba.

## Validación ejecutada en esta preparación

| Comando / alcance | Resultado | Observación |
| --- | --- | --- |
| Auth: `.venv/bin/python -m unittest discover -s tests -p 'test_*.py' -q` | **10 OK** | Dobles de repositorio y transporte; sin red real. |
| Users: mismo comando en `users-service` | **18 OK** | ASGI y colección/servicio falsos; sin Mongo. |
| Talks: `TEST_MONGO_URI=mongodb://127.0.0.1:27099 TEST_MONGO_DB=sso_riesgo_qr_test .venv/bin/python -m pytest tests/unit -q` | **227 passed** | URI ficticia y solo `tests/unit`. El primer intento con otro nombre de DB se detuvo en la guarda de importación (exit 4, cero tests ejecutados); se corrigió solo la variable del proceso. |
| JWT: `jwt_consumer_contract.py` desde los venv de alerts, areas, dashboard, digital-twin, incidents, reports, users y workers | **13 casos × 8 consumidores, OK** | Secret y clave interna ficticios en cada proceso. Talks se cubre en su suite unitaria. |
| Móvil: `npm test -- --run` | **34 archivos, 261 tests passed** | Sin API remota. |
| Talks: `pytest tests/integration --collect-only -q` con URI/DB de prueba | **106 recopilados, 0 ejecutados** | No se activaron fixtures de escritura. |
| Inspección AST de `auth_headers` en integración | **38 identidades literales conocidas, 0 discordancias** | Compara `user_id`, rol y tenant explícitos con las identidades sembradas; no ejecuta fixtures. |
| `git diff --check` | **exit 0** | Solo diff rastreado; repetir tras preparar cada parche y en el índice futuro. |

No se ejecutaron tests que escriban Mongo o Azure/Azurite, ni pruebas de despliegue. La partición A–D es verificable con las pruebas indicadas, pero los límites de integración y revocación impiden declarar esas capacidades cerradas. Antes de crear commits, revisar el parche staged de **cada** bloque, confirmar que `rep_talks.py` y `users-service/app/dependencies.py` no arrastren hunks del bloque siguiente, y comprobar que los archivos nuevos queden incluidos exactamente una vez. No se hizo staging, commit, push, merge ni despliegue.
