import { HelpTooltip } from './HelpTooltip';
import { useState, useEffect } from 'react';
import { FileText, Download, Calendar, Filter, RefreshCw, AlertCircle } from 'lucide-react';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';
import { BarChart, Bar, PieChart, Pie, Cell, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

const REPORTS_API = import.meta.env.VITE_REPORTS_API_URL || 'http://localhost:8001';
const ALERTS_API  = import.meta.env.VITE_ALERTS_API_URL  || 'http://localhost:8007';
const CLIENT_ID   = import.meta.env.VITE_CLIENT_ID        || 'cliente_prueba_123';


// ─── FIRESTORE TYPES ──────────────────────────────────────────────────────────
interface FirestoreTimestamp { _seconds: number; _nanoseconds?: number; }
type RawDate = string | FirestoreTimestamp | null | undefined;
// ─── TIPOS ────────────────────────────────────────────────────────────────────
interface Report {
  report_id:   string;
  area_id:     string;
  type:        string;
  is_iap:      boolean;
  description: string;
  shift:       string;
  status:      string;
  reported_by: string;
  created_at:  string;
  image_url?:  string;
}

interface Alert {
  id:         string;
  type:       string;
  title:      string;
  zone_id:    string;
  severity:   string;
  status:     string;
  created_at: string;
}

interface ExportRecord {
  id:       string;
  filename: string;
  date:     string;
  format:   string;
  rows:     number;
}

const templates = [
  { id: 'all',       name: 'Reporte Completo',          description: 'Todos los reportes con detalle completo', icon: '📊' },
  { id: 'iap',       name: 'Reporte de IAP',            description: 'Solo Incidentes de Alto Potencial',       icon: '⚠️' },
  { id: 'open',      name: 'Incidentes Abiertos',       description: 'Reportes pendientes de cierre',           icon: '📋' },
  { id: 'closed',    name: 'Incidentes Cerrados',       description: 'Reportes resueltos en el período',        icon: '✅' },
  { id: 'alerts',    name: 'Centro de Alertas',         description: 'Alertas activas y resueltas',             icon: '🔔' },
];

// ─── HELPERS ──────────────────────────────────────────────────────────────────
function getToken(): string {
  return localStorage.getItem('sso_token') ?? '';
}

function formatDate(raw: RawDate): string {
  if (!raw) return 'Sin fecha';
  try {
    const d = raw._seconds ? new Date(raw._seconds * 1000) : new Date(raw);
    if (isNaN(d.getTime())) return 'Sin fecha';
    return d.toLocaleDateString('es-ES', { day: '2-digit', month: '2-digit', year: 'numeric' });
  } catch { return 'Sin fecha'; }
}

function filterByDateRange<T extends { created_at?: RawDate }>(items: T[], range: string): T[] {
  const now = new Date();
  const from = new Date();
  if (range === '7d')    from.setDate(now.getDate() - 7);
  if (range === '30d')   from.setDate(now.getDate() - 30);
  if (range === 'month') from.setDate(1);
  if (range === 'all')   return items;
  return items.filter(item => {
    const d = item.created_at?._seconds
      ? new Date(item.created_at._seconds * 1000)
      : new Date(item.created_at);
    return d >= from;
  });
}

// ─── COMPONENTE ───────────────────────────────────────────────────────────────
type ReportsProps = { userRole?: string; userAssignedAreas?: string[]; userAssignedZones?: string[] };
export default function Reports({ userRole, userAssignedAreas, userAssignedZones }: ReportsProps) {
  // Jefe de área: filtro forzado a sus áreas asignadas (no puede cambiarlo)
  const isAreaManager = userRole === 'jefe de area' || userRole === 'jefe de área';
  const isSupervisor = userRole === 'supervisor';
  const forcedZones = isSupervisor && userAssignedZones && userAssignedZones.length > 0
    ? userAssignedZones.map(z => z.trim().toLowerCase())
    : null;
  const forcedAreas = (isAreaManager || isSupervisor) && userAssignedAreas && userAssignedAreas.length > 0
    ? userAssignedAreas.map(a => a.trim().toLowerCase())
    : null;
  const [viewMode, setViewMode] = useState<'visual' | 'export'>('visual');
  const [selectedTemplate, setSelectedTemplate] = useState<string>('all');
  const [dateRange, setDateRange]               = useState('30d');
  const [areaFilter, setAreaFilter]             = useState('all');
  const [format, setFormat]                     = useState('pdf');
  const [reports, setReports]                   = useState<Report[]>([]);
  const [alerts, setAlerts]                     = useState<Alert[]>([]);
  const [loading, setLoading]                   = useState(false);
  const [exporting, setExporting]               = useState(false);
  const [error, setError]                       = useState<string | null>(null);
  const [exportHistory, setExportHistory]       = useState<ExportRecord[]>([]);

  // ── Cargar datos reales ────────────────────────────────────────────────────
  const loadData = async () => {
    setLoading(true);
    setError(null);
    try {
      const token = getToken();
      const [reportsRes, alertsRes] = await Promise.allSettled([
        fetch(`${REPORTS_API}/v1/admin/reports`, {
          headers: { Authorization: `Bearer ${token}` },
        }),
        fetch(`${ALERTS_API}/v1/alerts/?status=active&page_size=100`, {
          headers: { Authorization: `Bearer ${token}` },
        }),
      ]);

      if (reportsRes.status === 'fulfilled' && reportsRes.value.ok) {
        const data = await reportsRes.value.json();
        setReports(Array.isArray(data) ? data : []);
      }
      if (alertsRes.status === 'fulfilled' && alertsRes.value.ok) {
        const data = await alertsRes.value.json();
        setAlerts(Array.isArray(data.data) ? data.data : []);
      }
    } catch (e) {
      setError('Error al cargar datos: ' + e.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { loadData(); }, []);

  // ── Filtrar datos según template y filtros ─────────────────────────────────
  const getFilteredData = () => {
    let data = filterByDateRange(reports, dateRange);
    // Jefe de área: siempre filtrado a sus áreas (ignora el selector)
    if (forcedZones) {
      data = data.filter(r => forcedZones.includes(((r as any).zone_id || '').trim().toLowerCase()));
    } else if (forcedAreas) {
      data = data.filter(r => forcedAreas.includes((r.area_id || '').trim().toLowerCase()));
    } else if (areaFilter !== 'all') {
      data = data.filter(r => r.area_id === areaFilter);
    }
    if (selectedTemplate === 'iap')    data = data.filter(r => r.is_iap);
    if (selectedTemplate === 'open')   data = data.filter(r => r.status !== 'closed');
    if (selectedTemplate === 'closed') data = data.filter(r => r.status === 'closed');
    if (selectedTemplate === 'alerts') return { type: 'alerts', data: filterByDateRange(alerts, dateRange) };
    return { type: 'reports', data };
  };

  // ── Áreas únicas para el filtro ────────────────────────────────────────────
  const uniqueAreas = [...new Set(reports.map(r => r.area_id))].filter(Boolean);

  // ── Exportar PDF ───────────────────────────────────────────────────────────
  const exportPDF = (filtered: Report[], type: string) => {
    const doc = new jsPDF();
    const templateName = templates.find(t => t.id === selectedTemplate)?.name ?? 'Reporte';
    const dateStr = new Date().toLocaleDateString('es-ES');

    // Header
    doc.setFillColor(255, 106, 0);
    doc.rect(0, 0, 210, 25, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(16);
    doc.setFont('helvetica', 'bold');
    doc.text('GPI - ALLOXENTRIC', 14, 10);
    doc.setFontSize(10);
    doc.text(templateName.toUpperCase(), 14, 18);
    doc.text(`Generado: ${dateStr}`, 150, 18);

    doc.setTextColor(0, 0, 0);
    doc.setFontSize(10);
    doc.text(`Total registros: ${filtered.length}`, 14, 32);
    doc.text(`Período: ${dateRange === 'all' ? 'Todo' : dateRange === '7d' ? 'Últimos 7 días' : dateRange === '30d' ? 'Últimos 30 días' : 'Mes actual'}`, 14, 38);

    if (type === 'alerts') {
      autoTable(doc, {
        startY: 45,
        head: [['ID', 'Tipo', 'Título', 'Zona', 'Severidad', 'Estado', 'Fecha']],
        body: filtered.map((a: Alert) => [
          a.id?.slice(-6) ?? '-',
          a.type?.toUpperCase() ?? '-',
          a.title ?? '-',
          a.zone_id ?? '-',
          a.severity?.toUpperCase() ?? '-',
          a.status?.toUpperCase() ?? '-',
          formatDate(a.created_at),
        ]),
        headStyles: { fillColor: [255, 106, 0] },
        alternateRowStyles: { fillColor: [245, 245, 245] },
      });
    } else {
      autoTable(doc, {
        startY: 45,
        head: [['ID', 'Área', 'Tipo', 'IAP', 'Estado', 'Fecha']],
        body: filtered.map((r: Report) => [
          r.report_id?.slice(-6) ?? '-',
          r.area_id ?? '-',
          r.type ?? '-',
          r.is_iap ? 'SÍ' : 'No',
          r.status?.toUpperCase() ?? '-',
          formatDate(r.created_at),
        ]),
        headStyles: { fillColor: [255, 106, 0] },
        alternateRowStyles: { fillColor: [245, 245, 245] },
        columnStyles: { 3: { fontStyle: 'bold' } },
      });
    }

    const filename = `gpi_${selectedTemplate}_${dateStr.replace(/\//g, '-')}.pdf`;
    doc.save(filename);
    return filename;
  };

  // ── Exportar Excel ─────────────────────────────────────────────────────────
  const exportExcel = (filtered: Report[], type: string) => {
    const dateStr = new Date().toLocaleDateString('es-ES').replace(/\//g, '-');
    let rows: Record<string, string | number | boolean>[];

    if (type === 'alerts') {
      rows = filtered.map((a: Alert) => ({
        ID:        a.id?.slice(-6) ?? '-',
        Tipo:      a.type?.toUpperCase() ?? '-',
        Título:    a.title ?? '-',
        Zona:      a.zone_id ?? '-',
        Severidad: a.severity?.toUpperCase() ?? '-',
        Estado:    a.status?.toUpperCase() ?? '-',
        Fecha:     formatDate(a.created_at),
      }));
    } else {
      rows = filtered.map((r: Report) => ({
        ID:          r.report_id?.slice(-6) ?? '-',
        Área:        r.area_id ?? '-',
        Tipo:        r.type ?? '-',
        IAP:         r.is_iap ? 'SÍ' : 'No',
        Estado:      r.status?.toUpperCase() ?? '-',
        Descripción: r.description ?? '-',
        Fecha:       formatDate(r.created_at),
      }));
    }

    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Datos');
    const filename = `gpi_${selectedTemplate}_${dateStr}.xlsx`;
    XLSX.writeFile(wb, filename);
    return filename;
  };

  // ── Exportar CSV ───────────────────────────────────────────────────────────
  const exportCSV = (filtered: Report[], type: string) => {
    const dateStr = new Date().toLocaleDateString('es-ES').replace(/\//g, '-');
    let headers: string;
    let rows: string[];

    if (type === 'alerts') {
      headers = 'ID,Tipo,Título,Zona,Severidad,Estado,Fecha';
      rows = filtered.map((a: Alert) =>
        `${a.id?.slice(-6)},${a.type},${a.title},${a.zone_id},${a.severity},${a.status},${formatDate(a.created_at)}`
      );
    } else {
      headers = 'ID,Área,Tipo,IAP,Estado,Fecha';
      rows = filtered.map((r: Report) =>
        `${r.report_id?.slice(-6)},${r.area_id},${r.type},${r.is_iap ? 'SÍ' : 'No'},${r.status},${formatDate(r.created_at)}`
      );
    }

    const csv = [headers, ...rows].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url  = URL.createObjectURL(blob);
    const link = document.createElement('a');
    const filename = `gpi_${selectedTemplate}_${dateStr}.csv`;
    link.href = url;
    link.download = filename;
    link.click();
    URL.revokeObjectURL(url);
    return filename;
  };

  // ── Handler principal de exportación ──────────────────────────────────────
  const handleExport = async () => {
    setExporting(true);
    try {
      const { type, data } = getFilteredData();
      if (data.length === 0) {
        alert('No hay datos para exportar con los filtros seleccionados.');
        return;
      }

      let filename = '';
      if (format === 'pdf')   filename = exportPDF(data, type);
      if (format === 'excel') filename = exportExcel(data, type);
      if (format === 'csv')   filename = exportCSV(data, type);

      // Agregar al historial local
      setExportHistory(prev => [{
        id:       `EXP-${Date.now()}`,
        filename,
        date:     new Date().toLocaleDateString('es-ES'),
        format:   format.toUpperCase(),
        rows:     data.length,
      }, ...prev].slice(0, 10));

    } finally {
      setExporting(false);
    }
  };

  // ── Stats ──────────────────────────────────────────────────────────────────
  const { data: filteredData } = getFilteredData();
  const iapCount    = reports.filter(r => r.is_iap).length;
  const openCount   = reports.filter(r => r.status !== 'closed').length;
  const alertCount  = alerts.filter(a => a.status === 'active').length;

  return (
    <div className="h-full p-6 overflow-auto bg-[#0B0F19] text-slate-100">

      {/* Header */}
      <div className="mb-8 border-b border-slate-800 pb-5 flex items-center justify-between">
        <div>
          <h1 className="text-4xl mb-2 tracking-tight uppercase"
            style={{ fontFamily: 'var(--font-display)', fontWeight: 800 }}>
            REPORTES Y EXPORTACIÓN
          </h1>
          <HelpTooltip steps={[
      { icon: '📄', title: 'Plantillas de reporte', description: 'Elige entre 5 plantillas: Reporte Completo, Solo IAP, Incidentes Abiertos, Incidentes Cerrados o Centro de Alertas. Cada una filtra los datos relevantes.' },
      { icon: '📅', title: 'Opciones de exportación', description: 'Selecciona el período (últimos 7, 30 o 90 días), el área operativa y el formato de salida (PDF, Excel o CSV) antes de exportar.' },
      { icon: '⬇️', title: 'Exportar', description: 'Presiona "Exportar registros" para generar y descargar el archivo. El botón muestra cuántos registros se incluirán según los filtros aplicados.' },
      { icon: '🕒', title: 'Historial de exportaciones', description: 'Cada exportación queda registrada con fecha, plantilla usada y cantidad de registros. Puedes ver el historial completo debajo del formulario.' },
    ]} />
          <p className="text-slate-400 text-sm">Genera y exporta reportes con datos en tiempo real</p>
        </div>
        <button onClick={loadData} disabled={loading}
          className="flex items-center gap-2 px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-sm hover:bg-slate-700 transition-colors disabled:opacity-50">
          <RefreshCw size={16} className={loading ? 'animate-spin' : ''} />
          Actualizar
        </button>
      </div>

      {/* Toggle Visual / Exportar */}
      <div className="flex gap-2 mb-6">
        <button onClick={() => setViewMode('visual')}
          className={`px-5 py-2 rounded-lg text-sm font-medium transition-all ${
            viewMode === 'visual' ? 'bg-[#00E5FF] text-[#0B1E36]' : 'bg-slate-800 border border-slate-700 text-slate-300 hover:bg-slate-700'
          }`}>
          📊 Vista Visual
        </button>
        <button onClick={() => setViewMode('export')}
          className={`px-5 py-2 rounded-lg text-sm font-medium transition-all ${
            viewMode === 'export' ? 'bg-[#00E5FF] text-[#0B1E36]' : 'bg-slate-800 border border-slate-700 text-slate-300 hover:bg-slate-700'
          }`}>
          ⬇️ Exportar
        </button>
      </div>

      {error && (
        <div className="bg-[#D72631]/10 border border-[#B71C25] text-[#D72631] p-3 rounded-lg mb-6 flex items-center gap-2">
          <AlertCircle size={16} />
          {error}
        </div>
      )}

      {/* Stats rápidas */}
      <div className="grid grid-cols-4 gap-4 mb-8">
        {[
          { label: 'Total Reportes', value: reports.length, color: 'text-white' },
          { label: 'IAP Activos',    value: iapCount,       color: 'text-[#D72631]' },
          { label: 'Abiertos',       value: openCount,      color: 'text-[#E8941A]' },
          { label: 'Alertas',        value: alertCount,     color: 'text-[#00C2DB]' },
        ].map(({ label, value, color }) => (
          <div key={label} className="bg-[#111827] border border-slate-800 rounded-xl p-4 text-center">
            <p className={`text-3xl font-bold ${color}`}>{loading ? '...' : value}</p>
            <p className="text-xs text-slate-400 mt-1">{label}</p>
          </div>
        ))}
      </div>


      {/* ── VISTA VISUAL ─────────────────────────────────────────────────── */}
      {viewMode === 'visual' && !loading && (
        <div className="space-y-6 mb-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

            {/* Reportes por Área */}
            <div className="bg-[#111827] border border-slate-800 rounded-xl p-6">
              <h3 className="text-lg mb-4 text-[#00E5FF] uppercase tracking-wide" style={{ fontFamily: 'var(--font-display)', fontWeight: 600 }}>
                Reportes por Área
              </h3>
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={(() => {
                  const counts: Record<string, number> = {};
                  reports.forEach(r => { counts[r.area_id] = (counts[r.area_id] || 0) + 1; });
                  return Object.entries(counts).map(([name, total]) => ({ name, total }));
                })()}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.2)" />
                  <XAxis dataKey="name" stroke="#94a3b8" style={{ fontSize: '11px' }} />
                  <YAxis stroke="#94a3b8" style={{ fontSize: '11px' }} />
                  <Tooltip contentStyle={{ backgroundColor: '#1f2937', border: '1px solid rgba(148,163,184,0.2)', borderRadius: '8px' }} />
                  <Bar dataKey="total" fill="#00E5FF" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Reportes por Estado */}
            <div className="bg-[#111827] border border-slate-800 rounded-xl p-6">
              <h3 className="text-lg mb-4 text-[#00E5FF] uppercase tracking-wide" style={{ fontFamily: 'var(--font-display)', fontWeight: 600 }}>
                Reportes por Estado
              </h3>
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie
                    data={(() => {
                      const counts: Record<string, number> = {};
                      reports.forEach(r => {
                        const label = r.status === 'open' ? 'Enviado' : r.status === 'reviewing' ? 'En Revisión' : r.status === 'assigned' ? 'Acción Asignada' : 'Cerrado';
                        counts[label] = (counts[label] || 0) + 1;
                      });
                      return Object.entries(counts).map(([name, value]) => ({ name, value }));
                    })()}
                    cx="50%" cy="50%" innerRadius={50} outerRadius={90} paddingAngle={4} dataKey="value"
                    label={({ name, value }) => `${name}: ${value}`}
                  >
                    {['#8b5cf6', '#3b82f6', '#f59e0b', '#16a34a'].map((color, i) => (
                      <Cell key={i} fill={color} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={{ backgroundColor: '#1f2937', border: '1px solid rgba(148,163,184,0.2)', borderRadius: '8px' }} />
                </PieChart>
              </ResponsiveContainer>
            </div>

            {/* Tendencia en el tiempo */}
            <div className="bg-[#111827] border border-slate-800 rounded-xl p-6 lg:col-span-2">
              <h3 className="text-lg mb-4 text-[#00E5FF] uppercase tracking-wide" style={{ fontFamily: 'var(--font-display)', fontWeight: 600 }}>
                Reportes en el Tiempo (últimos 30 días)
              </h3>
              <ResponsiveContainer width="100%" height={220}>
                <LineChart data={(() => {
                  const days: Record<string, { total: number; iap: number }> = {};
                  for (let i = 29; i >= 0; i--) {
                    const d = new Date(); d.setDate(d.getDate() - i);
                    days[d.toLocaleDateString('es-ES', { day: '2-digit', month: 'short' })] = { total: 0, iap: 0 };
                  }
                  reports.forEach(r => {
                    const d = new Date(r.created_at);
                    const key = d.toLocaleDateString('es-ES', { day: '2-digit', month: 'short' });
                    if (days[key]) {
                      days[key].total++;
                      if (r.is_iap) days[key].iap++;
                    }
                  });
                  return Object.entries(days).map(([day, v]) => ({ day, ...v }));
                })()}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.2)" />
                  <XAxis dataKey="day" stroke="#94a3b8" style={{ fontSize: '10px' }} />
                  <YAxis stroke="#94a3b8" style={{ fontSize: '11px' }} />
                  <Tooltip contentStyle={{ backgroundColor: '#1f2937', border: '1px solid rgba(148,163,184,0.2)', borderRadius: '8px' }} />
                  <Legend />
                  <Line type="monotone" dataKey="total" stroke="#00E5FF" strokeWidth={2} name="Total" dot={false} />
                  <Line type="monotone" dataKey="iap" stroke="#D72631" strokeWidth={2} name="IAP" dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>

            {/* IAP por Área */}
            <div className="bg-[#111827] border border-slate-800 rounded-xl p-6 lg:col-span-2">
              <h3 className="text-lg mb-4 text-[#00E5FF] uppercase tracking-wide" style={{ fontFamily: 'var(--font-display)', fontWeight: 600 }}>
                Incidentes de Alto Potencial por Área
              </h3>
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={(() => {
                  const counts: Record<string, number> = {};
                  reports.filter(r => r.is_iap).forEach(r => { counts[r.area_id] = (counts[r.area_id] || 0) + 1; });
                  return Object.entries(counts).map(([name, total]) => ({ name, total }));
                })()}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.2)" />
                  <XAxis dataKey="name" stroke="#94a3b8" style={{ fontSize: '11px' }} />
                  <YAxis stroke="#94a3b8" style={{ fontSize: '11px' }} />
                  <Tooltip contentStyle={{ backgroundColor: '#1f2937', border: '1px solid rgba(148,163,184,0.2)', borderRadius: '8px' }} />
                  <Bar dataKey="total" fill="#D72631" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      {viewMode === 'export' && (<div className="grid grid-cols-1 xl:grid-cols-3 gap-8">

        {/* Plantillas + Opciones */}
        <div className="xl:col-span-2 space-y-6">

          {/* Plantillas */}
          <div className="bg-[#111827] border border-slate-800 rounded-xl p-6">
            <h2 className="text-lg mb-4 text-[#00E5FF] tracking-wide uppercase flex items-center gap-2"
              style={{ fontFamily: 'var(--font-display)', fontWeight: 600 }}>
              <span className="w-1.5 h-4 bg-[#00E5FF] rounded-sm block"></span>
              Plantillas de Reporte
            </h2>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {templates.map(template => (
                <button key={template.id}
                  onClick={() => setSelectedTemplate(template.id)}
                  className={`p-4 rounded-lg border text-left transition-all ${
                    selectedTemplate === template.id
                      ? 'bg-[#00E5FF]/10 border-[#00E5FF]'
                      : 'bg-[#1F2937] border-slate-700 hover:border-slate-500'
                  }`}>
                  <div className="text-2xl mb-2">{template.icon}</div>
                  <h3 className="font-semibold text-sm mb-1">{template.name}</h3>
                  <p className="text-xs text-slate-400">{template.description}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Opciones de exportación — solo analista y sso_manager pueden exportar */}
          {!isAreaManager && <div className="bg-[#111827] border border-slate-800 rounded-xl p-6">
            <h2 className="text-lg mb-4 text-[#00E5FF] tracking-wide uppercase flex items-center gap-2"
              style={{ fontFamily: 'var(--font-display)', fontWeight: 600 }}>
              <span className="w-1.5 h-4 bg-[#00E5FF] rounded-sm block"></span>
              Opciones de Exportación
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                  <Calendar size={12} /> Período
                </label>
                <select value={dateRange} onChange={e => setDateRange(e.target.value)}
                  className="w-full px-3 py-2 bg-[#102A4C] border border-[#163760] rounded-lg text-sm focus:outline-none focus:border-[#00E5FF]">
                  <option value="7d">Últimos 7 días</option>
                  <option value="30d">Últimos 30 días</option>
                  <option value="month">Mes actual</option>
                  <option value="all">Todo el historial</option>
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                  <Filter size={12} /> Área
                </label>
                {forcedAreas ? (
                  // Jefe de área: muestra su área como etiqueta bloqueada
                  <div className="w-full px-3 py-2 bg-[#1F2937] border border-[#00E5FF]/50 rounded-lg text-sm text-[#00E5FF]">
                    {userAssignedAreas?.join(', ')}
                  </div>
                ) : (
                  <select value={areaFilter} onChange={e => setAreaFilter(e.target.value)}
                    className="w-full px-3 py-2 bg-[#102A4C] border border-[#163760] rounded-lg text-sm focus:outline-none focus:border-[#00E5FF]">
                    <option value="all">Todas las áreas</option>
                    {uniqueAreas.map(area => (
                      <option key={area} value={area}>{area}</option>
                    ))}
                  </select>
                )}
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                  <FileText size={12} /> Formato
                </label>
                <select value={format} onChange={e => setFormat(e.target.value)}
                  className="w-full px-3 py-2 bg-[#102A4C] border border-[#163760] rounded-lg text-sm focus:outline-none focus:border-[#00E5FF]">
                  <option value="pdf">PDF</option>
                  <option value="excel">Excel (.xlsx)</option>
                  <option value="csv">CSV</option>
                </select>
              </div>
            </div>

            <div className="flex items-center justify-between mb-4">
              <p className="text-sm text-slate-400">
                {loading ? 'Cargando...' : `${filteredData.length} registros encontrados`}
              </p>
            </div>

            <button onClick={handleExport}
              disabled={exporting || loading || filteredData.length === 0}
              className="w-full px-6 py-3 bg-[#00E5FF] text-[#0B1E36] rounded-lg font-semibold hover:bg-[#0097A8] transition-all disabled:opacity-50 flex items-center justify-center gap-2">
              <Download size={20} />
              {exporting ? 'Generando...' : `Exportar ${filteredData.length} registros`}
            </button>
          </div>}

          {/* Historial */}
          {exportHistory.length > 0 && (
            <div className="bg-[#111827] border border-slate-800 rounded-xl p-6">
              <h2 className="text-lg mb-4 tracking-wide uppercase flex items-center gap-2"
                style={{ fontFamily: 'var(--font-display)', fontWeight: 600 }}>
                <span className="w-1.5 h-4 bg-slate-600 rounded-sm block"></span>
                Historial de Exportaciones
              </h2>
              <div className="space-y-2">
                {exportHistory.map(item => (
                  <div key={item.id}
                    className="flex items-center justify-between py-3 px-4 bg-[#1F2937] rounded-lg">
                    <div className="flex items-center gap-3">
                      <FileText size={16} className="text-slate-400" />
                      <div>
                        <p className="text-sm font-medium">{item.filename}</p>
                        <p className="text-xs text-slate-400">{item.date} • {item.rows} registros</p>
                      </div>
                    </div>
                    <span className="px-2 py-1 rounded text-xs font-semibold bg-[#00E5FF]/10 text-[#00E5FF] border border-[#00E5FF]/20">
                      {item.format}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Panel Info */}
        <div className="space-y-6">
          <div className="bg-[#111827] border border-slate-800 rounded-xl p-6">
            <h2 className="text-lg mb-4 tracking-wide uppercase"
              style={{ fontFamily: 'var(--font-display)', fontWeight: 600 }}>
              Formatos
            </h2>
            <div className="space-y-3">
              {[
                { fmt: 'PDF',  desc: 'Documentos listos para imprimir y presentar',  color: 'text-[#D72631]' },
                { fmt: 'Excel', desc: 'Datos para análisis adicional en hojas de cálculo', color: 'text-[#16A34A]' },
                { fmt: 'CSV',  desc: 'Formato universal compatible con cualquier sistema', color: 'text-[#1A5276]' },
              ].map(({ fmt, desc, color }) => (
                <div key={fmt} className="flex items-start gap-3 p-3 bg-[#1F2937] rounded-lg">
                  <span className={`font-bold text-sm ${color} w-12`}>{fmt}</span>
                  <p className="text-xs text-slate-400">{desc}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-gradient-to-br from-[#00E5FF]/20 to-[#00C2DB]/5 border border-[#00E5FF]/30 rounded-xl p-6">
            <h3 className="text-lg font-semibold mb-2">💡 Datos en tiempo real</h3>
            <p className="text-sm text-slate-400">
              Los reportes se generan con datos actualizados directamente desde el sistema. 
              Presiona "Actualizar" para obtener los datos más recientes.
            </p>
          </div>

          <div className="bg-[#111827] border border-slate-800 rounded-xl p-6">
            <h2 className="text-lg mb-4 tracking-wide uppercase"
              style={{ fontFamily: 'var(--font-display)', fontWeight: 600 }}>
              Resumen
            </h2>
            <div className="space-y-3">
              {[
                { label: 'Total reportes',    value: reports.length },
                { label: 'IAP registrados',   value: iapCount },
                { label: 'Alertas activas',   value: alertCount },
                { label: 'Pendientes cierre', value: openCount },
              ].map(({ label, value }) => (
                <div key={label} className="flex items-center justify-between">
                  <span className="text-sm text-slate-400">{label}</span>
                  <span className="font-mono font-semibold text-[#00E5FF]">
                    {loading ? '...' : value}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>)}
    </div>
  );
}