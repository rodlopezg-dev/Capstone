# Vigia Industrial — Plataforma SSO

## Descripcion
Plataforma de gestion de seguridad industrial con dashboard web, app movil Android y 9 microservicios backend.

## Estructura
- GPI-SSO-Frontend/WebSSO/ — Dashboard web (React + Vite + Tailwind)
- GPI-SSO-Frontend/APP-GPI-ALLOXENTRIC/ — App movil (React + Capacitor)
- END-POINTS-SSO/ — Backend (FastAPI + MongoDB + Docker)

## Servicios Backend (puertos)
- auth-service: 8100
- users-service: 8101
- reports-service: 8102
- incidents-service: 8103
- alerts-service: 8104
- dashboard-service: 8105
- workers-service: 8106
- areas-service: 8107
- digital-twin-service: 8108
- talks-service: 8109

## Setup Backend
docker compose up -d --build

## Setup Dashboard
cd GPI-SSO-Frontend/WebSSO && npm install && npm run dev

## Setup App Movil
cd GPI-SSO-Frontend/APP-GPI-ALLOXENTRIC && npm install && npm run dev

## Variables de entorno (.env en ambos frontends)
VITE_AUTH_API_URL=http://localhost:8100
VITE_REPORTS_API_URL=http://localhost:8102
VITE_ALERTS_API_URL=http://localhost:8104
VITE_INCIDENTS_API_URL=http://localhost:8103
VITE_WORKERS_API_URL=http://localhost:8106
VITE_AREAS_API_URL=http://localhost:8107
VITE_CLIENT_ID=cliente_prueba_123

## Usuarios de prueba
- admin@demo.com / 123456 (Admin)
- patricia@demo.com / 123456 (Admin)
- joao@demo.com / 123456 (Admin)
- supervisor@demo.com / 123456 (Supervisor)
- jefe@demo.com / 123456 (Jefe de Area)
- usuario@demo.com / 123456 (Usuario)

## Modulos del Dashboard
- W-01 Centro de Comando — Todos los roles
- W-02 Incidentes — Admin, SSO Manager, Jefe, Supervisor, Usuario
- W-02b Precursores y Causas — Admin, SSO Manager
- W-03 Gemelo Digital — Admin, SSO Manager
- W-04 Alertas — Admin, SSO Manager, Analyst, Jefe, Supervisor
- W-05 Reportes — Admin, SSO Manager, Analyst
- W-06 Usuarios — Admin, SSO Manager
- W-07 Configuracion — Admin, SSO Manager, Analyst, Jefe, Supervisor
- W-08 Dialogos SSO — Admin, SSO Manager, Jefe, Supervisor

## Compilar APK Android
npm run build
npx cap sync android
cd android && ./gradlew assembleRelease

## Compilar AAB (Play Store)
cd android && ./gradlew bundleRelease

## Tecnologias
Frontend: React 18, TypeScript, Vite, Tailwind, Framer Motion, Lucide, Capacitor
Backend: Python 3.12, FastAPI, MongoDB (Motor async), JWT, Docker
Infra: Azure Spot VM, Docker Compose

## Pendientes / Mejoras posibles
- Integracion Power BI en dashboard
- Gestion completa de incidentes desde app movil
- Notificaciones push en app movil
- Modo offline con sincronizacion
- Exportar reportes a PDF desde la app
- Dashboard analytics avanzado

## Contacto
Desarrollado por Alloxentric — info@alloxentric.com
