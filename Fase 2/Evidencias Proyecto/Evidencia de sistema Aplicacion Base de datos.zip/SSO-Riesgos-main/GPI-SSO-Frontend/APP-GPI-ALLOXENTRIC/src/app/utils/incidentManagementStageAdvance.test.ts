import {
  describe,
  expect,
  it,
} from 'vitest';

import {
  getIncidentManagementStageAfterSave,
} from './incidentManagementStageAdvance';

import {
  getIncidentManagementStageState,
} from './incidentManagementStages';

describe('incidentManagementStageAdvance - TT-16 / SCRUM-322', () => {
  const openState = getIncidentManagementStageState({
    status: 'open',
  });

  const processState = getIncidentManagementStageState({
    status: 'en_proceso',
  });

  const completedTreatmentState =
    getIncidentManagementStageState({
      status: 'en_proceso',
      control_measures: [
        'Actualizar procedimiento',
      ],
      training: 'Capacitación realizada',
      deadline: '2026-10-11',
      feedback: 'Trabajador informado',
    });

  it('advances review to analysis after a successful save', () => {
    expect(
      getIncidentManagementStageAfterSave(
        'review',
        true,
        openState,
      ),
    ).toBe('analysis');
  });

  it('does not advance analysis to treatment while report is open', () => {
    expect(
      getIncidentManagementStageAfterSave(
        'analysis',
        true,
        openState,
      ),
    ).toBe('analysis');
  });

  it('can advance analysis to treatment once report is en_proceso', () => {
    expect(
      getIncidentManagementStageAfterSave(
        'analysis',
        true,
        processState,
      ),
    ).toBe('treatment');
  });

  it('advances treatment to closure when treatment is complete', () => {
    expect(
      getIncidentManagementStageAfterSave(
        'treatment',
        true,
        completedTreatmentState,
      ),
    ).toBe('closure');
  });

  it('does not invent workflow transitions for closure or validation', () => {
    const pendingClosureState = getIncidentManagementStageState({
      status: 'pending_closure',
    });

    const closedState = getIncidentManagementStageState({
      status: 'closed',
    });

    expect(
      getIncidentManagementStageAfterSave(
        'closure',
        true,
        pendingClosureState,
      ),
    ).toBe('closure');

    expect(
      getIncidentManagementStageAfterSave(
        'validation',
        true,
        closedState,
      ),
    ).toBe('validation');
  });

  it('keeps the current stage when persistence fails', () => {
    expect(
      getIncidentManagementStageAfterSave(
        'review',
        false,
        openState,
      ),
    ).toBe('review');

    expect(
      getIncidentManagementStageAfterSave(
        'analysis',
        false,
        processState,
      ),
    ).toBe('analysis');

    expect(
      getIncidentManagementStageAfterSave(
        'treatment',
        false,
        processState,
      ),
    ).toBe('treatment');
  });
});
