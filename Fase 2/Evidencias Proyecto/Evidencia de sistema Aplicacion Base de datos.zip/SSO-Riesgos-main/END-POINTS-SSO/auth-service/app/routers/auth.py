import logging
logger = logging.getLogger("auth")
from fastapi import Request, APIRouter, Depends
from app.schemas.auth import LoginRequest, TokenResponse, RefreshRequest
from app.services.auth_service import AuthService
from app.dependencies import (
    get_auth_service,
    get_current_user,
)  # Importamos de dependencies.py

router = APIRouter(prefix="/v1/auth", tags=["Auth"])


@router.post("/login", response_model=TokenResponse)
async def login(
    payload: LoginRequest, service: AuthService = Depends(get_auth_service)
):
    # 💡 Nota: Asegúrate de que internamente service.login_user ya esté metiendo "areas" o "area" 
    # dentro del access_token que genera y devuelve en el JSON.
    return await service.login_user(payload)


@router.post("/refresh", response_model=TokenResponse)
async def refresh(
    payload: RefreshRequest, service: AuthService = Depends(get_auth_service)
):
    return TokenResponse(**await service.refresh_user_session(payload.refresh_token))


# Ya que estamos aquí, podemos agregar el GET /me que pidió tu jefe
@router.get("/me")
async def get_me(current_user: dict = Depends(get_current_user)):
    # 🌟 CORRECCIÓN 2: Devolvemos TODO lo que decodificamos del token, incluyendo las áreas.
    # Así, si tu frontend consulta /me, recibirá el objeto con sus permisos geográficos intactos.
    return {
        "user_id": current_user.get("sub"),
        "client_id": current_user.get("client_id"),
        "role": current_user.get("role"),
        "areas": current_user.get("areas", []), # 👈 Múltiples áreas (Formato array de strings)
        "area": current_user.get("area", "")     # 👈 Área única (Formato string plano)
    }


# Nuevo endpoint interno para que otros microservicios creen credenciales
@router.post("/internal/credentials", status_code=201)
async def create_internal_credentials(
    payload: LoginRequest, # Reutilizamos el schema que tiene email y password
    service: AuthService = Depends(get_auth_service)
):
    # Aquí llamamos a la lógica interna que hashea la contraseña y guarda en Firestore
    # Asumimos que tu AuthService tiene un método para registrar/crear credenciales
    new_user = await service.create_auth_record(payload.email, payload.password)
    return {"user_id": new_user.id, "email": payload.email}
