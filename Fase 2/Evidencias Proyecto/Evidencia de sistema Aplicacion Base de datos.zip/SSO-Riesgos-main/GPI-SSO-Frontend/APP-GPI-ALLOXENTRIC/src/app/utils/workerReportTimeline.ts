import type {
  Report,
  ReportTimeline,
} from '../api/reports';

export type WorkerReportTimelineKey =
  | 'sent'
  | 'reviewing'
  | 'assigned'
  | 'en_proceso'
  | 'pending_closure'
  | 'closed';

export interface WorkerReportTimelineStep {
  key: WorkerReportTimelineKey;
  label: string;
  color: string;
  active: boolean;
  current: boolean;
  timestamp?: string;
}

const STEP_ORDER: WorkerReportTimelineKey[] = [
  'sent',
  'reviewing',
  'assigned',
  'en_proceso',
  'pending_closure',
  'closed',
];

const STEP_LABELS: Record<
  WorkerReportTimelineKey,
  string
> = {
  sent: 'Reporte enviado',
  reviewing: 'Revisión inicial',
  assigned: 'Análisis',
  en_proceso: 'Tratamiento',
  pending_closure: 'Cierre en validación',
  closed: 'Cerrado',
};

const STEP_COLORS: Record<
  WorkerReportTimelineKey,
  string
> = {
  sent: '#00E5FF',
  reviewing: '#3B82F6',
  assigned: '#00C2DB',
  en_proceso: '#E8941A',
  pending_closure: '#8B5CF6',
  closed: '#16A34A',
};

function currentTimelineKey(
  report: Report,
): WorkerReportTimelineKey {
  switch (report.status) {
    case 'sent':
      return 'sent';

    case 'reviewing':
      return 'reviewing';

    case 'assigned':
      return 'assigned';

    case 'open': {
      const hasAnalysisProgress =
        Boolean(report.timeline?.assigned)
        || Boolean(report.analysis?.trim())
        || Boolean(report.probable_consequence?.trim())
        || Boolean(report.causes?.length);

      return hasAnalysisProgress
        ? 'assigned'
        : 'reviewing';
    }

    case 'en_proceso':
      return 'en_proceso';

    case 'pending_closure':
      return 'pending_closure';

    case 'closed':
      return 'closed';

    default:
      return 'reviewing';
  }
}

function getTimestamp(
  report: Report,
  key: WorkerReportTimelineKey,
): string | undefined {
  const timeline: ReportTimeline =
    report.timeline || {};

  switch (key) {
    case 'sent':
      return timeline.sent || report.created_at;

    case 'reviewing':
      return timeline.reviewing || timeline.open;

    case 'assigned':
      return timeline.assigned;

    case 'en_proceso':
      return timeline.en_proceso;

    case 'pending_closure':
      return timeline.pending_closure;

    case 'closed':
      return timeline.closed;

    default:
      return undefined;
  }
}

export function getWorkerReportTimelineSteps(
  report: Report,
): WorkerReportTimelineStep[] {
  const currentKey = currentTimelineKey(report);
  const currentIndex = STEP_ORDER.indexOf(currentKey);

  return STEP_ORDER.map((key, index) => {
    const timestamp = getTimestamp(report, key);

    return {
      key,
      label: STEP_LABELS[key],
      color: STEP_COLORS[key],
      active:
        index <= currentIndex
        || Boolean(timestamp),
      current: index === currentIndex,
      timestamp,
    };
  });
}

const TIMELINE_TIMEZONE_PATTERN =
  /(?:Z|[+-]\d{2}:?\d{2})$/i;

function normalizeWorkerReportTimelineTimestamp(
  timestamp: string,
): string {
  const value = timestamp.trim();

  if (!value) {
    return '';
  }

  const timezoneAware =
    TIMELINE_TIMEZONE_PATTERN.test(value)
      ? value
      : `${value}Z`;

  // Python puede entregar microsegundos (6 dígitos).
  // Date de JavaScript trabaja de forma segura con milisegundos.
  return timezoneAware.replace(
    /(\.\d{3})\d+(?=(?:Z|[+-]\d{2}:?\d{2})$)/i,
    '$1',
  );
}

export function formatWorkerReportTimelineTimestamp(
  timestamp?: string,
  timeZone?: string,
): string {
  if (!timestamp?.trim()) {
    return '';
  }

  const normalized =
    normalizeWorkerReportTimelineTimestamp(
      timestamp,
    );

  const date = new Date(normalized);

  if (Number.isNaN(date.getTime())) {
    return timestamp.trim();
  }

  const options: Intl.DateTimeFormatOptions = {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23',
  };

  if (timeZone) {
    options.timeZone = timeZone;
  }

  const parts = new Intl.DateTimeFormat(
    'es-CL',
    options,
  ).formatToParts(date);

  const part = (type: Intl.DateTimeFormatPartTypes) =>
    parts.find(item => item.type === type)?.value || '';

  const day = part('day');
  const month = part('month');
  const year = part('year');
  const hour = part('hour');
  const minute = part('minute');

  if (
    !day
    || !month
    || !year
    || !hour
    || !minute
  ) {
    return new Intl.DateTimeFormat(
      'es-CL',
      options,
    ).format(date);
  }

  return `${day}-${month}-${year} ${hour}:${minute}`;
}
