import { describe, expect, it } from 'vitest';
import { renderToStaticMarkup } from 'react-dom/server';

import IncidentDeadlineField from './IncidentDeadlineField';

describe('IncidentDeadlineField - SCRUM-76', () => {
  const today = new Date(
    2026,
    8,
    14,
    12,
    0,
    0
  );

  it('renders a date picker', () => {
    const html = renderToStaticMarkup(
      <IncidentDeadlineField
        value=""
        onChange={() => undefined}
        today={today}
      />
    );

    expect(html).toContain('type="date"');
  });

  it('renders the reference range', () => {
    const html = renderToStaticMarkup(
      <IncidentDeadlineField
        value=""
        onChange={() => undefined}
        today={today}
      />
    );

    expect(html).toContain('min="2026-09-17"');
    expect(html).toContain('max="2026-10-14"');
    expect(html).toContain(
      'Rango: 3 a 30 días desde hoy'
    );
  });

  it('shows remaining days for a selected date', () => {
    const html = renderToStaticMarkup(
      <IncidentDeadlineField
        value="2026-09-20"
        onChange={() => undefined}
        today={today}
      />
    );

    expect(html).toContain(
      '6 día(s) restante(s)'
    );
  });

  it('does not show remaining days when empty', () => {
    const html = renderToStaticMarkup(
      <IncidentDeadlineField
        value=""
        onChange={() => undefined}
        today={today}
      />
    );

    expect(html).not.toContain(
      'día(s) restante(s)'
    );
  });
});
