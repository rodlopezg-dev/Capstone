
const AUTH_BASE = (
    import.meta.env.VITE_AUTH_API_URL || '/api/auth'
).replace(/\/+$/, '');

const ACCESS_TOKEN_KEY = 'sso_token';
const REFRESH_TOKEN_KEY = 'sso_refresh_token';

export const AUTH_SESSION_INVALIDATED_EVENT =
    'vigia:session-invalidated';

export class ApiError extends Error {
    constructor(
        public status: number,
        message: string,
    ) {
        super(message);
        this.name = 'ApiError';
    }
}

export const getToken = (): string | null =>
    localStorage.getItem(ACCESS_TOKEN_KEY);

export const getRefreshToken = (): string | null =>
    localStorage.getItem(REFRESH_TOKEN_KEY);

export function setAuthTokens(
    accessToken: string,
    refreshToken: string,
): void {
    localStorage.setItem(ACCESS_TOKEN_KEY, accessToken);
    localStorage.setItem(REFRESH_TOKEN_KEY, refreshToken);
}

export function clearAuthTokens(): void {
    localStorage.removeItem(ACCESS_TOKEN_KEY);
    localStorage.removeItem(REFRESH_TOKEN_KEY);
}

export function invalidateAuthSession(): void {
    clearAuthTokens();
    localStorage.removeItem('sso_user');

    window.dispatchEvent(
        new Event(AUTH_SESSION_INVALIDATED_EVENT)
    );
}

interface RefreshResponse {
    access_token: string;
    refresh_token?: string;
}

let refreshPromise: Promise<boolean> | null = null;

async function refreshSession(): Promise<boolean> {
    if (refreshPromise) return refreshPromise;

    refreshPromise = (async () => {
        const refreshToken = getRefreshToken();

        if (!refreshToken) {
            invalidateAuthSession();
            return false;
        }

        const response = await fetch(
            `${AUTH_BASE}/v1/auth/refresh`,
            {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    refresh_token: refreshToken,
                }),
            },
        );

        if ([400, 401, 403, 422].includes(response.status)) {
            invalidateAuthSession();
            return false;
        }

        if (!response.ok) {
            throw new ApiError(
                response.status,
                'No fue posible renovar la sesión.',
            );
        }

        const data = (await response.json()) as RefreshResponse;

        if (!data.access_token) {
            throw new Error('Respuesta de renovación inválida.');
        }

        setAuthTokens(
            data.access_token,
            data.refresh_token || refreshToken,
        );

        return true;
    })().finally(() => {
        refreshPromise = null;
    });

    return refreshPromise;
}

async function authenticatedFetch(
    path: string,
    options: RequestInit,
): Promise<Response> {
    if (!getToken() && getRefreshToken()) {
        await refreshSession();
    }

    const request = () => {
        const headers = new Headers(options.headers);
        const token = getToken();

        if (token) {
            headers.set('Authorization', `Bearer ${token}`);
        } else {
            headers.delete('Authorization');
        }

        return fetch(`${AUTH_BASE}${path}`, {
            ...options,
            headers,
        });
    };

    const tokenBefore = getToken();
    let response = await request();

    if (response.status !== 401) {
        return response;
    }

    const latestToken = getToken();

    if (latestToken && latestToken !== tokenBefore) {
        response = await request();

        if (response.status === 401) {
            invalidateAuthSession();
        }

        return response;
    }

    const refreshed = await refreshSession();

    if (!refreshed) return response;

    response = await request();

    if (response.status === 401) {
        invalidateAuthSession();
    }

    return response;
}

interface AuthRequestOptions extends RequestInit {
    auth?: boolean;
}

export async function authRequest<T>(
    path: string,
    options: AuthRequestOptions = {},
): Promise<T> {
    const { auth = true, ...requestOptions } = options;

    const headers = new Headers(requestOptions.headers);

    if (
        requestOptions.body &&
        !(requestOptions.body instanceof FormData) &&
        !headers.has('Content-Type')
    ) {
        headers.set('Content-Type', 'application/json');
    }

    const config: RequestInit = {
        ...requestOptions,
        headers,
        cache: 'no-store',
    };

    const response = auth
        ? await authenticatedFetch(path, config)
        : await fetch(`${AUTH_BASE}${path}`, config);

    if (!response.ok) {
        const body = await response.json().catch(() => null);

        const message =
            response.status === 401 && !auth
                ? 'Organización, correo o contraseña incorrectos.'
                : typeof body?.detail === 'string'
                    ? body.detail
                    : `Error HTTP ${response.status}`;

        throw new ApiError(response.status, message);
    }

    if (response.status === 204) {
        return undefined as T;
    }

    return response.json() as Promise<T>;
}
