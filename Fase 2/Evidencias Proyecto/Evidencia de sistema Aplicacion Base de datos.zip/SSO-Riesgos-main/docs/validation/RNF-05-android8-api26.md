# RNF-05 — Compatibilidad Android 8 / API 26

## 1. Objetivo

Documentar la validación de compatibilidad de Vigía Industrial para el
requisito RNF-05 dentro del alcance de EP-03, utilizando Android 8.0 / API 26
como entorno mínimo representativo.

La validación cubre compilación, instalación, autenticación, navegación,
gestión de reportes, evidencias, archivos y notificaciones locales.

## 2. Resultado

RNF-05 queda validado para el entorno probado:

- Android 8.0.0;
- API level 26;
- arquitectura x86_64 del AVD;
- Chrome/WebView 111.0.5563.116;
- aplicación construida desde `origin/main` sin adaptaciones específicas para
  WebView 69.

La validación no implica que cualquier versión de WebView posterior sea
automáticamente compatible con Android 8. El proveedor WebView debe ser
compatible tanto con el frontend como con el framework Android utilizado.

## 3. Configuración Android

La configuración efectiva del proyecto es:

```text
minSdkVersion     = 24
compileSdkVersion = 36
targetSdkVersion  = 36
```

El proyecto declara por lo tanto un nivel mínimo inferior a API 26 y puede
compilarse e instalarse en el entorno requerido por RNF-05.

## 4. Entorno de prueba

Se preparó un AVD específico:

```text
AVD:      vigia-api26
Android:  8.0.0
API:      26
ABI:      x86_64
WebView:  com.android.chrome 111.0.5563.116
```

El emulador utiliza aceleración KVM y renderizado gráfico del host.

Durante las pruebas se detectó consumo elevado del proceso QEMU. Un cold boot
redujo significativamente dicho consumo. Android no registró ANR atribuibles a
Vigía, por lo que este comportamiento se considera una característica del
entorno de emulación y no un defecto funcional de la aplicación.

## 5. Proveedor WebView

La imagen original de Android 8 utilizaba Chrome/WebView 69.

Con ese proveedor se observaron incompatibilidades con el frontend moderno:

- sintaxis JavaScript no disponible;
- ausencia de `queueMicrotask`;
- renderizado incompleto del CSS generado por Tailwind CSS 4.

Se evaluaron adaptaciones para Chrome 69, incluyendo:

- target de Vite para Chrome 69;
- transformación CSS mediante PostCSS;
- polyfills JavaScript.

Estas adaptaciones fueron descartadas porque alteraban significativamente el
pipeline frontend y no eran necesarias utilizando un proveedor WebView moderno.

### Baseline validado

La regresión final se realizó con:

```text
Chrome/WebView 111.0.5563.116
```

Con esta versión Tailwind CSS 4 se utiliza sin modificaciones legacy.

### Chrome 138

También se evaluó Chrome 138 en Android 8.

Aunque el APK podía instalarse, al utilizarlo como proveedor WebView se produjo
un fallo nativo durante la inicialización de WebView, asociado a APIs del
framework Android 8 y a la carga de `libmonochrome.so`.

Por esta razón no se generaliza la compatibilidad a cualquier WebView posterior
a la versión 111. La versión 111 corresponde al baseline comprobado en esta
validación.

## 6. Regresión automatizada

La regresión final se ejecutó desde `origin/main` limpio.

Resultados frontend:

```text
Test Files: 33 passed
Tests:      239 passed
Vite build: OK
```

El build utilizó Tailwind CSS 4 original, sin:

- `target: chrome69`;
- `cssTarget: chrome69`;
- `postcss-preset-env`;
- polyfills agregados específicamente para WebView 69.

Capacitor sincronizó correctamente los plugins Android y Gradle generó la APK
debug:

```text
BUILD SUCCESSFUL
APK aproximada: 14 MiB
```

## 7. Instalación y arranque

La APK construida desde `origin/main` fue instalada en Android 8/API 26.

Resultado:

```text
adb install: Success
PID Vigía: activo
MainActivity: Resumed
```

No se observaron durante la regresión final:

- `FATAL EXCEPTION`;
- `SIGSEGV`;
- `SyntaxError`;
- `ReferenceError`;
- errores JavaScript fatales.

## 8. Login y navegación

Se validó autenticación contra el backend real utilizando el API Edge.

La APK móvil debe construirse con URLs accesibles desde el dispositivo. Los
fallbacks `localhost` del frontend no son válidos dentro de un emulador porque
`localhost` representa al propio dispositivo Android.

Con las URLs correctas del edge se validaron:

- login;
- Home;
- perfil;
- Mis Reportes;
- detalle de reporte;
- módulo Gestionar para usuarios autorizados.

## 9. Gestión de reportes

Se validó con usuario worker:

- listado de reportes existentes;
- apertura y regreso al listado;
- creación de un reporte;
- persistencia en backend;
- actualización del contador;
- reapertura del reporte creado;
- renderizado de estado y timeline.

El reporte de prueba utilizado durante ST-233 quedó disponible posteriormente
desde Mis Reportes, confirmando persistencia del flujo.

## 10. Evidencia inicial

En el flujo worker se validó:

- apertura de cámara;
- captura de fotografía;
- confirmación de imagen;
- preview en formulario;
- envío junto al reporte;
- thumbnail en listado;
- visualización de la evidencia al reabrir el reporte.

Android utilizó `android.media.action.IMAGE_CAPTURE` y el FileProvider de la
aplicación.

## 11. Evidencia de cierre

Con una cuenta de gestión se validaron los controles:

- Tomar foto;
- Elegir foto;
- Elegir PDF;
- Guardar evidencia.

### PDF

Se seleccionó un PDF desde el almacenamiento del dispositivo y se guardó como
evidencia de cierre.

Después de abandonar y reabrir el reporte, el mismo PDF continuó apareciendo
como evidencia asociada.

### Fotografía

Se capturó una fotografía mediante el plugin Camera de Capacitor.

La integración ejecutó:

```text
Camera.requestPermissions
Camera.getPhoto
source = CAMERA
android.media.action.IMAGE_CAPTURE
```

Después de guardar, abandonar y reabrir el reporte, la fotografía continuó
apareciendo como evidencia asociada.

## 12. Notificaciones locales

Se validó el plugin de notificaciones locales en API 26.

La aplicación programó correctamente una notificación posterior a la creación
de un nuevo reporte.

Ejemplo validado:

```text
Título: Reporte recibido
Texto:  Tu reporte fue enviado y está siendo revisado.
```

La notificación fue registrada por Android mediante el canal `default`.

## 13. Hallazgos no bloqueantes

Durante las pruebas se observaron algunos elementos que no impidieron el flujo:

- advertencias relacionadas con `android.webkit.PacProcessor` en WebView 111;
- un mensaje no fatal al inyectar CSS de safe area;
- advertencias de APIs deprecadas durante compilación de algunos plugins;
- advertencia de tamaño de bundle Vite superior a 500 kB;
- comportamiento de alto consumo del AVD/QEMU.

Ninguno produjo fallos funcionales en los escenarios cubiertos por RNF-05.

## 14. Conclusión

La aplicación Vigía Industrial cumple RNF-05 dentro del alcance validado de
EP-03 sobre Android 8/API 26.

La evidencia obtenida demuestra funcionamiento de:

- instalación y arranque;
- autenticación;
- navegación;
- consulta y creación de reportes;
- persistencia;
- cámara;
- evidencia fotográfica;
- evidencia PDF;
- evidencia de cierre;
- notificaciones locales.

No se requieren modificaciones al código de producción para alcanzar este
resultado.

El baseline WebView comprobado para Android 8 es Chrome/WebView
111.0.5563.116. Cambiar el proveedor WebView en dispositivos Android antiguos
debe ser objeto de validación de compatibilidad y no asumirse únicamente por
número de versión.

## 15. Referencias de trabajo

Validación Jira:

- SCRUM-289 — TT-14;
- SCRUM-298 — ST-230;
- SCRUM-299 — ST-231;
- SCRUM-300 — ST-232;
- SCRUM-301 — ST-233;
- SCRUM-302 — ST-234;
- SCRUM-303 — ST-235;
- SCRUM-304 — ST-236.
