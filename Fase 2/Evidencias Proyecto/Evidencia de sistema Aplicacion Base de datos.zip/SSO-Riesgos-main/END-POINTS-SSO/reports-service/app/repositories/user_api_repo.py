import logging
import os

import httpx


logger = logging.getLogger(__name__)

HTTP_TIMEOUT = httpx.Timeout(
    15.0,
    connect=5.0,
)


class UserApiRepository:
    def __init__(
        self,
        base_url: str | None = None,
        internal_api_key: str | None = None,
    ):
        self.base_url = (
            base_url
            or os.getenv(
                "USERS_SERVICE_URL",
                "http://localhost:8082",
            )
        ).rstrip("/")

        self.internal_api_key = (
            internal_api_key
            or os.getenv("INTERNAL_API_KEY", "")
        )

    async def get_report_managers(
        self,
        *,
        client_id: str,
        area_id: str,
        exclude_user_id: str | None = None,
    ) -> list[dict]:
        if not self.internal_api_key:
            raise RuntimeError(
                "INTERNAL_API_KEY no configurada"
            )

        payload = {
            "client_id": client_id,
            "area_id": area_id,
            "exclude_user_id": exclude_user_id,
        }

        headers = {
            "X-Internal-Token": self.internal_api_key,
        }

        async with httpx.AsyncClient(
            timeout=HTTP_TIMEOUT
        ) as client:
            response = await client.post(
                (
                    f"{self.base_url}"
                    "/v1/internal/users/report-managers"
                ),
                json=payload,
                headers=headers,
            )

            response.raise_for_status()

            data = response.json()

            if not isinstance(data, list):
                raise ValueError(
                    "Respuesta inválida de users-service"
                )

            return data
