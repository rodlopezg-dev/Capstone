import pytest
from fastapi.testclient import TestClient

from app.main import app
from app.routers import rt_reports
from tests.integration.test_report_category import FakeDB


REPORT_ID = "report_scrum92"
TENANT_A = "tenant_a"
TENANT_B = "tenant_b"


def report_fixture(
    *,
    report_id=REPORT_ID,
    client_id=TENANT_A,
    status="open",
    **overrides,
):
    report = {
        "report_id": report_id,
        "client_id": client_id,
        "status": status,
        "reported_by": "",
        "type": "Condición Insegura",
        "is_iap": False,
        "causes": [
            "Procedimiento no aplicado",
        ],
        "probable_consequence": "Caída",
        "analysis": (
            "Se identificó la causa principal."
        ),
        "control_measures": [
            "Instalar señalización",
        ],
        "training": (
            "Capacitación realizada."
        ),
        "deadline": "2026-10-10",
        "feedback": (
            "Trabajador informado."
        ),
        "closure_evidence": {
            "url": "/closure.pdf",
            "filename": "closure.pdf",
            "content_type": "application/pdf",
        },
    }

    report.update(overrides)

    return report


@pytest.fixture
def fake_db():
    return FakeDB(
        [
            report_fixture(),
        ]
    )


@pytest.fixture
def client_factory(
    fake_db,
    monkeypatch,
):
    clients = []

    def _factory(
        *,
        role="supervisor",
        client_id=TENANT_A,
    ):
        app.dependency_overrides[
            rt_reports.get_db
        ] = lambda: fake_db

        monkeypatch.setattr(
            rt_reports,
            "get_current_user",
            lambda credentials: {
                "user_id": "manager_scrum92",
                "client_id": client_id,
                "role": role,
            },
        )

        client = TestClient(app)
        clients.append(client)

        return client

    yield _factory

    for client in clients:
        client.close()

    app.dependency_overrides.clear()


@pytest.mark.parametrize(
    "role",
    [
        "supervisor",
        "jefe_de_area",
        "jefe de area",
    ],
)
def test_authorized_roles_can_change_to_process(
    fake_db,
    client_factory,
    role,
):
    client = client_factory(role=role)

    response = client.patch(
        f"/v1/reports/{REPORT_ID}/status",
        headers={
            "Authorization": "Bearer fake_token"
        },
        json={
            "status": "en_proceso",
        },
    )

    assert response.status_code == 200
    assert response.json() == {
        "ok": True,
        "status": "en_proceso",
    }

    saved = fake_db["reports"].documents[0]

    assert saved["status"] == "en_proceso"


@pytest.mark.parametrize(
    "role",
    [
        "worker",
        "admin",
        "sso_manager",
    ],
)
def test_other_roles_cannot_change_to_process(
    fake_db,
    client_factory,
    role,
):
    client = client_factory(role=role)

    response = client.patch(
        f"/v1/reports/{REPORT_ID}/status",
        headers={
            "Authorization": "Bearer fake_token"
        },
        json={
            "status": "en_proceso",
        },
    )

    assert response.status_code == 403

    assert response.json()["detail"] == (
        "No tiene permisos para cambiar "
        "el incidente a proceso"
    )

    saved = fake_db["reports"].documents[0]

    assert saved["status"] == "open"


def test_change_to_process_requires_open_status(
    fake_db,
    client_factory,
):
    fake_db["reports"].documents[0][
        "status"
    ] = "en_proceso"

    client = client_factory(
        role="supervisor"
    )

    response = client.patch(
        f"/v1/reports/{REPORT_ID}/status",
        headers={
            "Authorization": "Bearer fake_token"
        },
        json={
            "status": "en_proceso",
        },
    )

    assert response.status_code == 409

    assert response.json()["detail"] == (
        "El incidente no está en un estado "
        "válido para cambiar a proceso"
    )

    saved = fake_db["reports"].documents[0]

    assert saved["status"] == "en_proceso"


@pytest.mark.parametrize(
    "role",
    [
        "supervisor",
        "jefe_de_area",
        "jefe de area",
    ],
)
def test_authorized_roles_can_request_closure(
    fake_db,
    client_factory,
    role,
):
    fake_db["reports"].documents[0][
        "status"
    ] = "en_proceso"

    client = client_factory(role=role)

    response = client.patch(
        f"/v1/reports/{REPORT_ID}/status",
        headers={
            "Authorization": "Bearer fake_token"
        },
        json={
            "status": "pending_closure",
        },
    )

    assert response.status_code == 200

    assert response.json() == {
        "ok": True,
        "status": "pending_closure",
    }

    saved = fake_db["reports"].documents[0]

    assert saved["status"] == "pending_closure"


@pytest.mark.parametrize(
    "role",
    [
        "worker",
        "admin",
        "sso_manager",
    ],
)
def test_other_roles_cannot_request_closure(
    fake_db,
    client_factory,
    role,
):
    fake_db["reports"].documents[0][
        "status"
    ] = "en_proceso"

    client = client_factory(role=role)

    response = client.patch(
        f"/v1/reports/{REPORT_ID}/status",
        headers={
            "Authorization": "Bearer fake_token"
        },
        json={
            "status": "pending_closure",
        },
    )

    assert response.status_code == 403

    assert response.json()["detail"] == (
        "No tiene permisos para solicitar "
        "el cierre del incidente"
    )

    saved = fake_db["reports"].documents[0]

    assert saved["status"] == "en_proceso"


def test_request_closure_requires_process_status(
    fake_db,
    client_factory,
):
    client = client_factory(
        role="supervisor"
    )

    response = client.patch(
        f"/v1/reports/{REPORT_ID}/status",
        headers={
            "Authorization": "Bearer fake_token"
        },
        json={
            "status": "pending_closure",
        },
    )

    assert response.status_code == 409

    assert response.json()["detail"] == (
        "El incidente no está en un estado "
        "válido para solicitar cierre"
    )

    saved = fake_db["reports"].documents[0]

    assert saved["status"] == "open"


@pytest.mark.parametrize(
    "role",
    [
        "admin",
        "sso_manager",
        "sso manager",
    ],
)
def test_authorized_roles_can_approve_closure(
    fake_db,
    client_factory,
    role,
):
    fake_db["reports"].documents[0][
        "status"
    ] = "pending_closure"

    client = client_factory(role=role)

    response = client.patch(
        f"/v1/reports/{REPORT_ID}/status",
        headers={
            "Authorization": "Bearer fake_token"
        },
        json={
            "status": "closed",
        },
    )

    assert response.status_code == 200

    assert response.json() == {
        "ok": True,
        "status": "closed",
    }

    saved = fake_db["reports"].documents[0]

    assert saved["status"] == "closed"


@pytest.mark.parametrize(
    "role",
    [
        "supervisor",
        "jefe_de_area",
        "jefe de area",
        "worker",
    ],
)
def test_other_roles_cannot_approve_closure(
    fake_db,
    client_factory,
    role,
):
    fake_db["reports"].documents[0][
        "status"
    ] = "pending_closure"

    client = client_factory(role=role)

    response = client.patch(
        f"/v1/reports/{REPORT_ID}/status",
        headers={
            "Authorization": "Bearer fake_token"
        },
        json={
            "status": "closed",
        },
    )

    assert response.status_code == 403

    assert response.json()["detail"] == (
        "No tiene permisos para aprobar "
        "el cierre del incidente"
    )

    saved = fake_db["reports"].documents[0]

    assert saved["status"] == "pending_closure"


def test_approve_closure_requires_pending_status(
    fake_db,
    client_factory,
):
    fake_db["reports"].documents[0][
        "status"
    ] = "en_proceso"

    client = client_factory(
        role="admin"
    )

    response = client.patch(
        f"/v1/reports/{REPORT_ID}/status",
        headers={
            "Authorization": "Bearer fake_token"
        },
        json={
            "status": "closed",
        },
    )

    assert response.status_code == 409

    assert response.json()["detail"] == (
        "El incidente no está pendiente "
        "de aprobación de cierre"
    )

    saved = fake_db["reports"].documents[0]

    assert saved["status"] == "en_proceso"


@pytest.mark.parametrize(
    (
        "role",
        "source_status",
        "target_status",
        "expected_status_code",
    ),
    [
        # Supervisor
        (
            "supervisor",
            "open",
            "en_proceso",
            200,
        ),
        (
            "supervisor",
            "en_proceso",
            "pending_closure",
            200,
        ),
        (
            "supervisor",
            "pending_closure",
            "closed",
            403,
        ),

        # Jefe de área
        (
            "jefe_de_area",
            "open",
            "en_proceso",
            200,
        ),
        (
            "jefe_de_area",
            "en_proceso",
            "pending_closure",
            200,
        ),
        (
            "jefe_de_area",
            "pending_closure",
            "closed",
            403,
        ),

        # Admin
        (
            "admin",
            "open",
            "en_proceso",
            403,
        ),
        (
            "admin",
            "en_proceso",
            "pending_closure",
            403,
        ),
        (
            "admin",
            "pending_closure",
            "closed",
            200,
        ),

        # SSO Manager
        (
            "sso_manager",
            "open",
            "en_proceso",
            403,
        ),
        (
            "sso_manager",
            "en_proceso",
            "pending_closure",
            403,
        ),
        (
            "sso_manager",
            "pending_closure",
            "closed",
            200,
        ),

        # Worker
        (
            "worker",
            "open",
            "en_proceso",
            403,
        ),
        (
            "worker",
            "en_proceso",
            "pending_closure",
            403,
        ),
        (
            "worker",
            "pending_closure",
            "closed",
            403,
        ),
    ],
)
def test_backend_role_permission_matrix(
    fake_db,
    client_factory,
    role,
    source_status,
    target_status,
    expected_status_code,
):
    fake_db["reports"].documents[0][
        "status"
    ] = source_status

    client = client_factory(role=role)

    response = client.patch(
        f"/v1/reports/{REPORT_ID}/status",
        headers={
            "Authorization": "Bearer fake_token"
        },
        json={
            "status": target_status,
        },
    )

    assert response.status_code == (
        expected_status_code
    )

    saved = fake_db["reports"].documents[0]

    if expected_status_code == 200:
        assert response.json() == {
            "ok": True,
            "status": target_status,
        }

        assert saved["status"] == target_status

    else:
        # Una llamada directa no autorizada
        # no puede modificar el incidente.
        assert saved["status"] == source_status


@pytest.mark.parametrize(
    (
        "client_id",
        "other_client_id",
    ),
    [
        (
            TENANT_A,
            TENANT_B,
        ),
        (
            TENANT_B,
            TENANT_A,
        ),
    ],
)
def test_status_transition_is_isolated_by_client_id(
    fake_db,
    client_factory,
    client_id,
    other_client_id,
):
    # Mismo report_id en dos tenants distintos.
    fake_db["reports"].documents[:] = [
        report_fixture(
            client_id=TENANT_A,
            status="open",
        ),
        report_fixture(
            client_id=TENANT_B,
            status="open",
        ),
    ]

    client = client_factory(
        role="supervisor",
        client_id=client_id,
    )

    response = client.patch(
        f"/v1/reports/{REPORT_ID}/status",
        headers={
            "Authorization": "Bearer fake_token"
        },
        json={
            "status": "en_proceso",
        },
    )

    assert response.status_code == 200

    own_report = next(
        report
        for report
        in fake_db["reports"].documents
        if report["client_id"] == client_id
    )

    other_report = next(
        report
        for report
        in fake_db["reports"].documents
        if report["client_id"] == other_client_id
    )

    assert own_report["status"] == "en_proceso"

    # El registro homónimo del otro tenant
    # debe permanecer intacto.
    assert other_report["status"] == "open"


def test_cross_tenant_status_update_is_rejected(
    fake_db,
    client_factory,
):
    foreign_report_id = "report_tenant_a_only"

    fake_db["reports"].documents[:] = [
        report_fixture(
            report_id=foreign_report_id,
            client_id=TENANT_A,
            status="open",
        ),
    ]

    # Tenant B intenta modificar un incidente
    # existente exclusivamente en Tenant A.
    client = client_factory(
        role="supervisor",
        client_id=TENANT_B,
    )

    response = client.patch(
        f"/v1/reports/{foreign_report_id}/status",
        headers={
            "Authorization": "Bearer fake_token"
        },
        json={
            "status": "en_proceso",
        },
    )

    assert response.status_code == 404
    assert response.json()["detail"] == (
        "Reporte no encontrado"
    )

    # La operación cross-tenant no modifica
    # el incidente perteneciente al otro cliente.
    saved = fake_db["reports"].documents[0]

    assert saved["client_id"] == TENANT_A
    assert saved["status"] == "open"


def test_full_incident_closure_workflow(
    fake_db,
    client_factory,
):
    other_report_id = "report_scrum99_other"

    fake_db["reports"].documents[:] = [
        # Incidente objetivo.
        report_fixture(
            report_id=REPORT_ID,
            client_id=TENANT_A,
            status="open",
        ),

        # Otro incidente del mismo tenant.
        report_fixture(
            report_id=other_report_id,
            client_id=TENANT_A,
            status="open",
        ),

        # Mismo report_id en otro tenant.
        report_fixture(
            report_id=REPORT_ID,
            client_id=TENANT_B,
            status="open",
        ),
    ]

    def target_report():
        return next(
            report
            for report
            in fake_db["reports"].documents
            if (
                report["report_id"] == REPORT_ID
                and report["client_id"] == TENANT_A
            )
        )

    def same_tenant_other_report():
        return next(
            report
            for report
            in fake_db["reports"].documents
            if (
                report["report_id"] == other_report_id
                and report["client_id"] == TENANT_A
            )
        )

    def other_tenant_report():
        return next(
            report
            for report
            in fake_db["reports"].documents
            if (
                report["report_id"] == REPORT_ID
                and report["client_id"] == TENANT_B
            )
        )

    def patch_status(
        *,
        role,
        status,
    ):
        client = client_factory(
            role=role,
            client_id=TENANT_A,
        )

        return client.patch(
            f"/v1/reports/{REPORT_ID}/status",
            headers={
                "Authorization": "Bearer fake_token"
            },
            json={
                "status": status,
            },
        )

    def assert_isolation(
        expected_target_status,
    ):
        assert (
            target_report()["status"]
            == expected_target_status
        )

        assert (
            same_tenant_other_report()["status"]
            == "open"
        )

        assert (
            other_tenant_report()["status"]
            == "open"
        )

    # -------------------------------------------------
    # 1. Estado inicial
    # -------------------------------------------------

    assert_isolation("open")

    # -------------------------------------------------
    # 2. Transición inválida:
    #    supervisor puede solicitar cierre,
    #    pero no desde open.
    # -------------------------------------------------

    response = patch_status(
        role="supervisor",
        status="pending_closure",
    )

    assert response.status_code == 409
    assert_isolation("open")

    # -------------------------------------------------
    # 3. Rol no autorizado:
    #    worker no puede cambiar a proceso.
    # -------------------------------------------------

    response = patch_status(
        role="worker",
        status="en_proceso",
    )

    assert response.status_code == 403
    assert_isolation("open")

    # -------------------------------------------------
    # 4. Supervisor:
    #    open -> en_proceso
    # -------------------------------------------------

    response = patch_status(
        role="supervisor",
        status="en_proceso",
    )

    assert response.status_code == 200
    assert response.json() == {
        "ok": True,
        "status": "en_proceso",
    }

    assert_isolation("en_proceso")

    # -------------------------------------------------
    # 5. Transición inválida:
    #    admin puede cerrar, pero solamente
    #    desde pending_closure.
    # -------------------------------------------------

    response = patch_status(
        role="admin",
        status="closed",
    )

    assert response.status_code == 409
    assert_isolation("en_proceso")

    # -------------------------------------------------
    # 6. Jefe de área:
    #    en_proceso -> pending_closure
    # -------------------------------------------------

    response = patch_status(
        role="jefe_de_area",
        status="pending_closure",
    )

    assert response.status_code == 200
    assert response.json() == {
        "ok": True,
        "status": "pending_closure",
    }

    assert_isolation("pending_closure")

    # -------------------------------------------------
    # 7. Supervisor no puede aprobar cierre.
    # -------------------------------------------------

    response = patch_status(
        role="supervisor",
        status="closed",
    )

    assert response.status_code == 403
    assert_isolation("pending_closure")

    # -------------------------------------------------
    # 8. SSO Manager:
    #    pending_closure -> closed
    # -------------------------------------------------

    response = patch_status(
        role="sso_manager",
        status="closed",
    )

    assert response.status_code == 200
    assert response.json() == {
        "ok": True,
        "status": "closed",
    }

    # Estado final del objetivo.
    assert_isolation("closed")


@pytest.mark.parametrize(
    (
        "field",
        "value",
        "expected_missing",
    ),
    [
        (
            "type",
            "",
            "categoría",
        ),
        (
            "type",
            "Categoría inválida",
            "categoría",
        ),
        (
            "causes",
            [],
            "causas / precursores",
        ),
        (
            "probable_consequence",
            "",
            "consecuencia probable",
        ),
        (
            "analysis",
            "",
            "análisis del supervisor",
        ),
        (
            "analysis",
            "   ",
            "análisis del supervisor",
        ),
    ],
)
def test_change_to_process_requires_complete_saved_analysis(
    fake_db,
    client_factory,
    field,
    value,
    expected_missing,
):
    report = fake_db["reports"].documents[0]
    report[field] = value

    client = client_factory(
        role="supervisor"
    )

    response = client.patch(
        f"/v1/reports/{REPORT_ID}/status",
        headers={
            "Authorization": "Bearer fake_token"
        },
        json={
            "status": "en_proceso",
        },
    )

    assert response.status_code == 409

    assert response.json()["detail"].startswith(
        "Debe completar y guardar antes "
        "de cambiar a proceso:"
    )

    assert expected_missing in (
        response.json()["detail"]
    )

    assert report["status"] == "open"


def test_change_to_process_accepts_legacy_iap_classification(
    fake_db,
    client_factory,
):
    report = fake_db["reports"].documents[0]

    report["type"] = "Categoría legacy"
    report["is_iap"] = True

    client = client_factory(
        role="supervisor"
    )

    response = client.patch(
        f"/v1/reports/{REPORT_ID}/status",
        headers={
            "Authorization": "Bearer fake_token"
        },
        json={
            "status": "en_proceso",
        },
    )

    assert response.status_code == 200
    assert report["status"] == "en_proceso"


@pytest.mark.parametrize(
    (
        "field",
        "value",
        "expected_missing",
    ),
    [
        (
            "control_measures",
            [],
            "medidas de control",
        ),
        (
            "training",
            "",
            "capacitación",
        ),
        (
            "training",
            "   ",
            "capacitación",
        ),
        (
            "deadline",
            "",
            "plazo",
        ),
        (
            "feedback",
            "",
            "feedback al trabajador",
        ),
        (
            "feedback",
            "   ",
            "feedback al trabajador",
        ),
        (
            "closure_evidence",
            None,
            "evidencia de cierre",
        ),
    ],
)
def test_request_closure_requires_complete_saved_treatment(
    fake_db,
    client_factory,
    field,
    value,
    expected_missing,
):
    report = fake_db["reports"].documents[0]

    report["status"] = "en_proceso"
    report[field] = value

    client = client_factory(
        role="supervisor"
    )

    response = client.patch(
        f"/v1/reports/{REPORT_ID}/status",
        headers={
            "Authorization": "Bearer fake_token"
        },
        json={
            "status": "pending_closure",
        },
    )

    assert response.status_code == 409

    assert response.json()["detail"].startswith(
        "Debe completar y guardar antes "
        "de solicitar cierre:"
    )

    assert expected_missing in (
        response.json()["detail"]
    )

    assert report["status"] == "en_proceso"
