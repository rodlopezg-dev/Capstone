export interface IncidentAnalysisPayload {
  causes: string[];
  probable_consequence: string;
  analysis: string;
  control_measures: string[];
  deadline: string;
  feedback: string;
}

export const buildIncidentAnalysisPayload = (
  causes: string[],
  probableConsequence: string,
  analysis: string,
  controlMeasures: string[],
  deadline: string,
  feedback: string
): IncidentAnalysisPayload => ({
  causes: [...causes],
  probable_consequence: probableConsequence,
  analysis,
  control_measures: [...controlMeasures],
  deadline,
  feedback,
});
