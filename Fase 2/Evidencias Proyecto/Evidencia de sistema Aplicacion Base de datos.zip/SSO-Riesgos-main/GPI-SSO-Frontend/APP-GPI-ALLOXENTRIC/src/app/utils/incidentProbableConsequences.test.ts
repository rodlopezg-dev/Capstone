import { describe, expect, it } from 'vitest';

import {
  PROBABLE_CONSEQUENCE_OPTIONS,
  isProbableConsequence,
} from './incidentProbableConsequences';

describe('probable consequences - SCRUM-73', () => {
  it('contains the 22 official options in the received order', () => {
    expect(PROBABLE_CONSEQUENCE_OPTIONS).toEqual([
      'Atrapamiento',
      'Atropellos',
      'Caída a distinto nivel',
      'Caída al mismo nivel',
      'Caída de objetos',
      'Choque contra objetos',
      'Contacto con energía eléctrica',
      'Contacto con sustancias químicas',
      'Contacto con temperaturas extremas',
      'Cortes',
      'Explosión',
      'Exposición a radiación',
      'Exposición a ruido',
      'Golpes por objetos',
      'Incendio',
      'Inhalación de gases o vapores',
      'Proyección de partículas',
      'Quemaduras',
      'Sobreesfuerzos por manipulación de cargas',
      'Sobreesfuerzos por posturas forzadas',
      'Volcamiento',
      'Ahogamiento',
    ]);
  });

  it('recognizes official values', () => {
    expect(
      isProbableConsequence('Caída a distinto nivel')
    ).toBe(true);

    expect(
      isProbableConsequence('Exposición a ruido')
    ).toBe(true);
  });

  it('rejects values from the legacy catalog', () => {
    expect(
      isProbableConsequence('Golpe o contusion')
    ).toBe(false);

    expect(
      isProbableConsequence('Otro')
    ).toBe(false);
  });
});
