export const PROBABLE_CONSEQUENCE_OPTIONS = [
  'Atrapamiento',
  'Atropellos',
  'Caída a distinto nivel',
  'Caída al mismo nivel',
  'Caída de objetos',
  'Choque contra objetos',
  'Contacto con energía eléctrica',
  'Contacto con sustancias químicas',
  'Contacto con temperaturas extremas',
  'Cortes',
  'Explosión',
  'Exposición a radiación',
  'Exposición a ruido',
  'Golpes por objetos',
  'Incendio',
  'Inhalación de gases o vapores',
  'Proyección de partículas',
  'Quemaduras',
  'Sobreesfuerzos por manipulación de cargas',
  'Sobreesfuerzos por posturas forzadas',
  'Volcamiento',
  'Ahogamiento',
] as const;

export type ProbableConsequence =
  typeof PROBABLE_CONSEQUENCE_OPTIONS[number];

export const isProbableConsequence = (
  value: string
): value is ProbableConsequence =>
  (PROBABLE_CONSEQUENCE_OPTIONS as readonly string[]).includes(value);
