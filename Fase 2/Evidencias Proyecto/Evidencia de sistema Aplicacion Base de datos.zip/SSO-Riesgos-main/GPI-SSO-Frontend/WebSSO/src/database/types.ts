/**
 * TIPOS DE DATOS PARA BASE DE DATOS
 * Sistema SSO - Sincronización App Móvil <-> Plataforma Web
 *
 * Estos tipos definen la estructura de datos que se sincroniza entre
 * la aplicación móvil (reportes de empleados) y la plataforma web
 * (gestión de supervisores/gerentes).
 */

import { Language } from '../app/i18n/translations';

export type MultilingualText = Record<Language, string>;

// ============================================
// TIPOS DE REPORTES (desde App Móvil)
// ============================================

export type TipoHallazgo = 'acto_inseguro' | 'condicion_insegura';

export type EstadoReporte = 'enviado' | 'en_revision' | 'accion_asignada' | 'cerrado' | 'vencido';

export type Turno = 'manana' | 'tarde' | 'noche';

export interface Reporte {
  id: string;
  fecha: Date;

  // Ubicación
  area: string;
  linea: string;
  proceso: string;

  // Clasificación
  tipo: TipoHallazgo;
  es_iap: boolean; // Incidente de Alto Potencial

  // Contenido
  descripcion: string;
  evidencia_foto_url: string;
  evidencia_video_url?: string;

  // Reportador (desde app móvil)
  reportador_nombre: string;
  reportador_id: string;
  reportador_turno: Turno;
  reportador_area_asignada: string;

  // Gestión (desde plataforma web)
  estado: EstadoReporte;
  responsable_asignado?: string;
  feedback_supervisor?: string;
  fecha_revision?: Date;
  fecha_asignacion?: Date;
  fecha_cierre?: Date;

  // SLA
  tiempo_sin_remediacion_horas?: number;
  sla_vencido: boolean;

  // Metadata
  created_at: Date;
  updated_at: Date;
}

// ============================================
// TIPOS DE ZONAS (Gemelo Digital)
// ============================================

export interface Coordenada {
  x: number;
  y: number;
}

export interface Zona {
  id: string;
  nombre: MultilingualText;
  proceso_asociado: MultilingualText;

  // Geometría del polígono
  coordenadas: Coordenada[];

  // Riesgo calculado
  score_riesgo: number; // 0-100
  nivel_riesgo: 'bajo' | 'medio' | 'alto'; // verde/amarillo/rojo

  // Metadata
  color_identificacion: string;
  plano_base_url: string;

  created_at: Date;
  updated_at: Date;
}

// ============================================
// TIPOS DE ALERTAS
// ============================================

export type TipoAlerta = 'iap' | 'sla' | 'zona' | 'auto';

export interface Alerta {
  id: string;
  tipo: TipoAlerta;

  // Contenido
  titulo: MultilingualText;
  descripcion: MultilingualText;
  area_afectada: string;

  // Estado
  activa: boolean;
  resuelta: boolean;
  fecha_resolucion?: Date;

  // Relaciones
  reporte_id?: string; // Si está relacionada con un reporte específico
  zona_id?: string; // Si está relacionada con una zona

  // Metadata
  created_at: Date;
  updated_at: Date;
}

// ============================================
// TIPOS DE USUARIOS
// ============================================

export type RolUsuario = 'empleado' | 'supervisor' | 'jefe_area' | 'gerente_sso' | 'analista';

export interface Usuario {
  id: string;
  nombre_completo: string;
  email: string;
  rol: RolUsuario;

  // Para empleados móviles
  turno?: Turno;
  area_asignada?: string;

  // Estadísticas (para app móvil)
  total_reportes?: number;
  reportes_mes_actual?: number;
  efectividad_porcentaje?: number;

  created_at: Date;
  updated_at: Date;
}

// ============================================
// TIPOS DE NOTIFICACIONES
// ============================================

export type TipoNotificacion = 'alerta' | 'actualizacion' | 'comentario' | 'resuelto';

export interface Notificacion {
  id: string;
  tipo: TipoNotificacion;

  titulo: string;
  mensaje: string;

  // Destinatario
  usuario_id: string;
  leida: boolean;

  // Relaciones
  reporte_id?: string;
  alerta_id?: string;

  created_at: Date;
}

// ============================================
// TIPOS PARA ESTADÍSTICAS Y KPIs
// ============================================

export interface EstadisticasGlobales {
  total_reportes: number;
  iap_activos: number;
  variacion_porcentual: number;
  reportes_cerrados_mes: number;
  promedio_tiempo_resolucion_horas: number;
}

export interface EstadisticasArea {
  area: string;
  score_riesgo: number;
  total_incidentes: number;
  incidentes_abiertos: number;
  tendencia: 'subiendo' | 'bajando' | 'estable';
}
