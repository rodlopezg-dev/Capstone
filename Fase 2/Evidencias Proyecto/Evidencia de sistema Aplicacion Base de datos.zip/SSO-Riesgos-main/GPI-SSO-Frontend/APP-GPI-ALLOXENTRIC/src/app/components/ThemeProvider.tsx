import { ReactNode } from 'react';

export interface ThemeColors {
  bg: string;
  bgSecondary: string;
  card: string;
  cardHover: string;
  border: string;
  text: string;
  textSecondary: string;
  textTertiary: string;
  input: string;
  inputBorder: string;
}

interface ThemeClassProps {
  theme: ThemeColors;
  children?: ReactNode;
  className?: string;
  variant?: 'card' | 'input' | 'border' | 'cardHover';
  style?: React.CSSProperties;
  [key: string]: any;
}

export const ThemedDiv = ({ theme, children, className = '', variant, style, ...props }: ThemeClassProps) => {
  const getStyles = (): React.CSSProperties => {
    const baseStyle: React.CSSProperties = {
      color: theme.text,
      ...style
    };

    if (variant === 'card') {
      return {
        ...baseStyle,
        backgroundColor: theme.card,
        borderColor: theme.border,
      };
    }

    if (variant === 'cardHover') {
      return {
        ...baseStyle,
        backgroundColor: theme.card,
        borderColor: theme.border,
      };
    }

    if (variant === 'input') {
      return {
        ...baseStyle,
        backgroundColor: theme.input,
        borderColor: theme.inputBorder,
      };
    }

    if (variant === 'border') {
      return {
        ...baseStyle,
        borderColor: theme.border,
      };
    }

    return baseStyle;
  };

  return (
    <div className={className} style={getStyles()} {...props}>
      {children}
    </div>
  );
};

export const ThemedButton = ({ theme, children, className = '', style, ...props }: ThemeClassProps) => {
  return (
    <button
      className={className}
      style={{
        backgroundColor: theme.card,
        borderColor: theme.border,
        color: theme.text,
        ...style
      }}
      {...props}
    >
      {children}
    </button>
  );
};
