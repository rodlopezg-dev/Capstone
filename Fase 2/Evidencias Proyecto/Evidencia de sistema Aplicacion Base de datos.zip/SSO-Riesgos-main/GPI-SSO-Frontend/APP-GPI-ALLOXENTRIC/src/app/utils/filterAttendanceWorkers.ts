
export type AttendanceWorker = {
    id: string;
    name: string;
    email?: string | null;
};

/**
 * Normaliza los valores para realizar búsquedas
 * sin distinguir mayúsculas, tildes ni espacios dobles.
 */
export const normalizeAttendanceSearch = (
    value: string
): string =>
    value
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .toLowerCase()
        .replace(/\s+/g, ' ')
        .trim();

/**
 * Verifica si la identidad se puede distinguir
 * visualmente dentro del listado disponible.
 *
 * Si existen nombres completos idénticos,
 * se exige un correo único para diferenciarlos.
 */
export function isWorkerDistinguishable(
    worker: AttendanceWorker,
    workers: readonly AttendanceWorker[]
): boolean {
    if (!worker.id.trim() || !worker.name.trim()) {
        return false;
    }

    const name = normalizeAttendanceSearch(worker.name);
    const email = normalizeAttendanceSearch(
        worker.email ?? ''
    );

    const repeatedName = workers.some(
        other =>
            other.id !== worker.id &&
            normalizeAttendanceSearch(other.name) === name
    );

    const repeatedEmail = Boolean(email) && workers.some(
        other =>
            other.id !== worker.id &&
            normalizeAttendanceSearch(other.email ?? '') === email
    );

    if (repeatedEmail) return false;

    if (repeatedName && !email) return false;

    return true;
}

/**
 * Función compartida de búsqueda.
 *
 * - Busca en nombre completo y correo.
 * - Excluye por ID, nunca por nombre.
 * - Mantiene personas homónimas disponibles.
 * - Devuelve hasta 5 resultados.
 */
export function filterAttendanceWorkers<
    T extends AttendanceWorker
>(
    workers: readonly T[],
    search: string,
    excludedIds: readonly string[] = [],
    limit = 5
): T[] {
    const query = normalizeAttendanceSearch(search);

    if (!query || limit <= 0) {
        return [];
    }

    const excluded = new Set(excludedIds);

    return workers
        .filter(worker => {
            if (excluded.has(worker.id)) {
                return false;
            }

            const name = normalizeAttendanceSearch(
                worker.name
            );

            const email = normalizeAttendanceSearch(
                worker.email ?? ''
            );

            return (
                name.includes(query) ||
                email.includes(query)
            );
        })
        .slice(0, limit);
}
