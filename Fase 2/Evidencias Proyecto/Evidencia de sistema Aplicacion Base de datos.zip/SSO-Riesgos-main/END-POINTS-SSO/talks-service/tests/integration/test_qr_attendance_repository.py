import asyncio
from datetime import datetime

import pytest

from app.repositories.rep_talks import TalksRepository


@pytest.mark.asyncio
async def test_first_scan_registers_attendance(db, seed):
    repo = TalksRepository(db)

    registered = await repo.register_qr_attendance(
        "empresa_a", seed, "worker_a", "Ana Prueba"
    )

    record = await db["attendance"].find_one({"source": "qr"})

    assert registered is True
    assert record["_id"].startswith("qr_")
    assert record["client_id"] == "empresa_a"
    assert record["talk_id"] == "talk_a"
    assert record["attended_user_ids"] == ["worker_a"]
    assert record["attendees"] == ["Ana Prueba"]

    entry = record["attendance_entries"][0]
    assert entry["user_id"] == "worker_a"
    assert entry["method"] == "qr"
    assert datetime.fromisoformat(entry["registered_at"]).tzinfo is not None


@pytest.mark.asyncio
async def test_duplicate_scan_preserves_first_registration(db, seed):
    repo = TalksRepository(db)

    await repo.register_qr_attendance(
        "empresa_a", seed, "worker_a", "Ana Prueba"
    )
    before = await db["attendance"].find_one({"source": "qr"})

    registered = await repo.register_qr_attendance(
        "empresa_a", seed, "worker_a", "Ana Prueba"
    )
    after = await db["attendance"].find_one({"source": "qr"})

    assert registered is False
    assert after == before


@pytest.mark.asyncio
async def test_manual_attendance_is_preserved(db, seed):
    repo = TalksRepository(db)

    manual_id = await repo.create_attendance("empresa_a", {
        "talk_id": "talk_a",
        "topic": "Registro manual",
        "date": "2026-09-22",
        "attendees": ["Persona manual"],
        "feedback": "Conservar este comentario",
        "file_name": "asistencia.pdf",
    })
    before = await db["attendance"].find_one({
        "attendance_id": manual_id
    })

    await repo.register_qr_attendance(
        "empresa_a", seed, "worker_a", "Ana Prueba"
    )

    after = await db["attendance"].find_one({
        "attendance_id": manual_id
    })

    assert after == before
    assert await db["attendance"].count_documents({}) == 2
    assert await db["attendance"].count_documents({"source": "qr"}) == 1


@pytest.mark.asyncio
@pytest.mark.parametrize("same_user", [True, False])
async def test_concurrent_scans_do_not_duplicate_records(
    db, seed, same_user
):
    repo = TalksRepository(db)
    user_ids = (
        ["worker_a"] * 10
        if same_user
        else [f"worker_{index}" for index in range(10)]
    )

    results = await asyncio.gather(*[
        repo.register_qr_attendance(
            "empresa_a", seed, user_id, user_id
        )
        for user_id in user_ids
    ])

    records = await db["attendance"].find({"source": "qr"}).to_list(20)
    expected = len(set(user_ids))

    assert len(records) == 1
    assert sum(results) == expected
    assert len(records[0]["attendance_entries"]) == expected
    assert set(records[0]["attended_user_ids"]) == set(user_ids)

@pytest.mark.asyncio
async def test_ensure_indexes_creates_qr_session_ttl_index(db):
    repo = TalksRepository(db)

    await repo.ensure_indexes()

    indexes = await db["talk_qr_sessions"].index_information()
    ttl_index = indexes["qr_sessions_expires_at_ttl"]

    assert ttl_index["key"] == [("expires_at", 1)]
    assert ttl_index["expireAfterSeconds"] == 0