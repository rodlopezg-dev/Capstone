import unittest

from pymongo.errors import DuplicateKeyError

from app.repositories.rep_reports import ReportRepository
from app.schemas.scm_reports import ReportCreate
from app.services.srv_reports import ReportService


def make_report():
    return ReportCreate(
        area_id="Linea 1",
        type="Acto Inseguro",
        is_iap=False,
        description="Prueba idempotencia",
        causes=[],
        shift="Dia",
    )


class FakeReportsCollection:
    def __init__(self, repository):
        self.repository = repository

    async def find_one(
        self,
        query,
        sort=None,
        projection=None,
    ):
        # Consulta de secuencia usada por create_report.
        if "idempotency_key" not in query:
            return None

        return self.repository.records.get(
            (
                query["client_id"],
                query["reported_by"],
                query["idempotency_key"],
            )
        )


class FakeDB:
    def __init__(self, repository):
        self.reports = FakeReportsCollection(repository)

    def __getitem__(self, name):
        if name == "reports":
            return self.reports

        raise KeyError(name)


class FakeReportRepository:
    def __init__(self):
        self.records = {}
        self.saved = []
        self.activities = []
        self.notifications = []
        self.ensure_indexes_calls = 0
        self.raise_duplicate = False
        self.db = FakeDB(self)

    async def ensure_indexes(self):
        self.ensure_indexes_calls += 1

    async def get_by_idempotency_key(
        self,
        client_id,
        user_id,
        idempotency_key,
    ):
        return self.records.get(
            (
                client_id,
                user_id,
                idempotency_key,
            )
        )

    async def save(
        self,
        client_id,
        report_id,
        report_data,
    ):
        if self.raise_duplicate:
            key = (
                client_id,
                report_data["reported_by"],
                report_data["idempotency_key"],
            )

            self.records[key] = {
                **report_data,
                "report_id": "77",
            }

            raise DuplicateKeyError(
                "duplicate idempotency key"
            )

        self.saved.append(report_data.copy())

        if report_data.get("idempotency_key"):
            self.records[
                (
                    client_id,
                    report_data["reported_by"],
                    report_data["idempotency_key"],
                )
            ] = report_data.copy()

        return report_id

    async def add_activity_log(
        self,
        client_id,
        report_id,
        entry,
    ):
        self.activities.append(
            {
                "client_id": client_id,
                "report_id": report_id,
                **entry,
            }
        )

    async def create_notification(
        self,
        client_id,
        user_id,
        data,
    ):
        self.notifications.append(
            {
                "client_id": client_id,
                "user_id": user_id,
                **data,
            }
        )


class FakeIndexCollection:
    def __init__(self):
        self.calls = []

    async def create_index(
        self,
        keys,
        **kwargs,
    ):
        self.calls.append((keys, kwargs))
        return kwargs.get("name")


class FakeIndexDB:
    def __init__(self):
        self.reports = FakeIndexCollection()

    def __getitem__(self, name):
        if name == "reports":
            return self.reports

        return FakeIndexCollection()


class ReportIdempotencyTests(
    unittest.IsolatedAsyncioTestCase
):
    async def test_existing_key_returns_same_report_without_side_effects(
        self,
    ):
        repository = FakeReportRepository()

        repository.records[
            ("tenant_a", "worker_a", "request-123")
        ] = {
            "report_id": "42",
            "client_id": "tenant_a",
            "reported_by": "worker_a",
            "idempotency_key": "request-123",
        }

        service = ReportService(repository)

        report_id = await service.create_report(
            client_id="tenant_a",
            report_in=make_report(),
            user_id="worker_a",
            file_bytes=b"",
            idempotency_key="request-123",
        )

        self.assertEqual(report_id, "42")
        self.assertEqual(repository.saved, [])
        self.assertEqual(repository.activities, [])
        self.assertEqual(repository.notifications, [])

    async def test_new_report_persists_idempotency_key(
        self,
    ):
        repository = FakeReportRepository()
        service = ReportService(repository)

        report_id = await service.create_report(
            client_id="tenant_a",
            report_in=make_report(),
            user_id="worker_a",
            file_bytes=b"",
            idempotency_key="request-new",
        )

        self.assertEqual(report_id, "1")
        self.assertEqual(len(repository.saved), 1)

        saved = repository.saved[0]

        self.assertEqual(
            saved["idempotency_key"],
            "request-new",
        )
        self.assertEqual(
            saved["client_id"],
            "tenant_a",
        )
        self.assertEqual(
            saved["reported_by"],
            "worker_a",
        )

    async def test_duplicate_key_race_returns_existing_report(
        self,
    ):
        repository = FakeReportRepository()
        repository.raise_duplicate = True

        service = ReportService(repository)

        report_id = await service.create_report(
            client_id="tenant_a",
            report_in=make_report(),
            user_id="worker_a",
            file_bytes=b"",
            idempotency_key="request-race",
        )

        self.assertEqual(report_id, "77")

        # El request que perdió la carrera no debe generar
        # actividad ni notificaciones duplicadas.
        self.assertEqual(repository.activities, [])
        self.assertEqual(repository.notifications, [])

    async def test_same_key_is_scoped_by_user(
        self,
    ):
        repository = FakeReportRepository()

        repository.records[
            ("tenant_a", "worker_a", "shared-key")
        ] = {
            "report_id": "55",
            "client_id": "tenant_a",
            "reported_by": "worker_a",
            "idempotency_key": "shared-key",
        }

        service = ReportService(repository)

        report_id = await service.create_report(
            client_id="tenant_a",
            report_in=make_report(),
            user_id="worker_b",
            file_bytes=b"",
            idempotency_key="shared-key",
        )

        self.assertEqual(report_id, "1")
        self.assertEqual(len(repository.saved), 1)
        self.assertEqual(
            repository.saved[0]["reported_by"],
            "worker_b",
        )


class ReportIndexTests(
    unittest.IsolatedAsyncioTestCase
):
    async def test_idempotency_index_is_partial_and_unique(
        self,
    ):
        db = FakeIndexDB()
        repository = ReportRepository(db)

        ReportRepository._indexes_ensured = False

        await repository.ensure_indexes()

        self.assertEqual(len(db.reports.calls), 1)

        keys, options = db.reports.calls[0]

        self.assertEqual(
            keys,
            [
                ("client_id", 1),
                ("reported_by", 1),
                ("idempotency_key", 1),
            ],
        )
        self.assertTrue(options["unique"])
        self.assertEqual(
            options["partialFilterExpression"],
            {
                "idempotency_key": {
                    "$type": "string",
                },
            },
        )
        self.assertEqual(
            options["name"],
            "uniq_report_idempotency",
        )


if __name__ == "__main__":
    unittest.main()
