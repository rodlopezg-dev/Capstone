# EP-04: fase 1 posterior a TT-17 y TT-18

Base local: `main` en `95a2d92`. Se conservaron los cambios pendientes descritos en `ep04-auditoria.md` y `ep04-tt18-permisos.md`. No se cambió la política RBAC, el emisor JWT, el frontend, bases de datos, migraciones ni `.env`. Se consultaron los criterios de [SCRUM-357](https://av-capstone-grupo6.atlassian.net/browse/SCRUM-357) y [SCRUM-358](https://av-capstone-grupo6.atlassian.net/browse/SCRUM-358) en Jira; ambos siguen en «Por hacer». La implementación propuesta aquí no cambia su estado.

## ST-252: proyección de `source` confirmada y corregida

En `END-POINTS-SSO/talks-service/app/repositories/rep_talks.py`, la estadística mensual leía `source` en la proyección de `talks` y omitía ese campo en la proyección de `attendance`. Por ello, un documento QR con `attended_user_ids=[]` y un nombre único podía pasar por la rama de compatibilidad manual y aumentar `attendance_count`. La nueva prueba `tests/unit/test_attendance_projection.py` aplica una proyección de inclusión como Mongo: falló antes del cambio (`1` frente a `0` esperado) y pasa después. Se movió únicamente `source` desde la proyección de `talks` a la de `attendance`; la proyección de estadísticas por área ya incluía `source`.

No se modificó la fórmula de cobertura, ni `mandatory`, ni `expected_user_ids`. El informe TT-18 queda como registro de lo detectado antes de esta fase; su nota incidental sobre la proyección está resuelta por este cambio.

## Pruebas ASGI permanentes, sin Mongo

`tests/unit/test_attendance_access_contract.py` ejecuta las siete rutas auditadas sobre `FastAPI`/`ASGITransport`, con `get_db` sustituido por colecciones inertes y métodos del repositorio simulados. Cubre las nueve variantes de rol (`worker`, `usuario`, `supervisor`, `jefe de area`, `jefe_de_area`, `sso_manager`, `admin`, `analyst`, desconocido), refresh, `sub`/`role`/`exp` ausentes, bearer ausente/inválido/vencido, `client_id` vacío/ausente/con espacios, y un `client_id` de query distinto al del JWT. También comprueba el comportamiento actual de `GET` y `POST /v1/attendance`. Son **pruebas de caracterización**: registran los accesos existentes, incluso los inseguros, para que un cambio posterior de autorización requiera una decisión y una actualización explícita de expectativas. No definen la política futura.

La prueba confirma que las siete rutas reciben siempre el tenant del JWT, incluso si la URL incluye `client_id=empresa_b`, y que actualmente devuelven 200 con `worker`, refresh y claims incompletos si el tenant es truthy. `client_id=""` o ausente produce 403 en esas siete rutas. Token inválido, vencido o sin bearer produce 401. `client_id="   "` sigue aceptado. La dependencia de auth no hace una consulta a `users`.

## Superficies adyacentes

| Ruta | Estado comprobado | Efecto para el diseño posterior |
| --- | --- | --- |
| `GET /v1/attendance` (`rt_talks.py:1060-1069`) | No comprueba rol ni `client_id` no vacío antes del repositorio. `rep_talks.py:630-638` filtra por el valor de tenant recibido y devuelve documentos completos. Prueba ASGI: `worker` obtiene 200 con lista del tenant. | El móvil la llama para todos los roles (`SafetyTalksMobile.tsx:357-361`, `:410-413`) y utiliza `attended_user_ids` para mostrar “Ingresado” al trabajador (`:278-294`). Restringir esta lista sin un endpoint de asistencia propia rompería ese indicador. La lista también permite a gestores ver hojas adjuntas. |
| `POST /v1/attendance` (`rt_talks.py:1071-1151`) | No comprueba rol ni tenant no vacío. Si hay archivo, exige charla del cliente y controla duplicado; sin archivo, acepta `talk_id` arbitrario, incluidos IDs de otra empresa, y escribe un registro manual bajo el tenant del token. Prueba ASGI con repositorio simulado: `worker` y token sin `client_id` llegan a `create_attendance(client_id=None, ...)` con `talk_id` ajeno. No se escribió en Mongo. | Una futura política debe decidir quién registra manualmente o adjunta hojas. Independientemente del RBAC, hace falta validar identidad/tenant antes de persistir y definir si el registro legacy sin charla sigue permitido; si llega un `talk_id`, su propiedad debe verificarse. |

El segundo caso es una vía de escritura sin `client_id` válido, más grave que el simple acceso a agregados. No se corrigió en esta fase porque el usuario pidió preparar SCRUM-357/358 y reservar la nueva política; conviene priorizar la validación de identidad/tenant como cambio independiente de la matriz RBAC.

## Contrato real y orden de implementación propuesto

1. **JWT entre servicios.** `auth-service/app/services/auth_service.py:58-83` emite access token con `sub`, `client_id`, `role`, `areas`, `area`, `exp`, pero sin claim `type`; refresh usa los mismos claims más `type=refresh` y dura siete días. `/v1/auth/refresh` (`auth-service/app/routers/auth.py:24-45`) acepta solo `type=refresh`, devuelve un access nuevo todavía sin `type` y reutiliza el refresh. `talks-service/app/dep_talks.py:47-53` verifica firma/exp presente, pero no exige los claims ni rechaza refresh. Para endurecer sin romper access tokens actuales: exigir `exp`, `sub` no blanco, `role` no blanco y `client_id` no blanco, rechazar `type=refresh`, y aceptar temporalmente `type` ausente como access legado. Exigir `type=access` requeriría primero un cambio coordinado del emisor y transición de tokens. Mantener `client_id` exclusivamente del JWT.
2. **Semántica HTTP.** El frontend `authenticatedFetch` (`client.ts:287-373`) renueva en 401 y no renueva en 403; sus pruebas cubren ambos casos. Un token inválido, de refresh usado como access o con claims esenciales incompletos debe dar 401. Un access válido sin permiso aprobado debe dar 403. Una respuesta 401 provocará intento de refresh y un reintento; si el nuevo access vuelve a fallar, el móvil invalida sesión. Conviene probar ese recorrido junto al cambio backend para evitar bucles o cierres de sesión incorrectos.
3. **Autorización de datos.** Definir por separado lectura agregada (estadísticas), lectura nominativa (comparación, ausencias, PDF/XLSX, lista de asistencia) y escritura (manual/hoja). La matriz `ep04-tt18-permisos.md` describe el estado actual, no una lista aprobada. Aclarar si `sso_manager`, `supervisor`, `jefe de area` y `jefe_de_area` son equivalentes, y si el permiso depende del área asignada. Normalizar roles en un solo lugar del backend y alinear la UI; el frontend puede ocultar acciones, pero el control debe ejecutarse antes de consultas y exportación.
4. **Asistencia propia del trabajador.** Si se restringe `GET /v1/attendance`, proveer una consulta propia acotada al `sub` del JWT para el estado de QR y mantener una consulta de gestores para hojas. No confiar en que el móvil filtre `attended_user_ids` de una lista completa. Decidir también si ausencias se exponen solo para charlas `mandatory`: hoy el botón móvil exige `mandatory`, la ruta backend no.
5. **Pruebas de aceptación.** Una vez aprobada la matriz, cambiar las pruebas de caracterización de 200 a los 401/403 esperados por rol y tipo de token. Mantener comprobaciones de tenant A/B y de que no hay llamadas al repositorio antes de rechazar un token. Probar `GET`/`POST /v1/attendance`, refresh y flujo móvil, además de las siete rutas. La suite Mongo sigue pendiente hasta que se autorice usar una base aislada; ninguna prueba de esta fase la tocó.

## Correspondencia con SCRUM-357 y SCRUM-358

| Ticket | Alcance confirmado en Jira | Preparado en esta fase | Pendiente |
| --- | --- | --- | --- |
| [SCRUM-357](https://av-capstone-grupo6.atlassian.net/browse/SCRUM-357) | Rechazar refresh como bearer de acceso y exigir `exp`, `sub`, `role` y `client_id` válidos; coordinar `type=access` con auth-service; definir usuario activo/revocación; distinguir 401 de 403. | Pruebas ASGI que reproducen la aceptación actual de refresh y claims incompletos, y revisión del emisor, consumidor y renovación móvil. | Endurecer la dependencia JWT y cambiar las expectativas de las pruebas; definir transición de `type` y política de usuario activo/revocación. |
| [SCRUM-358](https://av-capstone-grupo6.atlassian.net/browse/SCRUM-358) | Evitar acceso global de trabajadores a datos nominativos; revisar las siete rutas y `GET`/`POST /v1/attendance`; acordar roles, alias y ámbitos antes de implantar RBAC; conservar el flujo móvil. | Matriz TT-18, pruebas ASGI de roles y tenant, revisión de superficies adyacentes y dependencia del indicador móvil. | Aprobar matriz y ámbito, implantar autorización backend, dar al trabajador una consulta propia, y convertir las pruebas de caracterización en pruebas de denegación. |

Los criterios de SCRUM-357 permiten preparar validación de identidad sin resolver la matriz RBAC. SCRUM-358 depende de una decisión explícita sobre roles y áreas; no se aplicó su propuesta de permisos como si ya estuviera aprobada. Las pruebas nuevas registran el comportamiento actual y deben cambiar al implementar cada ticket.

## Decisiones pendientes para SCRUM-357/358

- Aprobar roles permitidos para estadísticas, exportaciones, comparación, ausencias, lista y registro de asistencia; decidir ámbito por empresa/área/charla y forma de tratar `analyst`/`usuario`.
- Decidir si `sso_manager`, `jefe_de_area` y `jefe de area` son alias oficiales y si ausencias se restringe a `mandatory`.
- Elegir cómo conservar el indicador QR del trabajador sin exponer la lista completa de asistencia.
- Decidir estrategia de transición hacia `type=access` y validación de usuario activo/revocación. No exigir `iss`/`aud` hasta que emisor y consumidores acuerden esos claims.
- Autorizar, en una fase posterior, una base de pruebas aislada para verificación Mongo real. Las pruebas de esta fase fueron enteramente simuladas.

## Validación y archivos de esta fase

- La prueba de proyección falló antes de la corrección y pasó después.
- `tests/unit`: **151 passed** (8 previas de TT-17, 1 de proyección y 142 casos ASGI nuevos, incluidos 2 de superficies adyacentes), sin fixture `db` ni conexión Mongo. Se inyectó `TEST_MONGO_URI` ficticia solo para superar la guarda de importación de `tests/conftest.py`.
- Pruebas focalizadas del cliente móvil (`client.test.ts`, `auth.test.ts`, `talkAttendance.test.ts`): **20 passed**.
- `git diff --check`: correcto.
- Archivos agregados: `tests/unit/test_attendance_projection.py`, `tests/unit/test_attendance_access_contract.py` y este documento. Archivo de código ajustado: `app/repositories/rep_talks.py` (proyección `source`). Los demás cambios pendientes de TT-17/TT-18 permanecen intactos.

No se hizo commit, push ni merge. No se cambió el estado de ningún ticket.
