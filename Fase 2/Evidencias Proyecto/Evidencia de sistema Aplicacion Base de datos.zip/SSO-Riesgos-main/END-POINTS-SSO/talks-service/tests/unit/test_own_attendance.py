"""The worker's attendance view must never return another person's data."""

import pytest

from app.repositories.rep_talks import TalksRepository


class Cursor:
    def __init__(self, records):
        self.records = iter(records)

    def sort(self, *_args):
        return self

    def __aiter__(self):
        return self

    async def __anext__(self):
        try:
            return next(self.records)
        except StopIteration:
            raise StopAsyncIteration


class AttendanceCollection:
    def __init__(self, records):
        self.records = records
        self.last_query = None
        self.last_projection = None

    def find(self, query, projection):
        self.last_query = query
        self.last_projection = projection
        matching = []
        for record in self.records:
            if all(
                (value in record.get(key, []) if key == "attended_user_ids"
                 else record.get(key) == value)
                for key, value in query.items()
            ):
                matching.append({key: value for key, value in record.items()
                                 if projection.get(key) == 1})
        return Cursor(matching)


@pytest.mark.asyncio
async def test_own_attendance_filters_in_mongo_and_removes_other_names():
    collection = AttendanceCollection([
        {"client_id": "empresa_a", "source": "qr", "talk_id": "talk_a",
         "attendance_id": "att_a", "attendees": ["Ana", "Luis"],
         "attended_user_ids": ["user_a", "user_b"]},
        {"client_id": "empresa_b", "source": "qr", "talk_id": "talk_a",
         "attendance_id": "att_b", "attendees": ["Ana"],
         "attended_user_ids": ["user_a"]},
        {"client_id": "empresa_a", "source": "manual", "talk_id": "talk_a",
         "attendance_id": "att_manual", "attendees": ["Ana"]},
    ])
    repo = TalksRepository({
        name: collection for name in
        ("talks", "attendance", "attendance_participants", "talk_qr_sessions", "attendance_scans", "users")
    })
    result = await repo.list_own_attendance("empresa_a", "user_a")
    assert result == [{"source": "qr", "talk_id": "talk_a",
                       "attendance_id": "att_a", "attended_user_ids": ["user_a"]}]
    assert collection.last_query == {
        "client_id": "empresa_a", "source": "qr", "attended_user_ids": "user_a"
    }
    assert "attendees" not in collection.last_projection
    assert "attended_user_ids" not in collection.last_projection
