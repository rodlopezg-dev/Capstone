export type AbsentWorker = {
  user_id: string;
  name?: string;
  last_name?: string;
  email?: string;
  role?: string;
  status?: string;
  assigned_areas?: string[];
};

export type AbsenceStatus =
  | 'absences_found'
  | 'no_absences'
  | 'no_expected_workers'
  | 'insufficient_data';

export type AbsentWorkersResponse = {
  talk_id: string;
  title: string;
  mandatory: boolean;
  expected_user_ids: string[];
  resolved_expected_user_ids: string[];
  missing_expected_user_ids: string[];
  attended_user_ids: string[];
  absent_user_ids: string[];
  absent_workers: AbsentWorker[];
  absence_status: AbsenceStatus;
};

export function buildAbsentWorkersUrl(
  baseUrl: string,
  talkId: string,
): string {
  const normalizedBaseUrl = baseUrl.replace(/\/+$/, '');

  return (
    normalizedBaseUrl +
    '/v1/talks/' +
    encodeURIComponent(talkId) +
    '/absent-workers'
  );
}

export function getAbsentWorkerDisplayName(
  worker: AbsentWorker,
): string {
  const fullName = [
    worker.name,
    worker.last_name,
  ]
    .map(value => (value || '').trim())
    .filter(Boolean)
    .join(' ');

  return (
    fullName ||
    worker.email?.trim() ||
    worker.user_id
  );
}


export function getAbsenceStatusMessage(
  result: AbsentWorkersResponse,
): string | null {
  switch (result.absence_status) {
    case 'no_absences':
      return 'No hay inasistencias registradas para esta charla.';

    case 'no_expected_workers':
      return 'La charla no tiene trabajadores asociados.';

    case 'insufficient_data':
      return (
        'No es posible generar el listado porque ' +
        'no hay información suficiente.'
      );

    case 'absences_found':
    default:
      return null;
  }
}
