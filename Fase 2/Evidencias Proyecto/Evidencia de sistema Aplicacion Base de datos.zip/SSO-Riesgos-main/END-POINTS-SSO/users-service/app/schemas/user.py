from pydantic import BaseModel, Field, EmailStr, ConfigDict
from typing import List, Optional

class UserBase(BaseModel):
    name: str = Field(..., description="Nombre completo del usuario")
    last_name: Optional[str] = Field(None, description="Apellido del usuario")
    email: EmailStr = Field(..., description="Correo electrónico")
    role: str = Field(..., description="worker, analyst, sso_manager, admin")
    assigned_areas: List[str] = Field(
        default_factory=list, description="IDs de las áreas asignadas"
    )
    client_id: Optional[str] = Field(None, description="ID del cliente corporativo")


class UserCreate(UserBase):
    password: str = Field(
        ..., min_length=6, description="Contraseña en texto plano (será encriptada)"
    )


class UserUpdate(BaseModel):
    name: Optional[str] = None
    last_name: Optional[str] = None
    role: Optional[str] = None
    assigned_areas: Optional[List[str]] = None
    status: Optional[str] = Field(None, description="active, inactive")
    password: Optional[str] = Field(
        None, min_length=6, description="Nueva contraseña si desea cambiarla"
    )


class UserResponse(UserBase):
    user_id: str
    status: str
    client_id: Optional[str] = Field(None, description="ID del cliente asociado")

    class Config:
        from_attributes = True


class CurrentUser(BaseModel):
    id: str
    role: str
    client_id: str

class UserProfileUpdate(BaseModel):
    model_config = ConfigDict(
        extra="forbid",
        str_strip_whitespace=True,
    )

    name: Optional[str] = Field(
        None,
        min_length=1,
        max_length=120,
    )
    last_name: Optional[str] = Field(
        None,
        max_length=120,
    )


class UserProfileResponse(BaseModel):
    user_id: str
    name: str
    last_name: Optional[str] = None
    email: EmailStr
    role: str
    assigned_areas: List[str] = Field(default_factory=list)
    client_id: str
    status: str
    profile_photo_url: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)
