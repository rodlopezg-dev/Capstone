# EP-04 / TT-18: implementación para revisión

Base: `main` en `95a2d92`; se preservaron los cambios sin commit de TT-17 y de la preparación TT-18. Política confirmada en los comentarios de aprobación de [SCRUM-357](https://av-capstone-grupo6.atlassian.net/browse/SCRUM-357), [SCRUM-358](https://av-capstone-grupo6.atlassian.net/browse/SCRUM-358), [SCRUM-359](https://av-capstone-grupo6.atlassian.net/browse/SCRUM-359) y [SCRUM-337](https://av-capstone-grupo6.atlassian.net/browse/SCRUM-337). No se cambió el estado de Jira. Las auditorías históricas `ep04-auditoria.md`, `ep04-tt18-permisos.md` y `ep04-fase1-preparacion.md` permanecen intactas y describen el estado anterior a estos cambios.

## Cambios por ticket

| Ticket | Implementación | Límite |
| --- | --- | --- |
| SCRUM-357 | `auth-service` emite `type=access` en login y refresh, exige claims esenciales y tipo válido al verificar; rechaza login de usuario con `status` distinto de `active`. `talks-service` y los consumidores JWT mantenidos (users, areas, workers, dashboard, digital-twin, incidents, alerts y reports) exigen `exp`, `sub`, `role`, `client_id`, rechazan cadenas en blanco, refresh y tipos desconocidos con 401. | Se acepta temporalmente access firmado sin `type`. El refresh no consulta de nuevo la cuenta activa: ver bloqueo abajo. |
| SCRUM-358 | Las siete rutas administrativas y `GET /v1/attendance` aplican rol backend antes de consultar. `GET /v1/attendance` para `worker`/`usuario` usa una consulta Mongo filtrada por tenant, `source=qr` e ID del sujeto; proyecta solo estado propio, sin nombres ni IDs ajenos. La descarga de hojas, edición de charlas y QR/OCR administrativo tienen el mismo límite de rol. `GET /v1/talks` conserva el flujo móvil del trabajador sin exponer `expected_user_ids`. La UI móvil ya no ofrece administración a roles sin ámbito verificable. | `supervisor` y `jefe_de_area` reciben 403 en funciones administrativas; la colección `talks` no guarda área de autorización, por lo que no es seguro concederles vistas parciales. |
| SCRUM-359 | `POST /v1/attendance` exige JWT/tenant y rol autorizado antes de repositorio. Verifica charla explícita por `client_id` antes de almacenamiento de archivo o escritura. Devuelve 404 idéntico para charla inexistente y ajena, y 422 para un `talk_id` compuesto solo por espacios. | Los registros manuales sin archivo y sin `talk_id` siguen permitidos para gestores del tenant. |
| SCRUM-355 | Toda referencia explícita de charla en asistencia manual y hoja requiere charla existente del tenant. El flujo legacy sin referencia se conserva. | La suite Mongo de integración no se ejecutó por la restricción de escritura. |
| SCRUM-337 | Pruebas ASGI de roles, JWT, tenant, lista propia y rechazos antes de persistir; prueba de emisión/refresh en auth; contrato repetible para ocho consumidores; pruebas móviles de visibilidad. Se actualizaron expectativas de pruebas de integración que suponían acceso administrativo de worker/supervisor. | Las pruebas de integración modificadas solo se recopilaron, no se ejecutaron con Mongo. |

## Matriz implementada

| Operación | `admin` / `sso_manager` | `supervisor` / `jefe_de_area` (incluye alias con espacios) | `worker` / `usuario` | `analyst` / desconocido |
| --- | --- | --- | --- | --- |
| Estadísticas área/mes, PDF/XLSX, población esperada, comparación, ausencias | Tenant completo | 403 hasta tener ámbito verificable | 403 | 403 |
| `GET /v1/attendance` y descarga de hoja | Tenant completo | 403 | Solo estado QR propio en GET; descarga 403 | 403 |
| `POST /v1/attendance` manual/hoja | Tenant, charla explícita verificada | 403 | 403 | 403 |
| QR administrativo y OCR | Tenant | 403 hasta tener ámbito verificable | 403 | 403 |
| Scan QR | Usuario conocido, activo y del tenant, sujeto a validación de sesión QR | 403 por rol sin ámbito | Flujo propio vigente | 403 |
| Lista y archivo de charla | Acceso del tenant | 403 hasta tener ámbito verificable | Lista sin `expected_user_ids`; archivo de charla vigente | 403 |

El rol se normaliza para reconocer `sso_manager` y `sso manager`; `jefe_de_area` y `jefe de area` se reconocen como el mismo grupo sin ámbito y ambos se deniegan. Las consultas globales usan exclusivamente `client_id` firmado. Para un trabajador, el filtro de sujeto se aplica en Mongo, no solo en el frontend; el resultado limita `attended_user_ids` a su propio ID para conservar el indicador «Ingresado» del móvil.

## JWT y cuenta activa

El emisor actual producía access sin `type` y refresh con `type=refresh`. Se añade `type=access` a ambos caminos de emisión. Los consumidores aceptan `type=access` y ausencia de `type` por compatibilidad temporal, pero ningún otro valor. PyJWT exige `exp` presente y válido; identidad, rol y tenant deben ser cadenas no blancas. Credencial ausente, inválida o vencida recibe 401; un access válido sin autorización recibe 403. La UI móvil ya renueva solo tras 401, por lo que la distinción se mantiene.

`auth-service` dispone de `users-service` por `client_id`/email en login: ahora impide login cuando el documento no está activo. No hay consulta existente por `sub` para revalidar un refresh, ni un mecanismo central de revocación/introspección compartido por todos los consumidores. QR/OCR sí consultan `users.status=active` en el tenant. **El requisito de revocación inmediata o de comprobar cuenta activa en todas las lecturas privilegiadas sigue pendiente**. Requiere definir endpoint interno por `sub`, caché/coste, fallo cerrado ante indisponibilidad y sincronía entre bases/servicios, o versionado de tokens. Un JWT firmado no demuestra estado actual. No se declara resuelto este punto.

## Pruebas ejecutadas sin Mongo

| Comando / alcance | Resultado |
| --- | --- |
| `talks-service`: `pytest tests/unit -q`, con `TEST_MONGO_URI` ficticia y `TEST_MONGO_DB=sso_riesgo_qr_test` solo para la guarda de importación; no se usó fixture `db` | **215 passed**. Incluye las siete rutas, GET/POST adyacentes, hoja rechazada antes de Blob/Mongo, lectura nominativa adyacente, QR/OCR denegado para supervisor sin ámbito y proyección/filtrado propio. |
| `auth-service`: `python -m unittest discover -s tests -p test_jwt_contract.py -v` | **4 passed**: emisión access/refresh, renovación, tipos desconocidos y login inactivo. |
| Ocho consumidores: `END-POINTS-SSO/tests/jwt_consumer_contract.py` con los venv de cada servicio | **13 casos por servicio**, 8 servicios aprobados. Sin conexión a BD. |
| `reports-service`: `pytest tests/unit/test_report_auth.py -q` | **4 passed**. |
| `reports-service`: `pytest tests/unit/test_report_manager_notifications.py tests/unit/test_report_idempotency.py -q` | **8 passed**. |
| Móvil: `npm test -- --run` | **34 archivos, 259 passed**. |
| `talks-service`: `pytest tests/integration --collect-only -q` | **106 casos recopilados**, ninguno ejecutado; no se abrió conexión Mongo. |
| `git diff --check` | Correcto. |

La suite completa de `reports-service/tests/unit` se interrumpió tras quedar detenida después del primer caso; la prueba de Azure Blob restante no se declara aprobada. Los venv de `workers-service` y `users-service` no contienen `pytest`; no se ejecutaron sus suites. `npx tsc --noEmit` devolvió ayuda/exit 1 porque el proyecto móvil no tiene `tsconfig.json`; los tests Vitest sí compilaron los archivos tocados. No se ejecutó ninguna suite de integración que cree o elimine bases Mongo, ni pruebas de Blob/Azurite. Las pruebas de integración de `talks-service` se actualizaron para el nuevo contrato, pero su resultado de ejecución queda pendiente.

## Riesgos y decisiones pendientes

1. Definir y persistir una relación verificable charla–área y sujeto–área antes de habilitar operaciones de supervisor/jefe. Hasta entonces responden 403 incluso si la UI antigua ofrecía botones.
2. Resolver revalidación de cuenta activa y revocación para refresh y APIs; el control nuevo de login no invalida tokens emitidos previamente.
3. Retirar access legacy sin `type` solo tras comprobar emisión/consumo y expiración de tokens antiguos. No se exigieron `iss`/`aud` porque el contrato emisor no los incluye.
4. Ejecutar integración con Mongo aislado y almacenamiento de prueba solo cuando se autorice. En especial, confirmar filtros/proyecciones, QR válido, OCR, concurrencia e indexación con datos reales.
5. Revisar respuestas móviles de supervisor/jefe al 403 y definir experiencia de ámbito antes de devolverles funciones administrativas. La interfaz ahora oculta esos controles; no hay Dashboard Web fuente mantenido en este checkout para ajustar.

## Archivos y propuesta de commits separados (sin crearlos)

- **JWT:** `auth-service/app/{services/auth_service.py,routers/auth.py,dependencies.py}`, `auth-service/tests/test_jwt_contract.py`, dependencias de `users`, `areas`, `workers`, `dashboard`, `digital-twin`, `incidents`, `alerts`, `reports`, y `END-POINTS-SSO/tests/jwt_consumer_contract.py`.
- **Asistencia y RBAC:** `talks-service/app/{dep_talks.py,routers/rt_talks.py,repositories/rep_talks.py}`, `talks-service/tests/unit/{test_attendance_access_contract.py,test_own_attendance.py}`, pruebas de integración de asistencia/charlas adaptadas, y `APP-GPI-ALLOXENTRIC/src/app/{pages/SafetyTalksMobile.tsx,utils/talkPermissions.ts,utils/talkPermissions.test.ts}`.
- **Pruebas de integración adaptadas, solo recopiladas:** `talks-service/tests/integration/test_absence_states.py`, `test_absence_tenant_isolation.py`, `test_absent_workers.py`, `test_absent_workers_functional.py`, `test_attendance_comparison.py`, `test_attendance_export_pdf.py`, `test_attendance_export_xlsx.py`, `test_attendance_sheet.py`, `test_attendance_stats.py`, `test_expected_workers.py`, `test_ocr_attendance.py`, `test_qr_attendance_router.py` y `test_talk_attachments.py`.
- **TT-17 preservado:** `talks-service/app/attendance_export.py`, porciones previas de `rep_talks.py`, `tests/unit/{test_attendance_consistency.py,test_attendance_projection.py}` y las tres auditorías anteriores. Separar estos cambios por hunks al preparar commits; no se hizo staging ni commit.
- **Documentación:** este archivo.

No se modificaron bases de datos, migraciones ni `.env`; no se hizo commit, push, merge o despliegue.
