import os
import secrets
from datetime import datetime, timedelta, timezone
from pathlib import Path
from uuid import uuid4

import jwt
import pytest
import pytest_asyncio
from dotenv import dotenv_values
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient
from motor.motor_asyncio import AsyncIOMotorClient


SERVICE_DIR = Path(__file__).resolve().parents[1]
test_env = dotenv_values(SERVICE_DIR / ".env.test")

TEST_MONGO_URI = (
    os.getenv("TEST_MONGO_URI")
    or test_env.get("MONGO_URI")
)
TEST_DB_PREFIX = (
    os.getenv("TEST_MONGO_DB")
    or test_env.get("MONGO_DB")
)

if not TEST_MONGO_URI:
    raise RuntimeError("Falta MONGO_URI en .env.test.")

if TEST_DB_PREFIX != "sso_riesgo_qr_test":
    raise RuntimeError(
        "MONGO_DB debe ser exactamente sso_riesgo_qr_test."
    )

# Configuración exclusiva del proceso de pruebas.
# Debe establecerse antes de importar la aplicación.
os.environ.update({
    "MONGO_URI": TEST_MONGO_URI,
    "MONGO_DB": TEST_DB_PREFIX,
    "JWT_SECRET": secrets.token_hex(32),
    "JWT_ALGORITHM": "HS256",
    "QR_SIGNING_SECRET": secrets.token_hex(32),
    "QR_SIGNING_ALGORITHM": "HS256",
    "QR_TTL_MINUTES": "15",
})

from app.dep_talks import get_db
from app.routers.rt_talks import router


@pytest_asyncio.fixture
async def db():
    client = AsyncIOMotorClient(
        TEST_MONGO_URI,
        serverSelectionTimeoutMS=5000,
        tz_aware=True,
    )
    database_name = f"{TEST_DB_PREFIX}_{uuid4().hex}"

    try:
        await client.admin.command("ping")
        yield client[database_name]
    finally:
        # Solo se elimina la base temporal creada por este fixture.
        try:
            if database_name.startswith("sso_riesgo_qr_test_"):
                await client.drop_database(database_name)
        finally:
            client.close()


@pytest_asyncio.fixture
async def api(db):
    application = FastAPI()
    application.include_router(router)
    application.dependency_overrides[get_db] = lambda: db

    transport = ASGITransport(app=application)
    async with AsyncClient(
        transport=transport,
        base_url="http://test",
    ) as client:
        yield client


@pytest.fixture
def auth_headers():
    def build(user_id=None, client_id="empresa_a", role="worker"):
        if user_id is None:
            user_id = {
                ("empresa_a", "admin"): "admin_a",
                ("empresa_b", "admin"): "admin_b",
                ("empresa_a", "supervisor"): "supervisor_a",
                ("empresa_b", "worker"): "worker_b",
            }.get((client_id, role), "worker_a")
        now = datetime.now(timezone.utc)
        token = jwt.encode(
            {
                "type": "access",
                "sub": user_id,
                "client_id": client_id,
                "role": role,
                "iat": now,
                "exp": now + timedelta(minutes=10),
            },
            os.environ["JWT_SECRET"],
            algorithm="HS256",
        )
        return {"Authorization": f"Bearer {token}"}

    return build


@pytest_asyncio.fixture
async def seed(db):
    await db["users"].insert_many([
        {
            "user_id": "worker_a",
            "client_id": "empresa_a",
            "role": "worker",
            "status": "active",
            "name": "Ana",
            "last_name": "Prueba",
        },
        {
            "user_id": "worker_a2",
            "client_id": "empresa_a",
            "role": "worker",
            "status": "active",
            "name": "Luis",
            "last_name": "Prueba",
        },
        {
            "user_id": "supervisor_a",
            "client_id": "empresa_a",
            "role": "supervisor",
            "status": "active",
            "name": "Supervisor",
            "last_name": "Prueba",
        },
        {
            "user_id": "inactive_a",
            "client_id": "empresa_a",
            "role": "admin",
            "status": "inactive",
            "name": "Usuario",
            "last_name": "Inactivo",
        },
        {
            "user_id": "worker_b",
            "client_id": "empresa_b",
            "role": "worker",
            "status": "active",
            "name": "Beatriz",
            "last_name": "Prueba",
        },
        {
            "user_id": "admin_a",
            "client_id": "empresa_a",
            "role": "admin",
            "status": "active",
            "name": "Administradora",
            "last_name": "Prueba",
        },
        {
            "user_id": "admin_b",
            "client_id": "empresa_b",
            "role": "admin",
            "status": "active",
            "name": "Administrador",
            "last_name": "Prueba",
        },
    ])

    talk = {
        "talk_id": "talk_a",
        "client_id": "empresa_a",
        "title": "Charla de prueba",
        "month": "9",
        "year": "2026",
    }
    await db["talks"].insert_one(dict(talk))
    return talk


@pytest_asyncio.fixture
async def qr_token(db, seed):
    async def build(
        *,
        expired=False,
        active=True,
        client_id="empresa_a",
        talk_id="talk_a",
    ):
        now = datetime.now(timezone.utc).replace(microsecond=0)
        issued_at = now - timedelta(minutes=20)
        expires_at = (
            now - timedelta(minutes=1)
            if expired
            else now + timedelta(minutes=15)
        )
        jti = uuid4().hex

        await db["talk_qr_sessions"].insert_one({
            "jti": jti,
            "client_id": client_id,
            "talk_id": talk_id,
            "created_by": "admin_a",
            "created_at": issued_at,
            "expires_at": expires_at,
            "active": active,
        })

        return jwt.encode(
            {
                "type": "sso-talk-attendance",
                "version": 2,
                "client_id": client_id,
                "talk_id": talk_id,
                "jti": jti,
                "iat": issued_at,
                "exp": expires_at,
            },
            os.environ["QR_SIGNING_SECRET"],
            algorithm="HS256",
        )

    return build
