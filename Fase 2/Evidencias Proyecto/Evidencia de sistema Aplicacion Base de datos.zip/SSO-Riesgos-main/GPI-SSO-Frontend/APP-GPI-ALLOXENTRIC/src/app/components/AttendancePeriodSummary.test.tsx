import { describe, expect, it } from 'vitest';
import { renderToStaticMarkup } from 'react-dom/server';

import AttendancePeriodSummary from './AttendancePeriodSummary';

describe('AttendancePeriodSummary - SCRUM-106', () => {
  it('shows attendance percentage when the period has data', () => {
    const html = renderToStaticMarkup(
      <AttendancePeriodSummary
        monthName="Septiembre"
        year="2026"
        stat={{
          active_workers: 20,
          attendance_count: 15,
          attendance_percentage: 75,
        }}
      />
    );

    expect(html).toContain('Cobertura Septiembre 2026');
    expect(html).toContain('75%');
    expect(html).toContain('15 de 20 trabajadores');
  });

  it('shows an explicit no-data message when the period has no records', () => {
    const html = renderToStaticMarkup(
      <AttendancePeriodSummary
        monthName="Septiembre"
        year="2026"
      />
    );

    expect(html).toContain(
      'No hay registros de asistencia para este período.'
    );
  });

  it('does not invent a zero percentage when there are no records', () => {
    const html = renderToStaticMarkup(
      <AttendancePeriodSummary
        monthName="Septiembre"
        year="2026"
      />
    );

    expect(html).not.toContain('0%');
    expect(html).not.toContain('0 de');
  });

  it('shows a loading state', () => {
    const html = renderToStaticMarkup(
      <AttendancePeriodSummary
        monthName="Septiembre"
        year="2026"
        loading
      />
    );

    expect(html).toContain(
      'Cargando estadísticas del período...'
    );
    expect(html).not.toContain(
      'No hay registros de asistencia para este período.'
    );
  });

  it('shows an error state independently from no-data', () => {
    const html = renderToStaticMarkup(
      <AttendancePeriodSummary
        monthName="Septiembre"
        year="2026"
        error
      />
    );

    expect(html).toContain(
      'No fue posible obtener las estadísticas del período.'
    );
    expect(html).not.toContain(
      'No hay registros de asistencia para este período.'
    );
  });
});
