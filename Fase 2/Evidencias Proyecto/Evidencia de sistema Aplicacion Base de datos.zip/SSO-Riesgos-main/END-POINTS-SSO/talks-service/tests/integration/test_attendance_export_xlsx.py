from io import BytesIO

import pytest
from openpyxl import load_workbook

from app.routers import rt_talks


@pytest.mark.asyncio
async def test_export_xlsx_returns_valid_workbook(
    api,
    db,
    auth_headers,
):
    await db["talks"].insert_one({
        "talk_id": "talk_xlsx",
        "client_id": "empresa_a",
        "title": "Prevención de caídas",
        "month": "9",
        "year": "2026",
    })

    await db["attendance"].insert_one({
        "attendance_id": "att_xlsx",
        "client_id": "empresa_a",
        "talk_id": "talk_xlsx",
        "topic": "Tema",
        "date": "2026-09-27",
        "area": "Operaciones",
        "source": "qr",
        "attendees": [
            "Ana Prueba",
            "Luis Prueba",
        ],
        "feedback": "Participación correcta",
        "created_at": "2026-09-27T10:00:00+00:00",
    })

    response = await api.get(
        "/v1/attendance/export/xlsx"
        "?month=9&year=2026",
        headers=auth_headers(
            user_id="admin_a",
            role="admin",
        ),
    )

    assert response.status_code == 200

    assert response.headers[
        "content-type"
    ].startswith(
        "application/vnd.openxmlformats-"
        "officedocument.spreadsheetml.sheet"
    )

    assert (
        'filename="asistencia_2026_09.xlsx"'
        in response.headers[
            "content-disposition"
        ]
    )

    workbook = load_workbook(
        BytesIO(response.content)
    )

    sheet = workbook["Asistencia"]

    assert [
        sheet.cell(
            row=1,
            column=index,
        ).value
        for index in range(1, 8)
    ] == [
        "Fecha",
        "Charla / tema",
        "Área",
        "Tipo",
        "Cantidad asistentes",
        "Asistentes",
        "Retroalimentación",
    ]

    assert sheet["A2"].value == "2026-09-27"
    assert sheet["B2"].value == (
        "Prevención de caídas"
    )
    assert sheet["C2"].value == "Operaciones"
    assert sheet["D2"].value == "QR"
    assert sheet["E2"].value == 2
    assert "Ana Prueba" in sheet["F2"].value
    assert "Luis Prueba" in sheet["F2"].value
    assert sheet["G2"].value == (
        "Participación correcta"
    )

    workbook.close()


@pytest.mark.asyncio
async def test_export_xlsx_is_tenant_isolated(
    api,
    db,
    auth_headers,
):
    await db["attendance"].insert_many([
        {
            "attendance_id": "att_a",
            "client_id": "empresa_a",
            "talk_id": "",
            "topic": "Empresa A",
            "date": "2026-09-27",
            "area": "Área A",
            "attendees": ["Ana A"],
            "feedback": "",
            "created_at": "2026-09-27T10:00:00+00:00",
        },
        {
            "attendance_id": "att_b",
            "client_id": "empresa_b",
            "talk_id": "",
            "topic": "Empresa B",
            "date": "2026-09-27",
            "area": "Área B",
            "attendees": ["Usuario B"],
            "feedback": "",
            "created_at": "2026-09-27T11:00:00+00:00",
        },
    ])

    response = await api.get(
        "/v1/attendance/export/xlsx"
        "?month=9&year=2026",
        headers=auth_headers(role="admin"),
    )

    assert response.status_code == 200

    workbook = load_workbook(
        BytesIO(response.content)
    )
    sheet = workbook["Asistencia"]

    values = [
        cell.value
        for row in sheet.iter_rows()
        for cell in row
        if cell.value is not None
    ]

    assert "Empresa A" in values
    assert "Empresa B" not in values
    assert "Usuario B" not in values

    workbook.close()


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("query", "detail"),
    [
        (
            "month=0&year=2026",
            "Mes inválido.",
        ),
        (
            "month=14&year=2026",
            "Mes inválido.",
        ),
        (
            "month=9&year=invalid",
            "Año inválido.",
        ),
    ],
)
async def test_export_xlsx_rejects_invalid_period(
    api,
    auth_headers,
    query,
    detail,
):
    response = await api.get(
        f"/v1/attendance/export/xlsx?{query}",
        headers=auth_headers(role="admin"),
    )

    assert response.status_code == 422
    assert response.json()["detail"] == detail


@pytest.mark.asyncio
async def test_export_xlsx_returns_no_data_message(
    api,
    auth_headers,
):
    response = await api.get(
        "/v1/attendance/export/xlsx"
        "?month=9&year=2026",
        headers=auth_headers(role="admin"),
    )

    assert response.status_code == 404
    assert response.json()["detail"] == (
        "No hay registros de asistencia para el período seleccionado."
    )


@pytest.mark.asyncio
async def test_export_xlsx_handles_generation_failure(
    api,
    db,
    auth_headers,
    monkeypatch,
):
    await db["attendance"].insert_one({
        "attendance_id": "att_xlsx_failure",
        "client_id": "empresa_a",
        "talk_id": "",
        "topic": "Prueba generación Excel",
        "date": "2026-09-27",
        "area": "Planta",
        "attendees": ["Ana Prueba"],
        "feedback": "",
        "created_at": "2026-09-27T10:00:00+00:00",
    })

    def fail_generation(*args, **kwargs):
        raise RuntimeError(
            "detalle interno que no debe exponerse"
        )

    monkeypatch.setattr(
        rt_talks,
        "build_attendance_xlsx",
        fail_generation,
    )

    response = await api.get(
        "/v1/attendance/export/xlsx"
        "?month=9&year=2026",
        headers=auth_headers(role="admin"),
    )

    assert response.status_code == 500
    assert response.json()["detail"] == (
        "No fue posible generar la exportación Excel."
    )
    assert (
        "detalle interno que no debe exponerse"
        not in response.text
    )
