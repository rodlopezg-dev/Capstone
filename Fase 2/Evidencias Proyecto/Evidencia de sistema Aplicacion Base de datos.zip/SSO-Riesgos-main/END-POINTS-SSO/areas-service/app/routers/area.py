from fastapi import APIRouter, Depends, status
from typing import List

from app.schemas.area import AreaCreate, AreaUpdate, AreaResponse
from app.services.area_service import AreaService
from app.repositories.area_repo import AreaRepository

# Cabeceras de dependencias de seguridad y contexto
from app.dependencies import get_db, verify_role
from app.schemas.area import CurrentUser  

router = APIRouter(prefix="/v1/areas", tags=["Areas"])


# --- FÁBRICA DE DEPENDENCIAS ---
def get_area_service(db = Depends(get_db)) -> AreaService:
    repo = AreaRepository(db)
    return AreaService(repo)


# --- ENDPOINTS CORREGIDOS CON EL ROL jefe de area ---


@router.post("/", response_model=AreaResponse, status_code=status.HTTP_201_CREATED)
async def create_area(
    area_in: AreaCreate,
    service: AreaService = Depends(get_area_service),
    # 🔐 Se añade "sso_manager" para permitirle crear áreas
    current_user: CurrentUser = Depends(verify_role("admin", "manager", "sso_manager")),
):
    return await service.create_area(client_id=current_user.client_id, area_in=area_in)


@router.get("/", response_model=List[AreaResponse])
async def list_areas(
    service: AreaService = Depends(get_area_service),
    # 🔐 SOLUCIÓN AL 403: Se añade "jefe de area" para que pueda consumir la tabla y los selectores del formulario
    current_user: CurrentUser = Depends(verify_role("admin", "manager", "user", "sso_manager", "jefe de area")),
):
    return await service.get_areas(client_id=current_user.client_id)


@router.get("/{area_id}", response_model=AreaResponse)
async def get_area(
    area_id: str,
    service: AreaService = Depends(get_area_service),
    # 🔐 Se añade "jefe de area" para permitirle ver los detalles específicos
    current_user: CurrentUser = Depends(verify_role("admin", "manager", "user", "sso_manager", "jefe de area")),
):
    return await service.get_area(client_id=current_user.client_id, area_id=area_id)


@router.patch("/{area_id}", response_model=AreaResponse)
async def update_area(
    area_id: str,
    area_in: AreaUpdate,
    service: AreaService = Depends(get_area_service),
    # 🔐 Se añade "sso_manager" para permitirle actualizar/editar el estado o nombre del área
    current_user: CurrentUser = Depends(verify_role("admin", "manager", "sso_manager")),
):
    return await service.update_area(
        client_id=current_user.client_id, area_id=area_id, area_in=area_in
    )


@router.delete("/{area_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_area(
    area_id: str,
    service: AreaService = Depends(get_area_service),
    # 🔐 Se añade "sso_manager" para otorgarle permisos de eliminación de zonas
    current_user: CurrentUser = Depends(verify_role("admin", "sso_manager")),
):
    await service.delete_area(client_id=current_user.client_id, area_id=area_id)