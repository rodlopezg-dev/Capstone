import pytest


async def _prepare_workers(db):
    await db["users"].update_one(
        {
            "user_id": "worker_a",
            "client_id": "empresa_a",
        },
        {
            "$set": {
                "role": "worker",
                "status": "active",
            },
        },
    )

    await db["users"].update_one(
        {
            "user_id": "worker_a2",
            "client_id": "empresa_a",
        },
        {
            "$set": {
                "role": "worker",
                "status": "active",
            },
        },
    )


async def _create_talk(
    db,
    talk_id,
    expected_user_ids,
):
    await db["talks"].insert_one({
        "talk_id": talk_id,
        "client_id": "empresa_a",
        "title": "Charla obligatoria",
        "month": "9",
        "year": "2026",
        "mandatory": True,
        "expected_user_ids": expected_user_ids,
    })


@pytest.mark.asyncio
async def test_absent_workers_returns_worker_without_attendance(
    api,
    db,
    auth_headers,
    seed,
):
    await _prepare_workers(db)

    await _create_talk(
        db,
        "talk_absent_one",
        [
            "worker_a",
            "worker_a2",
        ],
    )

    await db["attendance"].insert_one({
        "attendance_id": "att_absent_one",
        "client_id": "empresa_a",
        "talk_id": "talk_absent_one",
        "source": "qr",
        "attended_user_ids": [
            "worker_a",
        ],
        "attendees": [
            "Ana Prueba",
        ],
    })

    response = await api.get(
        (
            "/v1/talks/"
            "talk_absent_one/"
            "absent-workers"
        ),
        headers=auth_headers(role="admin"),
    )

    assert response.status_code == 200

    data = response.json()

    assert data["attended_user_ids"] == [
        "worker_a",
    ]

    assert data["absent_user_ids"] == [
        "worker_a2",
    ]

    assert [
        worker["user_id"]
        for worker in data["absent_workers"]
    ] == [
        "worker_a2",
    ]


@pytest.mark.asyncio
async def test_absent_workers_returns_all_when_no_attendance(
    api,
    db,
    auth_headers,
    seed,
):
    await _prepare_workers(db)

    await _create_talk(
        db,
        "talk_absent_all",
        [
            "worker_a",
            "worker_a2",
        ],
    )

    response = await api.get(
        (
            "/v1/talks/"
            "talk_absent_all/"
            "absent-workers"
        ),
        headers=auth_headers(role="admin"),
    )

    assert response.status_code == 200

    assert response.json()[
        "absent_user_ids"
    ] == [
        "worker_a",
        "worker_a2",
    ]


@pytest.mark.asyncio
async def test_absent_workers_returns_empty_when_everyone_attended(
    api,
    db,
    auth_headers,
    seed,
):
    await _prepare_workers(db)

    await _create_talk(
        db,
        "talk_absent_none",
        [
            "worker_a",
            "worker_a2",
        ],
    )

    await db["attendance"].insert_one({
        "attendance_id": "att_absent_none",
        "client_id": "empresa_a",
        "talk_id": "talk_absent_none",
        "source": "qr",
        "attended_user_ids": [
            "worker_a",
            "worker_a2",
        ],
        "attendees": [
            "Ana Prueba",
            "Luis Prueba",
        ],
    })

    response = await api.get(
        (
            "/v1/talks/"
            "talk_absent_none/"
            "absent-workers"
        ),
        headers=auth_headers(role="admin"),
    )

    assert response.status_code == 200

    data = response.json()

    assert data["absent_user_ids"] == []
    assert data["absent_workers"] == []


@pytest.mark.asyncio
async def test_unresolved_expected_worker_is_not_marked_absent(
    api,
    db,
    auth_headers,
    seed,
):
    await _prepare_workers(db)

    await _create_talk(
        db,
        "talk_absent_missing",
        [
            "worker_a",
            "missing_worker",
        ],
    )

    response = await api.get(
        (
            "/v1/talks/"
            "talk_absent_missing/"
            "absent-workers"
        ),
        headers=auth_headers(role="admin"),
    )

    assert response.status_code == 200

    data = response.json()

    assert data[
        "resolved_expected_user_ids"
    ] == [
        "worker_a",
    ]

    assert data[
        "missing_expected_user_ids"
    ] == [
        "missing_worker",
    ]

    assert data["absent_user_ids"] == [
        "worker_a",
    ]

    assert "missing_worker" not in data[
        "absent_user_ids"
    ]


@pytest.mark.asyncio
async def test_absent_workers_returns_404_for_unknown_talk(
    api,
    auth_headers,
):
    response = await api.get(
        (
            "/v1/talks/"
            "talk_not_found/"
            "absent-workers"
        ),
        headers=auth_headers(role="admin"),
    )

    assert response.status_code == 404
    assert response.json()["detail"] == (
        "Charla no encontrada."
    )
