import { describe, expect, it } from 'vitest';

import {
  canApproveIncidentClosure,
  canChangeIncidentToProcess,
  canRequestIncidentClosure,
  incidentStatusErrorMessage,
  incidentStatusSuccessMessage,
  normalizeIncidentRole,
} from './incidentStatus';

describe('incidentStatus permissions and transitions', () => {
  it.each([
    'supervisor',
    'jefe de area',
    'jefe_de_area',
  ])(
    'allows %s to change an open incident to process',
    role => {
      expect(
        canChangeIncidentToProcess('open', role),
      ).toBe(true);
    },
  );

  it.each([
    'worker',
    'admin',
    'sso_manager',
  ])(
    'does not allow %s to change an incident to process',
    role => {
      expect(
        canChangeIncidentToProcess('open', role),
      ).toBe(false);
    },
  );

  it('only allows the action from open status', () => {
    expect(
      canChangeIncidentToProcess(
        'en_proceso',
        'supervisor',
      ),
    ).toBe(false);

    expect(
      canChangeIncidentToProcess(
        'closed',
        'supervisor',
      ),
    ).toBe(false);
  });

  it('normalizes underscore role variants', () => {
    expect(
      normalizeIncidentRole(' jefe_de_area '),
    ).toBe('jefe de area');
  });

  it.each([
    'supervisor',
    'jefe de area',
    'jefe_de_area',
  ])(
    'allows %s to request closure from process',
    role => {
      expect(
        canRequestIncidentClosure(
          'en_proceso',
          role,
        ),
      ).toBe(true);
    },
  );

  it.each([
    'worker',
    'admin',
    'sso_manager',
  ])(
    'does not allow %s to request closure',
    role => {
      expect(
        canRequestIncidentClosure(
          'en_proceso',
          role,
        ),
      ).toBe(false);
    },
  );

  it('only requests closure from en_proceso', () => {
    expect(
      canRequestIncidentClosure(
        'open',
        'supervisor',
      ),
    ).toBe(false);

    expect(
      canRequestIncidentClosure(
        'pending_closure',
        'supervisor',
      ),
    ).toBe(false);

    expect(
      canRequestIncidentClosure(
        'closed',
        'supervisor',
      ),
    ).toBe(false);
  });

  it.each([
    'admin',
    'sso_manager',
    'sso manager',
  ])(
    'allows %s to approve pending closure',
    role => {
      expect(
        canApproveIncidentClosure(
          'pending_closure',
          role,
        ),
      ).toBe(true);
    },
  );

  it.each([
    'supervisor',
    'jefe_de_area',
    'jefe de area',
    'worker',
  ])(
    'does not allow %s to approve closure',
    role => {
      expect(
        canApproveIncidentClosure(
          'pending_closure',
          role,
        ),
      ).toBe(false);
    },
  );

  it('only approves closure from pending_closure', () => {
    expect(
      canApproveIncidentClosure(
        'open',
        'admin',
      ),
    ).toBe(false);

    expect(
      canApproveIncidentClosure(
        'en_proceso',
        'admin',
      ),
    ).toBe(false);

    expect(
      canApproveIncidentClosure(
        'closed',
        'admin',
      ),
    ).toBe(false);
  });
});


describe('SCRUM-95 role visibility matrix', () => {
  const matrix = [
    // Supervisor
    {
      role: 'supervisor',
      status: 'open',
      changeToProcess: true,
      requestClosure: false,
      approveClosure: false,
    },
    {
      role: 'supervisor',
      status: 'en_proceso',
      changeToProcess: false,
      requestClosure: true,
      approveClosure: false,
    },
    {
      role: 'supervisor',
      status: 'pending_closure',
      changeToProcess: false,
      requestClosure: false,
      approveClosure: false,
    },
    {
      role: 'supervisor',
      status: 'closed',
      changeToProcess: false,
      requestClosure: false,
      approveClosure: false,
    },

    // Jefe de área
    {
      role: 'jefe_de_area',
      status: 'open',
      changeToProcess: true,
      requestClosure: false,
      approveClosure: false,
    },
    {
      role: 'jefe_de_area',
      status: 'en_proceso',
      changeToProcess: false,
      requestClosure: true,
      approveClosure: false,
    },
    {
      role: 'jefe_de_area',
      status: 'pending_closure',
      changeToProcess: false,
      requestClosure: false,
      approveClosure: false,
    },
    {
      role: 'jefe_de_area',
      status: 'closed',
      changeToProcess: false,
      requestClosure: false,
      approveClosure: false,
    },

    // Admin
    {
      role: 'admin',
      status: 'open',
      changeToProcess: false,
      requestClosure: false,
      approveClosure: false,
    },
    {
      role: 'admin',
      status: 'en_proceso',
      changeToProcess: false,
      requestClosure: false,
      approveClosure: false,
    },
    {
      role: 'admin',
      status: 'pending_closure',
      changeToProcess: false,
      requestClosure: false,
      approveClosure: true,
    },
    {
      role: 'admin',
      status: 'closed',
      changeToProcess: false,
      requestClosure: false,
      approveClosure: false,
    },

    // SSO Manager
    {
      role: 'sso_manager',
      status: 'open',
      changeToProcess: false,
      requestClosure: false,
      approveClosure: false,
    },
    {
      role: 'sso_manager',
      status: 'en_proceso',
      changeToProcess: false,
      requestClosure: false,
      approveClosure: false,
    },
    {
      role: 'sso_manager',
      status: 'pending_closure',
      changeToProcess: false,
      requestClosure: false,
      approveClosure: true,
    },
    {
      role: 'sso_manager',
      status: 'closed',
      changeToProcess: false,
      requestClosure: false,
      approveClosure: false,
    },

    // Worker / usuario
    {
      role: 'worker',
      status: 'open',
      changeToProcess: false,
      requestClosure: false,
      approveClosure: false,
    },
    {
      role: 'worker',
      status: 'en_proceso',
      changeToProcess: false,
      requestClosure: false,
      approveClosure: false,
    },
    {
      role: 'worker',
      status: 'pending_closure',
      changeToProcess: false,
      requestClosure: false,
      approveClosure: false,
    },
    {
      role: 'worker',
      status: 'closed',
      changeToProcess: false,
      requestClosure: false,
      approveClosure: false,
    },
  ];

  it.each(matrix)(
    '$role in $status exposes only its allowed actions',
    ({
      role,
      status,
      changeToProcess,
      requestClosure,
      approveClosure,
    }) => {
      expect(
        canChangeIncidentToProcess(status, role),
      ).toBe(changeToProcess);

      expect(
        canRequestIncidentClosure(status, role),
      ).toBe(requestClosure);

      expect(
        canApproveIncidentClosure(status, role),
      ).toBe(approveClosure);
    },
  );
});


describe('SCRUM-97 status feedback messages', () => {
  it.each([
    [
      'en_proceso',
      'Incidente cambiado a proceso correctamente.',
    ],
    [
      'pending_closure',
      'Solicitud de cierre enviada correctamente.',
    ],
    [
      'closed',
      'Cierre del incidente aprobado correctamente.',
    ],
    [
      'other_status',
      'Estado actualizado correctamente.',
    ],
  ])(
    'returns success feedback for %s',
    (status, expected) => {
      expect(
        incidentStatusSuccessMessage(status),
      ).toBe(expected);
    },
  );

  it('prefers backend detail for an HTTP error', () => {
    expect(
      incidentStatusErrorMessage(
        403,
        ' No tiene permisos específicos. ',
      ),
    ).toBe('No tiene permisos específicos.');
  });

  it('returns fallback feedback for 403', () => {
    expect(
      incidentStatusErrorMessage(403),
    ).toBe(
      'No tiene permisos para realizar esta acción.',
    );
  });

  it('returns fallback feedback for 409', () => {
    expect(
      incidentStatusErrorMessage(409),
    ).toBe(
      'El incidente no se encuentra en un estado '
      + 'válido para realizar esta acción.',
    );
  });

  it('returns generic feedback for unexpected errors', () => {
    expect(
      incidentStatusErrorMessage(500),
    ).toBe(
      'No fue posible cambiar el estado del incidente.',
    );
  });
});
