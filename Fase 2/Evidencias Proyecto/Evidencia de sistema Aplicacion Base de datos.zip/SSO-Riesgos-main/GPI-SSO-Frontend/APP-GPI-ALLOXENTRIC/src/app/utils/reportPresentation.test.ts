import { describe, expect, it } from 'vitest';
import type { Report } from '../api/reports';
import {
  formatReportDate,
  getReportDisplayId,
  getReportEvidenceUrl,
  resolveReportEvidenceUrl,
} from './reportPresentation';

const report: Report = {
  report_id: '5',
  area_id: 'Linea 1',
  type: 'unsafe_condition',
  status: 'open',
  is_iap: false,
  description: 'Probando',
  created_at: '2026-09-25T12:00:00Z',
  evidences: ['https://example.test/evidence.jpg'],
  timeline: {
    sent: '2026-09-25T12:00:00Z',
  },
};

describe('reportPresentation - SCRUM-129', () => {
  it('usa report_id como identificador visible', () => {
    expect(getReportDisplayId(report)).toBe('5');
  });

  it('usa created_at como fecha visible', () => {
    expect(formatReportDate(report.created_at)).toBe(
      new Date(report.created_at).toLocaleDateString('es-CL'),
    );
  });

  it('usa la primera evidencia disponible', () => {
    expect(getReportEvidenceUrl(report)).toBe(
      'https://example.test/evidence.jpg',
    );
  });

  it('resuelve evidencia local usando el origin de reports API', () => {
    expect(
      resolveReportEvidenceUrl(
        '/local-evidence/reports/5/evidence.jpg',
        'https://desktop-home.tail3b178f.ts.net/api/reports',
      ),
    ).toBe(
      'https://desktop-home.tail3b178f.ts.net/local-evidence/reports/5/evidence.jpg',
    );
  });

  it('mantiene intacta una URL absoluta de evidencia', () => {
    expect(
      resolveReportEvidenceUrl(
        'https://example.test/evidence.jpg',
        'https://desktop-home.tail3b178f.ts.net/api/reports',
      ),
    ).toBe('https://example.test/evidence.jpg');
  });

  it('mantiene la ruta local si no existe una API publica configurada', () => {
    expect(
      resolveReportEvidenceUrl(
        '/local-evidence/reports/5/evidence.jpg',
        undefined,
      ),
    ).toBe('/local-evidence/reports/5/evidence.jpg');
  });

  it('retorna null cuando el reporte no tiene evidencia', () => {
    expect(
      getReportEvidenceUrl({
        ...report,
        evidences: [],
      }),
    ).toBeNull();
  });

  it('soporta estados vigentes del flujo de cierre', () => {
    const statuses: Report['status'][] = [
      'open',
      'en_proceso',
      'pending_closure',
      'closed',
    ];

    expect(statuses).toHaveLength(4);
  });
});
