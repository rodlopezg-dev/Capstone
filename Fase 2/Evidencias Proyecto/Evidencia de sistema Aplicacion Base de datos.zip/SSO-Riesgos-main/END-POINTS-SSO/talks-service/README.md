# Talks Service

Microservicio responsable de las charlas de seguridad, los archivos asociados y los
registros de asistencia manual o mediante código QR.

## Asistencia mediante QR

### Flujo general

1. Un administrador, supervisor o jefe de área solicita el QR de una charla.
2. El backend genera un JWT firmado y crea una sesión en `talk_qr_sessions`.
3. El trabajador autenticado escanea el código desde la aplicación móvil.
4. El backend valida:
   - firma y estructura del token;
   - fecha de expiración;
   - sesión QR existente y activa;
   - charla asociada;
   - correspondencia de `client_id`;
   - estado activo del trabajador.
5. La identidad del asistente se obtiene desde el usuario autenticado.
6. La asistencia se registra en un documento QR separado de cualquier asistencia manual.

El QR identifica una charla y una sesión. Nunca debe contener ni aceptar como fuente
confiable el nombre, correo, RUT o identificador del trabajador.

## Roles

Pueden generar o visualizar códigos QR:

- `admin`
- `supervisor`
- `jefe de area`

Los trabajadores pueden escanear el QR, pero no generarlo.

## Expiración y renovación

Cada QR contiene su propio `jti`, `iat` y `exp`. Su duración se configura mediante
`QR_TTL_MINUTES`.

Cuando el QR expira:

- el JWT deja de ser válido;
- el endpoint de escaneo lo rechaza;
- conservar una captura del QR no permite utilizarlo después de su expiración.

Mientras la ventana QR permanezca abierta, el frontend solicita automáticamente un
código nuevo después de expirar el actual.

### Comportamiento actual al generar otro QR

Generar un QR nuevo no revoca las sesiones anteriores que todavía no hayan expirado.
Por lo tanto, pueden existir temporalmente varios códigos válidos para la misma charla.

Cada código deja de funcionar cuando alcanza su propia expiración o cuando su sesión
deja de estar activa.

Se permite mantener varias sesiones QR activas para una misma charla. Esto facilita que
dos o más responsables exhiban simultáneamente el código cuando existe una gran cantidad
de asistentes. Aunque un trabajador escanee distintas sesiones válidas, su asistencia se
registra una sola vez por empresa y charla.

## Múltiples asistentes

El mismo QR puede ser escaneado por varios trabajadores mientras permanezca válido.

Para cada empresa y charla existe un documento determinístico de asistencia QR. Cada
trabajador se incorpora una sola vez, incluso si:

- escanea el código repetidamente;
- se reciben solicitudes concurrentes;
- varios trabajadores escanean al mismo tiempo.

La hora se obtiene desde el servidor y se conserva el primer registro de cada trabajador.

## Separación entre asistencia manual y QR

Los registros QR utilizan:

```text
source=qr
```

y un identificador determinístico basado en:

```text
client_id + talk_id
```

Una asistencia QR no reutiliza ni modifica una asistencia manual existente.

## Aislamiento por empresa

Todas las operaciones validan el `client_id` obtenido desde el usuario autenticado.

El `client_id` del QR, la sesión, la charla y el usuario deben coincidir. Un trabajador
de otra empresa no puede registrar asistencia utilizando ese código.

## Sesiones QR

Las sesiones se almacenan en:

```text
talk_qr_sessions
```

Cada sesión contiene:

```text
jti
client_id
talk_id
created_by
created_at
expires_at
active
```

Actualmente `active` se crea con valor `true`. Todavía no existe un flujo funcional que
lo cambie a `false`.

Al iniciar, `talks-service` crea el índice TTL `qr_sessions_expires_at_ttl` sobre el campo
`expires_at`, con `expireAfterSeconds=0`. MongoDB elimina periódicamente las sesiones
expiradas; esta limpieza puede no ser inmediata.

La seguridad no depende del momento en que MongoDB elimine el documento. La API rechaza
inmediatamente un QR vencido mediante la expiración del JWT y la validación de
`expires_at` almacenada en la sesión.

## Variables de entorno

```env
QR_SIGNING_SECRET=<clave-larga-aleatoria-y-distinta-de-jwt-secret>
QR_SIGNING_ALGORITHM=HS256
QR_TTL_MINUTES=15

AZURE_STORAGE_CONNECTION_STRING=<connection-string-del-storage>
AZURE_STORAGE_CONTAINER=attendance-scans
```

- `QR_SIGNING_SECRET`: clave utilizada exclusivamente para firmar los QR.
- `QR_SIGNING_ALGORITHM`: algoritmo entregado a PyJWT.
- `QR_TTL_MINUTES`: duración del QR; debe ser mayor que cero.
- `AZURE_STORAGE_CONNECTION_STRING`: cadena de conexión utilizada por OCR para Azure Blob Storage o Azurite.
- `AZURE_STORAGE_CONTAINER`: contenedor de imágenes OCR; por defecto `attendance-scans`.

`QR_SIGNING_SECRET` no debe reutilizar `JWT_SECRET` ni incluirse en Git.

`AZURE_STORAGE_CONNECTION_STRING` contiene credenciales y no debe incluirse en Git, logs ni documentación con valores reales.

### Validaciones actuales

- La ausencia de una variable obligatoria impide iniciar el servicio.
- `QR_TTL_MINUTES` debe ser mayor que cero.
- `QR_SIGNING_ALGORITHM` sólo admite `HS256`; cualquier otro valor impide iniciar el servicio.
- `QR_SIGNING_SECRET` debe contener al menos 32 caracteres.
- La configuración Blob se carga únicamente al utilizar OCR.
- Sin `AZURE_STORAGE_CONNECTION_STRING`, el servicio puede iniciar, pero `/v1/attendance/ocr` responde almacenamiento no disponible.
- `AZURE_STORAGE_CONTAINER` debe cumplir las reglas de nombres de Azure Blob Storage.

## Pruebas en Docker

La suite utiliza una MongoDB temporal y separada de la instancia normal, junto con una instancia Azurite aislada.

```powershell
docker compose -p sso-qr-tests -f docker-compose.test.yml up --build --abort-on-container-exit --exit-code-from talks-service-test
```

Para limpiar los contenedores:

```powershell
docker compose -p sso-qr-tests -f docker-compose.test.yml down --volumes
```

Antes de iniciar `docker-compose.test.yml` se deben definir `TEST_AZURITE_ACCOUNT` y `TEST_AZURITE_KEY` con valores efímeros exclusivos para pruebas. No deben utilizarse credenciales reales de Azure.

La Mongo de pruebas:

- no publica puertos;
- utiliza almacenamiento temporal en memoria;
- crea bases con el prefijo `sso_riesgo_qr_test_`;
- elimina cada base temporal al finalizar;
- nunca debe sustituirse por una URI de producción.

Azurite:

- no publica Blob Storage fuera de la red temporal de Compose;
- utiliza credenciales efímeras para la suite;
- permite probar upload, listado y eliminación real de blobs;
- utiliza el mismo flujo Azure Blob del servicio sin requerir una cuenta Azure real.

La suite también verifica que el índice TTL tenga la configuración esperada y que se
cree automáticamente durante el inicio de `talks-service`.

## Pruebas funcionales y de rendimiento

La ejecución predeterminada en `docker-compose.test.yml` excluye las pruebas marcadas
como `performance`. Esto evita que las variaciones de velocidad del equipo o del runner
de CI produzcan falsos fallos en la suite funcional.

Para ejecutar únicamente las pruebas funcionales:

```powershell
docker compose -p sso-qr-tests -f docker-compose.test.yml run --rm talks-service-test pytest -q -m "not performance"
```

Para ejecutar separadamente las pruebas de rendimiento:

```powershell
docker compose -p sso-qr-tests -f docker-compose.test.yml run --rm talks-service-test pytest -q -m performance
```

La prueba de escaneo QR conserva como criterio que la respuesta tarde menos de dos
segundos. Este resultado debe evaluarse considerando las condiciones del entorno donde
se ejecute.

## Endpoints QR

```text
GET  /v1/talks/{talk_id}/qr
POST /v1/attendance/scan
```

El primer endpoint genera el QR y su sesión. El segundo valida el código y registra al
trabajador autenticado.

## OCR de asistencia

```text
POST /v1/attendance/ocr
```

El endpoint recibe una imagen de una hoja de asistencia y:

1. valida rol, usuario activo, empresa y charla;
2. valida tipo, tamaño e integridad de la imagen;
3. ejecuta Tesseract OCR en español fuera del event loop principal;
4. intenta asociar los nombres detectados con usuarios activos de la misma empresa;
5. almacena la imagen en Azure Blob Storage o Azurite;
6. guarda en MongoDB únicamente metadata y la referencia al blob.

Los blobs utilizan un prefijo aislado por empresa y charla:

```text
{client_id}/{talk_id}/{uuid}.{extension}
```

MongoDB no almacena la imagen, Base64 ni URLs SAS persistentes.

Si falla la persistencia de metadata después de subir la imagen, el servicio intenta eliminar el blob recién creado para evitar archivos huérfanos.

Actualmente se aceptan imágenes JPEG, PNG y WEBP de hasta 10 MB.

## Configuración CORS

El servicio permite configurar los orígenes CORS mediante variables de entorno.

- `CORS_ORIGINS`: opcional. Lista de orígenes separados por coma.
- `CORS_ORIGIN_REGEX`: opcional. Expresión regular adicional para orígenes permitidos.

Si `CORS_ORIGINS` no está definido, se conserva la lista de orígenes que utilizaba
el servicio antes de externalizar esta configuración. Esto mantiene compatibilidad
con los ambientes existentes.

No se deben almacenar secretos ni credenciales en estas variables.
