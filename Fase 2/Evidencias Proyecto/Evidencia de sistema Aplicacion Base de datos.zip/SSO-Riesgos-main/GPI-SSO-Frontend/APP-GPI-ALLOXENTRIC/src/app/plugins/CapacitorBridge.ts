import { Capacitor } from '@capacitor/core';
import {
  Camera,
  CameraResultType,
  CameraSource,
} from '@capacitor/camera';

// ── Cámara ────────────────────────────────────────────────────────────────────
export async function requestCameraPermission(): Promise<boolean> {
  if (!Capacitor.isNativePlatform()) return true;

  try {
    const perm = await Camera.requestPermissions({
      permissions: ['camera'],
    });

    return perm.camera === 'granted';
  } catch {
    return false;
  }
}

export async function takePhoto(): Promise<string | null> {
  if (!Capacitor.isNativePlatform()) return null;

  const granted = await requestCameraPermission();

  if (!granted) {
    console.warn('[Camera] Permiso denegado');
    return null;
  }

  try {
    const photo = await Camera.getPhoto({
      quality: 90,
      allowEditing: false,
      resultType: CameraResultType.DataUrl,
      source: CameraSource.Camera,
      saveToGallery: false,
      width: 1920,
      height: 1080,
    });

    return photo.dataUrl ?? null;
  } catch {
    // Cancelar la cámara no se considera error.
    return null;
  }
}

export async function pickFromGallery(): Promise<string | null> {
  if (!Capacitor.isNativePlatform()) return null;

  try {
    /*
     * No solicitar permiso "photos" manualmente.
     *
     * En Android moderno el selector del sistema concede acceso
     * únicamente al elemento elegido. La solicitud previa fue la
     * causa del bloqueo inicial observado en ZFlip7FE.
     *
     * DataUrl además evita tener que adivinar el MIME de URI HEIC/HEIF
     * devueltas por algunos dispositivos Samsung.
     */
    const photo = await Camera.getPhoto({
      quality: 90,
      allowEditing: false,
      resultType: CameraResultType.DataUrl,
      source: CameraSource.Photos,
      saveToGallery: false,
      width: 1920,
      height: 1080,
    });

    return photo.dataUrl ?? null;
  } catch {
    // Cancelar la galería no se considera error.
    return null;
  }
}
