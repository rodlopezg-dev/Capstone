import base64
import os

import pytest
from azure.core.exceptions import ResourceNotFoundError
from azure.storage.blob.aio import BlobServiceClient

from app.repositories.rep_talks import TalksRepository


async def _list_test_blobs(prefix: str):
    connection_string = os.environ[
        "AZURE_STORAGE_CONNECTION_STRING"
    ]
    container_name = os.environ[
        "AZURE_STORAGE_CONTAINER"
    ]

    async with BlobServiceClient.from_connection_string(
        connection_string
    ) as service:
        container = service.get_container_client(
            container_name
        )

        try:
            blobs = set()
            async for blob in container.list_blobs(
                name_starts_with=prefix
            ):
                blobs.add(blob.name)
            return blobs
        except ResourceNotFoundError:
            return set()


@pytest.mark.asyncio
async def test_create_talk_stores_attachment_in_blob_and_downloads_it(
    api,
    db,
    auth_headers,
):
    content = b"material de charla"

    response = await api.post(
        "/v1/talks",
        data={
            "title": "Uso seguro de herramientas",
            "month": "9",
            "year": "2026",
        },
        files={
            "file": (
                "material.txt",
                content,
                "text/plain",
            ),
        },
        headers=auth_headers(
            user_id="admin_a",
            role="admin",
        ),
    )

    assert response.status_code == 200, response.text

    talk_id = response.json()["talk_id"]

    document = await db["talks"].find_one(
        {
            "talk_id": talk_id,
            "client_id": "empresa_a",
        }
    )

    assert document is not None
    assert document["file_id"]
    assert document["file_url"] == ""
    assert document["file_name"] == "material.txt"
    assert document["file_content_type"] == "text/plain"
    assert document["file_size"] == len(content)
    assert document["file_storage"]["provider"] == "azure_blob"
    assert document["file_storage"]["blob_name"].startswith(
        "empresa_a/talks/"
    )

    assert not document["file_url"].startswith(
        "data:"
    )

    blobs = await _list_test_blobs(
        "empresa_a/talks/"
    )

    assert document[
        "file_storage"
    ]["blob_name"] in blobs

    response = await api.get(
        "/v1/talks",
        headers=auth_headers(
            user_id="admin_a",
            role="admin",
        ),
    )

    assert response.status_code == 200

    listed = next(
        talk
        for talk in response.json()
        if talk["talk_id"] == talk_id
    )

    assert listed["file_id"] == document["file_id"]
    assert listed["file_url"] == ""
    assert "file_storage" not in listed

    response = await api.get(
        f"/v1/talks/{talk_id}/file",
        headers=auth_headers(
            user_id="admin_a",
            role="admin",
        ),
    )

    assert response.status_code == 200
    assert response.content == content
    assert response.headers["content-type"].startswith(
        "text/plain"
    )
    assert (
        "material.txt"
        in response.headers["content-disposition"]
    )


@pytest.mark.asyncio
async def test_legacy_talk_attachment_remains_downloadable(
    api,
    db,
    seed,
    auth_headers,
):
    content = b"archivo legacy"
    encoded = base64.b64encode(
        content
    ).decode("ascii")

    await db["talks"].update_one(
        {
            "talk_id": "talk_a",
            "client_id": "empresa_a",
        },
        {
            "$set": {
                "file_name": "legacy.txt",
                "file_url": (
                    "data:text/plain;base64,"
                    + encoded
                ),
            }
        },
    )

    response = await api.get(
        "/v1/talks",
        headers=auth_headers(role="admin"),
    )

    assert response.status_code == 200

    talk = next(
        item
        for item in response.json()
        if item["talk_id"] == "talk_a"
    )

    assert talk["file_id"] == "legacy"
    assert talk["file_url"] == ""
    assert "file_storage" not in talk

    response = await api.get(
        "/v1/talks/talk_a/file",
        headers=auth_headers(role="admin"),
    )

    assert response.status_code == 200
    assert response.content == content
    assert response.headers["content-type"].startswith(
        "text/plain"
    )


@pytest.mark.asyncio
async def test_replacing_talk_attachment_deletes_previous_blob(
    api,
    db,
    seed,
    auth_headers,
):
    headers = auth_headers(
        user_id="admin_a",
        role="admin",
    )

    response = await api.patch(
        "/v1/talks/talk_a",
        files={
            "file": (
                "primero.txt",
                b"primero",
                "text/plain",
            ),
        },
        headers=headers,
    )

    assert response.status_code == 200, response.text

    first = await db["talks"].find_one(
        {
            "talk_id": "talk_a",
            "client_id": "empresa_a",
        }
    )

    first_blob = first[
        "file_storage"
    ]["blob_name"]

    response = await api.patch(
        "/v1/talks/talk_a",
        files={
            "file": (
                "segundo.txt",
                b"segundo",
                "text/plain",
            ),
        },
        headers=headers,
    )

    assert response.status_code == 200, response.text

    second = await db["talks"].find_one(
        {
            "talk_id": "talk_a",
            "client_id": "empresa_a",
        }
    )

    second_blob = second[
        "file_storage"
    ]["blob_name"]

    assert second_blob != first_blob

    blobs = await _list_test_blobs(
        "empresa_a/talks/"
    )

    assert first_blob not in blobs
    assert second_blob in blobs

    response = await api.get(
        "/v1/talks/talk_a/file",
        headers=headers,
    )

    assert response.status_code == 200
    assert response.content == b"segundo"


@pytest.mark.asyncio
async def test_remove_talk_attachment_deletes_blob_and_metadata(
    api,
    db,
    seed,
    auth_headers,
):
    headers = auth_headers(
        user_id="admin_a",
        role="admin",
    )

    response = await api.patch(
        "/v1/talks/talk_a",
        files={
            "file": (
                "temporal.txt",
                b"temporal",
                "text/plain",
            ),
        },
        headers=headers,
    )

    assert response.status_code == 200

    before = await db["talks"].find_one(
        {
            "talk_id": "talk_a",
            "client_id": "empresa_a",
        }
    )

    blob_name = before[
        "file_storage"
    ]["blob_name"]

    response = await api.patch(
        "/v1/talks/talk_a",
        data={
            "remove_file": "true",
        },
        headers=headers,
    )

    assert response.status_code == 200, response.text

    after = await db["talks"].find_one(
        {
            "talk_id": "talk_a",
            "client_id": "empresa_a",
        }
    )

    assert after["file_id"] == ""
    assert after["file_url"] == ""
    assert after["file_name"] == ""
    assert after["file_content_type"] == ""
    assert after["file_size"] == 0
    assert after["file_storage"] is None

    blobs = await _list_test_blobs(
        "empresa_a/talks/"
    )

    assert blob_name not in blobs

    response = await api.get(
        "/v1/talks/talk_a/file",
        headers=headers,
    )

    assert response.status_code == 404


@pytest.mark.asyncio
async def test_delete_talk_deletes_attachment_blob(
    api,
    db,
    auth_headers,
):
    headers = auth_headers(
        user_id="admin_a",
        role="admin",
    )

    response = await api.post(
        "/v1/talks",
        data={
            "title": "Charla temporal",
            "month": "9",
            "year": "2026",
        },
        files={
            "file": (
                "temporal.txt",
                b"contenido",
                "text/plain",
            ),
        },
        headers=headers,
    )

    assert response.status_code == 200

    talk_id = response.json()["talk_id"]

    document = await db["talks"].find_one(
        {
            "talk_id": talk_id,
            "client_id": "empresa_a",
        }
    )

    blob_name = document[
        "file_storage"
    ]["blob_name"]

    response = await api.delete(
        f"/v1/talks/{talk_id}",
        headers=headers,
    )

    assert response.status_code == 200

    assert await db["talks"].find_one(
        {
            "talk_id": talk_id,
            "client_id": "empresa_a",
        }
    ) is None

    blobs = await _list_test_blobs(
        "empresa_a/talks/"
    )

    assert blob_name not in blobs


@pytest.mark.asyncio
async def test_talk_file_download_is_tenant_isolated(
    api,
    db,
    seed,
    auth_headers,
):
    await db["talks"].update_one(
        {
            "talk_id": "talk_a",
            "client_id": "empresa_a",
        },
        {
            "$set": {
                "file_name": "legacy.txt",
                "file_url": (
                    "data:text/plain;base64,"
                    + base64.b64encode(
                        b"privado"
                    ).decode("ascii")
                ),
            }
        },
    )

    response = await api.get(
        "/v1/talks/talk_a/file",
        headers=auth_headers(
            user_id="worker_b",
            client_id="empresa_b",
        ),
    )

    assert response.status_code == 404


@pytest.mark.asyncio
async def test_talk_attachment_over_10_mb_is_rejected(
    api,
    db,
    auth_headers,
):
    content = b"x" * (
        10 * 1024 * 1024 + 1
    )

    before = await _list_test_blobs(
        "empresa_a/talks/"
    )

    response = await api.post(
        "/v1/talks",
        data={
            "title": "Archivo demasiado grande",
            "month": "9",
            "year": "2026",
        },
        files={
            "file": (
                "grande.bin",
                content,
                "application/octet-stream",
            ),
        },
        headers=auth_headers(
            user_id="admin_a",
            role="admin",
        ),
    )

    assert response.status_code == 413

    assert await db["talks"].count_documents(
        {
            "client_id": "empresa_a",
            "title": "Archivo demasiado grande",
        }
    ) == 0

    after = await _list_test_blobs(
        "empresa_a/talks/"
    )

    assert after == before


@pytest.mark.asyncio
async def test_attendance_attachment_uses_blob_and_download_endpoint(
    api,
    db,
    auth_headers,
):
    content = b"respaldo asistencia"
    await db["talks"].insert_one({
        "talk_id": "talk_attachment", "client_id": "empresa_a",
        "title": "Uso de EPP", "month": "9", "year": "2026",
    })

    response = await api.post(
        "/v1/attendance",
        data={
            "topic": "Uso de EPP",
            "date": "2026-09-27",
            "area": "Planta",
            "talk_id": "talk_attachment",
            "attendees": "Ana Prueba",
            "feedback": "",
        },
        files={
            "file": (
                "asistencia.txt",
                content,
                "text/plain",
            ),
        },
        headers=auth_headers(
            user_id="admin_a",
            role="admin",
        ),
    )

    assert response.status_code == 200, response.text

    attendance_id = response.json()[
        "attendance_id"
    ]

    document = await db[
        "attendance"
    ].find_one(
        {
            "attendance_id": attendance_id,
            "client_id": "empresa_a",
        }
    )

    assert document is not None
    assert document["file_id"]
    assert document["file_url"] == ""
    assert document["file_name"] == "asistencia.txt"
    assert document["file_content_type"] == "text/plain"
    assert document["file_size"] == len(content)
    assert document["file_storage"]["provider"] == "azure_blob"
    assert document["file_storage"]["blob_name"].startswith(
        "empresa_a/attendance/"
    )

    response = await api.get(
        "/v1/attendance",
        headers=auth_headers(role="admin"),
    )

    assert response.status_code == 200

    listed = next(
        item
        for item in response.json()
        if item["attendance_id"] == attendance_id
    )

    assert listed["file_id"] == document["file_id"]
    assert listed["file_url"] == ""
    assert "file_storage" not in listed

    response = await api.get(
        f"/v1/attendance/{attendance_id}/file",
        headers=auth_headers(role="admin"),
    )

    assert response.status_code == 200
    assert response.content == content


@pytest.mark.asyncio
async def test_create_talk_cleans_blob_when_mongo_persistence_fails(
    api,
    auth_headers,
    monkeypatch,
):
    async def fail_create(
        self,
        client_id,
        data,
    ):
        raise RuntimeError(
            "fallo simulado de Mongo"
        )

    monkeypatch.setattr(
        TalksRepository,
        "create_talk",
        fail_create,
    )

    before = await _list_test_blobs(
        "empresa_a/talks/"
    )

    with pytest.raises(
        RuntimeError,
        match="fallo simulado de Mongo",
    ):
        await api.post(
            "/v1/talks",
            data={
                "title": "Rollback de archivo",
                "month": "9",
                "year": "2026",
            },
            files={
                "file": (
                    "rollback.txt",
                    b"contenido temporal",
                    "text/plain",
                ),
            },
            headers=auth_headers(
                user_id="admin_a",
                role="admin",
            ),
        )

    after = await _list_test_blobs(
        "empresa_a/talks/"
    )

    assert after == before
