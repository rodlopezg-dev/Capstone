# TT-15 — Responsabilidades de Reports Service e Incidents Service

## 1. Objetivo

Definir formalmente las responsabilidades de `reports-service` e
`incidents-service` respecto del ciclo de vida de reportes e incidentes
implementado por EP-03.

Esta definición refleja el estado actual del sistema y no introduce cambios
funcionales ni migraciones de datos.

## 2. Decisión arquitectónica

`reports-service` es la fuente canónica del ciclo de vida de reportes e
incidentes implementado actualmente por EP-03.

`incidents-service` no forma parte del flujo funcional activo de EP-03 y no
debe considerarse una segunda fuente de verdad para dicho ciclo de vida.

Cualquier integración, migración, reemplazo o retiro futuro de
`incidents-service` debe abordarse mediante una tarea arquitectónica y de
implementación independiente.

## 3. Reports Service

### Responsabilidades actuales

Reports Service gestiona:

- creación de reportes;
- consulta y listado;
- categorización;
- causas y precursores;
- consecuencia probable;
- análisis del supervisor;
- tratamiento;
- medidas de control;
- capacitación;
- plazo;
- feedback al trabajador;
- cambios de estado;
- evidencia inicial;
- evidencia de cierre;
- actividad y trazabilidad;
- estadísticas del trabajador;
- notificaciones asociadas al reporte;
- exportación y consultas administrativas.

### Persistencia

Colecciones principales:

- `reports`
- `notifications`
- `activity_log`

### Ciclo de vida canónico

```text
open
  ↓
en_proceso
  ↓
pending_closure
  ↓
closed
```

Las reglas y validaciones asociadas a este ciclo de vida se encuentran en
Reports Service.

## 4. Consumidores de Reports Service

### App / frontend

El frontend utiliza Reports Service para:

- crear reportes;
- listar reportes;
- gestionar reportes;
- categorizar;
- registrar análisis;
- registrar tratamiento;
- cambiar estados;
- asociar evidencia;
- consultar notificaciones;
- obtener estadísticas.

El módulo frontend denominado `api/incidents.ts` también utiliza actualmente
Reports Service y Alerts Service; su nombre no representa una dependencia real
de `incidents-service`.

### Dashboard Web

El frontend Web/Dashboard consume `/api/reports` para:

- Command Center;
- creación de reportes;
- gestión de incidentes;
- cierre y cambio de estados;
- reportería;
- visualización de riesgos.

El backend de Dashboard mantiene además acceso directo a la colección
`reports` para cálculos y agregaciones.

Este acceso directo constituye acoplamiento a persistencia y se considera
deuda arquitectónica independiente.

## 5. Incidents Service

### Estado actual

Incidents Service mantiene una colección independiente:

- `incidents`

Expone conceptualmente operaciones de:

- listado;
- consulta;
- creación.

El repositorio contiene además una operación de cambio de estado que no se
encuentra expuesta por el router actual.

### Problemas identificados

Actualmente existen inconsistencias entre Router, Service y Repository:

- la inyección de `IncidentService` no coincide con su constructor;
- el Service utiliza llamadas síncronas sobre métodos async del Repository;
- las firmas y argumentos entre capas están desalineados;
- el listado no obtiene correctamente el tenant autenticado;
- el endpoint de detalle utiliza `client_id` como identificador de ruta;
- el Repository espera `incident_id` más `client_id`;
- no existe suite de pruebas propia de `incidents-service`;
- no se detectaron consumidores funcionales de `/v1/incidents`.

## 6. Solapamientos

Existen capacidades conceptualmente duplicadas:

| Capacidad | Reports Service | Incidents Service |
|---|---|---|
| Crear recurso | Sí | Sí |
| Listar | Sí | Sí |
| Consultar detalle | Sí | Sí |
| Cambiar estado | Sí | Solo Repository |
| Análisis | Sí | No |
| Tratamiento | Sí | No |
| Evidencia | Sí | No |
| Actividad | Sí | No |
| Notificaciones | Sí | No |
| Uso real en EP-03 | Sí | No |
| Suite automatizada | Sí | No |

Mantener ambas colecciones como fuentes activas del mismo flujo generaría
riesgo de divergencia entre `reports` e `incidents`.

## 7. Límites de responsabilidad

### Reports Service

Es responsable del dominio funcional implementado actualmente por EP-03.

Debe seguir siendo la autoridad para los estados y datos de gestión mientras no
exista una migración arquitectónica explícita.

### Incidents Service

No participa del ciclo de vida canónico de EP-03.

Puede mantenerse como servicio independiente mientras se decide su propósito
futuro, pero no debe recibir escrituras duplicadas de Reports Service ni
convertirse implícitamente en una segunda fuente de verdad.

## 8. Relación con TT-07 / SCRUM-171

TT-07 corrige problemas internos de `incidents-service`, incluyendo:

- contratos entre Router, Service y Repository;
- inyección de dependencias;
- aislamiento multitenant;
- autenticación;
- pruebas automatizadas.

TT-07 se clasifica como deuda técnica independiente.

No es una dependencia para completar EP-03 porque el flujo funcional actual
opera sobre Reports Service.

Completar TT-07 tampoco implica automáticamente migrar EP-03 hacia
Incidents Service.

## 9. Deuda técnica identificada

Quedan fuera del alcance de TT-15:

1. Corregir `incidents-service` mediante TT-07.
2. Evaluar si `incidents-service` debe:
   - mantenerse para otro dominio;
   - integrarse con Reports Service;
   - reemplazarse;
   - o retirarse.
3. Eliminar configuraciones de Incidents Service que resulten obsoletas.
4. Revisar el acceso directo del Dashboard a la colección `reports`.
5. Definir contratos de eventos o APIs si en el futuro se separa formalmente
   el concepto de reporte del concepto de incidente.

Cada cambio funcional deberá implementarse mediante una tarea separada.

## 10. Resultado

```text
App / Web
    │
    ▼
Reports Service
    │
    ├── reports
    ├── notifications
    └── activity_log

    FUENTE CANÓNICA EP-03


Incidents Service
    │
    └── incidents

    SERVICIO PARALELO / NO CONSUMIDO POR EP-03
    Deuda técnica: TT-07
```

Esta decisión evita introducir una segunda fuente de verdad y conserva el
comportamiento funcional actualmente validado de EP-03.
