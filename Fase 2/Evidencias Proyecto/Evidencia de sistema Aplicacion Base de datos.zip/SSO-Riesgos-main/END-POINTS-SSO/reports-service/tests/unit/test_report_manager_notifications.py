import unittest

from app.services.srv_reports import ReportService


class FakeReportRepository:
    def __init__(self):
        self.notifications = []

    async def create_notification(
        self,
        client_id,
        user_id,
        data,
    ):
        self.notifications.append(
            {
                "client_id": client_id,
                "user_id": user_id,
                **data,
            }
        )


class FakeManagerRepository:
    def __init__(
        self,
        managers=None,
        error=None,
    ):
        self.managers = managers or []
        self.error = error
        self.calls = []

    async def get_report_managers(
        self,
        *,
        client_id,
        area_id,
        exclude_user_id=None,
    ):
        self.calls.append(
            {
                "client_id": client_id,
                "area_id": area_id,
                "exclude_user_id": exclude_user_id,
            }
        )

        if self.error:
            raise self.error

        return self.managers


class ReportManagerNotificationTests(
    unittest.IsolatedAsyncioTestCase
):
    async def test_notifies_unique_managers(self):
        report_repo = FakeReportRepository()

        manager_repo = FakeManagerRepository(
            managers=[
                {
                    "user_id": "supervisor_a",
                    "role": "supervisor",
                },
                {
                    "user_id": "admin_a",
                    "role": "admin",
                },
                {
                    "user_id": "supervisor_a",
                    "role": "supervisor",
                },
                {
                    "user_id": "creator_a",
                    "role": "admin",
                },
            ]
        )

        service = ReportService(
            report_repo,
            manager_repository=manager_repo,
        )

        await service._notify_report_managers(
            client_id="tenant_a",
            report_id="12",
            area_id="Linea 1",
            creator_user_id="creator_a",
        )

        self.assertEqual(
            [
                item["user_id"]
                for item in report_repo.notifications
            ],
            [
                "supervisor_a",
                "admin_a",
            ],
        )

        self.assertTrue(
            all(
                item["client_id"] == "tenant_a"
                for item in report_repo.notifications
            )
        )

        self.assertTrue(
            all(
                item["report_id"] == "12"
                for item in report_repo.notifications
            )
        )

    async def test_passes_tenant_area_and_creator(self):
        report_repo = FakeReportRepository()
        manager_repo = FakeManagerRepository()

        service = ReportService(
            report_repo,
            manager_repository=manager_repo,
        )

        await service._notify_report_managers(
            client_id="tenant_a",
            report_id="15",
            area_id="Linea 2",
            creator_user_id="worker_a",
        )

        self.assertEqual(
            manager_repo.calls,
            [
                {
                    "client_id": "tenant_a",
                    "area_id": "Linea 2",
                    "exclude_user_id": "worker_a",
                }
            ],
        )

    async def test_manager_service_failure_is_best_effort(
        self,
    ):
        report_repo = FakeReportRepository()

        manager_repo = FakeManagerRepository(
            error=RuntimeError(
                "users-service unavailable"
            )
        )

        service = ReportService(
            report_repo,
            manager_repository=manager_repo,
        )

        await service._notify_report_managers(
            client_id="tenant_a",
            report_id="20",
            area_id="Linea 1",
            creator_user_id="worker_a",
        )

        self.assertEqual(
            report_repo.notifications,
            [],
        )


if __name__ == "__main__":
    unittest.main()
