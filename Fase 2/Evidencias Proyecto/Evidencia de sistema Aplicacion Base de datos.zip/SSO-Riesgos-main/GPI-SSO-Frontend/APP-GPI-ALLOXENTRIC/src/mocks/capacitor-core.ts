export class WebPlugin {
  addListener() { return { remove: () => {} }; }
  removeAllListeners() { return Promise.resolve(); }
  notifyListeners() {}
}

export const Capacitor = {
  isNativePlatform: () => false,
  getPlatform: () => 'web',
  isPluginAvailable: () => false,
  convertFileSrc: (path: string) => path,
};

export const registerPlugin = (_name: string, _impl?: any) => {
  return new Proxy(new WebPlugin(), {
    get: (target: any, prop: string) => {
      if (prop in target) return target[prop];
      return () => Promise.resolve();
    }
  });
};

export const Plugins = new Proxy({}, {
  get: () => new Proxy({}, { get: () => () => Promise.resolve() })
});
