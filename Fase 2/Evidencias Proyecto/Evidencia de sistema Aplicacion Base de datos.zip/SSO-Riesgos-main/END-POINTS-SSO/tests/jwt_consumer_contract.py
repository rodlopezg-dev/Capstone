"""Run from each service's venv: python ../tests/jwt_consumer_contract.py app.dependencies.

No database connection is made. JWT_SECRET and INTERNAL_API_KEY must be test
values supplied in the process environment before importing the dependency.
"""

import asyncio
import importlib
import inspect
import sys
from pathlib import Path
from datetime import datetime, timedelta, timezone

import jwt
from fastapi import HTTPException
from fastapi.security import HTTPAuthorizationCredentials

sys.path.insert(0, str(Path.cwd()))


def check(module_name):
    module = importlib.import_module(module_name)
    settings = importlib.import_module("app.config").settings if not hasattr(module, "JWT_SECRET") else None
    secret = module.JWT_SECRET if settings is None else settings.JWT_SECRET
    algorithm = module.JWT_ALGORITHM if settings is None else settings.JWT_ALGORITHM

    def request(changes):
        payload = {
            "sub": "user_a", "client_id": "empresa_a", "role": "admin",
            "exp": datetime.now(timezone.utc) + timedelta(minutes=5),
            **changes,
        }
        payload = {key: value for key, value in payload.items()
                   if value is not None or key == "type"}
        token = jwt.encode(payload, secret, algorithm=algorithm)
        credentials = HTTPAuthorizationCredentials(scheme="Bearer", credentials=token)
        result = module.get_current_user(credentials)
        return asyncio.run(result) if inspect.isawaitable(result) else result

    for changes in ({}, {"type": "access"}):
        result = request(changes)
        assert result is not None
    for changes in (
        {"type": "refresh"}, {"type": "other"}, {"type": None}, {"exp": None},
        {"sub": None}, {"role": None}, {"client_id": None},
        {"sub": "  "}, {"role": "  "}, {"client_id": "  "},
        {"exp": datetime.now(timezone.utc) - timedelta(minutes=1)},
    ):
        try:
            request(changes)
        except HTTPException as exc:
            assert exc.status_code == 401, (module_name, changes, exc.status_code)
        else:
            raise AssertionError((module_name, changes))
    print(f"{module_name}: 13 JWT cases passed")


if __name__ == "__main__":
    check(sys.argv[1])
