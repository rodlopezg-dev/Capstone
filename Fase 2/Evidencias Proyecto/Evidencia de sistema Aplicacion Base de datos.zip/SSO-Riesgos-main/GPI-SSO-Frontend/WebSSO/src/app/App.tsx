import { useState, useEffect } from 'react';
import { LanguageProvider, useLanguage } from './context/LanguageContext';
import Login from './components/Login';
import CommandCenter from './components/CommandCenter';
import IncidentManagement from './components/IncidentManagement';
import DigitalTwin from './components/DigitalTwin';
import AlertCenter from './components/AlertCenter';
import Reports from './components/Reports';
import UserManagement from './components/UserManagement';
import { LayoutDashboard, FileWarning, Map, Bell, FileBarChart, Users, Menu, X, LogOut, Settings, Scale, BookOpen } from 'lucide-react';
import SettingsModule from './components/Settings';
import TypesWeightsManagement from './components/TypesWeightsManagement';
import SafetyTalks from './components/SafetyTalks';
import { ErrorBoundary } from './components/ErrorBoundary';
import {
  clearSession,
  isWebRole,
  normalizeWebRole,
  restoreSession,
  type SessionUser,
} from './api/auth';

import {
  AUTH_SESSION_INVALIDATED_EVENT,
} from './api/client';

function AppContent() {
  const { t } = useLanguage();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [activeModule, setActiveModule] = useState('command-center');
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [incidentAreaFilter, setIncidentAreaFilter] = useState<string | undefined>(undefined);
  const [currentUser, setCurrentUser] =
    useState<SessionUser | null>(null);

  const [checkingSession, setCheckingSession] = useState(true);
  // Restore session from localStorage on mount



  useEffect(() => {
    let cancelled = false;

    async function restore() {
      try {
        const session = await restoreSession();

        if (!cancelled && session) {
          setCurrentUser(session.user);
          setIsAuthenticated(true);
        }
      } catch (error) {
        console.error(
          'No se pudo restaurar la sesión:',
          error,
        );
      } finally {
        if (!cancelled) {
          setCheckingSession(false);
        }
      }
    }

    void restore();

    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    const handleInvalidSession = () => {
      setCurrentUser(null);
      setIsAuthenticated(false);
      setActiveModule('command-center');
    };

    window.addEventListener(
      AUTH_SESSION_INVALIDATED_EVENT,
      handleInvalidSession,
    );

    return () => {
      window.removeEventListener(
        AUTH_SESSION_INVALIDATED_EVENT,
        handleInvalidSession,
      );
    };
  }, []);




  const role = normalizeWebRole(currentUser?.role ?? '');

  // Módulos filtrados exactamente por la tabla de la imagen
  const allModules = [
    // W-01: todos los roles
    { id: 'command-center', name: t.nav.commandCenter, code: 'W-01', icon: LayoutDashboard, roles: ['admin', 'sso_manager', 'analyst', 'analista', 'jefe de area', 'supervisor', 'prevencion de riesgos', 'prevencionista'] },
    // W-02: gestión de incidentes — solo gerente SSO y jefe de área (analista monitorea, no gestiona)
    { id: 'incidents', name: t.nav.incidents, code: 'W-02', icon: FileWarning, roles: ['admin', 'sso_manager', 'jefe de area', 'supervisor', 'usuario'] },
    // W-02b: tipos y pesos — solo gerente SSO
    { id: 'types-weights', name: 'Precursores y Causas', code: 'W-02b', icon: Scale, roles: ['admin', 'sso_manager'] },
    // W-03: gemelo digital — solo gerente SSO
    { id: 'digital-twin', name: t.nav.digitalTwin, code: 'W-03', icon: Map, roles: ['admin', 'sso_manager'] },
    // W-04: alertas — todos los roles
    { id: 'alerts', name: t.nav.alerts, code: 'W-04', icon: Bell, roles: ['admin', 'sso_manager', 'analyst', 'jefe de area', 'supervisor'] },
    // W-05: reportes — solo gerente SSO y analista (jefe de área gestiona, no reportea)
    { id: 'reports', name: t.nav.reports, code: 'W-05', icon: FileBarChart, roles: ['admin', 'sso_manager', 'analyst'] },
    // W-06/W-07: gestión y configuración — solo gerente SSO
    { id: 'users', name: t.nav.users, code: 'W-06', icon: Users, roles: ['admin', 'sso_manager'] },
    { id: 'safety-talks', name: 'Dialogos SSO', code: 'W-08', icon: BookOpen, roles: ['admin', 'sso_manager', 'jefe de area', 'supervisor'] },
    { id: 'settings', name: t.nav.settings, code: 'W-07', icon: Settings, roles: ['admin', 'sso_manager', 'analyst', 'jefe de area', 'supervisor'] },
  ];
  const modules = allModules.filter(m => m.roles.includes(role));



  const handleLogin = (
    token: string,
    user: SessionUser
  ) => {
    const normalizedRole = normalizeWebRole(user.role);

    if (!isWebRole(normalizedRole)) {
      clearSession();

      alert(
        'Acceso denegado. Tu rol no tiene autorización para ingresar a WebSSO.'
      );

      return;
    }

    const authenticatedUser: SessionUser = {
      ...user,
      role: normalizedRole,
    };

    setCurrentUser(authenticatedUser);
    setIsAuthenticated(true);
    setActiveModule('command-center');
  };


  const handleLogout = () => {
    clearSession();
    setCurrentUser(null);
    setIsAuthenticated(false);
    setActiveModule('command-center'); // Siempre volver al inicio al cerrar sesión
  };

  const handleNavigateToIncidents = (areaFilter: string) => {
    setIncidentAreaFilter(areaFilter);
    setActiveModule('incidents');
  };

  if (checkingSession) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background text-muted-foreground">
        Validando sesión...
      </div>
    );
  }



  if (!isAuthenticated) {
    return <Login onLogin={handleLogin} />;
  }

  const renderModule = () => {
    switch (activeModule) {
      case 'command-center':
        return <CommandCenter onNavigateToIncidents={handleNavigateToIncidents} userRole={currentUser?.role} userAssignedAreas={currentUser?.assigned_areas} userAssignedZones={currentUser?.assigned_zones} />;
      case 'incidents':
        return (
          <IncidentManagement
            initialAreaFilter={incidentAreaFilter}
            userRole={currentUser?.role}
            userArea={currentUser?.area}
            userAssignedAreas={currentUser?.assigned_areas}
            userAssignedZones={currentUser?.assigned_zones}
            userId={currentUser?.user_id}
          />
        );
      case 'types-weights':
        return <TypesWeightsManagement />;
      case 'digital-twin':
        return <DigitalTwin />;
      case 'alerts':
        return <AlertCenter userRole={currentUser?.role} userAssignedAreas={currentUser?.assigned_areas} userAssignedZones={currentUser?.assigned_zones} />;
      case 'reports':
        return <Reports userRole={currentUser?.role} userAssignedAreas={currentUser?.assigned_areas} userAssignedZones={currentUser?.assigned_zones} />;
      case 'users':
        return <UserManagement />;
      case 'safety-talks':
        return <SafetyTalks userRole={role} />;
      case 'settings':
        return <SettingsModule userRole={currentUser?.role} />;
      default:
        return <CommandCenter onNavigateToIncidents={handleNavigateToIncidents} userRole={currentUser?.role} userAssignedAreas={currentUser?.assigned_areas} userAssignedZones={currentUser?.assigned_zones} />;
    }
  };

  return (
    <div className="h-screen w-full flex bg-background overflow-hidden">
      {/* Sidebar */}
      <aside className={`bg-sidebar border-r border-sidebar-border relative flex h-full min-h-0 flex-col transition-all duration-300 ${sidebarOpen ? 'w-72' : 'w-20 hover:w-72 group/sidebar'}`}>
        {/* Header */}
        <div className="h-20 border-b border-sidebar-border flex items-center justify-between px-4 overflow-hidden">
          <div className="flex items-center gap-3 min-w-0">
            <img
              src="/logo-vigia.png"
              alt="Vigía Industrial"
              className="w-10 h-10 object-contain shrink-0"
            />
            <div className={`transition-all duration-300 overflow-hidden whitespace-nowrap ${sidebarOpen ? 'opacity-100 max-w-xs' : 'opacity-0 max-w-0 group-hover/sidebar:opacity-100 group-hover/sidebar:max-w-xs'}`}>
              <p className="text-sm font-bold tracking-widest uppercase text-primary" style={{ fontFamily: 'var(--font-display)' }}>Vigía Industrial</p>
              <p className="text-xs text-muted-foreground">{t.login.subtitle}</p>
            </div>
          </div>
          <button onClick={() => setSidebarOpen(!sidebarOpen)} className="p-2 hover:bg-sidebar-accent rounded transition-colors shrink-0">
            {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>

        {/* Navigation */}
        <nav className="min-h-0 flex-1 overflow-y-auto p-4 space-y-2">
          {modules.map((module) => {
            const Icon = module.icon;
            const isActive = activeModule === module.id;

            return (
              <button
                key={module.id}
                onClick={() => { setActiveModule(module.id); if (module.id !== 'incidents') setIncidentAreaFilter(undefined); }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded transition-all ${isActive ? 'bg-primary text-primary-foreground shadow-lg' : 'hover:bg-sidebar-accent text-sidebar-foreground'
                  } ${!sidebarOpen && 'justify-center'}`}
              >
                <Icon size={20} className="shrink-0" />
                <div className={`flex-1 text-left transition-all duration-300 overflow-hidden ${sidebarOpen ? 'opacity-100 max-w-xs' : 'opacity-0 max-w-0 group-hover/sidebar:opacity-100 group-hover/sidebar:max-w-xs'}`}>
                  <div className="text-sm font-medium whitespace-nowrap">{module.name}</div>
                  <div className="text-xs opacity-70 whitespace-nowrap">{module.code}</div>
                </div>
              </button>
            );
          })}
        </nav>

        {/* Footer Info */}
        {sidebarOpen && (
          <div className="shrink-0 p-6 border-t border-sidebar-border space-y-3">
            <div className="text-xs text-muted-foreground">
              <div className="flex items-center justify-between mb-1">
                <span>{t.nav.version}</span>
                <span className="font-mono">1.0</span>
              </div>
              <div className="flex items-center justify-between">
                <span>{t.nav.user}</span>
                <span className="font-mono truncate max-w-[120px]">{currentUser?.user_id ?? currentUser?.role ?? 'Admin'}</span>
              </div>
              <div className="flex items-center justify-between mt-1">
                <span>Rol</span>
                <span className="font-mono capitalize">{currentUser?.role ?? ''}</span>
              </div>
            </div>
            <button onClick={handleLogout} className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-destructive/20 hover:bg-destructive/30 text-destructive rounded transition-all">
              <LogOut size={16} />
              <span className="text-sm font-medium">{t.nav.logout}</span>
            </button>
          </div>
        )}
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto relative flex flex-col">
        <ErrorBoundary>
          {renderModule()}
        </ErrorBoundary>
      </main>
    </div>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <AppContent />
    </LanguageProvider>
  );
}
