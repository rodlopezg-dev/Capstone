import pytest


@pytest.mark.asyncio
async def test_create_talk_persists_expected_workers(
    api,
    db,
    auth_headers,
    seed,
):
    await db["users"].update_one(
        {
            "user_id": "worker_a",
            "client_id": "empresa_a",
        },
        {
            "$set": {
                "role": "worker",
                "status": "active",
            },
        },
    )

    await db["users"].update_one(
        {
            "user_id": "worker_a2",
            "client_id": "empresa_a",
        },
        {
            "$set": {
                "role": "worker",
                "status": "active",
            },
        },
    )

    response = await api.post(
        "/v1/talks",
        data={
            "title": "Charla obligatoria",
            "month": "9",
            "year": "2026",
            "mandatory": "true",
            "expected_user_ids": (
                "worker_a,worker_a2"
            ),
        },
        headers=auth_headers(
            user_id="admin_a",
            role="admin",
        ),
    )

    assert response.status_code == 200, response.text

    talk = await db["talks"].find_one({
        "talk_id": response.json()["talk_id"],
        "client_id": "empresa_a",
    })

    assert talk is not None
    assert talk["mandatory"] is True
    assert talk["expected_user_ids"] == [
        "worker_a",
        "worker_a2",
    ]


@pytest.mark.asyncio
async def test_create_talk_rejects_expected_worker_from_other_tenant(
    api,
    db,
    auth_headers,
    seed,
):
    await db["users"].update_one(
        {
            "user_id": "worker_b",
            "client_id": "empresa_b",
        },
        {
            "$set": {
                "role": "worker",
                "status": "active",
            },
        },
    )

    response = await api.post(
        "/v1/talks",
        data={
            "title": "Charla inválida",
            "month": "9",
            "year": "2026",
            "mandatory": "true",
            "expected_user_ids": "worker_b",
        },
        headers=auth_headers(
            user_id="admin_a",
            role="admin",
        ),
    )

    assert response.status_code == 422
    assert response.json()["detail"] == (
        "Uno o más trabajadores esperados "
        "no son trabajadores activos de esta empresa."
    )


@pytest.mark.asyncio
async def test_expected_workers_endpoint_returns_configured_population(
    api,
    db,
    auth_headers,
    seed,
):
    await db["users"].update_one(
        {
            "user_id": "worker_a",
            "client_id": "empresa_a",
        },
        {
            "$set": {
                "role": "worker",
                "status": "active",
                "assigned_areas": ["Produccion"],
            },
        },
    )

    await db["talks"].insert_one({
        "talk_id": "talk_expected",
        "client_id": "empresa_a",
        "title": "Uso obligatorio de EPP",
        "month": "9",
        "year": "2026",
        "mandatory": True,
        "expected_user_ids": [
            "worker_a",
        ],
    })

    response = await api.get(
        "/v1/talks/talk_expected/expected-workers",
        headers=auth_headers(role="admin"),
    )

    assert response.status_code == 200

    data = response.json()

    assert data["talk_id"] == "talk_expected"
    assert data["mandatory"] is True
    assert data["expected_user_ids"] == [
        "worker_a",
    ]
    assert data["missing_user_ids"] == []

    assert [
        worker["user_id"]
        for worker in data["workers"]
    ] == ["worker_a"]


@pytest.mark.asyncio
async def test_expected_workers_does_not_resolve_other_tenant(
    api,
    db,
    auth_headers,
    seed,
):
    await db["talks"].insert_one({
        "talk_id": "talk_malformed",
        "client_id": "empresa_a",
        "title": "Legacy mal configurada",
        "month": "9",
        "year": "2026",
        "mandatory": True,
        "expected_user_ids": [
            "worker_b",
        ],
    })

    response = await api.get(
        "/v1/talks/talk_malformed/expected-workers",
        headers=auth_headers(role="admin"),
    )

    assert response.status_code == 200

    data = response.json()

    assert data["workers"] == []
    assert data["missing_user_ids"] == [
        "worker_b",
    ]


@pytest.mark.asyncio
async def test_expected_workers_supports_legacy_talk(
    api,
    auth_headers,
    seed,
):
    response = await api.get(
        "/v1/talks/talk_a/expected-workers",
        headers=auth_headers(role="admin"),
    )

    assert response.status_code == 200

    data = response.json()

    assert data["mandatory"] is False
    assert data["expected_user_ids"] == []
    assert data["workers"] == []
    assert data["missing_user_ids"] == []
