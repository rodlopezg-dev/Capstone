from io import BytesIO

import pytest
from openpyxl import load_workbook

from app.attendance_export import build_attendance_pdf, build_attendance_xlsx
from app.repositories.rep_talks import TalksRepository


class Cursor:
    def __init__(self, documents):
        self.documents = documents

    def sort(self, *_args):
        return self

    def __aiter__(self):
        self.iterator = iter(self.documents)
        return self

    async def __anext__(self):
        try:
            return next(self.iterator).copy()
        except StopIteration:
            raise StopAsyncIteration


class Collection:
    def __init__(self, documents):
        self.documents = documents

    def find(self, query, _projection=None):
        return Cursor([
            document for document in self.documents
            if all(
                document.get(key) in value["$in"]
                if isinstance(value, dict) and "$in" in value
                else document.get(key) == value
                for key, value in query.items()
            )
        ])

    async def find_one(self, query, _projection=None):
        return next((document.copy() for document in self.documents
                     if all(document.get(key) == value for key, value in query.items())), None)


@pytest.mark.asyncio
async def test_qr_identity_agrees_with_comparison_absences_and_stats():
    workers = [
        {"client_id": "a", "user_id": "u1", "status": "active", "role": "worker",
         "name": "Ana", "last_name": "Uno", "assigned_areas": ["Planta"]},
        {"client_id": "a", "user_id": "u2", "status": "active", "role": "worker",
         "name": "Beto", "last_name": "Dos", "assigned_areas": ["Planta"]},
        {"client_id": "b", "user_id": "u3", "status": "active", "role": "worker",
         "name": "Eva", "last_name": "Tres", "assigned_areas": ["Planta"]},
    ]
    talks = [{"client_id": "a", "talk_id": "t1", "title": "Seguridad",
              "month": "9", "year": "2026", "mandatory": True,
              "expected_user_ids": ["u1", "u2"]}]
    attendance = [
        {"client_id": "a", "talk_id": "t1", "source": "qr", "date": "2026-09-12",
         "area": "Planta", "attended_user_ids": ["u1"], "attendees": ["Beto Dos"]},
        {"client_id": "b", "talk_id": "t1", "source": "manual", "date": "2026-09-12",
         "area": "Planta", "attendees": ["Beto Dos"]},
    ]
    repo = TalksRepository({"users": Collection(workers), "talks": Collection(talks),
                            "attendance": Collection(attendance),
                            "talk_qr_sessions": Collection([]),
                            "attendance_participants": Collection([]),
                            "attendance_scans": Collection([])})

    comparison = await repo.attendance_comparison_for_talk("a", "t1")
    absences = await repo.absent_workers_for_talk("a", "t1")
    areas = await repo.attendance_stats_by_area("a")
    months = await repo.attendance_stats_by_month("a", "2026")

    assert comparison["attended_user_ids"] == ["u1"]
    assert absences["absent_user_ids"] == ["u2"]
    assert areas[0]["attendance_count"] == 1
    assert months[0]["attendance_count"] == 1


def test_xlsx_distinguishes_sheet_from_manual_and_qr():
    records = [
        {"source": "sheet", "attendees": ["Ana Uno"]},
        {"source": "manual", "attendees": ["Beto Dos"]},
        {"source": "qr", "attendees": ["Eva Tres"]},
    ]
    workbook = load_workbook(BytesIO(build_attendance_xlsx(records)))
    try:
        assert [workbook.active[f"D{row}"].value for row in (2, 3, 4)] == [
            "Hoja", "Manual", "QR"
        ]
    finally:
        workbook.close()

    pdf = build_attendance_pdf(records)
    assert pdf.startswith(b"%PDF-")


@pytest.mark.asyncio
async def test_qr_manual_and_ocr_scan_coexist_without_double_counting():
    workers = [
        {"client_id": "a", "user_id": "u1", "status": "active", "role": "worker",
         "name": "Ana", "last_name": "Uno", "assigned_areas": ["Planta"]},
        {"client_id": "a", "user_id": "u2", "status": "active", "role": "worker",
         "name": "Beto", "last_name": "Dos", "assigned_areas": ["Planta"]},
    ]
    talk = {"client_id": "a", "talk_id": "t1", "title": "Seguridad",
            "month": "9", "year": "2026", "mandatory": True,
            "expected_user_ids": ["u1", "u2"]}
    attendance = [
        {"client_id": "a", "talk_id": "t1", "source": "qr", "date": "2026-09-12",
         "area": "Planta", "attended_user_ids": ["u1", "u1"],
         "attendees": ["Ana Uno", "Ana Uno"]},
        {"client_id": "a", "talk_id": "t1", "source": "manual", "date": "2026-09-12",
         "area": "Planta", "attendees": ["Beto Dos", "Beto Dos"]},
    ]
    repo = TalksRepository({"users": Collection(workers),
                            "talks": Collection([talk]),
                            "attendance": Collection(attendance),
                            "talk_qr_sessions": Collection([]),
                            "attendance_participants": Collection([]),
                            "attendance_scans": Collection([
                                {"client_id": "a", "talk_id": "t1",
                                 "matched_count": 2}
                            ])})

    comparison = await repo.attendance_comparison_for_talk("a", "t1")
    absences = await repo.absent_workers_for_talk("a", "t1")
    areas = await repo.attendance_stats_by_area("a")
    months = await repo.attendance_stats_by_month("a", "2026")

    assert comparison["attended_user_ids"] == ["u1", "u2"]
    assert absences["absence_status"] == "no_absences"
    assert areas[0]["attendance_count"] == 2
    assert months[0]["attendance_count"] == 2
