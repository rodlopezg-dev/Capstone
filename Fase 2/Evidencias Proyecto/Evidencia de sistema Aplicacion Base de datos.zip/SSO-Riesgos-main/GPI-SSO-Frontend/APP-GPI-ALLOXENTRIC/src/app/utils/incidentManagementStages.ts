export type IncidentManagementStageId =
  | 'review'
  | 'analysis'
  | 'treatment'
  | 'closure'
  | 'validation';

export interface IncidentManagementStageDefinition {
  id: IncidentManagementStageId;
  label: string;
}

export const INCIDENT_MANAGEMENT_STAGES:
IncidentManagementStageDefinition[] = [
  { id: 'review', label: 'Revisión' },
  { id: 'analysis', label: 'Análisis' },
  { id: 'treatment', label: 'Tratamiento' },
  { id: 'closure', label: 'Solicitud de cierre' },
  { id: 'validation', label: 'Validación' },
];

export interface IncidentManagementStageSource {
  status?: string;
  causes?: string[];
  probable_consequence?: string;
  analysis?: string;
  control_measures?: string[];
  training?: string;
  deadline?: string;
  feedback?: string;
  closure_evidence?: unknown;
}

export interface IncidentManagementStageState {
  workflowStage: IncidentManagementStageId;
  maxAccessibleIndex: number;
  completedThroughIndex: number;
  readOnly: boolean;
}

function hasText(value?: string): boolean {
  return Boolean(value?.trim());
}

export function hasIncidentAnalysisProgress(
  report: IncidentManagementStageSource,
): boolean {
  return (
    Boolean(report.causes?.length)
    || hasText(report.probable_consequence)
    || hasText(report.analysis)
  );
}

export function hasIncidentTreatmentCompletion(
  report: IncidentManagementStageSource,
): boolean {
  return (
    Boolean(report.control_measures?.length)
    && hasText(report.training)
    && hasText(report.deadline)
    && hasText(report.feedback)
  );
}

export function getIncidentManagementStageIndex(
  stageId: IncidentManagementStageId,
): number {
  return INCIDENT_MANAGEMENT_STAGES.findIndex(
    stage => stage.id === stageId,
  );
}

export function getIncidentManagementStageState(
  report: IncidentManagementStageSource,
): IncidentManagementStageState {
  switch (report.status) {
    case 'open': {
      const hasAnalysis = hasIncidentAnalysisProgress(report);

      return {
        workflowStage: hasAnalysis ? 'analysis' : 'review',
        maxAccessibleIndex: 1,
        completedThroughIndex: hasAnalysis ? 0 : -1,
        readOnly: false,
      };
    }

    case 'en_proceso': {
      const treatmentComplete =
        hasIncidentTreatmentCompletion(report);

      return {
        workflowStage: treatmentComplete
          ? 'closure'
          : 'treatment',
        maxAccessibleIndex: treatmentComplete ? 3 : 2,
        completedThroughIndex: treatmentComplete ? 2 : 1,
        readOnly: false,
      };
    }

    case 'pending_closure':
      return {
        workflowStage: 'validation',
        maxAccessibleIndex: 4,
        completedThroughIndex: 3,
        readOnly: true,
      };

    case 'closed':
      return {
        workflowStage: 'validation',
        maxAccessibleIndex: 4,
        completedThroughIndex: 4,
        readOnly: true,
      };

    default:
      return {
        workflowStage: 'review',
        maxAccessibleIndex: 0,
        completedThroughIndex: -1,
        readOnly: true,
      };
  }
}

export function isIncidentManagementStageAccessible(
  state: IncidentManagementStageState,
  stageId: IncidentManagementStageId,
): boolean {
  const index = getIncidentManagementStageIndex(stageId);

  return (
    index >= 0
    && index <= state.maxAccessibleIndex
  );
}
