import unittest

from pydantic import ValidationError

from app.schemas.user import (
    UserProfileResponse,
    UserProfileUpdate,
)
from app.services.user_service import UserService


class FakeUserRepository:
    def __init__(self):
        self.calls = []
        self.document = {
            "user_id": "usr_a",
            "client_id": "tenant_a",
            "name": "Nombre",
            "last_name": "Original",
            "email": "usuario@example.com",
            "role": "worker",
            "assigned_areas": ["Linea 1"],
            "status": "active",
            "hashed_password": "NO_DEBE_SALIR",
        }

    async def get(self, client_id, user_id):
        self.calls.append(("get", client_id, user_id))

        if (
            client_id != self.document["client_id"]
            or user_id != self.document["user_id"]
        ):
            return None

        return dict(self.document)

    async def update(self, client_id, user_id, update_data):
        self.calls.append(
            ("update", client_id, user_id, dict(update_data))
        )

        if (
            client_id == self.document["client_id"]
            and user_id == self.document["user_id"]
        ):
            self.document.update(update_data)


class UserProfileTests(unittest.IsolatedAsyncioTestCase):
    async def test_profile_lookup_is_scoped_by_user_and_tenant(self):
        repo = FakeUserRepository()
        service = UserService(repo)

        profile = await service.get_user(
            "tenant_a",
            "usr_a",
        )

        self.assertEqual(profile["user_id"], "usr_a")
        self.assertEqual(profile["client_id"], "tenant_a")
        self.assertEqual(
            repo.calls,
            [("get", "tenant_a", "usr_a")],
        )

    async def test_profile_update_only_updates_self_service_fields(self):
        repo = FakeUserRepository()
        service = UserService(repo)

        result = await service.update_profile(
            "tenant_a",
            "usr_a",
            UserProfileUpdate(
                name="Nombre Nuevo",
                last_name="Apellido Nuevo",
            ),
        )

        self.assertEqual(result["name"], "Nombre Nuevo")
        self.assertEqual(
            result["last_name"],
            "Apellido Nuevo",
        )

        update_call = next(
            call
            for call in repo.calls
            if call[0] == "update"
        )

        self.assertEqual(
            update_call[3],
            {
                "name": "Nombre Nuevo",
                "last_name": "Apellido Nuevo",
            },
        )

    async def test_profile_update_ignores_null_fields(self):
        repo = FakeUserRepository()
        service = UserService(repo)

        result = await service.update_profile(
            "tenant_a",
            "usr_a",
            UserProfileUpdate(
                name=None,
                last_name=None,
            ),
        )

        self.assertEqual(
            result["name"],
            "Nombre",
        )

        self.assertEqual(
            result["last_name"],
            "Original",
        )

        self.assertFalse(
            any(
                call[0] == "update"
                for call in repo.calls
            )
        )

    def test_profile_update_rejects_administrative_fields(self):
        with self.assertRaises(ValidationError):
            UserProfileUpdate(
                name="Nombre",
                role="admin",
            )

        with self.assertRaises(ValidationError):
            UserProfileUpdate(
                name="Nombre",
                client_id="tenant_b",
            )

        with self.assertRaises(ValidationError):
            UserProfileUpdate(
                name="Nombre",
                assigned_areas=["Otra Area"],
            )

    def test_profile_response_does_not_expose_password_hash(self):
        raw = {
            "user_id": "usr_a",
            "client_id": "tenant_a",
            "name": "Nombre",
            "last_name": "Apellido",
            "email": "usuario@example.com",
            "role": "worker",
            "assigned_areas": [],
            "status": "active",
            "hashed_password": "SECRETO",
        }

        response = UserProfileResponse.model_validate(raw)

        self.assertNotIn(
            "hashed_password",
            response.model_dump(),
        )


if __name__ == "__main__":
    unittest.main()
