
import { useState, type FormEvent } from 'react';
import {
  Building2,
  Lock,
  User,
  AlertCircle,
} from 'lucide-react';

import { useLanguage } from '../context/LanguageContext';
import LanguageSelector from './LanguageSelector';

import {
  signIn,
  type SessionUser,
} from '../api/auth';

const ORGANIZATIONS = [
  // El backend remoto conserva este identificador interno para Empresa A.
  { id: 'cliente_prueba_123', label: 'Empresa A' },
  { id: 'empresa_b', label: 'Empresa B' },
] as const;

interface LoginProps {
  onLogin: (
    token: string,
    user: SessionUser
  ) => void;
}

export default function Login({ onLogin }: LoginProps) {
  const { t } = useLanguage();

  const [clientId, setClientId] = useState(
    ORGANIZATIONS[0].id,
  );
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (event: FormEvent) => {
    event.preventDefault();

    setError('');
    setIsLoading(true);

    try {
      const session = await signIn({
        client_id: clientId,
        email,
        password,
      });

      onLogin(session.token, session.user);
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : 'No se pudo conectar al servidor.'
      );
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-background relative overflow-y-auto py-8">
      <div className="absolute inset-0 opacity-20">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage:
              'linear-gradient(rgba(0, 229, 255, 0.07) 1px, transparent 1px), linear-gradient(90deg, rgba(0, 229, 255, 0.07) 1px, transparent 1px)',
            backgroundSize: '50px 50px',
          }}
        />
      </div>

      <div className="absolute top-20 left-20 w-96 h-96 bg-primary/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-20 right-20 w-96 h-96 bg-primary/10 rounded-full blur-3xl pointer-events-none" />

      <div className="absolute top-4 right-4 z-50">
        <LanguageSelector />
      </div>

      <div className="relative z-10 w-full max-w-md mx-4">
        <div className="bg-card border border-border rounded-lg p-8 shadow-2xl">
          <div className="text-center mb-8">
            <img
              src="/logo-vigia.png"
              alt="Vigía Industrial"
              className="w-28 h-28 mx-auto mb-4 object-contain"
            />

            <h1
              className="text-4xl mb-2 tracking-tight"
              style={{
                fontFamily: 'var(--font-display)',
                fontWeight: 700,
              }}
            >
              {t.login.title}
            </h1>

            <p className="text-muted-foreground text-sm">
              {t.login.subtitle}
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label
                htmlFor="login-tenant"
                className="text-sm text-muted-foreground mb-2 block"
              >
                Organización / Tenant
              </label>

              <div className="relative">
                <Building2
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"
                  size={18}
                />

                <select
                  id="login-tenant"
                  value={clientId}
                  onChange={(e) => setClientId(e.target.value)}
                  required
                  disabled={isLoading}
                  className="w-full appearance-none pl-10 pr-10 py-3 bg-secondary border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary transition-all"
                >
                  {ORGANIZATIONS.map((organization) => (
                    <option
                      key={organization.id}
                      value={organization.id}
                    >
                      {organization.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label
                htmlFor="login-email"
                className="text-sm text-muted-foreground mb-2 block"
              >
                {t.login.username}
              </label>

              <div className="relative">
                <User
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"
                  size={18}
                />

                <input
                  id="login-email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder={t.login.usernamePlaceholder}
                  autoComplete="username"
                  required
                  disabled={isLoading}
                  className="w-full pl-10 pr-4 py-3 bg-secondary border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary transition-all"
                />
              </div>
            </div>

            <div>
              <label
                htmlFor="login-password"
                className="text-sm text-muted-foreground mb-2 block"
              >
                {t.login.password}
              </label>

              <div className="relative">
                <Lock
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"
                  size={18}
                />

                <input
                  id="login-password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder={t.login.passwordPlaceholder}
                  autoComplete="current-password"
                  required
                  disabled={isLoading}
                  className="w-full pl-10 pr-4 py-3 bg-secondary border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary transition-all"
                />
              </div>
            </div>

            {error && (
              <div
                role="alert"
                className="flex items-center gap-2 p-3 bg-destructive/20 border border-destructive/50 rounded-lg text-sm text-destructive"
              >
                <AlertCircle size={16} className="shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={
                isLoading ||
                !clientId.trim() ||
                !email.trim() ||
                !password
              }
              className="w-full py-3 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90 transition-all disabled:opacity-50"
            >
              {isLoading ? t.login.verifying : t.login.login}
            </button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-xs text-muted-foreground">
              {t.login.version} 1.0
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
