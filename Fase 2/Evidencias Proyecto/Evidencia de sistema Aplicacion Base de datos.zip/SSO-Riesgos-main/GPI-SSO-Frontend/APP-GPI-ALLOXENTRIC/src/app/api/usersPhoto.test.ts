import {
  beforeEach,
  describe,
  expect,
  it,
  vi,
} from 'vitest';

import { apiFetch } from './client';
import { updateUserProfilePhoto } from './users';

vi.mock('./client', () => ({
  apiFetch: vi.fn(),
}));

const apiFetchMock = vi.mocked(apiFetch);

describe('profile photo API', () => {
  beforeEach(() => {
    apiFetchMock.mockReset();
  });

  it('uploads profile photo as FormData', async () => {
    apiFetchMock.mockResolvedValue({
      user_id: 'usr_demo',
      name: 'Usuario',
      last_name: 'Demo',
      email: 'demo@example.com',
      role: 'worker',
      assigned_areas: [],
      client_id: 'cliente_demo',
      status: 'active',
      profile_photo_url:
        '/local-evidence/profiles/avatar.png',
    });

    const file = new File(
      ['image-data'],
      'avatar.png',
      {
        type: 'image/png',
      },
    );

    await updateUserProfilePhoto(file);

    expect(apiFetchMock).toHaveBeenCalledOnce();

    const [path, options] =
      apiFetchMock.mock.calls[0];

    expect(path).toBe(
      '/v1/users/me/photo',
    );

    expect(options).toMatchObject({
      method: 'PUT',
      base: 'users',
    });

    expect(
      options?.body,
    ).toBeInstanceOf(FormData);

    const form =
      options?.body as FormData;

    const uploaded =
      form.get('file');

    expect(
      uploaded,
    ).toBeInstanceOf(File);

    const uploadedFile =
      uploaded as File;

    expect(uploadedFile.name).toBe(
      'avatar.png',
    );
    expect(uploadedFile.type).toBe(
      'image/png',
    );
    expect(uploadedFile.size).toBe(
      file.size,
    );
    expect(
      await uploadedFile.text(),
    ).toBe('image-data');
  });
});
