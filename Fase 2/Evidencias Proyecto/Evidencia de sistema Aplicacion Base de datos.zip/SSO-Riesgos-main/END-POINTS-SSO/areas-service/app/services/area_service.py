from typing import List
from fastapi import HTTPException
from app.repositories.area_repo import AreaRepository
from app.schemas.area import AreaCreate, AreaUpdate, AreaResponse


class AreaService:
    def __init__(self, repo: AreaRepository):
        self.repo = repo

    async def create_area(self, client_id: str, area_in: AreaCreate) -> AreaResponse:
        # Convertimos el modelo Pydantic a diccionario
        data = area_in.model_dump()
        result = await self.repo.create(client_id, data)
        return AreaResponse(**result)

    async def get_areas(self, client_id: str) -> List[AreaResponse]:
        results = await self.repo.get_all(client_id)
        return [AreaResponse(**r) for r in results]

    async def get_area(self, client_id: str, area_id: str) -> AreaResponse:
        result = await self.repo.get_by_id(client_id, area_id)
        if not result:
            raise HTTPException(status_code=404, detail="Área no encontrada")
        return AreaResponse(**result)

    async def update_area(
        self, client_id: str, area_id: str, area_in: AreaUpdate
    ) -> AreaResponse:
        # exclude_unset=True ignora los campos que el usuario no envió en el PATCH
        update_data = area_in.model_dump(exclude_unset=True)

        if not update_data:
            # Si no envió nada para actualizar, devolvemos el área tal cual está
            return await self.get_area(client_id, area_id)

        result = await self.repo.update(client_id, area_id, update_data)
        if not result:
            raise HTTPException(status_code=404, detail="Área no encontrada")
        return AreaResponse(**result)

    async def delete_area(self, client_id: str, area_id: str) -> dict:
        success = await self.repo.delete(client_id, area_id)
        if not success:
            raise HTTPException(status_code=404, detail="Área no encontrada")
        return {"detail": "Área eliminada correctamente"}
