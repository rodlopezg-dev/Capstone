from datetime import datetime, timedelta, timezone

import jwt
import pytest
from fastapi import HTTPException
from fastapi.security import HTTPAuthorizationCredentials

from app import dep_reports


TEST_SECRET = "reports-auth-test-secret-32-bytes-minimum"
TEST_ALGORITHM = "HS256"


@pytest.fixture(autouse=True)
def configure_jwt(monkeypatch):
    monkeypatch.setattr(
        dep_reports,
        "JWT_SECRET",
        TEST_SECRET,
    )
    monkeypatch.setattr(
        dep_reports,
        "JWT_ALGORITHM",
        TEST_ALGORITHM,
    )


def bearer(token: str) -> HTTPAuthorizationCredentials:
    return HTTPAuthorizationCredentials(
        scheme="Bearer",
        credentials=token,
    )


def test_missing_credentials_returns_401():
    with pytest.raises(HTTPException) as exc:
        dep_reports.get_current_user(None)

    assert exc.value.status_code == 401
    assert exc.value.detail == "Token requerido"


def test_invalid_token_returns_401():
    with pytest.raises(HTTPException) as exc:
        dep_reports.get_current_user(
            bearer("token-invalido")
        )

    assert exc.value.status_code == 401
    assert exc.value.detail == "Token requerido"


def test_expired_token_returns_401():
    token = jwt.encode(
        {
            "sub": "user_test",
            "client_id": "tenant_test",
            "role": "admin",
            "exp": datetime.now(timezone.utc)
            - timedelta(minutes=1),
        },
        TEST_SECRET,
        algorithm=TEST_ALGORITHM,
    )

    with pytest.raises(HTTPException) as exc:
        dep_reports.get_current_user(
            bearer(token)
        )

    assert exc.value.status_code == 401
    assert exc.value.detail == "Token requerido"


def test_valid_token_returns_current_user():
    token = jwt.encode(
        {
            "sub": "user_test",
            "client_id": "tenant_test",
            "role": "admin",
            "exp": datetime.now(timezone.utc)
            + timedelta(minutes=5),
        },
        TEST_SECRET,
        algorithm=TEST_ALGORITHM,
    )

    current_user = dep_reports.get_current_user(
        bearer(token)
    )

    assert current_user == {
        "user_id": "user_test",
        "client_id": "tenant_test",
        "role": "admin",
    }
