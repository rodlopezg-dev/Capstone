# EP-04 / TT-17 y TT-18 — revisión técnica previa a commits

Fecha de revisión: 2026-10-07. Base: `main` en `95a2d92`, con cambios locales pendientes. Esta revisión contrasta el diff y los archivos sin seguimiento con `ep04-auditoria.md`, `ep04-tt18-permisos.md`, `ep04-fase1-preparacion.md` y `ep04-tt18-implementacion.md`. Los hallazgos son propuestas; **no se modificó código ni se preparó ningún commit**.

## Estado real del árbol y alcance

`git status --short` antes de escribir este informe mostró 29 archivos rastreados modificados y 12 archivos sin seguimiento. `git diff --stat` mostró 326 inserciones y 183 eliminaciones en los 29 archivos rastreados; esa cifra excluye los archivos nuevos. Se revisaron el diff rastreado y los contenidos nuevos. Los archivos nuevos eran: `auth-service/tests/test_jwt_contract.py`, `talks-service/tests/unit/{test_attendance_access_contract.py,test_attendance_consistency.py,test_attendance_projection.py,test_own_attendance.py}`, `END-POINTS-SSO/tests/jwt_consumer_contract.py`, `APP-GPI-ALLOXENTRIC/src/app/utils/{talkPermissions.ts,talkPermissions.test.ts}` y los cuatro informes de EP-04 citados arriba. Este informe es el decimotercer archivo sin seguimiento.

El diff rastreado comprende las dependencias JWT de `auth`, `alerts`, `areas`, `dashboard`, `digital-twin`, `incidents`, `reports`, `users`, `workers` y `talks`; emisión/renovación de `auth`; `talks-service/app/{attendance_export.py,repositories/rep_talks.py,routers/rt_talks.py}`; 13 archivos de integración de `talks-service`; y `SafetyTalksMobile.tsx`. No se detectaron cambios locales en bases de datos, migraciones, `.env` ni bundles compilados.

## Hallazgos, ordenados por severidad

### Alta — H1: renovación mantiene permisos de una cuenta desactivada o degradada

**Evidencia.** `auth-service/app/services/auth_service.py:40-48` consulta al usuario y exige `status=active` solamente durante `login_user`. `AuthService.verify_token` (`:100-122`) verifica firma, vencimiento, tipo y claims, pero no el estado actual. `auth-service/app/routers/auth.py:25-49` construye el siguiente access token con `sub`, `role`, `client_id` y áreas copiados del refresh recibido y devuelve el mismo refresh. Este refresh dura siete días (`auth_service.py:76-87`). `GET /v1/auth/me` (`auth.py:53-63`) también devuelve claims firmados sin consultar el estado. Los consumidores validan el JWT, no una revocación central.

**Impacto.** Un refresh emitido mientras el usuario era administrador puede seguir generando access tokens de administrador después de desactivarlo o cambiarle el rol/tenant en el directorio, hasta el vencimiento del refresh. No requiere falsificar JWT. El test `auth-service/tests/test_jwt_contract.py` cubre login inactivo, pero no desactivación o degradación *después* de emitir refresh. La implementación anterior documenta este límite; sigue abierto para esta revisión.

**Propuesta previa a cualquier corrección.** Resolver el usuario por `sub` y `client_id` mediante una fuente confiable en `/refresh`, exigir estado activo y decidir si el rol/áreas del token deben coincidir con el registro vigente o renovarse desde él. Definir revocación/rotación de refresh y probar baja, degradación y cambio de tenant. Aclarar el comportamiento ante indisponibilidad del servicio de usuarios: denegar la renovación. Mantener la compatibilidad de access legacy sin `type` durante la transición aprobada.

### Alta — H2: ruta nominativa alternativa para `jefe de area` fuera del RBAC de talks

**Evidencia.** En el código actual, `users-service/app/routers/users.py:15-21` permite a `"jefe de area"` llamar `GET /v1/admin/users/` y pasa solo `client_id` a `UserService.get_all_users` (`app/services/user_service.py:34-40`). `UserRepository.get_all` (`app/repositories/user_repo.py:17-24`) consulta **todos** los usuarios del tenant y retira únicamente `_id` y `hashed_password`; no filtra por área. Este camino no forma parte del diff de TT-18, pero sí de la superficie alternativa solicitada. El alias `jefe_de_area` ni siquiera coincide con el literal autorizado aquí.

**Impacto.** Un jefe de área representado con el rol literal `jefe de area` puede leer la nómina global de su tenant aun cuando las siete rutas de asistencia, las exportaciones y `GET /v1/attendance` deniegan acceso por falta de ámbito verificable. No se constató fuga entre tenants: la consulta sí usa `client_id`. La ruta expone datos nominativos generales, aunque no los registros de asistencia.

**Propuesta previa a cualquier corrección.** Alinear `users-service` con la política aprobada: comprobación de áreas contra datos persistidos y filtrado por área, o denegar al jefe hasta disponer de esa información. Agregar una prueba ASGI/contrato que compruebe que el jefe no recibe usuarios de otras áreas. Coordinar alias de rol entre servicios y frontend.

### Media — H3: un `talk_id` enviado vacío se interpreta como ausencia legacy

**Evidencia.** `talks-service/app/routers/rt_talks.py:1110-1126` usa `talk_id: str | None = Form(None)` y luego comprueba `if talk_id is not None and not talk_id.strip()`. Una prueba aislada de FastAPI/ASGI con la misma firma confirmó que tanto omitir el campo como enviar `talk_id=""` producen `None`; `"   "` sí llega como cadena y se rechaza. Por ello, el campo vacío explícito omite la comprobación de pertenencia y termina en `create_attendance` con `talk_id=""` (`:1159-1172`). Un archivo adjunto todavía se rechaza sin charla (`:1130-1135`). La prueba ASGI `test_manual_post_validates_explicit_talk_before_writing` no incluye la cadena vacía.

**Impacto.** No permite asociar asistencia a otra charla ni subir una hoja sin charla, pero amplía la excepción legacy a una solicitud que sí incluyó el campo. La aceptación de formularios legacy que envían campo vacío debe decidirse explícitamente antes de llamarlo defecto contractual definitivo.

**Propuesta previa a cualquier corrección.** Fijar si legacy significa campo omitido o también campo vacío. Si es solo omitido, distinguir presencia en `Request.form()` antes de normalizar y devolver 422 al vacío; añadir casos ASGI con y sin archivo que certifiquen cero llamadas de escritura/subida. Si ambos son legacy, documentar esa semántica y probarla.

### Media — H4: los datos de prueba de integración ocultan inconsistencias de identidad/rol

**Evidencia.** Se sustituyeron tokens `supervisor`/`worker` por `admin` para adaptar la nueva política, manteniendo identificadores como `supervisor_a` (`talks-service/tests/integration/test_expected_workers.py:49-50`, `test_talk_attachments.py:60-61`) y `worker_b` (`test_attendance_sheet.py:302-304`, `test_ocr_attendance.py:198-200`). En OCR, la comprobación de miembro (`rt_talks.py:1214-1229`) verifica `user_id`, `client_id` y `status`, pero no que el rol persistido coincida con el JWT. Las suites de integración solo se recopilaron; no demuestran el comportamiento en Mongo.

**Impacto.** Estos fixtures prueban decisiones basadas en el claim `role`, pero no representan una sesión normal de un administrador ni detectan una degradación de rol posterior a la emisión. Debilitan la señal de regresión; la posibilidad de rol obsoleto se materializa en H1.

**Propuesta previa a cualquier corrección.** Crear usuarios administradores reales en los fixtures y emitir tokens con identidad/rol coherentes. Mantener pruebas separadas para claims obsoletos y documentar la fuente de autoridad esperada. Ejecutar integración solo en un Mongo de prueba autorizado en otra fase.

### Baja / riesgo de evolución — H5: el estado móvil no se sincroniza con una renovación que cambie claims

**Evidencia.** `APP-GPI-ALLOXENTRIC/src/app/api/client.ts:156-221` renueva por `/v1/auth/refresh`, guarda access/refresh y no actualiza el objeto de usuario en memoria. `src/app/api/auth.ts:221-275` reconstruye el usuario desde `/me` únicamente en `restoreSession`. `SafetyTalksMobile.tsx:274-277` usa `userRole` recibido y la nueva función `canManageTalkAttendance`. Actualmente el backend vuelve a firmar el mismo rol, por lo que esto no produce por sí solo un desajuste nuevo; si se resuelve H1 renovando desde el directorio, la interfaz puede mantener controles visuales antiguos hasta restaurar sesión.

**Propuesta.** Al cambiar el contrato de renovación, coordinar actualización del perfil/rol en la aplicación o invalidar la sesión tras una degradación; probar renovación y permisos visuales. El backend debe seguir siendo la autoridad.

## Controles revisados y límites de prueba

**JWT.** La emisión nueva añade `type=access` en login (`auth_service.py:60-74`) y refresh (`auth.py:31-42`). `AuthService.verify_token` y las nueve dependencias consumidoras modificadas, incluida `talks-service`, exigen `exp`, `sub`, `role` y `client_id` de tipo cadena no vacía, rechazan refresh y tipos desconocidos, y aceptan temporalmente access sin `type`. El script contractual ejecutado contra los ocho consumidores ajenos a talks verificó 13 variantes por servicio, sin conexión DB. La aceptación legacy carece de fecha/criterio de retirada; esto es deuda deliberada, no un hallazgo de incumplimiento actual. `auth-service/app/dependencies.py` aplica su verificador a `/me`.

**RBAC y rutas alternativas.** `rt_talks.py:43-76` permite solo `admin`/`sso_manager` (normalizando guion bajo y espacios) en las siete rutas auditadas: PDF, XLSX, estadísticas por área, estadísticas mensuales, trabajadores esperados, comparación y ausencias (`:562-660,824-1088`). El mismo control protege `GET /v1/attendance` global, `POST /v1/attendance`, descarga de hoja, gestión de charlas, QR de emisión y OCR. Supervisores/jefes quedan denegados porque no hay ámbito de charla verificable. `GET /v1/talks` permite admin y worker, pero retira `expected_user_ids` para worker (`:314-329`); descarga de archivo de charla permite a esos mismos roles y consulta `get_talk(client_id,talk_id)` (`:663-686`). Debe mantenerse la separación entre adjunto de charla y hoja nominativa de asistencia; el contenido concreto de archivos legacy no se validó. La descarga de hoja (`:689-706`) exige administrador. QR de registro (`:720-772`) ata token QR y usuario al tenant, valida sesión activa y obtiene la identidad del usuario autenticado; OCR (`:1185-1247`) exige administrador, membresía activa y charla del tenant. Ninguna de estas rutas concede acceso global alternativo a supervisor.

**Datos propios.** `GET /v1/attendance` para `worker`/`usuario` usa `list_own_attendance` (`rt_talks.py:1091-1103`), que consulta `client_id`, `source=qr` y `attended_user_ids=user_id` y proyecta solo metadatos sin nombres ajenos (`rep_talks.py:640-661`). Esto preserva el estado QR móvil, pero deliberadamente no muestra asistencias manuales/OCR sin identidad inequívoca. Los reportes globales usan `client_id` del JWT, no del query. La prueba de proyección de ST-252 comprueba el `source` de asistencia mensual (`rep_talks.py:1073-1083`); la estadística por área también lo proyecta (`:874-883`). En ambas se excluye la recuperación por nombre de QR y de registros con IDs directos (`:897-929,1151-1164`). Cobertura observada sigue sin equivaler a cumplimiento de charlas obligatorias; `mandatory` y `expected_user_ids` se evalúan por charla en la comparación/ausencias.

**POST de asistencia.** La secuencia de aplicación es autenticación JWT → RBAC → consulta `get_talk(client_id,talk_id)` si hay ID → comprobación de duplicado de hoja → `_store_attachment` → `create_attendance` (`rt_talks.py:1105-1182`). Las pruebas ASGI sustituyen repositorio y Blob: token/claim/rol inválido no invoca repositorio; charla ajena devuelve 404 con solo `get_talk` del tenant y no invoca Blob ni `create_attendance` (`test_attendance_access_contract.py:242-377`). El código demuestra que las comprobaciones preceden a la escritura de aplicación. No hay una prueba combinada de *cada* rechazo con archivo adjunto; FastAPI puede procesar/spool el multipart antes de ejecutar el handler, lo que no equivale a subida a Blob ni escritura Mongo. No se probó una carrera entre consulta de charla y escritura, ni fallo real de Blob/Mongo.

## Pruebas de esta revisión

| Comando / modalidad | Resultado | Límite |
| --- | --- | --- |
| `talks-service`: `TEST_MONGO_URI=mongodb://127.0.0.1:27017 TEST_MONGO_DB=sso_riesgo_qr_test PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -m pytest tests/unit -q` | **215 passed** | Colecciones falsas; sin fixture de integración ni escritura Mongo. |
| `auth-service`: `.venv/bin/python -m unittest discover -s tests -p test_jwt_contract.py -v` | **4 passed** | No cubre baja/degradación posterior al login. |
| `END-POINTS-SSO/tests/jwt_consumer_contract.py`, desde los venv de alerts, areas, dashboard, digital-twin, incidents, reports, users y workers, con `JWT_SECRET` e `INTERNAL_API_KEY` de prueba solo en el proceso | **13 casos por cada uno de 8 consumidores** | El primer intento sin variables de prueba falló en cuatro servicios por clave ausente; se repitió con valores ficticios. Sin llamadas DB. |
| `APP-GPI-ALLOXENTRIC`: `npm test -- --run` | **34 archivos, 259 tests passed** | No es prueba visual ni flujo móvil de extremo a extremo. |
| `talks-service`: `pytest tests/integration --collect-only -q`, con URI/DB ficticias | **106 tests recopilados** | Ninguno ejecutado. |
| `reports-service`: `pytest tests/unit/test_azure_blob_service.py -q` excluyendo los dos casos async de subida | **5 passed, 2 deselected** | Todo simulado; no Azure real. |
| `git diff --check` | **exit 0** | Solo diff rastreado; verificar de nuevo después de preparar commits. |
| FastAPI/ASGI aislado con `talk_id: str | None = Form(None)` | Omitido y `""` devuelven `None`; espacios conservados | No invoca el servicio de talks. |

**Suite Azure Blob detenida.** `timeout 12s .venv/bin/python -m pytest tests/unit/test_azure_blob_service.py -vv -s -o faulthandler_timeout=5` terminó con código **124** tras marcar el primer caso **PASSED**. `tests/unit/test_azure_blob_service.py:7-45` reemplaza `_sync_upload` con una función local; no abrió almacenamiento Azure. La traza de `faulthandler` quedó en `pytest_asyncio._scoped_runner` → `asyncio.runners.close` → `loop.run_until_complete`, durante teardown. Un programa mínimo con `asyncio.run(asyncio.to_thread(lambda: 1))` imprimió el resultado y también terminó por timeout (124) antes de salir de `asyncio.run`. Esto apunta al cierre del ejecutor de `asyncio.to_thread` en este entorno Python 3.14, no a una llamada de red de Azure. Los dos casos async **no se declaran aprobados**. Repetirlos con un runtime compatible o una estrategia de test que controle el ejecutor, siempre sin almacenamiento real.

**No ejecutado.** Pruebas de integración de talks (escriben Mongo); cualquier prueba contra Mongo o Blob/Azurite real; comprobación visual de la app; despliegue. No se modificó ninguna DB, migración, `.env` ni bundle.

## Separación propuesta de commits (sin staging actual)

La separación requiere revisar `git add -p` porque `rep_talks.py` mezcla TT-17 y TT-18. Las rutas son relativas a la raíz del repositorio.

| Commit | Archivos y hunks propuestos |
| --- | --- |
| **A. TT-17: estadísticas y exportaciones** | `END-POINTS-SSO/talks-service/app/attendance_export.py` completo; `app/repositories/rep_talks.py` **solo** hunks actuales `@@ -767...`, `@@ -852...`, `@@ -870...`, `@@ -895...`, `@@ -961...`, `@@ -1044...`, `@@ -1118...` (comentarios, proyección `source`, precedencia de IDs y fallback manual); `tests/unit/test_attendance_consistency.py` y `test_attendance_projection.py`. |
| **B. TT-18: autenticación JWT** | `auth-service/app/{dependencies.py,routers/auth.py,services/auth_service.py}`, `auth-service/tests/test_jwt_contract.py`; dependencias de `alerts`, `areas`, `dashboard`, `digital-twin`, `incidents`, `reports`, `users`, `workers` y `talks-service/app/dep_talks.py`; `END-POINTS-SSO/tests/jwt_consumer_contract.py`. Considerar H1 antes de cerrar este commit. |
| **C. TT-18: RBAC y asistencia** | `talks-service/app/routers/rt_talks.py` completo; `app/repositories/rep_talks.py` **solo** primer hunk `@@ -637,6 +637,29 @@` (`list_own_attendance`); `tests/unit/test_attendance_access_contract.py` y `test_own_attendance.py`; los 13 `tests/integration/test_{absence_states,absence_tenant_isolation,absent_workers,absent_workers_functional,attendance_comparison,attendance_export_pdf,attendance_export_xlsx,attendance_sheet,attendance_stats,expected_workers,ocr_attendance,qr_attendance_router,talk_attachments}.py`; `APP-GPI-ALLOXENTRIC/src/app/pages/SafetyTalksMobile.tsx` y `src/app/utils/{talkPermissions.ts,talkPermissions.test.ts}`. Considerar H2-H4 y los fixtures antes de cerrar este commit. |
| **D. Documentación y pruebas complementarias** | `docs/{ep04-auditoria.md,ep04-tt18-permisos.md,ep04-fase1-preparacion.md,ep04-tt18-implementacion.md,ep04-tt18-revision.md}`. Si se agregan pruebas transversales para H1-H4, ubicarlas con el código que protegen en B/C o reservar aquí solo las que no cambian contrato. |

Al aplicar el plan, comprobar que A no incluye `list_own_attendance` y que C no arrastra los cambios de `source`/cobertura de A. Revisar cada diff staged; este informe no ejecutó `git add`, `commit`, `push` ni `merge`.

## Veredicto

**Requiere ajustes antes de preparar commits para cierre de EP-04.** Los controles JWT de tipo/claims y el RBAC específico de talks tienen pruebas unitarias favorables y el POST rechaza accesos inválidos antes de escribir en la aplicación. H1 deja viable la renovación de permisos obsoletos; H2 deja un listado nominativo global por una ruta alternativa; H3 necesita decisión contractual; H4 reduce la validez de las pruebas de integración adaptadas. La suite de Blob y las pruebas de integración permanecen sin ejecución completa por los límites indicados. No se alteró el código al emitir este veredicto.
