from io import BytesIO
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)


def _text(value) -> str:
    value = str(value or "").strip()
    return value or "-"


def _paragraph(value, style):
    return Paragraph(
        escape(_text(value)),
        style,
    )


def _source_label(record) -> str:
    source = str(record.get("source") or "").strip().lower()
    return {"qr": "QR", "sheet": "Hoja"}.get(source, "Manual")


def build_attendance_pdf(
    records,
    *,
    month=None,
    year=None,
) -> bytes:
    buffer = BytesIO()

    document = SimpleDocTemplate(
        buffer,
        pagesize=landscape(A4),
        rightMargin=10 * mm,
        leftMargin=10 * mm,
        topMargin=10 * mm,
        bottomMargin=10 * mm,
        title="Registros de asistencia",
    )

    styles = getSampleStyleSheet()

    title_style = ParagraphStyle(
        "AttendanceTitle",
        parent=styles["Title"],
        alignment=TA_CENTER,
        fontSize=16,
        leading=20,
        spaceAfter=8,
    )

    cell_style = ParagraphStyle(
        "AttendanceCell",
        parent=styles["BodyText"],
        fontSize=7,
        leading=9,
    )

    header_style = ParagraphStyle(
        "AttendanceHeader",
        parent=cell_style,
        fontName="Helvetica-Bold",
        textColor=colors.white,
    )

    story = [
        Paragraph(
            "Reporte de asistencia",
            title_style,
        ),
    ]

    period_parts = []

    if month:
        period_parts.append(
            f"Mes: {int(month):02d}"
        )

    if year:
        period_parts.append(
            f"Año: {year}"
        )

    if period_parts:
        story.append(
            Paragraph(
                " | ".join(period_parts),
                styles["BodyText"],
            )
        )
        story.append(Spacer(1, 5 * mm))

    table_data = [[
        _paragraph("Fecha", header_style),
        _paragraph("Charla / tema", header_style),
        _paragraph("Área", header_style),
        _paragraph("Tipo", header_style),
        _paragraph("Cantidad", header_style),
        _paragraph("Asistentes", header_style),
        _paragraph("Retroalimentación", header_style),
    ]]

    for record in records:
        attendees = record.get(
            "attendees"
        ) or []

        attendees_text = ", ".join(
            str(item)
            for item in attendees
            if str(item).strip()
        )

        source = _source_label(record)

        table_data.append([
            _paragraph(
                record.get("date"),
                cell_style,
            ),
            _paragraph(
                record.get("talk_title")
                or record.get("topic"),
                cell_style,
            ),
            _paragraph(
                record.get("area"),
                cell_style,
            ),
            _paragraph(
                source,
                cell_style,
            ),
            _paragraph(
                len(attendees),
                cell_style,
            ),
            _paragraph(
                attendees_text,
                cell_style,
            ),
            _paragraph(
                record.get("feedback"),
                cell_style,
            ),
        ])

    if not records:
        table_data.append([
            _paragraph(
                "Sin registros de asistencia.",
                cell_style,
            ),
            "",
            "",
            "",
            "",
            "",
            "",
        ])

    table = Table(
        table_data,
        repeatRows=1,
        colWidths=[
            24 * mm,
            42 * mm,
            30 * mm,
            18 * mm,
            18 * mm,
            58 * mm,
            65 * mm,
        ],
    )

    table.setStyle(
        TableStyle([
            (
                "BACKGROUND",
                (0, 0),
                (-1, 0),
                colors.HexColor("#0B1E36"),
            ),
            (
                "TEXTCOLOR",
                (0, 0),
                (-1, 0),
                colors.white,
            ),
            (
                "VALIGN",
                (0, 0),
                (-1, -1),
                "TOP",
            ),
            (
                "GRID",
                (0, 0),
                (-1, -1),
                0.25,
                colors.HexColor("#B8C2CC"),
            ),
            (
                "ROWBACKGROUNDS",
                (0, 1),
                (-1, -1),
                [
                    colors.white,
                    colors.HexColor("#F4F7F9"),
                ],
            ),
            (
                "SPAN",
                (0, 1),
                (-1, 1),
            )
            if not records
            else (
                "LEFTPADDING",
                (0, 0),
                (-1, -1),
                4,
            ),
        ])
    )

    if records:
        table.setStyle(
            TableStyle([
                (
                    "LEFTPADDING",
                    (0, 0),
                    (-1, -1),
                    4,
                ),
                (
                    "RIGHTPADDING",
                    (0, 0),
                    (-1, -1),
                    4,
                ),
                (
                    "TOPPADDING",
                    (0, 0),
                    (-1, -1),
                    4,
                ),
                (
                    "BOTTOMPADDING",
                    (0, 0),
                    (-1, -1),
                    4,
                ),
            ])
        )

    story.append(table)

    document.build(story)

    return buffer.getvalue()


def build_attendance_xlsx(
    records,
    *,
    month=None,
    year=None,
) -> bytes:
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font
    from openpyxl.utils import get_column_letter

    buffer = BytesIO()

    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Asistencia"

    sheet.append([
        "Fecha",
        "Charla / tema",
        "Área",
        "Tipo",
        "Cantidad asistentes",
        "Asistentes",
        "Retroalimentación",
    ])

    for cell in sheet[1]:
        cell.font = Font(bold=True)
        cell.alignment = Alignment(
            vertical="top",
        )

    for record in records:
        attendees = record.get(
            "attendees"
        ) or []

        attendees_text = ", ".join(
            str(item)
            for item in attendees
            if str(item).strip()
        )

        source = _source_label(record)

        sheet.append([
            _text(record.get("date")),
            _text(
                record.get("talk_title")
                or record.get("topic")
            ),
            _text(record.get("area")),
            source,
            len(attendees),
            attendees_text,
            _text(record.get("feedback")),
        ])

    widths = [
        14,
        35,
        24,
        12,
        20,
        55,
        45,
    ]

    for index, width in enumerate(
        widths,
        start=1,
    ):
        sheet.column_dimensions[
            get_column_letter(index)
        ].width = width

    for row in sheet.iter_rows():
        for cell in row:
            cell.alignment = Alignment(
                vertical="top",
                wrap_text=True,
            )

    sheet.freeze_panes = "A2"
    sheet.auto_filter.ref = sheet.dimensions

    if month or year:
        filters = []

        if month:
            filters.append(
                f"Mes {int(month):02d}"
            )

        if year:
            filters.append(
                str(year)
            )

        sheet.oddHeader.center.text = (
            "Reporte de asistencia - "
            + " / ".join(filters)
        )
    else:
        sheet.oddHeader.center.text = (
            "Reporte de asistencia"
        )

    workbook.save(buffer)
    workbook.close()

    return buffer.getvalue()
