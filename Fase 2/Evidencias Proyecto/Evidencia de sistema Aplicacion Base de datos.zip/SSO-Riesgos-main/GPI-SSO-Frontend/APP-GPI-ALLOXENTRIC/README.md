
  # GPI MOBILE CASI LISTO

  This is a code bundle for GPI MOBILE CASI LISTO. The original project is available at https://www.figma.com/design/FqQiFoB8CVORYrdT0DKm5j/GPI-MOBILE-CASI-LISTO.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  