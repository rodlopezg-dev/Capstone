
from typing import Literal
from pydantic import BaseModel, Field


class ExtractedPerson(BaseModel):
    row: int | None = Field(
        default=None,
        description="Fila donde aparece la persona."
    )
    name: str | None = Field(
        default=None,
        description="Nombre completo visible."
    )
    email: str | None = Field(
        default=None,
        description="Correo visible o null."
    )
    needs_review: bool = False


class ExtractedAttendance(BaseModel):
    workers: list[ExtractedPerson] = Field(
        default_factory=list
    )


class PreviewWorker(BaseModel):
    local_id: str
    row: int | None = None
    name: str
    email: str | None = None

    # Nunca se confirma una identidad desde Gemini.
    user_id: str | None = None

    # Coincidencia sugerida usando la BD real.
    suggested_user_id: str | None = None

    match_status: Literal[
        "suggested",
        "ambiguous",
        "unmatched",
        "review"
    ]

    needs_review: bool = False


class AttendancePreviewResponse(BaseModel):
    talk_id: str
    detected_count: int
    recognized_workers: list[PreviewWorker]
    pending_confirmation: bool = True
