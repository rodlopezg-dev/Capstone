package com.vigiaindustrial.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
