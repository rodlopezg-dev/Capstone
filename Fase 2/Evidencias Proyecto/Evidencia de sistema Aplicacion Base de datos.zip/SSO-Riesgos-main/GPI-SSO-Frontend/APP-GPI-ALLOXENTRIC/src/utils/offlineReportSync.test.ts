import {
  describe,
  expect,
  it,
  vi,
} from 'vitest';

import {
  submitReportWithOfflineFallback,
  syncPendingReports,
  type OfflineSubmissionDependencies,
  type OfflineSyncDependencies,
} from './offlineReportSync';

import {
  ReportNetworkError,
  ReportRequestError,
} from '../app/api/reports';

import type {
  PendingReport,
} from './offlineQueue';

function pending(
  overrides:
    Partial<PendingReport> = {},
): PendingReport {
  return {
    localId: 1,
    clientId: 'tenant-a',
    userId: 'worker-a',
    idempotencyKey: 'idem-1',
    payload: {
      area_id: 'Linea 1',
      type: 'Acto Inseguro',
      is_iap: false,
      description: 'Prueba',
      causes: [],
      shift: 'Dia',
      worker_type: 'planta',
    },
    photoBase64: null,
    photoName: null,
    photoType: null,
    shift: 'Dia',
    createdAt:
      '2026-09-28T12:00:00.000Z',
    attempts: 0,
    ...overrides,
  };
}

function deps(
  reports: PendingReport[],
): OfflineSyncDependencies {
  return {
    getPendingReports:
      vi.fn().mockResolvedValue(reports),
    deletePendingReport:
      vi.fn().mockResolvedValue(undefined),
    updatePendingReport:
      vi.fn().mockResolvedValue(undefined),
    countPendingReports:
      vi.fn().mockResolvedValue(0),
    createReportWithPhoto:
      vi.fn().mockResolvedValue('10'),
  };
}

function submissionDeps(
  connected = true,
): OfflineSubmissionDependencies {
  return {
    getNetworkConnected:
      vi.fn().mockResolvedValue(
        connected,
      ),
    createReportWithPhoto:
      vi.fn().mockResolvedValue(
        '20',
      ),
    savePendingReport:
      vi.fn().mockResolvedValue(
        undefined,
      ),
    countPendingReports:
      vi.fn().mockResolvedValue(1),
    fileToDataUrl:
      vi.fn().mockResolvedValue(
        'data:image/jpeg;base64,AA==',
      ),
  };
}

const submissionInput = {
  clientId: 'tenant-a',
  userId: 'worker-a',
  payload: {
    area_id: 'Linea 1',
    type: 'Acto Inseguro',
    is_iap: false,
    description: 'Prueba offline',
    causes: [],
    shift: 'Dia',
    worker_type: 'planta',
  },
  photoFile: null,
  shift: 'Dia',
  idempotencyKey: 'idem-submit',
};

describe(
  'submitReportWithOfflineFallback',
  () => {
    it(
      'encola inmediatamente si el dispositivo está offline',
      async () => {
        const dependencies =
          submissionDeps(false);

        const result =
          await submitReportWithOfflineFallback(
            submissionInput,
            dependencies,
          );

        expect(
          dependencies.createReportWithPhoto,
        ).not.toHaveBeenCalled();

        expect(
          dependencies.savePendingReport,
        ).toHaveBeenCalledWith(
          expect.objectContaining({
            clientId: 'tenant-a',
            userId: 'worker-a',
            idempotencyKey:
              'idem-submit',
            attempts: 0,
          }),
        );

        expect(result).toEqual({
          status: 'queued',
          pendingCount: 1,
        });
      },
    );

    it(
      'encola con la misma key si falla el transporte',
      async () => {
        const dependencies =
          submissionDeps(true);

        vi.mocked(
          dependencies.createReportWithPhoto,
        ).mockRejectedValue(
          new ReportNetworkError(
            'network down',
          ),
        );

        const result =
          await submitReportWithOfflineFallback(
            submissionInput,
            dependencies,
          );

        expect(
          dependencies.savePendingReport,
        ).toHaveBeenCalledWith(
          expect.objectContaining({
            idempotencyKey:
              'idem-submit',
          }),
        );

        expect(result.status)
          .toBe('queued');
      },
    );

    it(
      'no encola errores HTTP',
      async () => {
        const dependencies =
          submissionDeps(true);

        vi.mocked(
          dependencies.createReportWithPhoto,
        ).mockRejectedValue(
          new ReportRequestError(
            422,
            'invalid report',
          ),
        );

        await expect(
          submitReportWithOfflineFallback(
            submissionInput,
            dependencies,
          ),
        ).rejects.toBeInstanceOf(
          ReportRequestError,
        );

        expect(
          dependencies.savePendingReport,
        ).not.toHaveBeenCalled();
      },
    );
  },
);

describe('syncPendingReports', () => {
  it(
    'sincroniza y elimina solamente después del éxito',
    async () => {
      const dependencies =
        deps([pending()]);

      const result =
        await syncPendingReports(
          'tenant-a',
          'worker-a',
          dependencies,
        );

      expect(
        dependencies.createReportWithPhoto,
      ).toHaveBeenCalledWith(
        expect.objectContaining({
          area_id: 'Linea 1',
        }),
        undefined,
        'Dia',
        'worker-a',
        'idem-1',
      );

      expect(
        dependencies.deletePendingReport,
      ).toHaveBeenCalledWith(1);

      expect(result).toEqual({
        attempted: 1,
        synced: 1,
        failed: 0,
        remaining: 0,
      });
    },
  );

  it(
    'conserva y marca el pendiente cuando falla',
    async () => {
      const dependencies =
        deps([pending()]);

      vi.mocked(
        dependencies.createReportWithPhoto,
      ).mockRejectedValue(
        new Error('backend unavailable'),
      );

      vi.mocked(
        dependencies.countPendingReports,
      ).mockResolvedValue(1);

      const result =
        await syncPendingReports(
          'tenant-a',
          'worker-a',
          dependencies,
        );

      expect(
        dependencies.deletePendingReport,
      ).not.toHaveBeenCalled();

      expect(
        dependencies.updatePendingReport,
      ).toHaveBeenCalledWith(
        1,
        expect.objectContaining({
          attempts: 1,
          lastError:
            'backend unavailable',
        }),
      );

      expect(result).toEqual({
        attempted: 1,
        synced: 0,
        failed: 1,
        remaining: 1,
      });
    },
  );

  it(
    'consulta y cuenta solo al propietario actual',
    async () => {
      const dependencies = deps([]);

      await syncPendingReports(
        'tenant-b',
        'worker-b',
        dependencies,
      );

      expect(
        dependencies.getPendingReports,
      ).toHaveBeenCalledWith(
        'tenant-b',
        'worker-b',
      );

      expect(
        dependencies.countPendingReports,
      ).toHaveBeenCalledWith(
        'tenant-b',
        'worker-b',
      );
    },
  );

  it(
    'libera el single-flight después de un fallo inicial',
    async () => {
      const dependencies = deps([]);

      vi.mocked(
        dependencies.getPendingReports,
      )
        .mockRejectedValueOnce(
          new Error('indexeddb unavailable'),
        )
        .mockResolvedValueOnce([]);

      await expect(
        syncPendingReports(
          'tenant-a',
          'worker-a',
          dependencies,
        ),
      ).rejects.toThrow(
        'indexeddb unavailable',
      );

      const result =
        await syncPendingReports(
          'tenant-a',
          'worker-a',
          dependencies,
        );

      expect(result).toEqual({
        attempted: 0,
        synced: 0,
        failed: 0,
        remaining: 0,
      });

      expect(
        dependencies.getPendingReports,
      ).toHaveBeenCalledTimes(2);
    },
  );

  it(
    'reutiliza una única sincronización concurrente',
    async () => {
      let release:
        ((value: string) => void)
        | undefined;

      const blocked =
        new Promise<string>(resolve => {
          release = resolve;
        });

      const dependencies =
        deps([pending()]);

      vi.mocked(
        dependencies.createReportWithPhoto,
      ).mockReturnValue(blocked);

      const first =
        syncPendingReports(
          'tenant-a',
          'worker-a',
          dependencies,
        );

      const second =
        syncPendingReports(
          'tenant-a',
          'worker-a',
          dependencies,
        );

      expect(second).toBe(first);

      release?.('20');

      await Promise.all([
        first,
        second,
      ]);

      expect(
        dependencies.createReportWithPhoto,
      ).toHaveBeenCalledTimes(1);
    },
  );
});
