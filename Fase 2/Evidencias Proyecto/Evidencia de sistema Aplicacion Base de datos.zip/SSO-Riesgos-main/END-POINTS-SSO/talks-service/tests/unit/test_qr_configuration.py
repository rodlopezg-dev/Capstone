import pytest

from app import dep_talks

def test_qr_signing_algorithm_rejects_unsupported_values():
    with pytest.raises(
        RuntimeError,
        match="QR_SIGNING_ALGORITHM no soportado. Use HS256.",
    ):
        dep_talks.validate_qr_signing_config("a" * 32, "HS512")


def test_qr_signing_secret_requires_at_least_32_characters():
    with pytest.raises(
        RuntimeError,
        match="QR_SIGNING_SECRET debe tener al menos 32 caracteres.",
    ):
        dep_talks.validate_qr_signing_config("clave-demasiado-corta", "HS256")


def test_qr_signing_config_accepts_hs256_with_long_secret():
    dep_talks.validate_qr_signing_config("a" * 32, "HS256")

def test_required_environment_variable_rejects_missing_value():
    with pytest.raises(
        RuntimeError,
        match="Falta la variable de entorno obligatoria: MONGO_URI",
    ):
        dep_talks.get_required_env("MONGO_URI", {})


def test_required_environment_variable_rejects_blank_value():
    with pytest.raises(
        RuntimeError,
        match="Falta la variable de entorno obligatoria: QR_SIGNING_SECRET",
    ):
        dep_talks.get_required_env(
            "QR_SIGNING_SECRET",
            {"QR_SIGNING_SECRET": "   "},
        )