import os
import re
from pathlib import PurePath
from uuid import uuid4

from azure.core.exceptions import ResourceExistsError, ResourceNotFoundError
from azure.storage.blob import ContentSettings
from azure.storage.blob.aio import BlobServiceClient


DEFAULT_CONTAINER = "attendance-scans"

_CONTENT_TYPE_EXTENSIONS = {
    "image/jpeg": ".jpg",
    "image/png": ".png",
    "image/webp": ".webp",
}


class BlobStorageConfigurationError(RuntimeError):
    pass


def _storage_settings():
    connection_string = os.getenv(
        "AZURE_STORAGE_CONNECTION_STRING",
        "",
    ).strip()

    if not connection_string:
        raise BlobStorageConfigurationError(
            "AZURE_STORAGE_CONNECTION_STRING no está configurada."
        )

    container = os.getenv(
        "AZURE_STORAGE_CONTAINER",
        DEFAULT_CONTAINER,
    ).strip().lower()

    if (
        not 3 <= len(container) <= 63
        or not re.fullmatch(
            r"[a-z0-9](?:[a-z0-9-]*[a-z0-9])?",
            container,
        )
        or "--" in container
    ):
        raise BlobStorageConfigurationError(
            "AZURE_STORAGE_CONTAINER no es un nombre válido."
        )

    return connection_string, container


def _safe_segment(value: str, fallback: str) -> str:
    cleaned = re.sub(
        r"[^A-Za-z0-9._-]+",
        "_",
        (value or "").strip(),
    )
    cleaned = cleaned.strip("._-")
    return (cleaned or fallback)[:100]


def sanitize_filename(filename: str | None) -> str:
    normalized = (filename or "").replace("\\", "/")
    basename = PurePath(normalized).name

    cleaned = re.sub(
        r"[^A-Za-z0-9._ -]+",
        "_",
        basename,
    ).strip()

    return (cleaned or "attendance-scan")[:180]


def build_attendance_scan_blob_name(
    client_id: str,
    talk_id: str,
    content_type: str,
) -> str:
    extension = _CONTENT_TYPE_EXTENSIONS.get(content_type)
    if not extension:
        raise ValueError("Tipo de imagen no soportado.")

    safe_client = _safe_segment(client_id, "tenant")
    safe_talk = _safe_segment(talk_id, "talk")

    return (
        f"{safe_client}/"
        f"{safe_talk}/"
        f"{uuid4().hex}{extension}"
    )


async def upload_attendance_scan(
    *,
    client_id: str,
    talk_id: str,
    content: bytes,
    content_type: str,
) -> dict:
    connection_string, container_name = _storage_settings()

    blob_name = build_attendance_scan_blob_name(
        client_id,
        talk_id,
        content_type,
    )

    async with BlobServiceClient.from_connection_string(
        connection_string
    ) as service:
        container = service.get_container_client(container_name)

        try:
            await container.create_container()
        except ResourceExistsError:
            pass

        blob = container.get_blob_client(blob_name)

        await blob.upload_blob(
            content,
            overwrite=False,
            content_settings=ContentSettings(
                content_type=content_type,
            ),
        )

    return {
        "provider": "azure_blob",
        "container": container_name,
        "blob_name": blob_name,
    }

def build_attachment_blob_name(
    client_id: str,
    category: str,
    file_name: str,
) -> str:
    safe_client = _safe_segment(
        client_id,
        "tenant",
    )
    safe_category = _safe_segment(
        category,
        "attachments",
    )

    normalized = (
        file_name or ""
    ).replace("\\", "/")
    suffix = PurePath(normalized).suffix.lower()

    if not re.fullmatch(
        r"\.[a-z0-9]{1,10}",
        suffix,
    ):
        suffix = ""

    return (
        f"{safe_client}/"
        f"{safe_category}/"
        f"{uuid4().hex}{suffix}"
    )


async def upload_attachment(
    *,
    client_id: str,
    category: str,
    file_name: str,
    content_type: str,
    stream,
) -> dict:
    connection_string, container_name = (
        _storage_settings()
    )

    blob_name = build_attachment_blob_name(
        client_id,
        category,
        file_name,
    )

    async with BlobServiceClient.from_connection_string(
        connection_string
    ) as service:
        container = service.get_container_client(
            container_name
        )

        try:
            await container.create_container()
        except ResourceExistsError:
            pass

        blob = container.get_blob_client(
            blob_name
        )

        await blob.upload_blob(
            stream,
            overwrite=False,
            content_settings=ContentSettings(
                content_type=(
                    content_type
                    or "application/octet-stream"
                ),
            ),
        )

    return {
        "provider": "azure_blob",
        "container": container_name,
        "blob_name": blob_name,
    }


async def open_blob_stream(
    storage_ref: dict,
):
    connection_string, configured_container = (
        _storage_settings()
    )

    container_name = (
        storage_ref.get("container")
        or configured_container
    )
    blob_name = storage_ref.get(
        "blob_name"
    )

    if not blob_name:
        raise ResourceNotFoundError(
            "Blob no definido."
        )

    service = (
        BlobServiceClient.from_connection_string(
            connection_string
        )
    )

    blob = service.get_blob_client(
        container=container_name,
        blob=blob_name,
    )

    try:
        downloader = await blob.download_blob()
    except Exception:
        await service.close()
        raise

    async def chunks():
        try:
            async for chunk in downloader.chunks():
                yield chunk
        finally:
            await service.close()

    return chunks()


async def delete_blob(storage_ref: dict) -> None:
    connection_string, configured_container = _storage_settings()

    container_name = (
        storage_ref.get("container")
        or configured_container
    )
    blob_name = storage_ref.get("blob_name")

    if not blob_name:
        return

    async with BlobServiceClient.from_connection_string(
        connection_string
    ) as service:
        blob = service.get_blob_client(
            container=container_name,
            blob=blob_name,
        )

        try:
            await blob.delete_blob(
                delete_snapshots="include",
            )
        except ResourceNotFoundError:
            pass
