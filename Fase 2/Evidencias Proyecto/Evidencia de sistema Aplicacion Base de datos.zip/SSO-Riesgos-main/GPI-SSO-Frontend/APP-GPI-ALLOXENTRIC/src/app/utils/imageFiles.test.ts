import {
  describe,
  expect,
  it,
} from 'vitest';

import {
  dataUrlToImageFile,
} from './imageFiles';

describe('image file helpers', () => {
  it('converts JPEG data URL to File', () => {
    const file = dataUrlToImageFile(
      'data:image/jpeg;base64,aG9sYQ==',
      'asistencia',
    );

    expect(file.name).toBe('asistencia.jpg');
    expect(file.type).toBe('image/jpeg');
    expect(file.size).toBeGreaterThan(0);
  });

  it('rejects unsupported data URL', () => {
    expect(() =>
      dataUrlToImageFile(
        'data:application/pdf;base64,aG9sYQ==',
      ),
    ).toThrow('Formato de imagen no soportado');
  });
});
