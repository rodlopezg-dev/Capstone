from datetime import datetime, timezone
import ulid as ulid_lib

def _now_iso():
    return datetime.now(timezone.utc).isoformat()

class AlertRepository:
    def __init__(self, db):
        self.alerts = db["alerts"]

    async def get_all(self, client_id, status=None, alert_type=None, zone_id=None, page=1, page_size=100):
        query = {"client_id": client_id}
        if status:
            query["status"] = status
        if alert_type:
            query["type"] = alert_type
        if zone_id:
            query["zone_id"] = zone_id
        results = []
        async for doc in self.alerts.find(query).sort("created_at", -1).limit(page_size):
            doc.pop("_id", None)
            doc["id"] = doc.get("alert_id", "")
            results.append(doc)
        total = await self.alerts.count_documents(query)
        return results, total

    async def get_by_id(self, client_id, alert_id):
        doc = await self.alerts.find_one({"alert_id": alert_id, "client_id": client_id})
        if doc:
            doc.pop("_id", None)
            doc["id"] = doc.get("alert_id", "")
        return doc

    async def create(self, client_id, alert_data):
        alert_id = f"alert_{ulid_lib.ULID()}"
        alert_data.update({"alert_id": alert_id, "client_id": client_id, "created_at": _now_iso()})
        await self.alerts.insert_one(alert_data)
        return alert_id

    async def update_status(self, client_id, alert_id, status):
        result = await self.alerts.update_one(
            {"alert_id": alert_id, "client_id": client_id},
            {"$set": {"status": status, "resolved_at": _now_iso() if status == "resolved" else None}}
        )
        return result.modified_count > 0

    async def get_stats(self, client_id):
        total = await self.alerts.count_documents({"client_id": client_id})
        active = await self.alerts.count_documents({"client_id": client_id, "status": "active"})
        resolved = await self.alerts.count_documents({"client_id": client_id, "status": "resolved"})
        return {"total": total, "active": active, "resolved": resolved}

    async def create_iap_alert(self, client_id, report_id, area_id, user_id):
        alert_id = f"alert_{ulid_lib.ULID()}"
        doc = {
            "alert_id": alert_id,
            "client_id": client_id,
            "type": "iap",
            "severity": "critical",
            "status": "active",
            "title": f"IAP detectado en {area_id}",
            "body": f"Reporte {report_id} marcado como Incidente de Alto Potencial",
            "zone_id": area_id,
            "report_id": report_id,
            "triggered_by": user_id,
            "created_at": _now_iso(),
        }
        await self.alerts.insert_one(doc)
        return alert_id
