import os, jwt
from fastapi import HTTPException, Security
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from motor.motor_asyncio import AsyncIOMotorClient


def validate_qr_signing_config(secret: str, algorithm: str) -> None:
    if algorithm != "HS256":
        raise RuntimeError("QR_SIGNING_ALGORITHM no soportado. Use HS256.")
    if len(secret) < 32:
        raise RuntimeError(
            "QR_SIGNING_SECRET debe tener al menos 32 caracteres."
        )

def get_required_env(name: str, environ=None) -> str:
    source = os.environ if environ is None else environ
    value = source.get(name)

    if value is None or not value.strip():
        raise RuntimeError(
            f"Falta la variable de entorno obligatoria: {name}"
        )

    return value


MONGO_URI = get_required_env("MONGO_URI")
MONGO_DB = get_required_env("MONGO_DB")
JWT_SECRET = get_required_env("JWT_SECRET")
JWT_ALGORITHM = get_required_env("JWT_ALGORITHM")
QR_SIGNING_SECRET = get_required_env("QR_SIGNING_SECRET")
QR_SIGNING_ALGORITHM = get_required_env("QR_SIGNING_ALGORITHM")
QR_TTL_MINUTES = int(get_required_env("QR_TTL_MINUTES"))
validate_qr_signing_config(QR_SIGNING_SECRET, QR_SIGNING_ALGORITHM)
if QR_TTL_MINUTES <= 0:
    raise RuntimeError("QR_TTL_MINUTES debe ser mayor que cero.")
_db_client = None
security = HTTPBearer(auto_error=False)

def get_db():
    global _db_client
    if _db_client is None:
        client = AsyncIOMotorClient(MONGO_URI)
        _db_client = client[MONGO_DB]
    return _db_client

def get_current_user(credentials: HTTPAuthorizationCredentials | None = Security(security)) -> dict:
    if credentials is None:
        raise HTTPException(status_code=401, detail="Token requerido")
    try:
        payload = jwt.decode(
            credentials.credentials, JWT_SECRET,
            algorithms=[JWT_ALGORITHM], options={"require": ["exp"]},
        )
    except jwt.PyJWTError as exc:
        raise HTTPException(status_code=401, detail="Token inválido o expirado") from exc

    if ("type" in payload and payload["type"] != "access") or any(
        not isinstance(payload.get(claim), str) or not payload[claim].strip()
        for claim in ("sub", "role", "client_id")
    ):
        raise HTTPException(status_code=401, detail="Token inválido")

    return {
        "user_id": payload["sub"],
        "client_id": payload["client_id"],
        "role": payload["role"],
        "areas": payload.get("areas"),
        "area": payload.get("area"),
    }
