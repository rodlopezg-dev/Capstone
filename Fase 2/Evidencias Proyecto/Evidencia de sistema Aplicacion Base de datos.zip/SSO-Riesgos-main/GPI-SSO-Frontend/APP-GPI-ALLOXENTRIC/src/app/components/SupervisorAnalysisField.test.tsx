import { describe, expect, it } from 'vitest';
import { renderToStaticMarkup } from 'react-dom/server';

import SupervisorAnalysisField from './SupervisorAnalysisField';

describe('SupervisorAnalysisField - SCRUM-74', () => {
  it('renders the supervisor analysis label', () => {
    const html = renderToStaticMarkup(
      <SupervisorAnalysisField
        value=""
        onChange={() => undefined}
      />
    );

    expect(html).toContain('Análisis del supervisor');
  });

  it('renders the expected placeholder', () => {
    const html = renderToStaticMarkup(
      <SupervisorAnalysisField
        value=""
        onChange={() => undefined}
      />
    );

    expect(html).toContain(
      'Describir el análisis del hallazgo...'
    );
  });

  it('renders the current analysis value', () => {
    const html = renderToStaticMarkup(
      <SupervisorAnalysisField
        value="Se identifica exposición por falta de control operacional."
        onChange={() => undefined}
      />
    );

    expect(html).toContain(
      'Se identifica exposición por falta de control operacional.'
    );
  });

  it('renders the supporting description', () => {
    const html = renderToStaticMarkup(
      <SupervisorAnalysisField
        value=""
        onChange={() => undefined}
      />
    );

    expect(html).toContain(
      'Registra el análisis técnico realizado sobre el hallazgo.'
    );
  });

  it('can be disabled', () => {
    const html = renderToStaticMarkup(
      <SupervisorAnalysisField
        value=""
        onChange={() => undefined}
        disabled
      />
    );

    expect(html).toContain('disabled');
  });
});
