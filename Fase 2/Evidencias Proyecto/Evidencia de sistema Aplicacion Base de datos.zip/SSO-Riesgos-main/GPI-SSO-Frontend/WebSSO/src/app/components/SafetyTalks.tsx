
import { useState, useEffect } from 'react';
import {
  Upload,
  Plus,
  Users,
  Calendar,
  FileUp,
  Hand,
  Image,
  Pencil,
  QrCode,
  Trash2,
  X,
} from 'lucide-react';

// Las rutas se mantienen relativas para que Nginx decida el backend activo.
const TALKS_API = window.location.origin + '/api/talks';

const USERS_API = window.location.origin + '/api/users';

type User = {
  id: string;
  name: string;
  email?: string;
  role: string;
  area?: string;
  status?: string;
};

type Talk = {
  talk_id: string;
  title: string;
  month: string;
  year: string;
  file_url: string;
  file_name: string;
  file_id?: string;
  status?: string;
  created_at: string;
};

type Attendance = {
  attendance_id: string;
  talk_id: string;
  topic: string;
  date: string;
  area: string;
  attendees: string[];
  attended_user_ids?: string[];
  attendance_entries?: Array<{
    name?: string;
    attendee_name?: string;
    full_name?: string;
    email?: string;
    registered_at?: string;
    method?: string;
  }>;
  source?: 'qr' | 'manual' | 'sheet' | string;
  feedback: string;
  created_at: string;
  file_id?: string;
  file_url?: string;
  file_name?: string;
  file_content_type?: string;
};

type Props = {
  userRole: string;
};

export default function SafetyTalks({ userRole }: Props) {
  // Charlas y asistencia
  const [talks, setTalks] = useState<Talk[]>([]);
  const [attendance, setAttendance] = useState<Attendance[]>([]);
  const [loading, setLoading] = useState(true);

  // Filtros de período
  const [month, setMonth] = useState(
    String(new Date().getMonth() + 1)
  );
  const [year, setYear] = useState(
    String(new Date().getFullYear())
  );

  // Ventanas y paneles
  const [showAddTalk, setShowAddTalk] = useState(false);
  const [showAddAttendance, setShowAddAttendance] = useState(false);
  const [editingTalk, setEditingTalk] = useState<Talk | null>(null);
  const [qrTalk, setQrTalk] = useState<{
    title: string;
    image: string;
  } | null>(null);
  const [isLoadingQr, setIsLoadingQr] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [actionError, setActionError] = useState('');

  // Charla seleccionada para visualizar asistencia
  const [selectedTalkId, setSelectedTalkId] = useState<
    string | null
  >(null);
  const [attendanceSourceFilter, setAttendanceSourceFilter] = useState<
    'all' | 'qr' | 'manual' | 'sheet'
  >('all');
  const [attendanceImagePreview, setAttendanceImagePreview] = useState('');

  // Usuarios
  const [users, setUsers] = useState<User[]>([]);
  const [userSearch, setUserSearch] = useState('');

  // Formulario: nueva charla
  const [newTitle, setNewTitle] = useState('');
  const [newFile, setNewFile] = useState<File | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [editFile, setEditFile] = useState<File | null>(null);
  const [removeEditFile, setRemoveEditFile] = useState(false);

  // Formulario: asistencia
  const [attTopic, setAttTopic] = useState('');
  const [attTalkId, setAttTalkId] = useState('');
  const [attDate, setAttDate] = useState(
    new Date().toISOString().split('T')[0]
  );
  const [attArea, setAttArea] = useState('');
  const [attAttendees, setAttAttendees] = useState('');
  const [attFeedback, setAttFeedback] = useState('');

  // Permisos actuales
  const canManageTalks = ['admin', 'sso_manager', 'supervisor', 'jefe de area'].includes(
    userRole?.toLowerCase() || ''
  );

  const token = localStorage.getItem('sso_token') ?? '';

  const headers = {
    Authorization: 'Bearer ' + token,
  };

  const readError = async (response: Response) => {
    const body = await response.json().catch(() => ({}));
    return body.detail || 'No fue posible completar la operación.';
  };

  const MONTHS = [
    'Enero',
    'Febrero',
    'Marzo',
    'Abril',
    'Mayo',
    'Junio',
    'Julio',
    'Agosto',
    'Septiembre',
    'Octubre',
    'Noviembre',
    'Diciembre',
  ];

  // ==========================================
  // CONSULTAS A LA API
  // ==========================================

  const fetchTalks = async () => {
    try {
      const res = await fetch(
        TALKS_API +
          '/v1/talks?month=' +
          month +
          '&year=' +
          year,
        { headers }
      );

      if (res.ok) {
        setTalks(await res.json());
      }
    } catch (e) {
      console.error('Error cargando charlas:', e);
    }
  };

  const fetchAttendance = async () => {
    try {
      const res = await fetch(
        TALKS_API + '/v1/attendance',
        { headers }
      );

      if (res.ok) {
        setAttendance(await res.json());
      }
    } catch (e) {
      console.error('Error cargando asistencia:', e);
    }
  };

  const fetchUsers = async () => {
    try {
      const res = await fetch(
        USERS_API + '/v1/admin/users/',
        { headers }
      );

      if (res.ok) {
        const data = await res.json();

        const userRecords = Array.isArray(data)
          ? data
          : Array.isArray(data.users)
            ? data.users
            : [];

        setUsers(
          userRecords
              .map((u: any) => ({
                id: u.id || u.user_id,
                name:
                  u.name ||
                  u.full_name ||
                  u.email,
                email: u.email || '',
                role: u.role || '',
                area: u.area_id || u.area || '',
                status: u.status || '',
              }))
              .filter((u: User) => Boolean(u.id) && u.status !== 'inactive')
        );
      }
    } catch (e) {
      console.error('Error cargando usuarios:', e);
    }
  };

  useEffect(() => {
    setLoading(true);

    Promise.all([
      fetchTalks(),
      fetchAttendance(),
      fetchUsers(),
    ]).finally(() => setLoading(false));
  }, [month, year]);

  // ==========================================
  // CREACIÓN DE CHARLAS
  // ==========================================

  const handleAddTalk = async () => {
    if (!newTitle) return;

    setActionError('');
    setIsSaving(true);

    const fd = new FormData();

    fd.append('title', newTitle);
    fd.append('month', month);
    fd.append('year', year);

    if (newFile) {
      fd.append('file', newFile);
    }

    try {
      const response = await fetch(TALKS_API + '/v1/talks', {
        method: 'POST',
        headers,
        body: fd,
      });

      if (!response.ok) {
        setActionError(await readError(response));
        return;
      }

      setNewTitle('');
      setNewFile(null);
      setShowAddTalk(false);
      fetchTalks();
    } finally {
      setIsSaving(false);
    }
  };

  // ==========================================
  // REGISTRO DE ASISTENCIA
  // ==========================================

  const handleAddAttendance = async () => {
    if (!attTopic || !attTalkId || attendeeList.length === 0) return;

    setActionError('');
    setIsSaving(true);

    const fd = new FormData();

    fd.append('topic', attTopic);
    fd.append('date', attDate);
    fd.append('area', attArea);
    fd.append('talk_id', attTalkId);
    fd.append('attendees', attAttendees);
    fd.append('feedback', attFeedback);

    try {
      const response = await fetch(TALKS_API + '/v1/attendance', {
        method: 'POST',
        headers,
        body: fd,
      });

      if (!response.ok) {
        setActionError(await readError(response));
        return;
      }

      setAttTopic('');
      setAttTalkId('');
      setAttDate(new Date().toISOString().split('T')[0]);
      setAttArea('');
      setAttAttendees('');
      setAttFeedback('');
      setShowAddAttendance(false);
      fetchAttendance();
    } finally {
      setIsSaving(false);
    }
  };

  const clearRightPanel = () => {
    setShowAddTalk(false);
    setShowAddAttendance(false);
    setEditingTalk(null);
    setQrTalk(null);
  };

  const openNewTalk = () => {
    clearRightPanel();
    setSelectedTalkId(null);
    setActionError('');
    setShowAddTalk(true);
  };

  const openEditTalk = (talk: Talk) => {
    clearRightPanel();
    setSelectedTalkId(null);
    setActionError('');
    setEditingTalk(talk);
    setEditTitle(talk.title);
    setEditFile(null);
    setRemoveEditFile(false);
  };

  const handleUpdateTalk = async () => {
    if (!editingTalk || !editTitle.trim()) return;

    setActionError('');
    setIsSaving(true);
    const fd = new FormData();
    fd.append('title', editTitle.trim());
    if (editFile) fd.append('file', editFile);
    if (removeEditFile) fd.append('remove_file', 'true');

    try {
      const response = await fetch(
        `${TALKS_API}/v1/talks/${encodeURIComponent(editingTalk.talk_id)}`,
        { method: 'PATCH', headers, body: fd },
      );

      if (!response.ok) {
        setActionError(await readError(response));
        return;
      }

      setEditingTalk(null);
      await fetchTalks();
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteTalk = async (talk: Talk) => {
    if (!window.confirm(`¿Deseas eliminar la charla «${talk.title}»?`)) return;

    setActionError('');
    const response = await fetch(
      `${TALKS_API}/v1/talks/${encodeURIComponent(talk.talk_id)}`,
      { method: 'DELETE', headers },
    );

    if (!response.ok) {
      setActionError(await readError(response));
      return;
    }

    if (selectedTalkId === talk.talk_id) setSelectedTalkId(null);
    await fetchTalks();
  };

  const openTalkQr = async (talk: Talk) => {
    clearRightPanel();
    setSelectedTalkId(null);
    setActionError('');
    setIsLoadingQr(true);

    try {
      const response = await fetch(
        `${TALKS_API}/v1/talks/${encodeURIComponent(talk.talk_id)}/qr`,
        { headers },
      );
      const data = await response.json().catch(() => ({}));

      if (!response.ok) {
        setActionError(data.detail || 'No fue posible obtener el código QR.');
        return;
      }

      setQrTalk({ title: talk.title, image: data.image || '' });
    } catch {
      setActionError('No fue posible obtener el código QR.');
    } finally {
      setIsLoadingQr(false);
    }
  };

  const removeAttendee = (name: string) => {
    setAttAttendees((prev) =>
      prev
        .split(',')
        .filter((n) => n.trim() !== name)
        .join(',')
    );
  };

  const attendeeList = attAttendees
    ? attAttendees
        .split(',')
        .filter((n) => n.trim())
    : [];

  const matchingUsers = users.filter((user) => {
    const query = userSearch.trim().toLowerCase();
    if (!query) return false;
    const searchable = `${user.name} ${user.email || ''}`.toLowerCase();
    return searchable.includes(query) && !attendeeList.includes(user.name);
  });

  // ==========================================
  // CHARLA Y ASISTENCIA SELECCIONADAS
  // ==========================================

  const selectedTalk =
    talks.find(
      (talk) => talk.talk_id === selectedTalkId
    ) ?? null;

  const selectedAttendance = selectedTalk
    ? attendance.filter(
        (item) =>
          item.talk_id === selectedTalk.talk_id
      )
    : [];

  const attendanceFileRecord = selectedAttendance.find(
    (record) => Boolean(record.file_id || record.file_url)
  );

  useEffect(() => {
    let active = true;
    let objectUrl = '';

    setAttendanceImagePreview('');

    if (!attendanceFileRecord?.attendance_id) {
      return undefined;
    }

    const loadAttendanceImage = async () => {
      try {
        const response = await fetch(
          `${TALKS_API}/v1/attendance/${encodeURIComponent(attendanceFileRecord.attendance_id)}/file`,
          { headers }
        );

        if (!response.ok) return;

        const image = await response.blob();
        if (!image.type.startsWith('image/')) return;

        objectUrl = URL.createObjectURL(image);
        if (active) setAttendanceImagePreview(objectUrl);
      } catch (error) {
        console.error('No fue posible cargar la hoja de asistencia:', error);
      }
    };

    void loadAttendanceImage();

    return () => {
      active = false;
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [
    attendanceFileRecord?.attendance_id,
    attendanceFileRecord?.file_id,
    attendanceFileRecord?.file_url,
    token,
  ]);

  const participantDetails = selectedAttendance.flatMap((record) => {
    const fallbackMethod =
      record.source === 'qr' || record.source === 'sheet'
        ? record.source
        : 'manual';

    const recordAttendees = Array.isArray(record.attendees)
      ? record.attendees
      : typeof record.attendees === 'string'
        ? record.attendees.split(',').map((name) => name.trim()).filter(Boolean)
        : [];

    if (record.attendance_entries?.length) {
      return record.attendance_entries.map((entry, index) => ({
        id: `${record.attendance_id}-${index}`,
        name:
          entry.name ||
          entry.attendee_name ||
          entry.full_name ||
          entry.email ||
          recordAttendees[index] ||
          'Participante',
        method:
          entry.method === 'qr' || entry.method === 'sheet'
            ? entry.method
            : fallbackMethod,
        registeredAt: entry.registered_at || record.created_at || record.date,
      }));
    }

    return recordAttendees.map((name, index) => ({
      id: `${record.attendance_id}-${index}`,
      name,
      method: fallbackMethod,
      registeredAt: record.created_at || record.date,
    }));
  });

  const visibleParticipants = participantDetails.filter(
    (participant) =>
      attendanceSourceFilter === 'all' ||
      participant.method === attendanceSourceFilter
  );

  const totalAttendees = participantDetails.length;

  const formatRegistrationDate = (value?: string) => {
    if (!value) return 'Sin hora individual registrada';

    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return 'Sin hora individual registrada';

    return date.toLocaleString('es-CL', {
      dateStyle: 'short',
      timeStyle: 'short',
    });
  };

  const attendanceMethodLabel = (method: string) => {
    if (method === 'qr') return 'Registro por código QR';
    if (method === 'sheet') return 'Registro mediante hoja de asistencia';
    return 'Registro manual';
  };

  const talkHasAttendance = (talkId: string) =>
    attendance.some((record) => record.talk_id === talkId);

  const openAttendanceRegistration = (talk: Talk | null) => {
    clearRightPanel();
    setSelectedTalkId(null);
    setActionError('');
    setAttTalkId(talk?.talk_id || '');
    setAttTopic(talk?.title || '');
    setAttAttendees('');
    setUserSearch('');
    setShowAddAttendance(true);
  };

  const selectTalkAttendance = (talkId: string) => {
    clearRightPanel();
    setAttendanceSourceFilter('all');
    setSelectedTalkId(talkId);
    void fetchAttendance();
  };

  // ==========================================
  // INTERFAZ
  // ==========================================

  return (
    <div className="min-h-full space-y-6 p-6 lg:p-8">
      {/* Encabezado general */}

      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">
            Repositorio de Diálogos de Seguridad
          </h1>

          <p className="text-muted-foreground text-sm">
            Charlas, material de apoyo y registro de
            asistencia
          </p>
        </div>
      </div>

      {actionError && (
        <div role="alert" className="rounded-lg border border-destructive/50 bg-destructive/10 px-4 py-3 text-sm text-destructive">
          {actionError}
        </div>
      )}

      {/* Paneles principales */}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* ==================================
            PANEL IZQUIERDO: CHARLAS
        ================================== */}

        <div className="bg-card border border-border rounded-lg p-6 lg:flex lg:h-[calc(100vh-11rem)] lg:min-h-0 lg:flex-col">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <Calendar size={20} />
              Diálogos de seguridad
            </h2>

            {canManageTalks && (
              <button
                type="button"
                onClick={openNewTalk}
                className="flex items-center gap-1 px-3 py-1.5 bg-primary/20 text-primary rounded-lg text-sm hover:bg-primary/30"
              >
                <Plus size={16} />
                Nueva charla
              </button>
            )}
          </div>

          {/* Filtros de período */}

          <div className="flex gap-2 mb-4">
            <select
              value={month}
              onChange={(e) =>
                setMonth(e.target.value)
              }
              className="px-3 py-2 bg-secondary border border-border rounded-lg text-sm"
            >
              {MONTHS.map((m, i) => (
                <option
                  key={i}
                  value={String(i + 1)}
                >
                  {m}
                </option>
              ))}
            </select>

            <select
              value={year}
              onChange={(e) =>
                setYear(e.target.value)
              }
              className="px-3 py-2 bg-secondary border border-border rounded-lg text-sm"
            >
              {[2025, 2026, 2027].map(
                (y) => (
                  <option
                    key={y}
                    value={String(y)}
                  >
                    {y}
                  </option>
                )
              )}
            </select>
          </div>

          {/* Listado de charlas */}

          {loading ? (
            <p className="text-muted-foreground text-sm">
              Cargando...
            </p>
          ) : talks.length === 0 ? (
            <p className="text-muted-foreground text-sm p-4 text-center">
              No hay charlas para este período
            </p>
          ) : (
            <div className="space-y-2 lg:min-h-0 lg:flex-1 lg:overflow-y-auto lg:pr-2">
              {talks.map((talk) => (
                <div
                  key={talk.talk_id}
                  className={`min-h-20 rounded-lg border p-3 transition-all ${
                    selectedTalkId === talk.talk_id
                      ? 'border-primary bg-primary/10'
                      : 'border-transparent bg-secondary/30 hover:bg-secondary/50'
                  }`}
                >
                  {/* Información de la charla */}

                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="text-sm font-medium break-words">
                        {talk.title}
                      </p>

                      <p className="mt-1 text-xs text-muted-foreground break-words">
                        {talk.file_name || 'Sin archivo adjunto'}
                      </p>

                      {talk.file_url && (
                        <a
                          href={talk.file_url}
                          download={talk.file_name}
                          aria-label={`Descargar archivo de ${talk.title}`}
                          className="mt-1 inline-flex text-xs font-medium text-primary hover:underline"
                        >
                          Descargar
                        </a>
                      )}
                    </div>

                    <button
                      type="button"
                      onClick={() => selectTalkAttendance(talk.talk_id)}
                      aria-pressed={selectedTalkId === talk.talk_id}
                      className={`shrink-0 rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${
                        selectedTalkId === talk.talk_id
                          ? 'bg-primary text-primary-foreground'
                          : 'bg-primary/20 text-primary hover:bg-primary/30'
                      }`}
                    >
                      Ver listado
                    </button>
                  </div>

                  {/* Acciones de cada charla */}

                  <div className="mt-3 flex flex-wrap items-center gap-2">
                    {canManageTalks && (
                      <button
                        type="button"
                        onClick={() => void openTalkQr(talk)}
                        disabled={isLoadingQr}
                        className="inline-flex items-center gap-1 rounded-md bg-primary px-3 py-1.5 text-xs font-medium text-primary-foreground disabled:cursor-wait disabled:opacity-60"
                      >
                        <QrCode size={14} /> {isLoadingQr ? 'Cargando...' : 'QR'}
                      </button>
                    )}

                    {canManageTalks && (
                      <>
                        <button
                          type="button"
                          onClick={() => openAttendanceRegistration(talk)}
                          className="inline-flex items-center gap-1 rounded-md bg-primary/20 px-3 py-1.5 text-xs font-medium text-primary hover:bg-primary/30"
                        >
                          <Plus size={14} /> Registrar
                        </button>
                        <button
                          type="button"
                          disabled={talkHasAttendance(talk.talk_id)}
                          onClick={() => openEditTalk(talk)}
                          className="inline-flex items-center gap-1 rounded-md bg-secondary px-3 py-1.5 text-xs font-medium hover:bg-secondary/80 disabled:cursor-not-allowed disabled:opacity-40"
                        >
                          <Pencil size={14} /> Modificar
                        </button>
                        <button
                          type="button"
                          disabled={talkHasAttendance(talk.talk_id)}
                          onClick={() => openEditTalk(talk)}
                          className="inline-flex items-center gap-1 rounded-md bg-primary/20 px-3 py-1.5 text-xs font-medium text-primary hover:bg-primary/30 disabled:cursor-not-allowed disabled:opacity-40"
                        >
                          <FileUp size={14} /> Subir asistencia
                        </button>
                        <button
                          type="button"
                          disabled={talkHasAttendance(talk.talk_id)}
                          onClick={() => void handleDeleteTalk(talk)}
                          className="inline-flex items-center gap-1 rounded-md bg-destructive/20 px-3 py-1.5 text-xs font-medium text-destructive hover:bg-destructive/30 disabled:cursor-not-allowed disabled:opacity-40"
                        >
                          <Trash2 size={14} /> Eliminar
                        </button>
                      </>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* ==================================
            PANEL DERECHO: ASISTENCIA
        ================================== */}

        <div className="bg-card border border-border rounded-lg p-6">
          {/* Encabezado del panel */}

          <div className="mb-4">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <Users size={20} />
              Registro de asistencia
            </h2>
          </div>

          {/* Asistencia de la charla seleccionada */}

          {showAddTalk ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold">Nueva charla de seguridad</h3>
                <button type="button" onClick={() => setShowAddTalk(false)} className="text-muted-foreground hover:text-foreground" aria-label="Cerrar nueva charla"><X size={20} /></button>
              </div>
              <input value={newTitle} onChange={(event) => setNewTitle(event.target.value)} placeholder="Título de la charla..." className="w-full rounded-lg border border-border bg-secondary px-3 py-2 text-sm" />
              <div className="flex gap-2">
                <select value={month} onChange={(event) => setMonth(event.target.value)} className="min-w-0 flex-1 rounded-lg border border-border bg-secondary px-3 py-2 text-sm">
                  {MONTHS.map((name, index) => <option key={name} value={String(index + 1)}>{name}</option>)}
                </select>
                <select value={year} onChange={(event) => setYear(event.target.value)} className="min-w-0 flex-1 rounded-lg border border-border bg-secondary px-3 py-2 text-sm">
                  {[2025, 2026, 2027].map((value) => <option key={value} value={String(value)}>{value}</option>)}
                </select>
              </div>
              <label className="flex cursor-pointer items-center gap-2 rounded-lg border border-border bg-secondary p-3 hover:border-primary/50">
                <Upload size={18} className="text-primary" />
                <span className="min-w-0 truncate text-sm">{newFile?.name || 'Subir archivo PPT/PDF'}</span>
                <input type="file" accept=".ppt,.pptx,.pdf" className="hidden" onChange={(event) => setNewFile(event.target.files?.[0] || null)} />
              </label>
              <button type="button" onClick={() => void handleAddTalk()} disabled={isSaving || !newTitle.trim()} className="w-full rounded-lg bg-primary py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90 disabled:opacity-50">{isSaving ? 'Guardando...' : 'Guardar charla'}</button>
            </div>
          ) : editingTalk ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold">Modificar charla</h3>
                <button type="button" onClick={() => setEditingTalk(null)} className="text-muted-foreground hover:text-foreground" aria-label="Cerrar modificación"><X size={20} /></button>
              </div>
              <input value={editTitle} onChange={(event) => setEditTitle(event.target.value)} aria-label="Título de la charla" className="w-full rounded-lg border border-border bg-secondary px-3 py-2 text-sm" />
              <label className="flex cursor-pointer items-center gap-2 rounded-lg border border-border bg-secondary p-3 hover:border-primary/50">
                <Upload size={18} className="text-primary" />
                <span className="min-w-0 truncate text-sm">{editFile?.name || 'Reemplazar o agregar archivo'}</span>
                <input type="file" accept=".ppt,.pptx,.pdf" className="hidden" onChange={(event) => { setEditFile(event.target.files?.[0] || null); setRemoveEditFile(false); }} />
              </label>
              {editingTalk.file_name && !editFile && (
                <label className="flex cursor-pointer items-center gap-2 text-sm text-muted-foreground">
                  <input type="checkbox" checked={removeEditFile} onChange={(event) => setRemoveEditFile(event.target.checked)} />
                  Eliminar archivo adjunto actual
                </label>
              )}
              <button type="button" onClick={() => void handleUpdateTalk()} disabled={isSaving || !editTitle.trim()} className="w-full rounded-lg bg-primary py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90 disabled:opacity-50">{isSaving ? 'Guardando...' : 'Guardar cambios'}</button>
            </div>
          ) : isLoadingQr ? (
            <div className="space-y-4" aria-live="polite">
              <div className="flex items-center justify-between gap-3">
                <h3 className="text-lg font-bold">Generando código QR</h3>
                <span className="text-sm text-muted-foreground">Cargando...</span>
              </div>
              <div className="mx-auto aspect-square w-full max-w-sm animate-pulse rounded-lg bg-secondary" />
              <div className="mx-auto h-4 w-2/3 animate-pulse rounded bg-secondary" />
            </div>
          ) : qrTalk ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between gap-3">
                <h3 className="text-lg font-bold">QR de asistencia</h3>
                <button type="button" onClick={() => setQrTalk(null)} className="text-muted-foreground hover:text-foreground" aria-label="Cerrar QR"><X size={20} /></button>
              </div>
              <p className="text-sm font-medium">{qrTalk.title}</p>
              {qrTalk.image ? <img src={qrTalk.image} alt={`QR de asistencia de ${qrTalk.title}`} className="mx-auto w-full max-w-sm rounded-lg bg-white p-3" /> : <p className="text-sm text-muted-foreground">No fue posible cargar el código QR.</p>}
            </div>
          ) : showAddAttendance ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold">Registrar asistencia</h3>
                <button type="button" onClick={() => setShowAddAttendance(false)} className="text-muted-foreground hover:text-foreground" aria-label="Cerrar registro de asistencia"><X size={20} /></button>
              </div>
              <div>
                <label className="mb-1 block text-xs text-muted-foreground">Charla</label>
                {attTalkId ? <div className="rounded-lg border border-border bg-secondary/50 px-3 py-2 text-sm font-medium">{attTopic}</div> : (
                  <select value="" onChange={(event) => { const talk = talks.find((item) => item.talk_id === event.target.value); setAttTalkId(talk?.talk_id || ''); setAttTopic(talk?.title || ''); }} className="w-full rounded-lg border border-border bg-secondary px-3 py-2 text-sm">
                    <option value="">Seleccionar charla...</option>
                    {talks.map((talk) => <option key={talk.talk_id} value={talk.talk_id}>{talk.title}</option>)}
                  </select>
                )}
              </div>
              <div>
                <label className="mb-1 block text-xs text-muted-foreground">Área objetivo</label>
                <input value={attArea} onChange={(event) => setAttArea(event.target.value)} placeholder="Ej: Línea 1" className="w-full rounded-lg border border-border bg-secondary px-3 py-2 text-sm" />
              </div>
              <div>
                <label className="mb-1 block text-xs text-muted-foreground">Asistentes ({attendeeList.length})</label>
                <div className="relative">
                  <input value={userSearch} onChange={(event) => setUserSearch(event.target.value)} placeholder="Buscar trabajador..." className="w-full rounded-lg border border-border bg-secondary px-3 py-2 text-sm" />
                  {userSearch && (
                    <div className="absolute z-10 mt-1 max-h-40 w-full overflow-y-auto rounded-lg border border-border bg-card shadow-lg">
                      {matchingUsers.map((user) => (
                        <button key={user.id} type="button" onClick={() => { setAttAttendees((previous) => previous ? `${previous},${user.name}` : user.name); setUserSearch(''); }} className="flex w-full justify-between px-3 py-2 text-left text-sm hover:bg-secondary/50">
                          <span>{user.name}</span><span className="text-xs text-muted-foreground">{user.email || user.role}</span>
                        </button>
                      ))}
                      {matchingUsers.length === 0 && <p className="px-3 py-2 text-sm text-muted-foreground">No hay trabajadores disponibles para esta búsqueda.</p>}
                    </div>
                  )}
                </div>
                {attendeeList.length > 0 && (
                  <div className="mt-2 flex max-h-32 flex-wrap gap-1 overflow-y-auto rounded-lg bg-secondary/30 p-2">
                    {attendeeList.map((name) => <span key={name} className="flex items-center gap-1 rounded-full bg-primary/20 px-2 py-1 text-xs text-primary">{name}<button type="button" onClick={() => removeAttendee(name)} className="hover:text-primary/60"><X size={12} /></button></span>)}
                  </div>
                )}
              </div>
              <div>
                <label className="mb-1 block text-xs text-muted-foreground">Retroalimentación</label>
                <textarea value={attFeedback} onChange={(event) => setAttFeedback(event.target.value)} rows={3} placeholder="Observaciones, comentarios o sugerencias..." className="w-full resize-none rounded-lg border border-border bg-secondary px-3 py-2 text-sm" />
              </div>
              <button type="button" onClick={() => void handleAddAttendance()} disabled={isSaving || !attTopic || !attTalkId || attendeeList.length === 0} className="w-full rounded-lg bg-primary py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90 disabled:opacity-50">{isSaving ? 'Guardando...' : 'Registrar asistencia'}</button>
            </div>
          ) : selectedTalk ? (
            <div className="space-y-4">
              {/* Cabecera del listado */}

              <div className="border-b border-border pb-4">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">
                      Charla seleccionada
                    </p>

                  </div>
                    <h2 className="text-base font-semibold text-center">
                      {selectedTalk.title}
                    </h2>

                  <button
                    type="button"
                    onClick={() =>
                      setSelectedTalkId(null)
                    }
                    aria-label="Cerrar listado de asistencia"
                    className="p-1 text-muted-foreground hover:text-foreground rounded"
                  >
                    <X size={18} />
                  </button>
                </div>

                {/* Contador de asistentes */}

                <div className="mt-3">
                  <span className="inline-flex items-center gap-2 text-xs bg-primary/20 text-primary px-3 py-1.5 rounded-lg">
                    <Users size={14} />
                    {totalAttendees} asistentes
                  </span>
                </div>
              </div>

              {/* Participantes y filtros por modalidad de registro */}

              <div className="space-y-3 max-h-96 overflow-y-auto pr-1">
                {selectedAttendance.length === 0 ? (
                  <div className="text-center text-muted-foreground text-sm p-8">
                    <Users size={40} className="mx-auto mb-3 opacity-30" />
                    <p>No hay registros de asistencia</p>
                    <p className="mt-1 text-xs">para esta charla.</p>
                  </div>
                ) : (
                  <>
                    <div className="border-b border-border pb-3">
                      <p className="text-sm font-medium">
                        Participantes · fecha y hora de registro (hora local)
                      </p>
                      <div className="mt-3 flex justify-center gap-2">
                        <button
                          type="button"
                          onClick={() => setAttendanceSourceFilter('all')}
                          aria-label="Mostrar todos los registros"
                          title="Todos los registros"
                          className={`rounded-md p-2 transition-colors ${
                            attendanceSourceFilter === 'all'
                              ? 'bg-primary text-primary-foreground'
                              : 'bg-secondary text-muted-foreground hover:text-foreground'
                          }`}
                        >
                          <Users size={16} />
                        </button>
                        <button
                          type="button"
                          onClick={() => setAttendanceSourceFilter('qr')}
                          aria-label="Filtrar registros QR"
                          title="Registro por código QR"
                          className={`rounded-md p-2 transition-colors ${
                            attendanceSourceFilter === 'qr'
                              ? 'bg-primary text-primary-foreground'
                              : 'bg-secondary text-muted-foreground hover:text-foreground'
                          }`}
                        >
                          <QrCode size={16} />
                        </button>
                        <button
                          type="button"
                          onClick={() => setAttendanceSourceFilter('manual')}
                          aria-label="Filtrar registros manuales"
                          title="Registro manual"
                          className={`rounded-md p-2 transition-colors ${
                            attendanceSourceFilter === 'manual'
                              ? 'bg-primary text-primary-foreground'
                              : 'bg-secondary text-muted-foreground hover:text-foreground'
                          }`}
                        >
                          <Hand size={16} />
                        </button>
                        <button
                          type="button"
                          onClick={() => setAttendanceSourceFilter('sheet')}
                          aria-label="Filtrar registros por hoja"
                          title="Registro mediante hoja de asistencia"
                          className={`rounded-md p-2 transition-colors ${
                            attendanceSourceFilter === 'sheet'
                              ? 'bg-primary text-primary-foreground'
                              : 'bg-secondary text-muted-foreground hover:text-foreground'
                          }`}
                        >
                          <Image size={16} />
                        </button>
                      </div>
                    </div>

                    {visibleParticipants.length === 0 ? (
                      <p className="py-6 text-center text-sm text-muted-foreground">
                        No hay participantes para este filtro.
                      </p>
                    ) : (
                      <div className="space-y-2">
                        {visibleParticipants.map((participant) => {
                          const MethodIcon =
                            participant.method === 'qr'
                              ? QrCode
                              : participant.method === 'sheet'
                                ? Image
                                : Hand;

                          return (
                            <div
                              key={participant.id}
                              className="flex items-center gap-3 rounded-lg bg-secondary/30 p-3"
                            >
                              <span
                                title={attendanceMethodLabel(participant.method)}
                                className="inline-flex size-8 shrink-0 items-center justify-center rounded-full bg-primary/15 text-primary"
                              >
                                <MethodIcon size={16} />
                              </span>
                              <div className="min-w-0">
                                <p className="truncate text-sm font-medium">
                                  {participant.name}
                                </p>
                                <p className="text-xs text-muted-foreground">
                                  {formatRegistrationDate(participant.registeredAt)}
                                </p>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}

                    {selectedAttendance
                      .filter((record) => Boolean(record.feedback))
                      .map((record) => (
                        <p
                          key={`${record.attendance_id}-feedback`}
                          className="rounded-lg bg-secondary/30 p-3 text-xs italic text-muted-foreground"
                        >
                          {record.feedback}
                        </p>
                      ))}

                    {attendanceImagePreview && (
                      <div className="border-t border-border pt-4">
                        <p className="mb-2 text-sm font-medium">
                          Hoja de asistencia adjunta
                        </p>
                        <img
                          src={attendanceImagePreview}
                          alt={attendanceFileRecord?.file_name || 'Hoja de asistencia'}
                          className="max-h-[32rem] w-full rounded-lg border border-border object-contain"
                        />
                      </div>
                    )}
                  </>
                )}
              </div>
            </div>
          ) : (
            /* Sin charla seleccionada */

            <div className="text-center text-muted-foreground text-sm p-8">
              <Users
                size={48}
                className="mx-auto mb-3 opacity-30"
              />

              <p>
                Selecciona «Ver listado» en una charla
              </p>

              <p>
                para consultar sus registros de
                asistencia.
              </p>
            </div>
          )}
        </div>
      </div>

      {/* ==================================
          MODAL: NUEVA CHARLA
      ================================== */}

      {false && showAddTalk && (
        <div
          className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4"
          onClick={() =>
            setShowAddTalk(false)
          }
        >
          <div
            className="bg-card border border-border rounded-xl w-full max-w-md p-6"
            onClick={(e) =>
              e.stopPropagation()
            }
          >
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-bold text-center">
                Nueva charla de seguridad
              </h2>

              <button
                type="button"
                onClick={() =>
                  setShowAddTalk(false)
                }
                className="text-muted-foreground hover:text-foreground"
              >
                <X size={20} />
              </button>
            </div>

            <div className="space-y-3">
              <input
                value={newTitle}
                onChange={(e) =>
                  setNewTitle(
                    e.target.value
                  )
                }
                placeholder="Título de la charla..."
                className="w-full px-3 py-2 bg-secondary border border-border rounded-lg text-sm"
              />

              <div className="flex gap-2">
                <select
                  value={month}
                  onChange={(e) =>
                    setMonth(
                      e.target.value
                    )
                  }
                  className="flex-1 px-3 py-2 bg-secondary border border-border rounded-lg text-sm"
                >
                  {MONTHS.map(
                    (m, i) => (
                      <option
                        key={i}
                        value={String(
                          i + 1
                        )}
                      >
                        {m}
                      </option>
                    )
                  )}
                </select>

                <select
                  value={year}
                  onChange={(e) =>
                    setYear(
                      e.target.value
                    )
                  }
                  className="flex-1 px-3 py-2 bg-secondary border border-border rounded-lg text-sm"
                >
                  {[2025, 2026, 2027].map(
                    (y) => (
                      <option
                        key={y}
                        value={String(y)}
                      >
                        {y}
                      </option>
                    )
                  )}
                </select>
              </div>

              <label className="flex items-center gap-2 p-3 bg-secondary border border-border rounded-lg cursor-pointer hover:border-primary/50">
                <Upload
                  size={18}
                  className="text-primary"
                />

                <span className="text-sm">
                  {newFile
                    ? newFile.name
                    : 'Subir archivo PPT/PDF'}
                </span>

                <input
                  type="file"
                  accept=".ppt,.pptx,.pdf"
                  className="hidden"
                  onChange={(e) =>
                    setNewFile(
                      e.target.files?.[0] ||
                        null
                    )
                  }
                />
              </label>

              <button
                type="button"
                onClick={handleAddTalk}
                disabled={!newTitle}
                className="w-full py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:bg-primary/90 disabled:opacity-50"
              >
                Guardar charla
              </button>
            </div>
          </div>
        </div>
      )}

      {false && editingTalk && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4"
          onClick={() => setEditingTalk(null)}
        >
          <div
            className="w-full max-w-md rounded-xl border border-border bg-card p-6"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="mb-4 flex items-center justify-between">
              <h3 className="text-lg font-bold">Modificar charla</h3>
              <button type="button" onClick={() => setEditingTalk(null)} className="text-muted-foreground hover:text-foreground" aria-label="Cerrar modificación">
                <X size={20} />
              </button>
            </div>

            <div className="space-y-4">
              <input
                value={editTitle}
                onChange={(event) => setEditTitle(event.target.value)}
                aria-label="Título de la charla"
                className="w-full rounded-lg border border-border bg-secondary px-3 py-2 text-sm"
              />

              <label className="flex cursor-pointer items-center gap-2 rounded-lg border border-border bg-secondary p-3 hover:border-primary/50">
                <Upload size={18} className="text-primary" />
                <span className="text-sm">{editFile?.name || 'Reemplazar o agregar archivo'}</span>
                <input
                  type="file"
                  accept=".ppt,.pptx,.pdf"
                  className="hidden"
                  onChange={(event) => {
                    setEditFile(event.target.files?.[0] || null);
                    setRemoveEditFile(false);
                  }}
                />
              </label>

              {editingTalk.file_name && !editFile && (
                <label className="flex cursor-pointer items-center gap-2 text-sm text-muted-foreground">
                  <input
                    type="checkbox"
                    checked={removeEditFile}
                    onChange={(event) => setRemoveEditFile(event.target.checked)}
                  />
                  Eliminar archivo adjunto actual
                </label>
              )}

              <button
                type="button"
                onClick={() => void handleUpdateTalk()}
                disabled={!editTitle.trim()}
                className="w-full rounded-lg bg-primary py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90 disabled:opacity-50"
              >
                Guardar cambios
              </button>
            </div>
          </div>
        </div>
      )}

      {false && qrTalk && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4"
          onClick={() => setQrTalk(null)}
        >
          <div
            className="w-full max-w-sm rounded-xl border border-border bg-card p-6"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="mb-4 flex items-center justify-between gap-3">
              <h3 className="text-lg font-bold">QR de asistencia</h3>
              <button type="button" onClick={() => setQrTalk(null)} className="text-muted-foreground hover:text-foreground" aria-label="Cerrar QR">
                <X size={20} />
              </button>
            </div>
            <p className="mb-4 text-sm font-medium">{qrTalk.title}</p>
            {qrTalk.image ? (
              <img src={qrTalk.image} alt={`QR de asistencia de ${qrTalk.title}`} className="w-full rounded-lg bg-white p-3" />
            ) : (
              <p className="text-sm text-muted-foreground">No fue posible cargar el código QR.</p>
            )}
            <button type="button" onClick={() => setQrTalk(null)} className="mt-4 w-full rounded-lg border border-border py-2 text-sm font-medium hover:bg-secondary">
              Cerrar
            </button>
          </div>
        </div>
      )}

      {/* ==================================
          MODAL: REGISTRAR ASISTENCIA
      ================================== */}

      {false && showAddAttendance && (
        <div
          className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4"
          onClick={() =>
            setShowAddAttendance(false)
          }
        >
          <div
            className="bg-card border border-border rounded-xl w-full max-w-lg p-6 max-h-[90vh] overflow-y-auto"
            onClick={(e) =>
              e.stopPropagation()
            }
          >
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-bold">
                Registrar asistencia
              </h3>

              <button
                type="button"
                onClick={() =>
                  setShowAddAttendance(false)
                }
                className="text-muted-foreground hover:text-foreground"
              >
                <X size={20} />
              </button>
            </div>

            <div className="space-y-3">
              {/* La charla queda identificada antes de registrar asistencia. */}
              <div>
                <label className="text-xs text-muted-foreground block mb-1">
                  Charla
                </label>

                {attTalkId ? (
                  <div className="rounded-lg border border-border bg-secondary/50 px-3 py-2 text-sm font-medium">
                    {attTopic}
                  </div>
                ) : (
                  <select
                    value=""
                    onChange={(event) => {
                      const talk = talks.find((item) => item.talk_id === event.target.value);
                      setAttTalkId(talk?.talk_id || '');
                      setAttTopic(talk?.title || '');
                    }}
                    className="w-full px-3 py-2 bg-secondary border border-border rounded-lg text-sm"
                  >
                    <option value="">Seleccionar charla...</option>
                    {talks.map((talk) => (
                      <option key={talk.talk_id} value={talk.talk_id}>
                        {talk.title}
                      </option>
                    ))}
                  </select>
                )}
              </div>

              <div>
                <label className="text-xs text-muted-foreground block mb-1">
                  Área objetivo
                </label>

                <input
                  value={attArea}
                  onChange={(e) => setAttArea(e.target.value)}
                  placeholder="Ej: Línea 1"
                  className="w-full px-3 py-2 bg-secondary border border-border rounded-lg text-sm"
                />
              </div>

              {/* Asistentes */}

              <div>
                <label className="text-xs text-muted-foreground block mb-1">
                  Asistentes ({attendeeList.length})
                </label>

                <div className="relative mb-2">
                  <input
                    value={userSearch}
                    onChange={(e) =>
                      setUserSearch(
                        e.target.value
                      )
                    }
                    placeholder="Buscar trabajador..."
                    className="w-full px-3 py-2 bg-secondary border border-border rounded-lg text-sm"
                  />

                  {userSearch && (
                    <div className="absolute z-10 w-full mt-1 bg-card border border-border rounded-lg shadow-lg max-h-40 overflow-y-auto">
                      {matchingUsers.map(
                          (u) => (
                            <button
                              key={u.id}
                              type="button"
                              onClick={() => {
                                setAttAttendees(
                                  (prev) =>
                                    prev
                                      ? prev +
                                        ',' +
                                        u.name
                                      : u.name
                                );
                                setUserSearch(
                                  ''
                                );
                              }}
                              className="w-full text-left px-3 py-2 text-sm hover:bg-secondary/50 flex justify-between"
                            >
                              <span>
                                {u.name}
                              </span>

                              <span className="text-xs text-muted-foreground">
                                {u.email || u.role}
                              </span>
                            </button>
                          )
                        )}

                      {matchingUsers.length === 0 && (
                        <div className="px-3 py-2 text-sm text-muted-foreground">
                          No hay trabajadores disponibles para esta búsqueda.
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Nombres seleccionados */}

                {attendeeList.length > 0 && (
                  <div className="flex flex-wrap gap-1 p-2 bg-secondary/30 rounded-lg max-h-32 overflow-y-auto">
                    {attendeeList.map(
                      (name, i) => (
                        <span
                          key={i}
                          className="flex items-center gap-1 px-2 py-1 bg-primary/20 text-primary text-xs rounded-full"
                        >
                          {name}

                          <button
                            type="button"
                            onClick={() =>
                              removeAttendee(
                                name
                              )
                            }
                            className="hover:text-primary/60"
                          >
                            <X size={12} />
                          </button>
                        </span>
                      )
                    )}
                  </div>
                )}
              </div>

              {/* Retroalimentación */}

              <div>
                <label className="text-xs text-muted-foreground block mb-1">
                  Retroalimentación
                </label>

                <textarea
                  value={attFeedback}
                  onChange={(e) =>
                    setAttFeedback(
                      e.target.value
                    )
                  }
                  rows={3}
                  placeholder="Observaciones, comentarios o sugerencias..."
                  className="w-full px-3 py-2 bg-secondary border border-border rounded-lg text-sm resize-none"
                />
              </div>

              {/* Guardar asistencia */}

              <button
                type="button"
                onClick={handleAddAttendance}
                disabled={
                  !attTopic || !attTalkId || attendeeList.length === 0
                }
                className="w-full py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:bg-primary/90 disabled:opacity-50"
              >
                Registrar asistencia
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
