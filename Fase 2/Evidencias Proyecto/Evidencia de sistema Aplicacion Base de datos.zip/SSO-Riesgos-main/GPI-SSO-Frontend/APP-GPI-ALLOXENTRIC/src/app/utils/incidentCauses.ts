export const CAUSE_OPTIONS = [
  'Falta de EPP',
  'No seguir procedimiento',
  'Distracción o falta de atención',
  'Fatiga o cansancio',
  'Falta de capacitación',
  'Herramienta o equipo defectuoso',
  'Condición del entorno',
  'Otra',
] as const;

export const normalizeSearchText = (value: string) =>
  value
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .trim();

export const filterCauseOptions = (query: string) => {
  const normalizedQuery = normalizeSearchText(query);

  if (!normalizedQuery) {
    return [...CAUSE_OPTIONS];
  }

  return CAUSE_OPTIONS.filter(cause =>
    normalizeSearchText(cause).includes(normalizedQuery)
  );
};

export const toggleCauseSelection = (
  selectedCauses: string[],
  cause: string
) =>
  selectedCauses.includes(cause)
    ? selectedCauses.filter(item => item !== cause)
    : [...selectedCauses, cause];
