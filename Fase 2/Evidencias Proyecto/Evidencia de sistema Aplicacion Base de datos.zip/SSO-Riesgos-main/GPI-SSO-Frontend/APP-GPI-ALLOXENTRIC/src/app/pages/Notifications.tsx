import { useState } from 'react';
import type { Translation } from '../constants/translations';
import { motion, AnimatePresence } from 'motion/react';
import { AlertCircle, FileText, User, CheckCircle } from 'lucide-react';
import type { Notification } from '../App';

interface Props {
  t: Translation;
  notifications: Notification[]; // cambios de estado, creación de reportes, comentarios
  alerts: Notification[];        // alertas manuales creadas desde la plataforma web
  onMarkAllRead: () => void;
}

type Tab = 'reports' | 'alerts';

export default function Notifications({ t, notifications, alerts, onMarkAllRead }: Props) {
  const [tab, setTab] = useState<Tab>('reports');

  const active = tab === 'reports' ? (Array.isArray(notifications) ? notifications : []) : (Array.isArray(alerts) ? alerts : []);
  const now = new Date();
  const todayStr = now.toISOString().slice(0, 10);
  const yest = new Date(now); yest.setDate(yest.getDate() - 1);
  const yesterdayStr = yest.toISOString().slice(0, 10);
  const getDate = (n: any) => (n.created_at || n.date || '').slice(0, 10);
  const todayNotifs = active.filter(n => getDate(n) === todayStr);
  const yesterdayNotifs = active.filter(n => getDate(n) === yesterdayStr);
  const olderNotifs = active.filter(n => getDate(n) !== todayStr && getDate(n) !== yesterdayStr);

  const unreadReports = (Array.isArray(notifications) ? notifications : []).filter(n => !n.read).length;
  const activeAlerts  = (Array.isArray(alerts) ? alerts : []).filter(n => !n.read).length;

  const iconFor = (type: Notification['type']) => {
    if (type === 'alert')                       return <AlertCircle size={16} />;
    if (type === 'update' || type === 'actualizacion') return <FileText size={16} />;
    if (type === 'comment')                     return <User size={16} />;
    return <CheckCircle size={16} />;
  };

  const colorFor = (type: Notification['type'], dim = false) => {
    const opacity = dim ? '/30' : '';
    if (type === 'alert')                       return `bg-[#D72631]${opacity}`;
    if (type === 'update' || type === 'actualizacion') return `bg-[#1A5276]${opacity}`;
    if (type === 'comment')                     return `bg-[#16A34A]${opacity}`;
    return `bg-[#7E8A94]${opacity}`;
  };

  const renderCard = (notif: Notification, i: number, dim = false) => (
    <motion.div
      key={notif.id}
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: i * 0.05 }}
      className={`rounded-2xl p-4 flex gap-3 items-start ${!dim && tab === 'reports' && !notif.read ? 'themed-card border' : 'themed-card'}`}
    >
      <div className={`rounded-full p-2 ${colorFor(notif.type, dim)}`}>
        {iconFor(notif.type)}
      </div>
      <div className="flex-1">
        <p className="font-semibold text-sm mb-0.5">{notif.title}</p>
        <p className="text-xs themed-text-secondary">{notif.description}</p>
      </div>
      <div className="flex flex-col items-end gap-2">
        <span className="text-xs themed-text-tertiary">{notif.time}</span>
        {tab === 'alerts' ? (
          <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full whitespace-nowrap ${
            notif.read ? 'bg-[#16A34A]/20 text-[#16A34A]' : 'bg-[#D72631]/20 text-[#D72631]'
          }`}>
            {notif.read ? 'Resuelta' : 'Activa'}
          </span>
        ) : (
          !dim && !notif.read && <div className="w-2 h-2 bg-[#00E5FF] rounded-full"></div>
        )}
      </div>
    </motion.div>
  );

  return (
    <motion.div
      key="notifications"
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 20 }}
      className="h-full overflow-y-auto"
    >
      <div className="px-6 py-6">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-2xl font-bold">{t.notifications}</h1>
          {tab === 'reports' && (
            <button onClick={onMarkAllRead} className="text-sm text-[#00C2DB] font-semibold">
              {t.markAllRead}
            </button>
          )}
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-4 themed-card rounded-2xl p-1">
          <button
            onClick={() => setTab('reports')}
            className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl text-sm font-semibold transition-colors ${
              tab === 'reports' ? 'bg-[#00E5FF] text-white' : 'themed-text-secondary'
            }`}
          >
            Reportes
            {unreadReports > 0 && (
              <span className="bg-[#D72631] text-white text-[10px] min-w-[16px] h-4 rounded-full flex items-center justify-center px-1">
                {unreadReports}
              </span>
            )}
          </button>
          <button
            onClick={() => setTab('alerts')}
            className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl text-sm font-semibold transition-colors ${
              tab === 'alerts' ? 'bg-[#00E5FF] text-white' : 'themed-text-secondary'
            }`}
          >
            Alertas
            {activeAlerts > 0 && (
              <span className="bg-[#D72631] text-white text-[10px] min-w-[16px] h-4 rounded-full flex items-center justify-center px-1">
                {activeAlerts}
              </span>
            )}
          </button>
        </div>

        {tab === 'alerts' && (
          <p className="text-xs themed-text-tertiary mb-4">
            Las alertas se marcan como "Resuelta" desde la plataforma web, no desde la app.
          </p>
        )}

        <AnimatePresence mode="wait">
          <motion.div key={tab} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            {/* Today */}
            {todayNotifs.length > 0 && (
              <div className="mb-6">
                <p className="text-sm themed-text-tertiary mb-3 font-semibold">{t.today}</p>
                <div className="space-y-2">
                  {todayNotifs.map((notif, i) => renderCard(notif, i))}
                </div>
              </div>
            )}

            {/* Yesterday */}
            {yesterdayNotifs.length > 0 && (
              <div className="mb-20">
                <p className="text-sm themed-text-tertiary mb-3 font-semibold">{t.yesterday}</p>
                <div className="space-y-2">
                  {yesterdayNotifs.map((notif, i) => renderCard(notif, i, true))}
                </div>
              </div>
            )}

            {olderNotifs.length > 0 && (
              <div className="mb-20">
                <p className="text-sm themed-text-tertiary mb-3 font-semibold">Anteriores</p>
                <div className="space-y-2">
                  {olderNotifs.map((notif, i) => renderCard(notif, i, true))}
                </div>
              </div>
            )}
            {todayNotifs.length === 0 && yesterdayNotifs.length === 0 && olderNotifs.length === 0 && (
              <p className="themed-text-secondary text-sm text-center py-12">
                {tab === 'reports' ? 'No tienes notificaciones de reportes.' : 'No hay alertas.'}
              </p>
            )}
          </motion.div>
        </AnimatePresence>
      </div>
    </motion.div>
  );
}