from fastapi import APIRouter, Depends, HTTPException, Header
from pydantic import BaseModel, ConfigDict, EmailStr, Field
from app.dependencies import get_db
from app.config import settings
from app.services.report_manager_selector import (
    select_report_managers,
)

async def verify_internal_token(x_internal_token: str = Header(...)):
    if x_internal_token != settings.INTERNAL_API_KEY:
        raise HTTPException(status_code=403, detail="Token interno invalido")

router = APIRouter(prefix="/v1/internal", tags=["Internal"], dependencies=[Depends(verify_internal_token)])

class InternalAuthRequest(BaseModel):
    client_id: str
    email: EmailStr

@router.post("/users/by-email")
async def get_user_for_auth(payload: InternalAuthRequest, db=Depends(get_db)):
    doc = await db["users"].find_one({"email": payload.email, "client_id": payload.client_id})
    if not doc:
        raise HTTPException(status_code=404, detail="User not found")
    doc.pop("_id", None)
    return doc


class InternalIdentityRequest(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True)

    client_id: str = Field(min_length=1)
    user_id: str = Field(min_length=1)


@router.post("/users/by-id")
async def get_user_identity(payload: InternalIdentityRequest, db=Depends(get_db)):
    """Snapshot de identidad para renovar sesión; protegido por X-Internal-Token."""
    doc = await db["users"].find_one(
        {"user_id": payload.user_id, "client_id": payload.client_id},
        {"_id": 0, "user_id": 1, "client_id": 1, "role": 1,
         "status": 1, "assigned_areas": 1, "areas": 1, "area": 1},
    )
    if doc is None:
        raise HTTPException(status_code=404, detail="User not found")
    return doc

class ReportManagersRequest(BaseModel):
    client_id: str
    area_id: str
    exclude_user_id: str | None = None


@router.post("/users/report-managers")
async def get_report_managers(
    payload: ReportManagersRequest,
    db=Depends(get_db),
):
    users = []

    projection = {
        "_id": 0,
        "user_id": 1,
        "client_id": 1,
        "role": 1,
        "status": 1,
        "assigned_areas": 1,
        "area": 1,
    }

    cursor = db["users"].find(
        {
            "client_id": payload.client_id,
            "status": "active",
        },
        projection,
    )

    async for user in cursor:
        users.append(user)

    return select_report_managers(
        users,
        client_id=payload.client_id,
        area_id=payload.area_id,
        exclude_user_id=payload.exclude_user_id,
    )
