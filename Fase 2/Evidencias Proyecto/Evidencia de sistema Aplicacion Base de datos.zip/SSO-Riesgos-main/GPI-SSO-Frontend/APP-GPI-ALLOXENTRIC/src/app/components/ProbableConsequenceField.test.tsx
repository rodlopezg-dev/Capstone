import { describe, expect, it } from 'vitest';
import { renderToStaticMarkup } from 'react-dom/server';

import ProbableConsequenceField from './ProbableConsequenceField';

describe('ProbableConsequenceField - SCRUM-73', () => {
  it('renders the probable consequence label', () => {
    const html = renderToStaticMarkup(
      <ProbableConsequenceField
        value=""
        onChange={() => undefined}
      />
    );

    expect(html).toContain('Consecuencia probable');
  });

  it('renders the 22 official catalog options', () => {
    const html = renderToStaticMarkup(
      <ProbableConsequenceField
        value=""
        onChange={() => undefined}
      />
    );

    const optionCount =
      (html.match(/<option/g) || []).length;

    // Placeholder + 22 opciones oficiales.
    expect(optionCount).toBe(23);

    expect(html).toContain('Atrapamiento');
    expect(html).toContain('Atropellos');
    expect(html).toContain('Caída a distinto nivel');
    expect(html).toContain('Contacto con energía eléctrica');
    expect(html).toContain('Exposición a ruido');
    expect(html).toContain(
      'Sobreesfuerzos por manipulación de cargas'
    );
    expect(html).toContain('Ahogamiento');
  });

  it('does not render legacy probable incident options', () => {
    const html = renderToStaticMarkup(
      <ProbableConsequenceField
        value=""
        onChange={() => undefined}
      />
    );

    expect(html).not.toContain('Golpe o contusion');
    expect(html).not.toContain('Caida de persona');
    expect(html).not.toContain(
      'Intoxicacion o exposicion quimica'
    );
  });

  it('renders the persisted consequence as selected', () => {
    const html = renderToStaticMarkup(
      <ProbableConsequenceField
        value="Caída al mismo nivel"
        onChange={() => undefined}
      />
    );

    expect(html).toContain(
      '<option value="Caída al mismo nivel" selected="">'
    );
  });

  it('can be disabled', () => {
    const html = renderToStaticMarkup(
      <ProbableConsequenceField
        value=""
        onChange={() => undefined}
        disabled
      />
    );

    expect(html).toContain('disabled');
  });
});
