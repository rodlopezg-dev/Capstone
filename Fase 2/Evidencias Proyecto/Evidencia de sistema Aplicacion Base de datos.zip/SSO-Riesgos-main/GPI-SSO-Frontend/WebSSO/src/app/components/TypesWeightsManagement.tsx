import { HelpTooltip } from './HelpTooltip';
import { useState } from 'react';
import { Plus, Trash2 } from 'lucide-react';

interface Precursor {
  id: string;
  name: string;
  category: 'Acto Inseguro' | 'Condicion Insegura';
  weight: number;
  active: boolean;
}

const INITIAL_PRECURSORS: Precursor[] = [
  { id: '1', name: 'No observar el entorno antes o durante la tarea', category: 'Acto Inseguro', weight: 10, active: true },
  { id: '2', name: 'Ingresar a un area sin autorizacion', category: 'Acto Inseguro', weight: 10, active: true },
  { id: '3', name: 'No respetar barreras, senalizacion o zonas demarcadas', category: 'Acto Inseguro', weight: 15, active: true },
  { id: '4', name: 'Ubicarse en linea de fuego', category: 'Acto Inseguro', weight: 20, active: true },
  { id: '5', name: 'Transitar bajo carga suspendida', category: 'Acto Inseguro', weight: 25, active: true },
  { id: '6', name: 'Intervenir equipo en movimiento', category: 'Acto Inseguro', weight: 25, active: true },
  { id: '7', name: 'No aplicar bloqueo o prueba de energia cero', category: 'Acto Inseguro', weight: 30, active: true },
  { id: '8', name: 'Operar equipo movil sin autorizacion', category: 'Acto Inseguro', weight: 20, active: true },
  { id: '9', name: 'No usar EPP requerido', category: 'Acto Inseguro', weight: 15, active: true },
  { id: '10', name: 'Usar EPP inadecuado o en mal estado', category: 'Acto Inseguro', weight: 10, active: true },
  { id: '11', name: 'Ejecutar trabajo critico sin permiso autorizado', category: 'Acto Inseguro', weight: 25, active: true },
  { id: '12', name: 'Usar celular u otro distractor durante la tarea', category: 'Acto Inseguro', weight: 10, active: true },
  { id: '13', name: 'Desviarse del procedimiento o pauta de trabajo', category: 'Acto Inseguro', weight: 15, active: true },
  { id: '14', name: 'Piso mojado o resbaloso', category: 'Condicion Insegura', weight: 15, active: true },
  { id: '15', name: 'Cable suelto o expuesto', category: 'Condicion Insegura', weight: 20, active: true },
  { id: '16', name: 'Andamio o plataforma inestable', category: 'Condicion Insegura', weight: 25, active: true },
  { id: '17', name: 'Falta de senalizacion', category: 'Condicion Insegura', weight: 10, active: true },
  { id: '18', name: 'Iluminacion deficiente', category: 'Condicion Insegura', weight: 10, active: true },
  { id: '19', name: 'Derrame de sustancia', category: 'Condicion Insegura', weight: 20, active: true },
  { id: '20', name: 'Herramienta o equipo defectuoso', category: 'Condicion Insegura', weight: 15, active: true },
];

export default function TypesWeightsManagement() {
  const [precursors, setPrecursors] = useState<Precursor[]>(INITIAL_PRECURSORS);
  const [newName, setNewName] = useState('');
  const [newCategory, setNewCategory] = useState<'Acto Inseguro' | 'Condicion Insegura'>('Acto Inseguro');
  const [newWeight, setNewWeight] = useState(10);
  const [filterCategory, setFilterCategory] = useState<'all' | 'Acto Inseguro' | 'Condicion Insegura'>('all');
  const [search, setSearch] = useState('');

  const handleCreate = () => {
    if (!newName.trim()) return;
    const id = String(Date.now());
    setPrecursors(prev => [...prev, { id, name: newName.trim(), category: newCategory, weight: newWeight, active: true }]);
    setNewName('');
    setNewWeight(10);
  };

  const handleDelete = (id: string) => {
    setPrecursors(prev => prev.filter(p => p.id !== id));
  };

  const handleToggle = (id: string) => {
    setPrecursors(prev => prev.map(p => p.id === id ? { ...p, active: !p.active } : p));
  };

  const filtered = precursors
    .filter(p => filterCategory === 'all' || p.category === filterCategory)
    .filter(p => p.name.toLowerCase().includes(search.toLowerCase()));

  const actoCount = precursors.filter(p => p.category === 'Acto Inseguro').length;
  const condCount = precursors.filter(p => p.category === 'Condicion Insegura').length;

  return (
    <div className="h-full p-6 overflow-auto">
      <div className="mb-6">
        <h1 className="text-4xl mb-2 tracking-tight"
          style={{ fontFamily: 'var(--font-display)', fontWeight: 700 }}>
          PRECURSORES Y CAUSAS
        </h1>
        <HelpTooltip steps={[
          { icon: '📋', title: 'Precursores', description: 'Administra las causas que aparecen en la lista desplegable de la app movil cuando un trabajador crea un reporte.' },
          { icon: '⚖️', title: 'Pesos', description: 'Cada precursor tiene un peso que afecta el calculo del score de riesgo en el mapa de calor.' },
          { icon: '📂', title: 'Categorias', description: 'Los precursores se agrupan en Acto Inseguro o Condicion Insegura. Segun la categoria, aparecen en el paso correspondiente del wizard de reporte.' },
          { icon: '✅', title: 'Activar/Desactivar', description: 'Puedes desactivar un precursor sin eliminarlo. Los inactivos no aparecen como opcion en la app movil.' },
        ]} />
        <p className="text-muted-foreground">Administra las causas que aparecen en el menu desplegable de la app movil</p>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="bg-card border border-border rounded-lg p-4 text-center">
          <p className="text-2xl font-bold">{precursors.length}</p>
          <p className="text-xs text-muted-foreground">Total precursores</p>
        </div>
        <div className="bg-card border border-border rounded-lg p-4 text-center">
          <p className="text-2xl font-bold text-[#E8941A]">{actoCount}</p>
          <p className="text-xs text-muted-foreground">Actos Inseguros</p>
        </div>
        <div className="bg-card border border-border rounded-lg p-4 text-center">
          <p className="text-2xl font-bold text-[#D72631]">{condCount}</p>
          <p className="text-xs text-muted-foreground">Condiciones Inseguras</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Formulario */}
        <div className="bg-card border border-border rounded-lg p-6">
          <h2 className="text-lg mb-4 text-primary uppercase tracking-wide flex items-center gap-2"
            style={{ fontFamily: 'var(--font-display)', fontWeight: 600 }}>
            <span className="w-1.5 h-4 bg-primary rounded-sm block"></span>
            Agregar Precursor
          </h2>
          <div className="space-y-4">
            <div>
              <label className="text-sm text-muted-foreground mb-1 block">Categoria</label>
              <select value={newCategory} onChange={e => setNewCategory(e.target.value as any)}
                className="w-full px-3 py-2 bg-secondary border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary">
                <option value="Acto Inseguro">Acto Inseguro</option>
                <option value="Condicion Insegura">Condicion Insegura</option>
              </select>
            </div>
            <div>
              <label className="text-sm text-muted-foreground mb-1 block">Nombre del precursor</label>
              <textarea value={newName} onChange={e => setNewName(e.target.value)}
                placeholder="Ej: No usar EPP requerido..."
                className="w-full px-3 py-2 bg-secondary border border-border rounded-lg text-sm h-20 resize-none focus:outline-none focus:ring-2 focus:ring-primary" />
            </div>
            <div>
              <label className="text-sm text-muted-foreground mb-1 block">Peso (impacto en score): {newWeight}</label>
              <input type="range" min="1" max="50" value={newWeight}
                onChange={e => setNewWeight(Number(e.target.value))}
                className="w-full" />
              <div className="flex justify-between text-xs text-muted-foreground mt-1">
                <span>Bajo</span><span>Alto</span>
              </div>
            </div>
            <button onClick={handleCreate} disabled={!newName.trim()}
              className="w-full py-2 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90 transition-all disabled:opacity-50 flex items-center justify-center gap-2">
              <Plus size={16} />
              Agregar precursor
            </button>
          </div>
        </div>

        {/* Lista */}
        <div className="lg:col-span-2 bg-card border border-border rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg text-primary uppercase tracking-wide flex items-center gap-2"
              style={{ fontFamily: 'var(--font-display)', fontWeight: 600 }}>
              <span className="w-1.5 h-4 bg-primary rounded-sm block"></span>
              Precursores Registrados
            </h2>
            <span className="text-sm text-muted-foreground">{filtered.length} items</span>
          </div>

          {/* Filtros */}
          <div className="flex gap-2 mb-4">
            {[
              { value: 'all', label: 'Todos' },
              { value: 'Acto Inseguro', label: 'Actos Inseguros' },
              { value: 'Condicion Insegura', label: 'Condiciones Inseguras' },
            ].map(f => (
              <button key={f.value} onClick={() => setFilterCategory(f.value as any)}
                className={"px-3 py-1.5 rounded-lg text-sm font-medium transition-all " + (filterCategory === f.value ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground hover:bg-secondary/80")}>
                {f.label}
              </button>
            ))}
          </div>

          <input type="text" value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Buscar precursor..."
            className="w-full px-3 py-2 bg-secondary border border-border rounded-lg text-sm mb-4 focus:outline-none focus:ring-2 focus:ring-primary" />

          <div className="space-y-2 max-h-[500px] overflow-y-auto">
            {filtered.map(p => (
              <div key={p.id}
                className={"p-3 rounded-lg border transition-all flex items-center justify-between " + (p.active ? "bg-secondary/50 border-border" : "bg-secondary/20 border-border/50 opacity-60")}>
                <div className="flex items-center gap-3 flex-1">
                  <span className={"text-xs px-2 py-0.5 rounded-full font-medium " + (p.category === 'Acto Inseguro' ? "bg-[#E8941A]/20 text-[#E8941A]" : "bg-[#D72631]/20 text-[#D72631]")}>
                    {p.category === 'Acto Inseguro' ? 'AI' : 'CI'}
                  </span>
                  <span className="text-sm">{p.name}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono text-muted-foreground">Peso: {p.weight}</span>
                  <button onClick={() => handleToggle(p.id)}
                    className={"px-2 py-1 rounded text-xs font-medium " + (p.active ? "bg-green-500/20 text-green-400" : "bg-secondary text-muted-foreground")}>
                    {p.active ? 'Activo' : 'Inactivo'}
                  </button>
                  <button onClick={() => handleDelete(p.id)}
                    className="p-1 text-muted-foreground hover:text-red-400 transition-colors">
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
