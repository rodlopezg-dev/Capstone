import os
from dotenv import load_dotenv

load_dotenv()

def get_required_env(name: str) -> str:
    value = os.getenv(name)
    if not value:
        raise RuntimeError(f"Missing required environment variable: {name}")
    return value


class Settings:
    JWT_SECRET: str = get_required_env("JWT_SECRET")
    JWT_ALGORITHM: str = "HS256"
    INTERNAL_API_KEY: str = get_required_env("INTERNAL_API_KEY")

settings = Settings()
