
import unicodedata
from collections import defaultdict

from .schemas import (
    ExtractedAttendance,
    PreviewWorker,
)


def normalize_text(value: str | None) -> str:
    value = unicodedata.normalize(
        "NFKD",
        value or "",
    )

    value = "".join(
        character
        for character in value
        if not unicodedata.combining(character)
    )

    return " ".join(
        value.casefold().split()
    )


def match_extracted_workers(
    extracted: ExtractedAttendance,
    registered_workers: list[dict],
) -> list[PreviewWorker]:

    by_name = defaultdict(list)
    by_email = defaultdict(list)

    for worker in registered_workers:
        full_name = " ".join(
            filter(
                None,
                [
                    worker.get("name"),
                    worker.get("last_name"),
                ],
            )
        ).strip()

        worker["_ocr_full_name"] = full_name

        normalized_name = normalize_text(full_name)
        normalized_email = normalize_text(
            worker.get("email")
        )

        if normalized_name:
            by_name[normalized_name].append(worker)

        if normalized_email:
            by_email[normalized_email].append(worker)

    results = []

    for person in extracted.workers:
        name = (person.name or "").strip()
        email = (person.email or "").strip() or None

        if not name and not email:
            continue

        normalized_name = normalize_text(name)
        normalized_email = normalize_text(email)

        name_matches = by_name.get(
            normalized_name, []
        )

        suggested_id = None
        status = "unmatched"

        if person.needs_review or not name:
            status = "review"

        elif normalized_email:
            email_matches = by_email.get(
                normalized_email, []
            )

            exact_matches = [
                worker
                for worker in name_matches
                if normalize_text(
                    worker.get("email")
                ) == normalized_email
            ]

            if (
                len(exact_matches) == 1
                and len(email_matches) == 1
            ):
                suggested_id = exact_matches[0]["user_id"]
                status = "suggested"

            elif (
                len(exact_matches) > 1
                or len(email_matches) > 1
            ):
                status = "ambiguous"

            else:
                status = "review"

        elif len(name_matches) == 1:
            suggested_id = name_matches[0]["user_id"]
            status = "suggested"

        elif len(name_matches) > 1:
            status = "ambiguous"

        results.append(
            PreviewWorker(
                local_id=f"ocr-{len(results) + 1}",
                row=person.row,
                name=name,
                email=email,
                user_id=None,
                suggested_user_id=suggested_id,
                match_status=status,
                needs_review=(
                    person.needs_review
                    or status != "suggested"
                ),
            )
        )

    return results
