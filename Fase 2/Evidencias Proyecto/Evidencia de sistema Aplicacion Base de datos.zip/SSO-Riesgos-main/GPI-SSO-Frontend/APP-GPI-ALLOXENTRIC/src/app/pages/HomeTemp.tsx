import type { Translation } from '../constants/translations';
import { motion } from 'motion/react';
import { Bell, FileText, CheckCircle, Camera, AlertCircle, ChevronRight, BookOpen } from 'lucide-react';
import type { Alert } from '../App';
import type { Report } from '../api/reports';

interface Props {
  user: { name: string; shift: string; area: string; stats: { totalReports: number; thisMonth: number; effectiveness: number } };
  t: Translation;
  alerts: Alert[];
  criticalAlert: { area: string; level: string } | null;
  reports: Report[];
  openReportsCount: number;
  closedThisMonth: number;
  unreadCount: number;
  onNavigateNotifications: () => void;
  onNavigateReports: () => void;
  onOpenCreateReport: () => void;
  onNavigateTalks?: () => void;
}

export default function Home({
  user, t, alerts, criticalAlert, reports,
  openReportsCount, closedThisMonth, unreadCount,
  onNavigateNotifications, onNavigateReports, onOpenCreateReport, onNavigateTalks,
}: Props) {
  return (
    <motion.div
      key="home"
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 20 }}
      className="h-full overflow-y-auto px-6 py-6"
    >
      {/* Header */}
      <div className="mb-6 relative">
        <p className="text-xs themed-text-secondary mb-1">{t.goodMorning}</p>
        <h1 className="text-2xl font-bold mb-1">{user.name}</h1>
        <p className="text-xs text-[#00C2DB]">{t.shift}: {user.shift} • {t.area}: {user.area}</p>
        <button onClick={onNavigateNotifications} className="absolute top-0 right-0">
          <Bell size={22} />
          {unreadCount > 0 && (
            <span className="absolute -top-1 -right-1 bg-[#D72631] text-white text-[10px] w-5 h-5 rounded-full flex items-center justify-center font-bold">
              {unreadCount}
            </span>
          )}
        </button>
      </div>

      {/* Critical Alert Banner */}
      {criticalAlert && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-r from-red-900/50 to-red-800/20 border border-[#B71C25] rounded-xl p-3 mb-5 flex items-center gap-3"
        >
          <div className="bg-[#D72631] rounded-full p-1.5 flex-shrink-0">
            <AlertCircle size={18} className="text-white" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-bold text-[#D72631]">{t.criticalAlert}</p>
            <p className="text-xs text-white/90">{criticalAlert.area} {t.criticalLevel}</p>
          </div>
          <ChevronRight size={18} className="text-[#D72631] flex-shrink-0" />
        </motion.div>
      )}

      {/* Stats Cards */}
      <div className="grid grid-cols-2 gap-3 mb-5">
        <motion.div whileHover={{ scale: 1.02 }} onClick={onNavigateReports} className="themed-card rounded-xl p-3 border cursor-pointer">
          <div className="flex items-start gap-2 mb-2">
            <FileText size={16} className="text-[#00C2DB] mt-0.5" />
            <p className="text-xs themed-text-secondary">{t.myReports}</p>
          </div>
          {/* REPARACIÓN: Usamos el largo en tiempo real del array para que cambie al instante */}
          <p className="text-3xl font-bold mb-0.5">{reports.length}</p>
          <p className="text-xs themed-text-tertiary">{openReportsCount} {t.open}</p>
        </motion.div>

        <motion.div whileHover={{ scale: 1.02 }} onClick={onNavigateReports} className="themed-card rounded-xl p-3 border cursor-pointer">
          <div className="flex items-start gap-2 mb-2">
            <CheckCircle size={16} className="text-[#16A34A] mt-0.5" />
            <p className="text-xs themed-text-secondary">{t.closed}</p>
          </div>
          <p className="text-3xl font-bold mb-0.5">{closedThisMonth}</p>
          <p className="text-xs themed-text-tertiary">{t.thisMonth}</p>
        </motion.div>
      </div>

      {/* Charlas de Seguridad */}
      {onNavigateTalks && (
        <motion.div whileHover={{ scale: 1.02 }} onClick={onNavigateTalks}
          className="themed-card rounded-xl p-3 border cursor-pointer mb-5 flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-[#00E5FF]/20 flex items-center justify-center">
            <BookOpen size={20} className="text-[#00E5FF]" />
          </div>
          <div className="flex-1">
            <p className="text-sm font-semibold">Dialogos de Seguridad</p>
            <p className="text-xs themed-text-secondary">Ver charlas y material</p>
          </div>
          <ChevronRight size={18} className="themed-text-tertiary" />
        </motion.div>
      )}

      {/* Alerts Feed */}
      <div className="mb-24">
        <h2 className="text-base font-bold mb-3">{t.shiftAlerts}</h2>
        <div className="space-y-2.5">
          {alerts.map((alert, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.1 }}
              className="themed-card border-l-4 border-[#D72631] rounded-lg p-3 flex items-start gap-2.5"
            >
              <div className="w-0.5 h-10 bg-[#D72631] rounded-full mt-1"></div>
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-sm leading-tight">{alert.area}</p>
                <p className="text-xs themed-text-secondary mt-0.5">{t.highRisk} • {alert.time}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Floating Report Button */}
      <motion.button
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        onClick={onOpenCreateReport}
        className="fixed bottom-24 left-1/2 -translate-x-1/2 w-fit max-w-[calc(420px-48px)] bg-[#00E5FF] text-[#0B1E36] rounded-full px-10 py-3.5 shadow-2xl flex items-center gap-2.5 font-bold text-sm z-40"
      > 
        <Camera size={20} strokeWidth={2.5} />
        {t.report}
      </motion.button>
    </motion.div>
  );
}