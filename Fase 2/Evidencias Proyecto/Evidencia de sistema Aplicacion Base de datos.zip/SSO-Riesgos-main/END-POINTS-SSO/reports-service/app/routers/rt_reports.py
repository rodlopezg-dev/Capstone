from fastapi import APIRouter, Depends, status, HTTPException, Security, Form, File, UploadFile, Header
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel
from typing import Optional
from datetime import datetime, timezone

from app.dep_reports import get_db, get_current_user
from app.services.srv_reports import ReportService
from app.repositories.rep_reports import ReportRepository
from app.repositories.user_api_repo import UserApiRepository
from app.services.azure_blob_service import (
    BLOB_BASE_URL,
    generate_read_url,
    sign_report_evidence_urls,
    upload_closure_evidence,
)
from app.schemas.scm_reports import ReportCreate
import httpx
import os

router  = APIRouter()
security = HTTPBearer(auto_error=False)


def get_service(db=Depends(get_db)) -> ReportService:
    return ReportService(ReportRepository(db))


class StatusUpdate(BaseModel):
    status:   str
    feedback: str = ""
    analysis: str = ""
    causes: list = []
    control_measures: list = []
    deadline: str = ""
    training: str = ""
    type: str = ""
    is_iap: bool = None


class CategoryUpdate(BaseModel):
    type: str


class AnalysisUpdate(BaseModel):
    causes: Optional[list[str]] = None
    probable_consequence: Optional[str] = None
    analysis: Optional[str] = None
    control_measures: Optional[list[str]] = None
    training: Optional[str] = None
    deadline: Optional[str] = None
    feedback: Optional[str] = None


class ClosureEvidenceReference(BaseModel):
    url: str
    filename: str
    content_type: str
    size: int
    uploaded_by: str
    uploaded_at: str


PROBABLE_CONSEQUENCE_OPTIONS = {
    "Atrapamiento",
    "Atropellos",
    "Caída a distinto nivel",
    "Caída al mismo nivel",
    "Caída de objetos",
    "Choque contra objetos",
    "Contacto con energía eléctrica",
    "Contacto con sustancias químicas",
    "Contacto con temperaturas extremas",
    "Cortes",
    "Explosión",
    "Exposición a radiación",
    "Exposición a ruido",
    "Golpes por objetos",
    "Incendio",
    "Inhalación de gases o vapores",
    "Proyección de partículas",
    "Quemaduras",
    "Sobreesfuerzos por manipulación de cargas",
    "Sobreesfuerzos por posturas forzadas",
    "Volcamiento",
    "Ahogamiento",
}


ALLOWED_REPORT_CATEGORIES = {
    "Acto Inseguro",
    "Condición Insegura",
    "Accidente",
    "IAP",
}



CLOSURE_EVIDENCE_ROLES = {
    "supervisor",
    "jefe de area",
    "admin",
    "sso manager",
}

CLOSURE_EVIDENCE_CONTENT_TYPES = {
    "image/jpeg",
    "image/png",
    "image/webp",
    "application/pdf",
}

CHANGE_TO_PROCESS_ROLES = {
    "supervisor",
    "jefe de area",
}

REQUEST_CLOSURE_ROLES = {
    "supervisor",
    "jefe de area",
}

APPROVE_CLOSURE_ROLES = {
    "admin",
    "sso manager",
}


MAX_CLOSURE_EVIDENCE_BYTES = 10 * 1024 * 1024

MANAGEMENT_CATEGORIES = {
    "Acto Inseguro",
    "Condición Insegura",
    "Accidente",
    "IAP",
}


def _has_management_text(value) -> bool:
    return (
        isinstance(value, str)
        and bool(value.strip())
    )


def _effective_management_category(report: dict) -> str:
    if report.get("is_iap"):
        return "IAP"

    value = report.get("type")

    if not isinstance(value, str):
        return ""

    return value.strip()


def _missing_process_requirements(
    report: dict,
) -> list[str]:
    missing = []

    if (
        _effective_management_category(report)
        not in MANAGEMENT_CATEGORIES
    ):
        missing.append("categoría")

    if not report.get("causes"):
        missing.append("causas / precursores")

    if not _has_management_text(
        report.get("probable_consequence")
    ):
        missing.append("consecuencia probable")

    if not _has_management_text(
        report.get("analysis")
    ):
        missing.append("análisis del supervisor")

    return missing


def _missing_closure_requirements(
    report: dict,
) -> list[str]:
    missing = []

    if not report.get("control_measures"):
        missing.append("medidas de control")

    if not _has_management_text(
        report.get("training")
    ):
        missing.append("capacitación")

    if not _has_management_text(
        report.get("deadline")
    ):
        missing.append("plazo")

    if not _has_management_text(
        report.get("feedback")
    ):
        missing.append("feedback al trabajador")

    if not report.get("closure_evidence"):
        missing.append("evidencia de cierre")

    return missing



def _normalize_role(value: str) -> str:
    return (
        (value or "")
        .strip()
        .lower()
        .replace("_", " ")
    )


def _closure_evidence_content_type(
    file: UploadFile,
) -> str:
    content_type = (
        file.content_type or ""
    ).strip().lower()

    if content_type not in {
        "",
        "application/octet-stream",
    }:
        return content_type

    filename = (file.filename or "").lower()

    if filename.endswith((".jpg", ".jpeg")):
        return "image/jpeg"
    if filename.endswith(".png"):
        return "image/png"
    if filename.endswith(".webp"):
        return "image/webp"
    if filename.endswith(".pdf"):
        return "application/pdf"

    return content_type


@router.post(
    "/v1/reports/{report_id}/closure-evidence/upload"
)
async def upload_report_closure_evidence_file(
    report_id: str,
    file: UploadFile = File(...),
    db=Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(
        security
    ),
):
    current_user = get_current_user(credentials)


    role = _normalize_role(
        current_user.get("role") or ""
    )

    if role not in CLOSURE_EVIDENCE_ROLES:
        raise HTTPException(
            status_code=403,
            detail=(
                "No tiene permisos para cargar "
                "evidencia de cierre"
            ),
        )

    client_id = current_user["client_id"]

    repository = ReportRepository(db)
    report = await repository.get_by_id(
        client_id,
        report_id,
    )

    if not report:
        raise HTTPException(
            status_code=404,
            detail="Reporte no encontrado",
        )

    content_type = _closure_evidence_content_type(
        file
    )

    if (
        content_type
        not in CLOSURE_EVIDENCE_CONTENT_TYPES
    ):
        raise HTTPException(
            status_code=415,
            detail=(
                "Tipo de archivo no permitido. "
                "Use JPEG, PNG, WebP o PDF"
            ),
        )

    file_bytes = await file.read(
        MAX_CLOSURE_EVIDENCE_BYTES + 1
    )

    if not file_bytes:
        raise HTTPException(
            status_code=422,
            detail="El archivo está vacío",
        )

    if (
        len(file_bytes)
        > MAX_CLOSURE_EVIDENCE_BYTES
    ):
        raise HTTPException(
            status_code=413,
            detail=(
                "La evidencia supera el máximo "
                "permitido de 10 MB"
            ),
        )

    try:
        url = await upload_closure_evidence(
            file_bytes=file_bytes,
            client_id=client_id,
            report_id=report_id,
            content_type=content_type,
        )
    except Exception:
        raise HTTPException(
            status_code=502,
            detail=(
                "No fue posible almacenar "
                "la evidencia"
            ),
        )

    uploaded_at = datetime.now(
        timezone.utc
    ).isoformat()

    return {
        "ok": True,
        "evidence_upload": {
            "url": url,
            "filename": (
                file.filename or "evidencia"
            ),
            "content_type": content_type,
            "size": len(file_bytes),
            "uploaded_by": (
                current_user["user_id"]
            ),
            "uploaded_at": uploaded_at,
        },
    }



@router.put(
    "/v1/reports/{report_id}/closure-evidence"
)
async def associate_report_closure_evidence(
    report_id: str,
    body: ClosureEvidenceReference,
    db=Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(
        security
    ),
):
    current_user = get_current_user(credentials)

    role = _normalize_role(
        current_user.get("role") or ""
    )

    if role not in CLOSURE_EVIDENCE_ROLES:
        raise HTTPException(
            status_code=403,
            detail=(
                "No tiene permisos para asociar "
                "evidencia de cierre"
            ),
        )

    client_id = current_user["client_id"]
    user_id = current_user["user_id"]

    if body.uploaded_by != user_id:
        raise HTTPException(
            status_code=422,
            detail=(
                "La evidencia no corresponde "
                "al usuario autenticado"
            ),
        )

    if (
        body.content_type
        not in CLOSURE_EVIDENCE_CONTENT_TYPES
    ):
        raise HTTPException(
            status_code=422,
            detail="Tipo de evidencia no válido",
        )

    if (
        body.size <= 0
        or body.size
        > MAX_CLOSURE_EVIDENCE_BYTES
    ):
        raise HTTPException(
            status_code=422,
            detail="Tamaño de evidencia no válido",
        )

    if not body.filename.strip():
        raise HTTPException(
            status_code=422,
            detail=(
                "El nombre de archivo es obligatorio"
            ),
        )

    try:
        datetime.fromisoformat(
            body.uploaded_at.replace(
                "Z",
                "+00:00",
            )
        )
    except ValueError:
        raise HTTPException(
            status_code=422,
            detail=(
                "Fecha de carga de evidencia "
                "no válida"
            ),
        )

    expected_prefix = (
        BLOB_BASE_URL.rstrip("/")
        + f"/reports/{client_id}/{report_id}"
        + "/closure-evidence/"
    )

    if not body.url.startswith(expected_prefix):
        raise HTTPException(
            status_code=422,
            detail=(
                "La referencia de evidencia no "
                "corresponde al incidente"
            ),
        )

    service = ReportService(
        ReportRepository(db)
    )

    saved = (
        await service.associate_closure_evidence(
            client_id=client_id,
            report_id=report_id,
            user_id=user_id,
            evidence=body.model_dump(),
        )
    )

    if saved is None:
        raise HTTPException(
            status_code=404,
            detail="Reporte no encontrado",
        )

    response_evidence = dict(saved)

    saved_url = response_evidence.get("url")

    if isinstance(saved_url, str):
        response_evidence["url"] = (
            generate_read_url(
                saved_url,
                client_id,
                report_id,
            )
        )

    return {
        "ok": True,
        "closure_evidence": response_evidence,
    }


# ─── REPORTS ──────────────────────────────────────────────────────────────────

# REMEDIO: Quitamos la barra "/" final para que responda directamente a "/v1/reports" sin redirecciones mutadas
@router.post("/v1/reports")
async def create_report(
    description: str = Form(...),
    area_id: str = Form(...),
    type: str = Form(...),
    shift: str = Form(...),
    is_iap: str = Form(default="false"),
    causes: str = Form(default="[]"),
    file: Optional[UploadFile] = File(None),
    idempotency_key: Optional[str] = Header(
        default=None,
        alias="Idempotency-Key",
    ),
    db=Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security),
):
    current_user = get_current_user(credentials)

    normalized_idempotency_key = (
        idempotency_key.strip()
        if idempotency_key
        else None
    )

    if (
        normalized_idempotency_key
        and len(normalized_idempotency_key) > 128
    ):
        raise HTTPException(
            status_code=400,
            detail="Idempotency-Key supera el máximo de 128 caracteres",
        )
    
    # 1. Leemos los bytes de la evidencia para almacenarla en Azure Blob
    file_bytes = b""
    if file and file.filename != "empty.jpg":
        file_bytes = await file.read()

    # 2. Mapeamos los datos del formulario al esquema ReportCreate que espera tu servicio
    report_in = ReportCreate(
        description=description,
        area_id=area_id,
        type=type,
        shift=shift,
        is_iap=is_iap.lower() == "true",
        causes=__import__("json").loads(causes) if causes else [],
    )

    # 3. Invocar al servicio estructurado
    service = ReportService(
        ReportRepository(db),
        manager_repository=UserApiRepository(),
    )
    report_id = await service.create_report(
        client_id=current_user["client_id"],
        report_in=report_in,
        user_id=current_user["user_id"],
        file_bytes=file_bytes,
        idempotency_key=normalized_idempotency_key,
    )

    return {"report_id": report_id}


@router.get("/v1/reports")  # <-- Forzado sin barra final
async def list_reports(
    db=Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security),
):
    current_user = get_current_user(credentials)
    service      = ReportService(ReportRepository(db))
    reports = await service.get_all(
        client_id=current_user["client_id"],
        user_id=current_user["user_id"],
    )

    return [
        sign_report_evidence_urls(report)
        for report in reports
    ]

# ─── HEALTH ───────────────────────────────────────────────────────────────────
@router.get("/health")
async def health_check():
    return {"status": "ok", "service": "reports-service"}

@router.get("/{report_id}")  # Sincronizado sin slash intermedio duplicado
async def get_report(
    report_id: str,
    db=Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security),
):
    current_user = get_current_user(credentials)
    service      = ReportService(ReportRepository(db))
    report = await service.get_by_id(
        client_id=current_user["client_id"],
        report_id=report_id,
    )
    if not report:
        raise HTTPException(
            status_code=404,
            detail="Reporte no encontrado",
        )

    return sign_report_evidence_urls(report)


@router.patch("/v1/reports/{report_id}/status")
async def update_status(
    report_id: str,
    body: StatusUpdate,
    db=Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(
        security
    ),
):
    current_user = get_current_user(credentials)

    client_id = current_user["client_id"]
    role = _normalize_role(
        current_user.get("role") or ""
    )

    repository = ReportRepository(db)

    report = await repository.get_by_id(
        client_id,
        report_id,
    )

    if not report:
        raise HTTPException(
            status_code=404,
            detail="Reporte no encontrado",
        )

    if body.status == "en_proceso":
        allowed_roles = CHANGE_TO_PROCESS_ROLES
        expected_status = "open"
        forbidden_detail = (
            "No tiene permisos para cambiar "
            "el incidente a proceso"
        )
        invalid_state_detail = (
            "El incidente no está en un estado "
            "válido para cambiar a proceso"
        )

    elif body.status == "pending_closure":
        allowed_roles = REQUEST_CLOSURE_ROLES
        expected_status = "en_proceso"
        forbidden_detail = (
            "No tiene permisos para solicitar "
            "el cierre del incidente"
        )
        invalid_state_detail = (
            "El incidente no está en un estado "
            "válido para solicitar cierre"
        )

    elif body.status == "closed":
        allowed_roles = APPROVE_CLOSURE_ROLES
        expected_status = "pending_closure"
        forbidden_detail = (
            "No tiene permisos para aprobar "
            "el cierre del incidente"
        )
        invalid_state_detail = (
            "El incidente no está pendiente "
            "de aprobación de cierre"
        )

    else:
        raise HTTPException(
            status_code=422,
            detail=(
                "Estado de destino no válido "
                "para esta operación"
            ),
        )

    if role not in allowed_roles:
        raise HTTPException(
            status_code=403,
            detail=forbidden_detail,
        )

    current_status = report.get("status") or "open"

    if current_status != expected_status:
        raise HTTPException(
            status_code=409,
            detail=invalid_state_detail,
        )

    if body.status == "en_proceso":
        missing = _missing_process_requirements(
            report
        )

        if missing:
            raise HTTPException(
                status_code=409,
                detail=(
                    "Debe completar y guardar antes "
                    "de cambiar a proceso: "
                    + ", ".join(missing)
                ),
            )

    elif body.status == "pending_closure":
        missing = _missing_closure_requirements(
            report
        )

        if missing:
            raise HTTPException(
                status_code=409,
                detail=(
                    "Debe completar y guardar antes "
                    "de solicitar cierre: "
                    + ", ".join(missing)
                ),
            )

    service = ReportService(repository)

    ok = await service.update_status(
        client_id=client_id,
        report_id=report_id,
        status=body.status,
        feedback=body.feedback,
    )

    if not ok:
        raise HTTPException(
            status_code=409,
            detail=(
                "No fue posible actualizar "
                "el estado del incidente"
            ),
        )

    # Compatibilidad con los campos de gestión
    # que este endpoint ya aceptaba.
    extra = {}

    if body.analysis:
        extra["analysis"] = body.analysis
    if body.causes:
        extra["causes"] = body.causes
    if body.control_measures:
        extra["control_measures"] = (
            body.control_measures
        )
    if body.deadline:
        extra["deadline"] = body.deadline
    if body.training:
        extra["training"] = body.training
    if body.type:
        extra["type"] = body.type
    if body.is_iap is not None:
        extra["is_iap"] = body.is_iap

    if extra:
        await db["reports"].update_one(
            {
                "report_id": report_id,
                "client_id": client_id,
            },
            {
                "$set": extra,
            },
        )

    return {
        "ok": True,
        "status": body.status,
    }


@router.patch("/v1/reports/{report_id}/category")
async def update_category(
    report_id: str,
    body: CategoryUpdate,
    db=Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security),
):
    current_user = get_current_user(credentials)

    role = (current_user.get("role") or "").strip().lower().replace("_", " ")
    allowed_roles = {"supervisor", "jefe de area"}

    if role not in allowed_roles:
        raise HTTPException(
            status_code=403,
            detail="No tiene permisos para recategorizar incidentes",
        )

    category = body.type.strip()
    if category not in ALLOWED_REPORT_CATEGORIES:
        raise HTTPException(
            status_code=422,
            detail="Categoría de incidente no válida",
        )

    is_iap = category == "IAP"
    query = {
        "report_id": report_id,
        "client_id": current_user["client_id"],
    }

    report = await db["reports"].find_one(
        query,
        {"type": 1, "is_iap": 1},
    )
    if not report:
        raise HTTPException(status_code=404, detail="Reporte no encontrado")

    previous_category = (
        "IAP"
        if report.get("is_iap")
        else report.get("type", "Sin categoría")
    )

    if (
        report.get("type") == category
        and bool(report.get("is_iap")) == is_iap
    ):
        return {
            "ok": True,
            "changed": False,
            "type": category,
            "is_iap": is_iap,
        }

    await db["reports"].update_one(
        query,
        {
            "$set": {
                "type": category,
                "is_iap": is_iap,
            }
        },
    )

    repository = ReportRepository(db)
    await repository.add_activity_log(
        current_user["client_id"],
        report_id,
        {
            "action": "recategorized",
            "user_id": current_user["user_id"],
            "detail": f"Recategorizado de {previous_category} a {category}",
        },
    )

    return {
        "ok": True,
        "changed": True,
        "type": category,
        "is_iap": is_iap,
    }



@router.patch("/v1/reports/{report_id}/analysis")
async def update_analysis(
    report_id: str,
    body: AnalysisUpdate,
    db=Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security),
):
    current_user = get_current_user(credentials)

    role = (
        (current_user.get("role") or "")
        .strip()
        .lower()
        .replace("_", " ")
    )
    allowed_roles = {"supervisor", "jefe de area"}

    if role not in allowed_roles:
        raise HTTPException(
            status_code=403,
            detail="No tiene permisos para gestionar el análisis del incidente",
        )

    repository = ReportRepository(db)

    report = await repository.get_by_id(
        current_user["client_id"],
        report_id,
    )

    if not report:
        raise HTTPException(
            status_code=404,
            detail="Reporte no encontrado",
        )

    current_values = {
        "causes": report.get("causes") or [],
        "probable_consequence": (
            report.get("probable_consequence") or ""
        ),
        "analysis": report.get("analysis") or "",
        "control_measures": report.get("control_measures") or [],
        "training": report.get("training") or "",
        "deadline": report.get("deadline") or "",
        "feedback": report.get("feedback") or "",
    }

    requested_updates = body.model_dump(
        exclude_unset=True
    )

    if "probable_consequence" in requested_updates:
        probable_consequence = (
            requested_updates["probable_consequence"]
        )

        if (
            probable_consequence
            and probable_consequence
            not in PROBABLE_CONSEQUENCE_OPTIONS
        ):
            raise HTTPException(
                status_code=422,
                detail="Consecuencia probable no válida",
            )

    changed_fields = {
        key: value
        for key, value in requested_updates.items()
        if current_values[key] != value
    }

    if not changed_fields:
        return {
            "ok": True,
            "changed": False,
            **current_values,
        }

    updated = await repository.update_analysis(
        current_user["client_id"],
        report_id,
        changed_fields,
    )

    if not updated:
        raise HTTPException(
            status_code=404,
            detail="Reporte no encontrado",
        )

    saved_values = {
        **current_values,
        **changed_fields,
    }

    await repository.add_activity_log(
        current_user["client_id"],
        report_id,
        {
            "action": "analysis_updated",
            "user_id": current_user["user_id"],
            "detail": (
                "Campos de análisis actualizados: "
                + ", ".join(sorted(changed_fields))
            ),
        },
    )

    return {
        "ok": True,
        "changed": True,
        **saved_values,
    }


# ─── WORKER STATS ─────────────────────────────────────────────────────────────

@router.get("/v1/workers/me/stats")
async def get_worker_stats(
    period: str = "month",
    db=Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security),
):
    current_user = get_current_user(credentials)
    service      = ReportService(ReportRepository(db))
    return await service.get_worker_stats(
        client_id=current_user["client_id"],
        user_id=current_user["user_id"],
        period=period,
    )


# ─── NOTIFICATIONS ────────────────────────────────────────────────────────────

@router.get("/v1/workers/me/notifications")
async def get_notifications(
    db=Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security),
):
    current_user = get_current_user(credentials)
    service      = ReportService(ReportRepository(db))
    return await service.get_notifications(
        client_id=current_user["client_id"],
        user_id=current_user["user_id"],
    )


@router.patch("/v1/workers/me/notifications/{notification_id}")
async def mark_notification_read(
    notification_id: str,
    db=Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security),
):
    current_user = get_current_user(credentials)
    service      = ReportService(ReportRepository(db))
    ok = await service.mark_notification_read(
        client_id=current_user["client_id"],
        notification_id=notification_id,
        user_id=current_user["user_id"],
    )
    if not ok:
        raise HTTPException(status_code=404, detail="Notificación no encontrada")
    return {"ok": True}



# ─── ACTIVITY LOG ─────────────────────────────────────────────────────────────

@router.get("/v1/reports/{report_id}/activity")
async def get_activity_log(
    report_id: str,
    db=Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security),
):
    current_user = get_current_user(credentials)
    service      = ReportService(ReportRepository(db))
    report = await service.get_by_id(
        client_id=current_user["client_id"],
        report_id=report_id,
    )
    if not report:
        raise HTTPException(status_code=404, detail="Reporte no encontrado")
    return await service.repository.get_activity_log(
        client_id=current_user["client_id"],
        report_id=report_id,
    )


# ─── ADMIN ────────────────────────────────────────────────────────────────────

@router.get("/v1/admin/reports")
async def list_all_reports(
    db=Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security),
):
    current_user = get_current_user(credentials)
    repository = ReportRepository(db)

    reports = await repository.get_all(
        client_id=current_user["client_id"],
    )

    return [
        sign_report_evidence_urls(report)
        for report in reports
    ]

# ─── EXPORT PARA POWER BI ─────────────────────────────────────────────
@router.get("/v1/export/csv")
async def export_csv(
    db=Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security),
):
    import csv
    import io
    from fastapi.responses import StreamingResponse

    current_user = get_current_user(credentials)
    repository = ReportRepository(db)

    reports = await repository.get_all(
        client_id=current_user["client_id"],
    )

    output = io.StringIO()
    if reports:
        fieldnames = ["report_id", "area_id", "type", "description", "status", "is_iap", "reported_by", "created_at", "shift"]
        writer = csv.DictWriter(output, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for r in reports:
            writer.writerow(r)

    output.seek(0)
    return StreamingResponse(
        iter([output.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=reportes_vigia.csv"}
    )
