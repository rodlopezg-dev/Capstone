import { authenticatedFetch } from '../api/client';
import { useState, useEffect } from 'react';
import { Clock, CheckCircle, AlertTriangle, ChevronRight } from 'lucide-react';

import {
  CAUSE_OPTIONS,
  filterCauseOptions,
  toggleCauseSelection,
} from '../utils/incidentCauses';
import SupervisorAnalysisField from './SupervisorAnalysisField';
import ControlMeasuresField from './ControlMeasuresField';
import ProbableConsequenceField from './ProbableConsequenceField';
import IncidentDeadlineField from './IncidentDeadlineField';
import WorkerFeedbackField from './WorkerFeedbackField';
import ClosureEvidencePhotoPicker from './ClosureEvidencePhotoPicker';
import ClosureEvidencePdfPicker from './ClosureEvidencePdfPicker';
import {
  associateClosureEvidence,
  uploadClosureEvidence,
  type ClosureEvidenceUpload,
} from '../api/reports';
import { resolveLocalEvidenceUrl } from '../utils/mediaUrl';
import {
  buildIncidentAnalysisPayload,
} from '../utils/incidentAnalysis';
import {
  canApproveIncidentClosure,
  canChangeIncidentToProcess,
  canRequestIncidentClosure,
  incidentStatusErrorMessage,
  incidentStatusSuccessMessage,
  normalizeIncidentRole,
} from '../utils/incidentStatus';
import { INCIDENT_AREAS } from '../constants/incidentAreas';
import { resolveReportEvidenceUrl } from '../utils/reportPresentation';
import IncidentManagementStepper from './IncidentManagementStepper';
import {
  getIncidentManagementStageState,
  type IncidentManagementStageId,
} from '../utils/incidentManagementStages';

import {
  getIncidentManagementStageAfterSave,
} from '../utils/incidentManagementStageAdvance';

import {
  getClosureTransitionMissingFields,
  getProcessTransitionMissingFields,
} from '../utils/incidentWorkflowRequirements';

interface Report {
  report_id: string;
  area_id: string;
  type: string;
  description: string;
  status: string;
  is_iap: boolean;
  created_at: string;
  reported_by: string;
  assigned_to?: string;
  evidences?: string[];
  feedback?: string;
  worker_type?: string;
  causes?: string[];
  probable_consequence?: string;
  analysis?: string;
  control_measures?: string[];
  training?: string;
  deadline?: string;
  closure_evidence?: ClosureEvidenceUpload;
}

const STATUS_MAP: Record<string, { label: string; color: string }> = {
  open: { label: 'Abierto', color: '#3b82f6' },
  en_proceso: { label: 'En Proceso', color: '#E8941A' },
  pending_closure: {
    label: 'Pendiente de cierre',
    color: '#8B5CF6',
  },
  closed: { label: 'Cerrado', color: '#16A34A' },
};

const CATEGORY_OPTIONS = [
  'Acto Inseguro',
  'Condición Insegura',
  'Accidente',
  'IAP',
];

export default function ManageIncidents({ userId, userRole, userArea, userAreas, reportsApi }: {
  userId: string; userRole: string; userArea: string; userAreas?: string[]; reportsApi: string;
}) {
  const [reports, setReports] = useState<Report[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<Report | null>(null);
  const [
    activeManagementStage,
    setActiveManagementStage,
  ] = useState<IncidentManagementStageId>('review');
  const [feedback, setFeedback] = useState('');
  const [closureEvidence, setClosureEvidence] = useState<File | null>(null);
  const [closureEvidenceError, setClosureEvidenceError] = useState('');
  const [closureEvidenceSaved, setClosureEvidenceSaved] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [categoryError, setCategoryError] = useState('');
  const [selectedCauses, setSelectedCauses] = useState<string[]>([]);
  const [probableConsequence, setProbableConsequence] = useState('');
  const [causeSearch, setCauseSearch] = useState('');
  const [analysis, setAnalysis] = useState('');
  const [selectedControlMeasures, setSelectedControlMeasures] =
    useState<string[]>([]);
  const [training, setTraining] = useState('');
  const [deadline, setDeadline] = useState('');
  const [analysisError, setAnalysisError] = useState('');
  const [treatmentError, setTreatmentError] = useState('');
  const [treatmentSaved, setTreatmentSaved] = useState('');
  const [analysisSaved, setAnalysisSaved] = useState('');
  const [statusError, setStatusError] = useState('');
  const [statusSaved, setStatusSaved] = useState('');
  const [updating, setUpdating] = useState(false);
  const [filterArea, setFilterArea] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [filterIAP, setFilterIAP] = useState('');

  useEffect(() => {
    const fetchReports = async () => {
      try {
        const res = await authenticatedFetch(
          reportsApi + '/v1/admin/reports',
        );
        if (!res.ok) throw new Error('Error ' + res.status);
        const data = await res.json();
        let filtered = data;
        if (userRole === 'supervisor') {
          const myAreas = userAreas?.map(a => a.toLowerCase()) || [userArea?.toLowerCase()];
          filtered = data.filter((r: Report) => myAreas.includes(r.area_id?.toLowerCase()) || r.assigned_to === userId || r.reported_by === userId);
        } else if (userRole === 'jefe de area' || userRole === 'jefe_de_area') {
          const myAreas = userAreas?.map(a => a.toLowerCase()) || [userArea?.toLowerCase()];
          filtered = data.filter((r: Report) => myAreas.includes(r.area_id?.toLowerCase()));
        } else if (userRole === 'usuario' || userRole === 'worker') {
          filtered = data.filter((r: Report) => r.reported_by === userId);
        }
        filtered.sort((a: Report, b: Report) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
        setReports(filtered);
      } catch (err) {
        console.error(err);
      }
      setLoading(false);
    };
    fetchReports();
  }, [userId, userRole, userArea, reportsApi]);

  const normalizedRole =
    normalizeIncidentRole(userRole);
  const canRecategorize = ['supervisor', 'jefe de area'].includes(normalizedRole);
  const canEditAnalysis = ['supervisor', 'jefe de area'].includes(normalizedRole);
  const canEditTreatment = ['supervisor', 'jefe de area'].includes(normalizedRole);
  const canManageClosureEvidence = [
    'supervisor',
    'jefe de area',
    'admin',
    'sso manager',
  ].includes(normalizedRole);

  const processTransitionMissingFields =
    selected
      ? getProcessTransitionMissingFields(selected)
      : [];

  const closureTransitionMissingFields =
    selected
      ? getClosureTransitionMissingFields(selected)
      : [];

  const openReport = (report: Report) => {
    setSelected(report);
    setActiveManagementStage(
      getIncidentManagementStageState(report)
        .workflowStage
    );
    setClosureEvidence(null);
    setClosureEvidenceError('');
    setClosureEvidenceSaved('');
    setFeedback(report.feedback || '');
    setCategoryError('');
    setSelectedCauses(report.causes || []);
    setProbableConsequence(report.probable_consequence || '');
    setCauseSearch('');
    setAnalysis(report.analysis || '');
    setSelectedControlMeasures(report.control_measures || []);
    setTraining(report.training || '');
    setDeadline(report.deadline || '');
    setAnalysisError('');
    setAnalysisSaved('');
    setTreatmentError('');
    setTreatmentSaved('');
    setStatusError('');
    setStatusSaved('');

    if (report.is_iap) {
      setSelectedCategory('IAP');
    } else if (CATEGORY_OPTIONS.some(category => category === report.type)) {
      setSelectedCategory(report.type);
    } else {
      setSelectedCategory('');
    }
  };

  const handleCategorySave = async () => {
    if (!selected || !selectedCategory || !canRecategorize) return;

    setUpdating(true);
    setCategoryError('');

    try {
      const res = await authenticatedFetch(
        reportsApi + '/v1/reports/' + selected.report_id + '/category',
        {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ type: selectedCategory }),
        }
      );

      const data = await res.json().catch(() => ({}));

      if (!res.ok) {
        throw new Error(data.detail || 'No fue posible actualizar la categoría');
      }

      const updatedReport: Report = {
        ...selected,
        type: data.type,
        is_iap: data.is_iap,
      };

      setSelected(updatedReport);
      setReports(prev =>
        prev.map(report =>
          report.report_id === updatedReport.report_id
            ? updatedReport
            : report
        )
      );

      setActiveManagementStage(current =>
        getIncidentManagementStageAfterSave(
          current,
          true,
          getIncidentManagementStageState(updatedReport),
        )
      );
    } catch (err) {
      console.error(err);
      setCategoryError(
        err instanceof Error
          ? err.message
          : 'No fue posible actualizar la categoría'
      );
    } finally {
      setUpdating(false);
    }
  };

  const handleAnalysisStageSave = async () => {
    if (
      !selected
      || !canEditAnalysis
      || getIncidentManagementStageState(selected).readOnly
    ) {
      return;
    }

    setUpdating(true);
    setAnalysisError('');
    setAnalysisSaved('');

    try {
      const res = await authenticatedFetch(
        reportsApi
          + '/v1/reports/'
          + selected.report_id
          + '/analysis',
        {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            causes: selectedCauses,
            probable_consequence: probableConsequence,
            analysis,
          }),
        }
      );

      const data = await res.json().catch(() => ({}));

      if (!res.ok) {
        throw new Error(
          data.detail
            || 'No fue posible guardar el análisis'
        );
      }

      const updatedReport: Report = {
        ...selected,
        causes: data.causes,
        probable_consequence: data.probable_consequence,
        analysis: data.analysis,
      };

      setSelected(updatedReport);

      setReports(current =>
        current.map(report =>
          report.report_id === updatedReport.report_id
            ? updatedReport
            : report
        )
      );

      setAnalysisSaved(
        data.changed
          ? 'Análisis guardado correctamente.'
          : 'No hay cambios por guardar.'
      );

      setActiveManagementStage(current =>
        getIncidentManagementStageAfterSave(
          current,
          true,
          getIncidentManagementStageState(updatedReport),
        )
      );
    } catch (err) {
      console.error(err);

      setAnalysisError(
        err instanceof Error
          ? err.message
          : 'No fue posible guardar el análisis'
      );
    } finally {
      setUpdating(false);
    }
  };

  const handleTreatmentSave = async () => {
    if (
      !selected
      || !canEditTreatment
      || getIncidentManagementStageState(selected).readOnly
    ) {
      return;
    }

    setUpdating(true);
    setTreatmentError('');
    setTreatmentSaved('');

    try {
      const res = await authenticatedFetch(
        reportsApi
          + '/v1/reports/'
          + selected.report_id
          + '/analysis',
        {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            control_measures: selectedControlMeasures,
            training,
            deadline,
            feedback,
          }),
        }
      );

      const data = await res.json().catch(() => ({}));

      if (!res.ok) {
        throw new Error(
          data.detail
            || 'No fue posible guardar el tratamiento'
        );
      }

      const updatedReport: Report = {
        ...selected,
        control_measures: data.control_measures,
        training: data.training,
        deadline: data.deadline,
        feedback: data.feedback,
      };

      setSelected(updatedReport);

      setReports(current =>
        current.map(report =>
          report.report_id === updatedReport.report_id
            ? updatedReport
            : report
        )
      );

      setTreatmentSaved(
        data.changed
          ? 'Tratamiento guardado correctamente.'
          : 'No hay cambios por guardar.'
      );

      setActiveManagementStage(current =>
        getIncidentManagementStageAfterSave(
          current,
          true,
          getIncidentManagementStageState(updatedReport),
        )
      );
    } catch (err) {
      console.error(err);

      setTreatmentError(
        err instanceof Error
          ? err.message
          : 'No fue posible guardar el tratamiento'
      );
    } finally {
      setUpdating(false);
    }
  };

  const handleAnalysisSave = async () => {
    if (!selected || !canRecategorize) return;

    setUpdating(true);
    setAnalysisError('');
    setAnalysisSaved('');

    try {
      const payload = buildIncidentAnalysisPayload(
        selectedCauses,
        probableConsequence,
        analysis,
        selectedControlMeasures,
        deadline,
        feedback
      );

      const res = await authenticatedFetch(
        reportsApi
          + '/v1/reports/'
          + selected.report_id
          + '/analysis',
        {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(payload),
        }
      );

      const data = await res.json().catch(() => ({}));

      if (!res.ok) {
        throw new Error(
          data.detail
            || 'No fue posible guardar el análisis'
        );
      }

      const updatedReport: Report = {
        ...selected,
        causes: data.causes,
        probable_consequence: data.probable_consequence,
        analysis: data.analysis,
        control_measures: data.control_measures,
        deadline: data.deadline,
        feedback: data.feedback,
      };

      setSelected(updatedReport);

      setReports(prev =>
        prev.map(report =>
          report.report_id === updatedReport.report_id
            ? updatedReport
            : report
        )
      );

      setAnalysisSaved(
        data.changed
          ? 'Análisis guardado correctamente.'
          : 'No hay cambios por guardar.'
      );
    } catch (err) {
      console.error(err);

      setAnalysisError(
        err instanceof Error
          ? err.message
          : 'No fue posible guardar el análisis'
      );
    } finally {
      setUpdating(false);
    }
  };

  const handleClosureEvidenceChange = (file: File | null) => {
    setClosureEvidence(file);
    setClosureEvidenceError('');
    setClosureEvidenceSaved('');
  };

  const handleClosureEvidenceSave = async () => {
    if (
      !selected
      || !closureEvidence
      || !canManageClosureEvidence
    ) {
      return;
    }

    setUpdating(true);
    setClosureEvidenceError('');
    setClosureEvidenceSaved('');

    try {
      const uploaded = await uploadClosureEvidence(
        selected.report_id,
        closureEvidence,
        reportsApi,
      );

      const associated = await associateClosureEvidence(
        selected.report_id,
        uploaded,
        reportsApi,
      );

      const updatedReport: Report = {
        ...selected,
        closure_evidence: associated,
      };

      setSelected(updatedReport);

      setReports(current =>
        current.map(report =>
          report.report_id === updatedReport.report_id
            ? updatedReport
            : report
        )
      );

      setClosureEvidence(null);
      setClosureEvidenceSaved(
        'Evidencia guardada correctamente.'
      );
    } catch (err) {
      console.error(err);

      setClosureEvidenceError(
        err instanceof Error
          ? err.message
          : 'No fue posible guardar la evidencia'
      );
    } finally {
      setUpdating(false);
    }
  };

  const handleStatusChange = async (
    report: Report,
    newStatus: string,
  ) => {
    setUpdating(true);
    setStatusError('');
    setStatusSaved('');

    try {
      const response = await authenticatedFetch(
        reportsApi
          + '/v1/reports/'
          + report.report_id
          + '/status',
        {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            status: newStatus,
            feedback,
          }),
        },
      );

      const data = await response
        .json()
        .catch(() => ({}));

      if (!response.ok) {
        setStatusError(
          incidentStatusErrorMessage(
            response.status,
            data?.detail,
          ),
        );

        return;
      }

      const effectiveStatus =
        typeof data?.status === 'string'
          ? data.status
          : newStatus;

      const updatedReport: Report = {
        ...report,
        status: effectiveStatus,
        feedback,
      };

      setReports(current =>
        current.map(item =>
          item.report_id === report.report_id
            ? updatedReport
            : item,
        ),
      );

      setSelected(updatedReport);
      setActiveManagementStage(
        getIncidentManagementStageState(
          updatedReport
        ).workflowStage
      );

      setStatusSaved(
        incidentStatusSuccessMessage(
          effectiveStatus,
        ),
      );
    } catch (err) {
      console.error(err);

      setStatusError(
        incidentStatusErrorMessage(0),
      );
    } finally {
      setUpdating(false);
    }
  };

  if (loading) return <div className="p-6 text-center" style={{color: '#888'}}>Cargando...</div>;

  if (selected) {
    const st = STATUS_MAP[selected.status] || STATUS_MAP.open;
    const managementStageState =
      getIncidentManagementStageState(selected);

    const closureEvidenceUrl =
      selected.closure_evidence
        ? resolveLocalEvidenceUrl(
            selected.closure_evidence.url,
            reportsApi,
          )
        : '';

    return (
      <div className="p-4 space-y-4">
        <button onClick={() => {
          setSelected(null);
          setActiveManagementStage('review');
          setClosureEvidence(null);
          setClosureEvidenceError('');
          setClosureEvidenceSaved('');
          setFeedback('');
          setSelectedCategory('');
          setCategoryError('');
          setSelectedCauses([]);
          setCauseSearch('');
          setAnalysis('');
          setSelectedControlMeasures([]);
          setTraining('');
          setDeadline('');
          setAnalysisError('');
          setAnalysisSaved('');
          setTreatmentError('');
          setTreatmentSaved('');
          setStatusError('');
          setStatusSaved('');
        }} className="text-sm" style={{color: '#00E5FF'}}>Volver</button>
        <div className="themed-card border rounded-2xl p-5">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold text-lg">#{selected.report_id?.slice(-6).toUpperCase()}</h3>
            <span className="text-xs px-3 py-1 rounded-full font-medium" style={{ background: st.color + '20', color: st.color }}>{st.label}</span>
          </div>
          <p className="text-sm mb-1" style={{color: '#aaa'}}><strong>Area:</strong> {selected.area_id}</p>
          <p className="text-sm mb-1" style={{color: '#aaa'}}><strong>Tipo:</strong> {selected.type}</p>
          <p className="text-sm mb-1" style={{color: '#aaa'}}><strong>Reportado por:</strong> {selected.reported_by?.split('_at_')[0]}</p>
          <p className="text-sm mb-1" style={{color: '#aaa'}}><strong>Tipo trabajador:</strong> {selected.worker_type === 'externo' ? 'Externo' : 'Planta'}</p>
          <p className="text-sm mb-1" style={{color: '#aaa'}}><strong>Fecha:</strong> {new Date(selected.created_at).toLocaleDateString('es-CL')}</p>
          {selected.is_iap && <p className="text-sm font-medium mt-2" style={{color: '#D72631'}}>Alto Potencial (IAP)</p>}
          <p className="text-sm mt-3">{selected.description}</p>
          {selected.evidences?.[0] && (
            <div className="w-full h-48 themed-photo-placeholder rounded-xl mt-3 overflow-hidden flex items-center justify-center text-5xl">
              <img
                src={resolveReportEvidenceUrl(
                  selected.evidences[0],
                  import.meta.env.VITE_REPORTS_API_URL,
                )}
                alt="Evidencia"
                className="w-full h-full object-cover"
                onError={(e) => {
                  e.currentTarget.style.display = 'none';
                  const parent = e.currentTarget.parentElement;
                  if (parent) parent.textContent = '📸';
                }}
              />
            </div>
          )}
        </div>

        <IncidentManagementStepper
          activeStage={activeManagementStage}
          state={managementStageState}
          onStageChange={setActiveManagementStage}
        />

        {activeManagementStage === 'review' && (
          <div className="themed-card border rounded-2xl p-5 space-y-3">
            <div>
              <h4 className="font-bold">Revisión inicial</h4>
              <p className="text-xs themed-text-secondary mt-1">
                Revisa los antecedentes originales del reporte y ajusta
                su categoría cuando corresponda.
              </p>
            </div>

            {canRecategorize && !managementStageState.readOnly && (
            <div>
              <p className="text-sm font-medium mb-1">Categoría del hallazgo</p>

              <select
                value={selectedCategory}
                onChange={e => {
                  setSelectedCategory(e.target.value);
                  setCategoryError('');
                }}
                className="w-full rounded-xl px-4 py-3 text-sm"
                style={{
                  background: '#0B2E36',
                  border: '1px solid rgba(0,229,255,0.3)',
                  color: 'white',
                }}
              >
                <option value="">Seleccionar categoría</option>
                {CATEGORY_OPTIONS.map(category => (
                  <option key={category} value={category}>
                    {category}
                  </option>
                ))}
              </select>

              <button
                onClick={handleCategorySave}
                disabled={
                  updating ||
                  !selectedCategory ||
                  selectedCategory === (selected.is_iap ? 'IAP' : selected.type)
                }
                className="w-full mt-2 py-3 rounded-xl text-sm font-medium disabled:opacity-40"
                style={{
                  background: '#00E5FF20',
                  color: '#00E5FF',
                  border: '1px solid rgba(0,229,255,0.4)',
                }}
              >
                Guardar categoría
              </button>

              {categoryError && (
                <p className="text-xs mt-2" style={{ color: '#D72631' }}>
                  {categoryError}
                </p>
              )}
            </div>
          )}

            {!canRecategorize && (
              <p className="text-sm themed-text-secondary">
                La información del reporte se encuentra disponible
                únicamente para consulta.
              </p>
            )}
          </div>
        )}

        {activeManagementStage === 'analysis' && (
          <div className="themed-card border rounded-2xl p-5 space-y-4">
            <div>
              <h4 className="font-bold">Análisis del incidente</h4>
              <p className="text-xs themed-text-secondary mt-1">
                Registra las causas, la consecuencia probable y el
                análisis realizado por el supervisor.
              </p>
            </div>

            {canEditAnalysis && !managementStageState.readOnly ? (
              <>
                <div>
                  <p className="text-sm font-medium mb-1">
                    Causas / precursores
                  </p>

                  <input
                    type="search"
                    value={causeSearch}
                    onChange={e => setCauseSearch(e.target.value)}
                    placeholder="Buscar causa o precursor"
                    className="w-full rounded-xl px-4 py-3 text-sm mb-2"
                    style={{
                      background: '#0B2E36',
                      border: '1px solid rgba(0,229,255,0.3)',
                      color: 'white',
                    }}
                  />

                  <div
                    className="rounded-xl overflow-hidden"
                    style={{
                      border: '1px solid rgba(0,229,255,0.2)',
                      background: '#08252C',
                      maxHeight: '220px',
                      overflowY: 'auto',
                    }}
                  >
                    {filterCauseOptions(causeSearch).length === 0 ? (
                      <p
                        className="px-4 py-3 text-sm"
                        style={{ color: '#888' }}
                      >
                        No se encontraron causas
                      </p>
                    ) : (
                      filterCauseOptions(causeSearch).map(cause => {
                        const checked =
                          selectedCauses.includes(cause);

                        return (
                          <label
                            key={cause}
                            className="flex items-center gap-3 px-4 py-3 cursor-pointer"
                            style={{
                              borderBottom:
                                '1px solid rgba(255,255,255,0.06)',
                            }}
                          >
                            <input
                              type="checkbox"
                              checked={checked}
                              onChange={() => {
                                setSelectedCauses(current =>
                                  toggleCauseSelection(
                                    current,
                                    cause
                                  )
                                );
                              }}
                            />

                            <span className="text-sm">
                              {cause}
                            </span>
                          </label>
                        );
                      })
                    )}
                  </div>

                  {selectedCauses.length > 0 && (
                    <div className="flex flex-wrap gap-2 mt-3">
                      {selectedCauses.map(cause => (
                        <button
                          key={cause}
                          type="button"
                          onClick={() =>
                            setSelectedCauses(current =>
                              toggleCauseSelection(
                                current,
                                cause
                              )
                            )
                          }
                          className="text-xs px-3 py-1.5 rounded-full"
                          style={{
                            background: '#00E5FF20',
                            color: '#00E5FF',
                            border:
                              '1px solid rgba(0,229,255,0.3)',
                          }}
                          title="Quitar causa"
                        >
                          {cause} ×
                        </button>
                      ))}
                    </div>
                  )}

                  <p
                    className="text-xs mt-2"
                    style={{ color: '#888' }}
                  >
                    {selectedCauses.length} causa(s) seleccionada(s)
                  </p>
                </div>

                <ProbableConsequenceField
                  value={probableConsequence}
                  onChange={setProbableConsequence}
                />

                <SupervisorAnalysisField
                  value={analysis}
                  onChange={setAnalysis}
                />

                <button
                  type="button"
                  onClick={handleAnalysisStageSave}
                  disabled={updating}
                  className="w-full py-3 rounded-xl text-sm font-medium disabled:opacity-40"
                  style={{
                    background: '#00E5FF20',
                    color: '#00E5FF',
                    border:
                      '1px solid rgba(0,229,255,0.35)',
                  }}
                >
                  {updating
                    ? 'Guardando...'
                    : 'Guardar análisis'}
                </button>

                {analysisError && (
                  <p
                    role="alert"
                    className="text-xs"
                    style={{ color: '#D72631' }}
                  >
                    {analysisError}
                  </p>
                )}

                {analysisSaved && (
                  <p
                    role="status"
                    className="text-xs"
                    style={{ color: '#16A34A' }}
                  >
                    {analysisSaved}
                  </p>
                )}

                {canChangeIncidentToProcess(
                  selected.status,
                  normalizedRole,
                ) && (
              <>
                  <button
                    type="button"
                    onClick={() =>
                      handleStatusChange(
                        selected,
                        'en_proceso',
                      )
                    }
                    disabled={
                      updating
                      || processTransitionMissingFields.length > 0
                    }
                    className="w-full py-3 rounded-xl text-sm font-medium disabled:opacity-40"
                    style={{
                      background: '#E8941A20',
                      color: '#E8941A',
                      border: '1px solid #E8941A50',
                    }}
                  >
                    Cambiar a proceso
                  </button>

                  {processTransitionMissingFields.length > 0 && (
                    <p
                      role="status"
                      className="text-xs"
                      style={{ color: '#E8941A' }}
                    >
                      Completa y guarda antes de cambiar a proceso:{' '}
                      {processTransitionMissingFields.join(', ')}.
                    </p>
                  )}
                </>
              )}
              </>
            ) : (
              <div className="space-y-4">
                <div>
                  <p className="text-xs themed-text-secondary">
                    Causas / precursores
                  </p>
                  <p className="text-sm mt-1">
                    {selectedCauses.length > 0
                      ? selectedCauses.join(', ')
                      : 'Sin causas registradas'}
                  </p>
                </div>

                <div>
                  <p className="text-xs themed-text-secondary">
                    Consecuencia probable
                  </p>
                  <p className="text-sm mt-1">
                    {probableConsequence
                      || 'Sin consecuencia registrada'}
                  </p>
                </div>

                <div>
                  <p className="text-xs themed-text-secondary">
                    Análisis del supervisor
                  </p>
                  <p className="text-sm mt-1 whitespace-pre-wrap">
                    {analysis || 'Sin análisis registrado'}
                  </p>
                </div>
              </div>
            )}
          </div>
        )}

        {activeManagementStage === 'treatment' && (
          <div className="themed-card border rounded-2xl p-5 space-y-4">
            <div>
              <h4 className="font-bold">
                Tratamiento del incidente
              </h4>
              <p className="text-xs themed-text-secondary mt-1">
                Registra las medidas implementadas, capacitación,
                plazo y feedback al trabajador.
              </p>
            </div>

            {canEditTreatment && !managementStageState.readOnly ? (
              <>
                <ControlMeasuresField
                  value={selectedControlMeasures}
                  onChange={setSelectedControlMeasures}
                />

                <div>
                  <p className="text-sm font-medium mb-1">
                    Registro de capacitación
                  </p>
                  <textarea
                    value={training}
                    onChange={event =>
                      setTraining(event.target.value)
                    }
                    placeholder="Describir la capacitación realizada..."
                    className="w-full rounded-xl px-4 py-3 text-sm resize-none h-20 outline-none"
                    style={{
                      background: '#0B2E36',
                      border:
                        '1px solid rgba(0,229,255,0.3)',
                      color: 'white',
                    }}
                  />
                </div>

                <IncidentDeadlineField
                  value={deadline}
                  onChange={setDeadline}
                />

                <WorkerFeedbackField
                  value={feedback}
                  onChange={setFeedback}
                />

                <button
                  type="button"
                  onClick={handleTreatmentSave}
                  disabled={updating}
                  className="w-full py-3 rounded-xl text-sm font-medium disabled:opacity-40"
                  style={{
                    background: '#00E5FF20',
                    color: '#00E5FF',
                    border:
                      '1px solid rgba(0,229,255,0.35)',
                  }}
                >
                  {updating
                    ? 'Guardando...'
                    : 'Guardar tratamiento'}
                </button>

                {treatmentError && (
                  <p
                    role="alert"
                    className="text-xs"
                    style={{ color: '#D72631' }}
                  >
                    {treatmentError}
                  </p>
                )}

                {treatmentSaved && (
                  <p
                    role="status"
                    className="text-xs"
                    style={{ color: '#16A34A' }}
                  >
                    {treatmentSaved}
                  </p>
                )}
              </>
            ) : (
              <div className="space-y-4">
                <div>
                  <p className="text-xs themed-text-secondary">
                    Medidas de control
                  </p>
                  <p className="text-sm mt-1">
                    {selectedControlMeasures.length > 0
                      ? selectedControlMeasures.join(', ')
                      : 'Sin medidas registradas'}
                  </p>
                </div>

                <div>
                  <p className="text-xs themed-text-secondary">
                    Capacitación
                  </p>
                  <p className="text-sm mt-1 whitespace-pre-wrap">
                    {training || 'Sin capacitación registrada'}
                  </p>
                </div>

                <div>
                  <p className="text-xs themed-text-secondary">
                    Plazo
                  </p>
                  <p className="text-sm mt-1">
                    {deadline || 'Sin plazo registrado'}
                  </p>
                </div>

                <div>
                  <p className="text-xs themed-text-secondary">
                    Feedback al trabajador
                  </p>
                  <p className="text-sm mt-1 whitespace-pre-wrap">
                    {feedback || 'Sin feedback registrado'}
                  </p>
                </div>
              </div>
            )}
          </div>
        )}

        {activeManagementStage === 'closure' && (
          <div className="themed-card border rounded-2xl p-5 space-y-5">
            <div>
              <h4 className="font-bold">
                Solicitud de cierre
              </h4>
              <p className="text-xs themed-text-secondary mt-1">
                Revisa la gestión realizada, adjunta la evidencia de cierre
                y solicita su validación.
              </p>
            </div>

            <div
              className="rounded-xl p-4 space-y-3"
              style={{
                background: 'rgba(255,255,255,0.03)',
                border: '1px solid rgba(255,255,255,0.08)',
              }}
            >
              <h5 className="text-sm font-semibold">
                Resumen de gestión
              </h5>

              <div>
                <p className="text-xs themed-text-secondary">
                  Causas / precursores
                </p>
                <p className="text-sm mt-1">
                  {selectedCauses.length > 0
                    ? selectedCauses.join(', ')
                    : 'Sin causas registradas'}
                </p>
              </div>

              <div>
                <p className="text-xs themed-text-secondary">
                  Consecuencia probable
                </p>
                <p className="text-sm mt-1">
                  {probableConsequence
                    || 'Sin consecuencia registrada'}
                </p>
              </div>

              <div>
                <p className="text-xs themed-text-secondary">
                  Análisis del supervisor
                </p>
                <p className="text-sm mt-1 whitespace-pre-wrap">
                  {analysis || 'Sin análisis registrado'}
                </p>
              </div>

              <div>
                <p className="text-xs themed-text-secondary">
                  Medidas de control
                </p>
                <p className="text-sm mt-1">
                  {selectedControlMeasures.length > 0
                    ? selectedControlMeasures.join(', ')
                    : 'Sin medidas registradas'}
                </p>
              </div>

              <div>
                <p className="text-xs themed-text-secondary">
                  Capacitación
                </p>
                <p className="text-sm mt-1 whitespace-pre-wrap">
                  {training || 'Sin capacitación registrada'}
                </p>
              </div>

              <div>
                <p className="text-xs themed-text-secondary">
                  Plazo
                </p>
                <p className="text-sm mt-1">
                  {deadline || 'Sin plazo registrado'}
                </p>
              </div>

              <div>
                <p className="text-xs themed-text-secondary">
                  Feedback al trabajador
                </p>
                <p className="text-sm mt-1 whitespace-pre-wrap">
                  {feedback || 'Sin feedback registrado'}
                </p>
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <h5 className="text-sm font-semibold">
                  Evidencia de cierre
                </h5>
                <p className="text-xs themed-text-secondary mt-1">
                  Adjunta una fotografía o documento PDF como respaldo
                  del cierre.
                </p>
              </div>

              {selected.closure_evidence && (
                <div
                  className="rounded-xl p-3"
                  style={{
                    background: 'rgba(22,163,74,0.08)',
                    border: '1px solid rgba(22,163,74,0.25)',
                  }}
                >
                  <p
                    className="text-xs font-medium"
                    style={{ color: '#16A34A' }}
                  >
                    Evidencia asociada
                  </p>
                  <p className="text-sm mt-1">
                    {selected.closure_evidence.filename}
                  </p>
                </div>
              )}

              {canManageClosureEvidence
                && !managementStageState.readOnly && (
                <>
                  <ClosureEvidencePhotoPicker
                    file={closureEvidence}
                    onChange={handleClosureEvidenceChange}
                    disabled={updating}
                  />

                  <div
                    className="flex items-center gap-3"
                    aria-hidden="true"
                  >
                    <div
                      className="h-px flex-1"
                      style={{
                        background: 'rgba(255,255,255,0.1)',
                      }}
                    />
                    <span
                      className="text-xs"
                      style={{ color: '#888' }}
                    >
                      o
                    </span>
                    <div
                      className="h-px flex-1"
                      style={{
                        background: 'rgba(255,255,255,0.1)',
                      }}
                    />
                  </div>

                  <ClosureEvidencePdfPicker
                    file={closureEvidence}
                    onChange={handleClosureEvidenceChange}
                    disabled={updating}
                  />

                  <button
                    type="button"
                    onClick={handleClosureEvidenceSave}
                    disabled={updating || !closureEvidence}
                    className="w-full py-3 rounded-xl text-sm font-medium disabled:opacity-40"
                    style={{
                      background: '#00E5FF20',
                      color: '#00E5FF',
                      border:
                        '1px solid rgba(0,229,255,0.35)',
                    }}
                  >
                    {updating
                      ? 'Guardando evidencia...'
                      : 'Guardar evidencia'}
                  </button>
                </>
              )}

              {closureEvidenceError && (
                <p
                  role="alert"
                  className="text-xs"
                  style={{ color: '#D72631' }}
                >
                  {closureEvidenceError}
                </p>
              )}

              {closureEvidenceSaved && (
                <p
                  role="status"
                  className="text-xs"
                  style={{ color: '#16A34A' }}
                >
                  {closureEvidenceSaved}
                </p>
              )}
            </div>

            <div
              className="rounded-xl p-4"
              style={{
                background: 'rgba(139,92,246,0.08)',
                border: '1px solid rgba(139,92,246,0.25)',
              }}
            >
              <p className="text-sm font-medium">
                Validación para solicitar cierre
              </p>
              <p className="text-xs themed-text-secondary mt-1">
                La acción se habilita según el estado actual del reporte
                y los permisos del usuario.
              </p>
            </div>

            {canRequestIncidentClosure(
              selected.status,
              normalizedRole,
            ) && (
              <>
              <button
                type="button"
                onClick={() =>
                  handleStatusChange(
                    selected,
                    'pending_closure',
                  )
                }
                disabled={
                  updating
                  || closureTransitionMissingFields.length > 0
                }
                className="w-full py-3 rounded-xl text-sm font-medium disabled:opacity-40"
                style={{
                  background: '#8B5CF620',
                  color: '#8B5CF6',
                  border: '1px solid #8B5CF650',
                }}
              >
                {updating
                  ? 'Solicitando cierre...'
                  : 'Solicitar cierre'}
              </button>

              {closureTransitionMissingFields.length > 0 && (
                <p
                  role="status"
                  className="text-xs"
                  style={{ color: '#8B5CF6' }}
                >
                  Completa y guarda antes de solicitar cierre:{' '}
                  {closureTransitionMissingFields.join(', ')}.
                </p>
              )}
              </>
            )}

            {statusError && (
              <p
                role="alert"
                className="text-xs"
                style={{ color: '#D72631' }}
              >
                {statusError}
              </p>
            )}
          </div>
        )}

        {activeManagementStage === 'validation' && (
          <div className="themed-card border rounded-2xl p-5 space-y-5">
            <div>
              <h4 className="font-bold">
                Validación y cierre
              </h4>

              <p className="text-xs themed-text-secondary mt-1">
                Revisa el reporte y toda la gestión realizada antes
                de aprobar el cierre.
              </p>
            </div>

            <div
              className="rounded-xl p-4 space-y-3"
              style={{
                background: 'rgba(255,255,255,0.03)',
                border: '1px solid rgba(255,255,255,0.08)',
              }}
            >
              <h5 className="text-sm font-semibold">
                Reporte original
              </h5>

              <div>
                <p className="text-xs themed-text-secondary">
                  Reporte
                </p>
                <p className="text-sm mt-1">
                  #{selected.report_id?.slice(-6).toUpperCase()}
                </p>
              </div>

              <div>
                <p className="text-xs themed-text-secondary">
                  Área
                </p>
                <p className="text-sm mt-1">
                  {selected.area_id}
                </p>
              </div>

              <div>
                <p className="text-xs themed-text-secondary">
                  Reportado por
                </p>
                <p className="text-sm mt-1">
                  {selected.reported_by?.split('_at_')[0]}
                </p>
              </div>

              <div>
                <p className="text-xs themed-text-secondary">
                  Tipo de trabajador
                </p>
                <p className="text-sm mt-1">
                  {selected.worker_type === 'externo'
                    ? 'Externo'
                    : 'Planta'}
                </p>
              </div>

              <div>
                <p className="text-xs themed-text-secondary">
                  Fecha
                </p>
                <p className="text-sm mt-1">
                  {new Date(
                    selected.created_at
                  ).toLocaleDateString('es-CL')}
                </p>
              </div>

              <div>
                <p className="text-xs themed-text-secondary">
                  Descripción
                </p>
                <p className="text-sm mt-1 whitespace-pre-wrap">
                  {selected.description}
                </p>
              </div>

              {selected.evidences?.[0] && (
                <div>
                  <p className="text-xs themed-text-secondary mb-2">
                    Evidencia inicial
                  </p>

                  <div className="w-full h-44 themed-photo-placeholder rounded-xl overflow-hidden flex items-center justify-center text-4xl">
                    <img
                      src={resolveReportEvidenceUrl(
                        selected.evidences[0],
                        import.meta.env.VITE_REPORTS_API_URL,
                      )}
                      alt="Evidencia inicial del reporte"
                      className="w-full h-full object-cover"
                      onError={event => {
                        event.currentTarget.style.display = 'none';

                        const parent =
                          event.currentTarget.parentElement;

                        if (parent) {
                          parent.textContent = '📸';
                        }
                      }}
                    />
                  </div>
                </div>
              )}
            </div>

            <div
              className="rounded-xl p-4 space-y-3"
              style={{
                background: 'rgba(255,255,255,0.03)',
                border: '1px solid rgba(255,255,255,0.08)',
              }}
            >
              <h5 className="text-sm font-semibold">
                Clasificación
              </h5>

              <div>
                <p className="text-xs themed-text-secondary">
                  Categoría
                </p>
                <p className="text-sm mt-1">
                  {selected.is_iap ? 'IAP' : selected.type}
                </p>
              </div>

              <div>
                <p className="text-xs themed-text-secondary">
                  Alto Potencial
                </p>
                <p className="text-sm mt-1">
                  {selected.is_iap ? 'Sí' : 'No'}
                </p>
              </div>
            </div>

            <div
              className="rounded-xl p-4 space-y-3"
              style={{
                background: 'rgba(255,255,255,0.03)',
                border: '1px solid rgba(255,255,255,0.08)',
              }}
            >
              <h5 className="text-sm font-semibold">
                Análisis
              </h5>

              <div>
                <p className="text-xs themed-text-secondary">
                  Causas / precursores
                </p>
                <p className="text-sm mt-1">
                  {selectedCauses.length > 0
                    ? selectedCauses.join(', ')
                    : 'Sin causas registradas'}
                </p>
              </div>

              <div>
                <p className="text-xs themed-text-secondary">
                  Consecuencia probable
                </p>
                <p className="text-sm mt-1">
                  {probableConsequence
                    || 'Sin consecuencia registrada'}
                </p>
              </div>

              <div>
                <p className="text-xs themed-text-secondary">
                  Análisis del supervisor
                </p>
                <p className="text-sm mt-1 whitespace-pre-wrap">
                  {analysis || 'Sin análisis registrado'}
                </p>
              </div>
            </div>

            <div
              className="rounded-xl p-4 space-y-3"
              style={{
                background: 'rgba(255,255,255,0.03)',
                border: '1px solid rgba(255,255,255,0.08)',
              }}
            >
              <h5 className="text-sm font-semibold">
                Tratamiento
              </h5>

              <div>
                <p className="text-xs themed-text-secondary">
                  Medidas de control
                </p>
                <p className="text-sm mt-1">
                  {selectedControlMeasures.length > 0
                    ? selectedControlMeasures.join(', ')
                    : 'Sin medidas registradas'}
                </p>
              </div>

              <div>
                <p className="text-xs themed-text-secondary">
                  Capacitación
                </p>
                <p className="text-sm mt-1 whitespace-pre-wrap">
                  {training || 'Sin capacitación registrada'}
                </p>
              </div>

              <div>
                <p className="text-xs themed-text-secondary">
                  Plazo
                </p>
                <p className="text-sm mt-1">
                  {deadline || 'Sin plazo registrado'}
                </p>
              </div>

              <div>
                <p className="text-xs themed-text-secondary">
                  Feedback al trabajador
                </p>
                <p className="text-sm mt-1 whitespace-pre-wrap">
                  {feedback || 'Sin feedback registrado'}
                </p>
              </div>
            </div>

            <div
              className="rounded-xl p-4 space-y-3"
              style={{
                background: 'rgba(255,255,255,0.03)',
                border: '1px solid rgba(255,255,255,0.08)',
              }}
            >
              <h5 className="text-sm font-semibold">
                Evidencia de cierre
              </h5>

              {selected.closure_evidence ? (
                <>
                  <div>
                    <p className="text-xs themed-text-secondary">
                      Archivo
                    </p>
                    <p className="text-sm mt-1">
                      {selected.closure_evidence.filename}
                    </p>
                  </div>

                  <div>
                    <p className="text-xs themed-text-secondary">
                      Tipo
                    </p>
                    <p className="text-sm mt-1">
                      {selected.closure_evidence.content_type}
                    </p>
                  </div>

                  {selected.closure_evidence.content_type
                    ?.startsWith('image/') && (
                    <div className="w-full h-44 themed-photo-placeholder rounded-xl overflow-hidden flex items-center justify-center text-4xl">
                      <img
                        src={closureEvidenceUrl}
                        alt="Evidencia de cierre"
                        className="w-full h-full object-cover"
                        onError={event => {
                          event.currentTarget.style.display =
                            'none';

                          const parent =
                            event.currentTarget.parentElement;

                          if (parent) {
                            parent.textContent = '📎';
                          }
                        }}
                      />
                    </div>
                  )}

                  <a
                    href={closureEvidenceUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex text-sm font-medium"
                    style={{ color: '#00E5FF' }}
                  >
                    Ver evidencia de cierre
                  </a>
                </>
              ) : (
                <p className="text-sm themed-text-secondary">
                  Sin evidencia de cierre asociada.
                </p>
              )}
            </div>

            {selected.status === 'pending_closure' && (
              <div
                className="rounded-xl p-4"
                style={{
                  background: 'rgba(139,92,246,0.08)',
                  border: '1px solid rgba(139,92,246,0.25)',
                }}
              >
                <p className="text-sm font-medium">
                  Pendiente de validación
                </p>
                <p className="text-xs themed-text-secondary mt-1">
                  La información permanece en modo de consulta.
                  Los roles autorizados pueden aprobar el cierre.
                </p>
              </div>
            )}

            {selected.status === 'closed' && (
              <div
                className="rounded-xl p-4"
                style={{
                  background: 'rgba(22,163,74,0.08)',
                  border: '1px solid rgba(22,163,74,0.25)',
                }}
              >
                <p
                  className="text-sm font-medium"
                  style={{ color: '#16A34A' }}
                >
                  Reporte cerrado
                </p>
                <p className="text-xs themed-text-secondary mt-1">
                  La gestión finalizó. El reporte permanece
                  disponible únicamente para consulta.
                </p>
              </div>
            )}

            {canApproveIncidentClosure(
              selected.status,
              normalizedRole,
            ) && (
              <button
                type="button"
                onClick={() =>
                  handleStatusChange(
                    selected,
                    'closed',
                  )
                }
                disabled={updating}
                className="w-full py-3 rounded-xl text-sm font-medium disabled:opacity-40"
                style={{
                  background: '#16A34A20',
                  color: '#16A34A',
                  border: '1px solid #16A34A50',
                }}
              >
                {updating
                  ? 'Aprobando cierre...'
                  : 'Aprobar cierre'}
              </button>
            )}

            {statusError && (
              <p
                role="alert"
                className="text-xs"
                style={{ color: '#D72631' }}
              >
                {statusError}
              </p>
            )}

            {statusSaved && (
              <p
                role="status"
                className="text-xs"
                style={{ color: '#16A34A' }}
              >
                {statusSaved}
              </p>
            )}
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="p-4 space-y-3">
      <h2 className="text-xl font-bold mb-2">Gestionar Incidentes</h2>
      <p className="text-xs mb-3" style={{color: '#888'}}>
        {userRole === 'supervisor' ? 'Incidentes asignados a ti' :
         userRole === 'jefe de area' ? 'Incidentes de tu area: ' + userArea :
         'Todos los incidentes'}
      </p>
      {/* Filtros */}
      <div className="flex gap-2">
        <select value={filterArea} onChange={e => setFilterArea(e.target.value)}
          className="flex-1 rounded-lg px-2 py-2 text-xs" style={{ background: '#0B2E36', border: '1px solid rgba(0,229,255,0.3)', color: 'white' }}>
          <option value="">Todas</option>
          {INCIDENT_AREAS.map(a => <option key={a} value={a}>{a}</option>)}
        </select>
        <select value={filterStatus} onChange={e => setFilterStatus(e.target.value)}
          className="flex-1 rounded-lg px-2 py-2 text-xs" style={{ background: '#0B2E36', border: '1px solid rgba(0,229,255,0.3)', color: 'white' }}>
          <option value="">Estado</option>
          <option value="open">Abierto</option>
          <option value="en_proceso">En Proceso</option>
          <option value="pending_closure">
            Pendiente de cierre
          </option>
          <option value="closed">Cerrado</option>
        </select>
        <select value={filterIAP} onChange={e => setFilterIAP(e.target.value)}
          className="flex-1 rounded-lg px-2 py-2 text-xs" style={{ background: '#0B2E36', border: '1px solid rgba(0,229,255,0.3)', color: 'white' }}>
          <option value="">IAP</option>
          <option value="si">Solo IAP</option>
          <option value="no">Sin IAP</option>
        </select>
      </div>

      {reports.filter(r => {
        if (filterArea && r.area_id !== filterArea) return false;
        if (filterStatus && r.status !== filterStatus) return false;
        if (filterIAP === 'si' && !r.is_iap) return false;
        if (filterIAP === 'no' && r.is_iap) return false;
        return true;
      }).length === 0 ? (
        <p className="text-center py-8" style={{color: '#888'}}>No hay incidentes para gestionar</p>
      ) : (
        reports.filter(r => {
          if (filterArea && r.area_id !== filterArea) return false;
          if (filterStatus && r.status !== filterStatus) return false;
          if (filterIAP === 'si' && !r.is_iap) return false;
          if (filterIAP === 'no' && r.is_iap) return false;
          return true;
        }).map(r => {
          const st = STATUS_MAP[r.status] || STATUS_MAP.open;
          return (
            <button key={r.report_id} onClick={() => openReport(r)}
              className="w-full themed-card border rounded-xl p-4 text-left flex items-center gap-3">
              <div className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0"
                style={{ background: st.color + '20' }}>
                {r.status === 'closed' ? <CheckCircle size={20} style={{ color: st.color }} /> :
                 ['en_proceso', 'pending_closure'].includes(r.status) ? <Clock size={20} style={{ color: st.color }} /> :
                 <AlertTriangle size={20} style={{ color: st.color }} />}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-medium truncate">{r.description?.slice(0, 35) || 'Sin descripcion'}</p>
                  <span className="text-xs px-2 py-0.5 rounded-full ml-2 flex-shrink-0" style={{ background: st.color + '20', color: st.color }}>{st.label}</span>
                </div>
                <p className="text-xs mt-0.5" style={{color: '#888'}}>{r.area_id} - {r.reported_by?.split('_at_')[0]}</p>
              </div>
              <ChevronRight size={16} style={{color: '#888'}} className="flex-shrink-0" />
            </button>
          );
        })
      )}
    </div>
  );
}
