interface SupervisorAnalysisFieldProps {
  value: string;
  onChange: (value: string) => void;
  disabled?: boolean;
}

export default function SupervisorAnalysisField({
  value,
  onChange,
  disabled = false,
}: SupervisorAnalysisFieldProps) {
  return (
    <div>
      <p className="text-sm font-medium mb-1">
        Análisis del supervisor
      </p>

      <textarea
        value={value}
        onChange={event => onChange(event.target.value)}
        disabled={disabled}
        placeholder="Describir el análisis del hallazgo..."
        className="w-full rounded-xl px-4 py-3 text-sm resize-none h-24 outline-none"
        style={{
          background: '#0B2E36',
          border: '1px solid rgba(0,229,255,0.3)',
          color: 'white',
        }}
      />

      <p
        className="text-xs mt-1"
        style={{ color: '#888' }}
      >
        Registra el análisis técnico realizado sobre el hallazgo.
      </p>
    </div>
  );
}
