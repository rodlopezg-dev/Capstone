import { Component, ReactNode } from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';

interface Props { children: ReactNode; }
interface State { hasError: boolean; message: string; }

export class ErrorBoundary extends Component<Props, State> {
  state: State = { hasError: false, message: '' };

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, message: error.message };
  }

  componentDidCatch(error: Error, info: { componentStack: string }) {
    console.error('[ErrorBoundary]', error, info.componentStack);
  }

  render() {
    if (!this.state.hasError) return this.props.children;
    return (
      <div className="flex-1 flex items-center justify-center bg-background">
        <div className="text-center max-w-md px-6">
          <div className="w-16 h-16 rounded-full bg-[#D72631]/10 border border-[#D72631]/30 flex items-center justify-center mx-auto mb-6">
            <AlertTriangle size={28} className="text-[#D72631]" />
          </div>
          <h2 className="text-xl font-bold text-white mb-2" style={{ fontFamily: 'var(--font-display)' }}>
            Algo salió mal
          </h2>
          <p className="text-sm text-[#9DBBD2] mb-6 leading-relaxed">
            Ocurrió un error inesperado en este módulo. El resto de la plataforma sigue funcionando.
          </p>
          {this.state.message && (
            <p className="text-xs font-mono text-[#5A8CB0] bg-[#102A4C] rounded-lg px-3 py-2 mb-6 text-left break-all">
              {this.state.message}
            </p>
          )}
          <button
            onClick={() => this.setState({ hasError: false, message: '' })}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[#00E5FF]/10 border border-[#00E5FF]/30 text-[#00E5FF] hover:bg-[#00E5FF]/20 transition-all mx-auto text-sm font-medium"
          >
            <RefreshCw size={14} />
            Reintentar
          </button>
        </div>
      </div>
    );
  }
}
