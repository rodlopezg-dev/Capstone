from pydantic import BaseModel, Field, EmailStr
from typing import Optional, List
from datetime import datetime

# ----------------------------------------
# REQUEST MODELS (Lo que manda el Frontend)
# ----------------------------------------


class AreaCreate(BaseModel):
    name: str = Field(..., description="Nombre de la zona o área")
    description: Optional[str] = Field(
        None, description="Descripción opcional del área"
    )
    is_active: bool = Field(default=True, description="Estado del área")

    # NOTA: No incluimos client_id aquí porque el Frontend NO DEBE enviarlo.
    # Lo sacaremos del token del usuario de forma segura (current_user.client_id).


class AreaUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    is_active: Optional[bool] = None


# ----------------------------------------
# RESPONSE MODELS (Lo que devolvemos al Frontend)
# ----------------------------------------


class AreaResponse(BaseModel):
    id: str
    client_id: str
    name: str
    description: Optional[str] = ""
    is_active: bool = True
    zones: Optional[List[str]] = []
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        # Permite que Pydantic lea diccionarios que vienen del Repository
        from_attributes = True


class UserBase(BaseModel):
    name: str = Field(..., description="Nombre completo del usuario")
    email: EmailStr = Field(..., description="Correo electrónico")
    role: str = Field(..., description="worker, analyst, sso_manager, admin")
    assigned_areas: List[str] = Field(
        default_factory=list, description="IDs de las áreas asignadas"
    )


class CurrentUser(BaseModel):
    id: str
    role: str
    client_id: str
