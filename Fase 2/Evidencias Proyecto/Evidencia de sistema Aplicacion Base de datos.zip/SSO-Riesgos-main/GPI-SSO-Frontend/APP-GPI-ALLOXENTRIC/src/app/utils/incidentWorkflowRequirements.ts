export interface IncidentWorkflowRequirementsSource {
  type?: string;
  is_iap?: boolean;
  causes?: string[];
  probable_consequence?: string;
  analysis?: string;
  control_measures?: string[];
  training?: string;
  deadline?: string;
  feedback?: string;
  closure_evidence?: unknown;
}

const VALID_CATEGORIES = new Set([
  'Acto Inseguro',
  'Condición Insegura',
  'Accidente',
  'IAP',
]);

function hasText(value?: string): boolean {
  return Boolean(value?.trim());
}

function hasItems(value?: string[]): boolean {
  return Boolean(value?.length);
}

function effectiveCategory(
  report: IncidentWorkflowRequirementsSource,
): string {
  if (report.is_iap) {
    return 'IAP';
  }

  return report.type?.trim() || '';
}

export function getProcessTransitionMissingFields(
  report: IncidentWorkflowRequirementsSource,
): string[] {
  const missing: string[] = [];

  if (!VALID_CATEGORIES.has(effectiveCategory(report))) {
    missing.push('categoría');
  }

  if (!hasItems(report.causes)) {
    missing.push('causas / precursores');
  }

  if (!hasText(report.probable_consequence)) {
    missing.push('consecuencia probable');
  }

  if (!hasText(report.analysis)) {
    missing.push('análisis del supervisor');
  }

  return missing;
}

export function getClosureTransitionMissingFields(
  report: IncidentWorkflowRequirementsSource,
): string[] {
  const missing: string[] = [];

  if (!hasItems(report.control_measures)) {
    missing.push('medidas de control');
  }

  if (!hasText(report.training)) {
    missing.push('capacitación');
  }

  if (!hasText(report.deadline)) {
    missing.push('plazo');
  }

  if (!hasText(report.feedback)) {
    missing.push('feedback al trabajador');
  }

  if (!report.closure_evidence) {
    missing.push('evidencia de cierre');
  }

  return missing;
}
