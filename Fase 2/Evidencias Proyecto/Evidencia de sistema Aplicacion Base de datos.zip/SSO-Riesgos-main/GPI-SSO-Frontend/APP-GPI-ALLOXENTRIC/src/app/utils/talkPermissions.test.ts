import { describe, expect, it } from 'vitest';
import { canManageTalkAttendance } from './talkPermissions';

describe('talk attendance permissions', () => {
  it.each(['admin', 'sso_manager', 'SSO MANAGER'])('shows tenant administration for %s', role => {
    expect(canManageTalkAttendance(role)).toBe(true);
  });

  it.each(['worker', 'usuario', 'supervisor', 'jefe_de_area', 'analyst', '', 'unknown'])(
    'does not show unscoped administration for %s', role => {
      expect(canManageTalkAttendance(role)).toBe(false);
    },
  );
});
