import asyncio

import pytest

from app.repositories.rep_talks import TalksRepository
from app.routers import rt_talks


def _sheet_files(content=b"imagen"):
    return {
        "file": (
            "asistencia.jpg",
            content,
            "image/jpeg",
        ),
    }


def _sheet_data(
    *,
    talk_id="talk_a",
    topic="Charla de prueba",
):
    return {
        "talk_id": talk_id,
        "topic": topic,
        "date": "2026-09-28",
    }


def _attachment(index: int):
    return {
        "file_id": f"file-{index}",
        "file_url": "",
        "file_name": f"asistencia-{index}.jpg",
        "file_content_type": "image/jpeg",
        "file_size": 6,
        "file_storage": {
            "provider": "test",
            "blob_name": f"attendance/{index}.jpg",
        },
    }


@pytest.mark.asyncio
async def test_attendance_sheet_requires_talk_id_before_storage(
    api,
    auth_headers,
    monkeypatch,
):
    async def unexpected_store(*args, **kwargs):
        raise AssertionError(
            "No debe almacenar el archivo sin talk_id."
        )

    monkeypatch.setattr(
        rt_talks,
        "_store_attachment",
        unexpected_store,
    )

    response = await api.post(
        "/v1/attendance",
        data={
            "topic": "Hoja sin charla",
            "date": "2026-09-28",
        },
        files=_sheet_files(),
        headers=auth_headers(
            user_id="admin_a",
            role="admin",
        ),
    )

    assert response.status_code == 422
    assert (
        response.json()["detail"]
        == "La hoja de asistencia debe estar asociada a una charla."
    )


@pytest.mark.asyncio
async def test_attendance_sheet_is_stored_once_per_tenant_talk(
    api,
    db,
    seed,
    auth_headers,
    monkeypatch,
):
    stored = []
    cleaned = []

    async def fake_store(
        file,
        *,
        client_id,
        category,
    ):
        attachment = _attachment(len(stored) + 1)
        stored.append(
            (
                client_id,
                category,
                attachment["file_storage"],
            )
        )
        return attachment

    async def fake_cleanup(storage_ref):
        cleaned.append(storage_ref)

    monkeypatch.setattr(
        rt_talks,
        "_store_attachment",
        fake_store,
    )
    monkeypatch.setattr(
        rt_talks,
        "_cleanup_storage",
        fake_cleanup,
    )

    headers = auth_headers(
        user_id="admin_a",
        role="admin",
    )

    first = await api.post(
        "/v1/attendance",
        data=_sheet_data(),
        files=_sheet_files(b"primera"),
        headers=headers,
    )

    assert first.status_code == 200, first.text

    document = await db["attendance"].find_one({
        "client_id": "empresa_a",
        "talk_id": "talk_a",
    })

    assert document is not None
    assert document["source"] == "sheet"
    assert document["file_id"] == "file-1"
    assert document["_id"].startswith("attendance_file_")

    second = await api.post(
        "/v1/attendance",
        data=_sheet_data(),
        files=_sheet_files(b"segunda"),
        headers=headers,
    )

    assert second.status_code == 409
    assert len(stored) == 1
    assert cleaned == []

    assert await db["attendance"].count_documents({
        "client_id": "empresa_a",
        "talk_id": "talk_a",
    }) == 1


@pytest.mark.asyncio
async def test_concurrent_attendance_sheet_upload_cleans_loser_blob(
    api,
    db,
    seed,
    auth_headers,
    monkeypatch,
):
    stored = []
    cleaned = []

    async def always_missing(
        self,
        client_id,
        talk_id,
    ):
        return False

    async def fake_store(
        file,
        *,
        client_id,
        category,
    ):
        attachment = _attachment(len(stored) + 1)
        stored.append(attachment)
        return attachment

    async def fake_cleanup(storage_ref):
        cleaned.append(storage_ref)

    monkeypatch.setattr(
        TalksRepository,
        "talk_has_attendance_file",
        always_missing,
    )
    monkeypatch.setattr(
        rt_talks,
        "_store_attachment",
        fake_store,
    )
    monkeypatch.setattr(
        rt_talks,
        "_cleanup_storage",
        fake_cleanup,
    )

    headers = auth_headers(
        user_id="admin_a",
        role="admin",
    )

    async def upload(content):
        return await api.post(
            "/v1/attendance",
            data=_sheet_data(),
            files=_sheet_files(content),
            headers=headers,
        )

    first, second = await asyncio.gather(
        upload(b"uno"),
        upload(b"dos"),
    )

    assert sorted([
        first.status_code,
        second.status_code,
    ]) == [200, 409]

    assert await db["attendance"].count_documents({
        "client_id": "empresa_a",
        "talk_id": "talk_a",
    }) == 1

    assert len(stored) == 2
    assert len(cleaned) == 1

    stored_refs = {
        item["file_storage"]["blob_name"]
        for item in stored
    }

    assert cleaned[0]["blob_name"] in stored_refs


@pytest.mark.asyncio
async def test_attendance_sheet_is_isolated_by_tenant(
    api,
    db,
    seed,
    auth_headers,
    monkeypatch,
):
    counter = 0

    await db["talks"].insert_one({
        "talk_id": "talk_a",
        "client_id": "empresa_b",
        "title": "Charla empresa B",
        "month": "9",
        "year": "2026",
    })

    async def fake_store(
        file,
        *,
        client_id,
        category,
    ):
        nonlocal counter
        counter += 1
        return _attachment(counter)

    monkeypatch.setattr(
        rt_talks,
        "_store_attachment",
        fake_store,
    )

    response_a = await api.post(
        "/v1/attendance",
        data=_sheet_data(),
        files=_sheet_files(b"a"),
        headers=auth_headers(
            user_id="admin_a",
            client_id="empresa_a",
            role="admin",
        ),
    )

    response_b = await api.post(
        "/v1/attendance",
        data=_sheet_data(
            topic="Charla empresa B",
        ),
        files=_sheet_files(b"b"),
        headers=auth_headers(
            user_id="admin_b",
            client_id="empresa_b",
            role="admin",
        ),
    )

    assert response_a.status_code == 200, response_a.text
    assert response_b.status_code == 200, response_b.text

    documents = await db["attendance"].find(
        {"talk_id": "talk_a"}
    ).to_list(length=10)

    assert len(documents) == 2
    assert {
        item["client_id"]
        for item in documents
    } == {
        "empresa_a",
        "empresa_b",
    }

    assert documents[0]["_id"] != documents[1]["_id"]
