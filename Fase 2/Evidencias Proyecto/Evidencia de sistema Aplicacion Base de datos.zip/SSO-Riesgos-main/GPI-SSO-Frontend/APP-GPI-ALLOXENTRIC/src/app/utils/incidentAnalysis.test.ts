import { describe, expect, it } from 'vitest';

import {
  buildIncidentAnalysisPayload,
} from './incidentAnalysis';

describe('incident analysis payload - SCRUM-78', () => {
  it('builds the complete analysis payload', () => {
    expect(
      buildIncidentAnalysisPayload(
        ['Falta de EPP'],
        'Caída al mismo nivel',
        'Análisis supervisor',
        ['Otra medida de control'],
        '2026-09-25',
        'Feedback trabajador'
      )
    ).toEqual({
      causes: ['Falta de EPP'],
      probable_consequence: 'Caída al mismo nivel',
      analysis: 'Análisis supervisor',
      control_measures: [
        'Otra medida de control',
      ],
      deadline: '2026-09-25',
      feedback: 'Feedback trabajador',
    });
  });

  it('preserves explicit empty values', () => {
    expect(
      buildIncidentAnalysisPayload(
        [],
        '',
        '',
        [],
        '',
        ''
      )
    ).toEqual({
      causes: [],
      probable_consequence: '',
      analysis: '',
      control_measures: [],
      deadline: '',
      feedback: '',
    });
  });

  it('does not expose the original arrays', () => {
    const causes = ['Falta de EPP'];
    const measures = ['Otra medida de control'];

    const payload = buildIncidentAnalysisPayload(
      causes,
      'Atrapamiento',
      'Análisis',
      measures,
      '',
      ''
    );

    expect(payload.causes).not.toBe(causes);
    expect(
      payload.control_measures
    ).not.toBe(measures);
  });
});
