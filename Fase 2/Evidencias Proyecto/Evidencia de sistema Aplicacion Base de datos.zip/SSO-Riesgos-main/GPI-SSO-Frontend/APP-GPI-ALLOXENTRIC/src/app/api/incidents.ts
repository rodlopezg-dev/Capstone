import {
  authenticatedFetch,
} from './client';

const REPORTS_API = import.meta.env.VITE_REPORTS_API_URL || 'http://localhost:8102';
const ALERTS_API = import.meta.env.VITE_ALERTS_API_URL || 'http://localhost:8104';

export interface RawAlertDoc {
  alert_id: string;
  type: string;
  title: string;
  description: string;
  area: string;
  status: string;
  priority: string;
  created_at: string;
}

export function alertToNotification(alert: RawAlertDoc) {
  return {
    id: alert.alert_id,
    type: 'alert' as const,
    title: alert.title,
    body: alert.description,
    createdAt: alert.created_at,
    read: false,
  };
}

export function listenNotifications(
  userId: string,
  onData: (notifs: any[]) => void,
  onReady?: () => void,
) {
  const fetchNotifs = async () => {
    try {
      const res = await authenticatedFetch(
        REPORTS_API + '/v1/workers/me/notifications',
      );
      if (!res.ok) {
        onData([]);
        return;
      }

      const data = await res.json();
      onData(Array.isArray(data) ? data : data.data || []);
      onReady?.();
    } catch {
      onData([]);
    }
  };
  fetchNotifs();
  const interval = setInterval(fetchNotifs, 30000);
  return () => clearInterval(interval);
}

export function listenAlerts(
  clientId: string,
  onData: (alerts: RawAlertDoc[]) => void,
  onReady?: () => void,
) {
  const fetchAlerts = async () => {
    try {
      const res = await authenticatedFetch(
        ALERTS_API + '/v1/alerts/?status=active&page_size=100',
      );
      if (!res.ok) {
        onData([]);
        return;
      }

      const data = await res.json();
      onData(data.alerts || data || []);
      onReady?.();
    } catch {
      onData([]);
    }
  };
  fetchAlerts();
  const interval = setInterval(fetchAlerts, 30000);
  return () => clearInterval(interval);
}

export async function getNotifications(): Promise<any[]> {
  try {
    const res = await authenticatedFetch(
      REPORTS_API + '/v1/workers/me/notifications',
    );
    if (!res.ok) return [];
    const data = await res.json();
    return Array.isArray(data) ? data : data.data || [];
  } catch { return []; }
}

export async function markAllNotificationsRead(): Promise<void> {
  // No-op por ahora
}

export async function getWorkerStats(): Promise<any> {
  try {
    const res = await authenticatedFetch(
      REPORTS_API + '/v1/reports',
    );
    if (!res.ok) return { total_reports: 0, reports_this_period: 0, effectiveness_rate: 0 };
    const reports = await res.json();
    const closed = reports.filter((r: any) => r.status === 'closed');
    return {
      total_reports: reports.length,
      reports_this_period: reports.length,
      effectiveness_rate: reports.length > 0 ? Math.round(closed.length / reports.length * 100) : 0,
    };
  } catch { return { total_reports: 0, reports_this_period: 0, effectiveness_rate: 0 }; }
}
