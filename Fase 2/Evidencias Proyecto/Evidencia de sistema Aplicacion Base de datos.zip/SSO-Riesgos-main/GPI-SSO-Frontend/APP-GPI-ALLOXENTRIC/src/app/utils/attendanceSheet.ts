export const MAX_ATTENDANCE_SHEET_BYTES =
  10 * 1024 * 1024;

export const ATTENDANCE_SHEET_TYPES = [
  'image/jpeg',
  'image/png',
  'image/webp',
];

export interface AttendanceSheetRecord {
  talk_id?: string;
  file_id?: string;
  file_url?: string;
}

export function localAttendanceDate(
  date = new Date(),
): string {
  const year = date.getFullYear();
  const month = String(
    date.getMonth() + 1,
  ).padStart(2, '0');
  const day = String(
    date.getDate(),
  ).padStart(2, '0');

  return `${year}-${month}-${day}`;
}

export function validateAttendanceSheet(
  file: Pick<File, 'type' | 'size'>,
): string | null {
  if (!ATTENDANCE_SHEET_TYPES.includes(file.type)) {
    return 'Formato no permitido. Usa JPG, PNG o WEBP.';
  }

  if (file.size <= 0) {
    return 'La imagen está vacía.';
  }

  if (file.size > MAX_ATTENDANCE_SHEET_BYTES) {
    return 'La imagen excede el límite de 10 MB.';
  }

  return null;
}

export function findAttendanceSheet<
  T extends AttendanceSheetRecord,
>(
  records: T[],
  talkId: string,
): T | null {
  return (
    records.find(record =>
      record.talk_id === talkId &&
      (
        Boolean(record.file_id) ||
        Boolean(record.file_url)
      )
    ) ?? null
  );
}
