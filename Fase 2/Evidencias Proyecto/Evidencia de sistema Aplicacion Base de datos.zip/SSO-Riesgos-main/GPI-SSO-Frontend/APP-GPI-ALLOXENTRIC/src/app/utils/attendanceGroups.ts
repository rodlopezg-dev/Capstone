import { attendanceParticipants } from './attendanceParticipants';

type Record = Parameters<typeof attendanceParticipants>[0] & {
  talk_id?: string;
  client_id?: string;
  topic: string;
  feedback?: string;
};

// Group for display only: original attendance documents remain unchanged.
export function groupAttendance<T extends Record>(records: T[]) {
  const groups = new Map<string, T & { participants: ReturnType<typeof attendanceParticipants> }>();
  for (const record of records) {
    const key = JSON.stringify([record.client_id, record.talk_id || record.attendance_id]);
    const participants = attendanceParticipants(record).map(row => ({ ...row, recordDate: record.date }));
    const group = groups.get(key);
    if (group) {
      group.participants.push(...participants);
      if (record.feedback) group.feedback = [group.feedback, record.feedback].filter(Boolean).join(' · ');
    } else {
      groups.set(key, { ...record, participants });
    }
  }
  return [...groups.values()];
}
