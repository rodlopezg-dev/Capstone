import { useState } from 'react';
import { Lock, Shield, Bell, Database, FileText, Activity, Key } from 'lucide-react';

type Props = { userRole?: string };

const USERS_API = window.location.origin + '/api/users/v1/admin/users';

export default function Settings({ userRole }: Props) {
  const [currentPass, setCurrentPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [confirmPass, setConfirmPass] = useState('');
  const [passMsg, setPassMsg] = useState('');
  const [passError, setPassError] = useState('');
  const [updating, setUpdating] = useState(false);

  const handleChangePassword = async () => {
    setPassMsg(''); setPassError('');
    if (!currentPass || !newPass) { setPassError('Completa todos los campos'); return; }
    if (newPass !== confirmPass) { setPassError('Las contraseñas no coinciden'); return; }
    if (newPass.length < 6) { setPassError('La contraseña debe tener al menos 6 caracteres'); return; }
    setUpdating(true);
    try {
      const res = await fetch(USERS_API + '/change-password', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + localStorage.getItem('sso_token') },
        body: JSON.stringify({ current_password: currentPass, new_password: newPass })
      });
      if (res.ok) {
        setPassMsg('Contraseña actualizada correctamente');
        setCurrentPass(''); setNewPass(''); setConfirmPass('');
      } else {
        const data = await res.json();
        setPassError(data.detail || 'Error al cambiar contraseña');
      }
    } catch (e) { setPassError('Error de conexión'); }
    setUpdating(false);
  };

  const isAdmin = ['admin', 'sso_manager'].includes(userRole?.toLowerCase() || '');

  return (
    <div className="h-full p-6 overflow-auto">
      <h1 className="text-2xl font-bold mb-6">Configuración</h1>

      {/* Cambio de contraseña */}
      <div className="border border-border rounded-xl p-6 mb-6">
        <div className="flex items-center gap-3 mb-4">
          <Key size={20} className="text-primary" />
          <h2 className="text-lg font-semibold">Cambiar Contraseña</h2>
        </div>
        <div className="space-y-3 max-w-md">
          <div>
            <label className="text-xs text-muted-foreground block mb-1">Contraseña actual</label>
            <input type="password" value={currentPass} onChange={e => setCurrentPass(e.target.value)}
              className="w-full px-3 py-2 bg-secondary border border-border rounded-lg text-sm" placeholder="••••••" />
          </div>
          <div>
            <label className="text-xs text-muted-foreground block mb-1">Nueva contraseña</label>
            <input type="password" value={newPass} onChange={e => setNewPass(e.target.value)}
              className="w-full px-3 py-2 bg-secondary border border-border rounded-lg text-sm" placeholder="••••••" />
          </div>
          <div>
            <label className="text-xs text-muted-foreground block mb-1">Confirmar nueva contraseña</label>
            <input type="password" value={confirmPass} onChange={e => setConfirmPass(e.target.value)}
              className="w-full px-3 py-2 bg-secondary border border-border rounded-lg text-sm" placeholder="••••••" />
          </div>
          {passError && <p className="text-xs text-red-400">{passError}</p>}
          {passMsg && <p className="text-xs text-green-400">{passMsg}</p>}
          <button onClick={handleChangePassword} disabled={updating}
            className="px-6 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:bg-primary/90 disabled:opacity-50">
            {updating ? 'Actualizando...' : 'Cambiar contraseña'}
          </button>
        </div>
      </div>

      {/* Otras configuraciones */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {[
          { icon: Shield, title: 'Seguridad', desc: 'Políticas de acceso y autenticación' },
          { icon: Bell, title: 'Notificaciones', desc: 'Configurar alertas y recordatorios' },
          { icon: Database, title: 'Datos', desc: 'Exportar o importar datos del sistema' },
          { icon: FileText, title: 'Reportes', desc: 'Plantillas y formatos de reportes' },
          { icon: Activity, title: 'Auditoría', desc: 'Registro de actividad del sistema' },
        ].map((item, i) => (
          <div key={i} className="border border-border rounded-xl p-4 hover:border-primary/50 transition-all cursor-pointer">
            <div className="flex items-center gap-3 mb-2">
              <item.icon size={18} className="text-primary" />
              <h3 className="font-medium">{item.title}</h3>
            </div>
            <p className="text-xs text-muted-foreground">{item.desc}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
