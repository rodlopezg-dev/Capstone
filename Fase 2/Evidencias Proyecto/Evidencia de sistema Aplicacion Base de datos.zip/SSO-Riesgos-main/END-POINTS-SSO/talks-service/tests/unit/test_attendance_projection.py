import pytest

from app.repositories.rep_talks import TalksRepository


class ProjectingCursor:
    def __init__(self, documents):
        self.documents = iter(documents)

    def __aiter__(self):
        return self

    async def __anext__(self):
        try:
            return next(self.documents)
        except StopIteration:
            raise StopAsyncIteration


class ProjectingCollection:
    def __init__(self, documents):
        self.documents = documents

    def find(self, query, projection=None):
        matches = (
            document for document in self.documents
            if all(document.get(key) == value for key, value in query.items())
        )
        if projection:
            included = {key for key, enabled in projection.items() if enabled}
            matches = (
                {key: value for key, value in document.items() if key in included}
                for document in matches
            )
        return ProjectingCursor(matches)


@pytest.mark.asyncio
async def test_monthly_stats_do_not_resolve_qr_name_when_ids_are_empty():
    database = {
        "users": ProjectingCollection([{
            "client_id": "empresa_a", "user_id": "worker_a",
            "status": "active", "role": "worker",
            "name": "Ana", "last_name": "Prueba",
        }]),
        "talks": ProjectingCollection([{
            "client_id": "empresa_a", "talk_id": "talk_a",
            "month": "9", "year": "2026",
        }]),
        "attendance": ProjectingCollection([{
            "client_id": "empresa_a", "talk_id": "talk_a",
            "source": "qr", "date": "2026-09-10",
            "attended_user_ids": [], "attendees": ["Ana Prueba"],
        }]),
        "talk_qr_sessions": ProjectingCollection([]),
        "attendance_participants": ProjectingCollection([]),
        "attendance_scans": ProjectingCollection([]),
    }

    result = await TalksRepository(database).attendance_stats_by_month(
        "empresa_a", "2026"
    )

    assert result[0]["active_workers"] == 1
    assert result[0]["attendance_count"] == 0
