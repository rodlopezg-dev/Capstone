import pytest


async def _create_tenant_a_talk(db, talk_id):
    await db["talks"].insert_one({
        "talk_id": talk_id,
        "client_id": "empresa_a",
        "title": "Charla obligatoria empresa A",
        "month": "9",
        "year": "2026",
        "mandatory": True,
        "expected_user_ids": [
            "worker_a",
            "worker_a2",
        ],
    })


async def _create_cross_tenant_attendance(db, talk_id):
    # Asistencia válida real de empresa_a.
    await db["attendance"].insert_one({
        "attendance_id": "att_tenant_a",
        "client_id": "empresa_a",
        "talk_id": talk_id,
        "source": "qr",
        "attended_user_ids": [
            "worker_a",
        ],
        "attendees": [
            "Ana Prueba",
        ],
    })

    # Registro QR malformado perteneciente a empresa_b.
    # Si faltara el filtro por client_id, worker_a2
    # podría considerarse asistente.
    await db["attendance"].insert_one({
        "attendance_id": "att_tenant_b_qr",
        "client_id": "empresa_b",
        "talk_id": talk_id,
        "source": "qr",
        "attended_user_ids": [
            "worker_a2",
        ],
        "attendees": [
            "Luis Prueba",
        ],
    })

    # Registro manual de empresa_b con el nombre exacto
    # de un trabajador esperado de empresa_a.
    await db["attendance"].insert_one({
        "attendance_id": "att_tenant_b_manual",
        "client_id": "empresa_b",
        "talk_id": talk_id,
        "attendees": [
            "Luis Prueba",
        ],
    })


@pytest.mark.asyncio
async def test_expected_workers_do_not_expose_other_tenant_worker(
    api,
    db,
    auth_headers,
    seed,
):
    await db["talks"].insert_one({
        "talk_id": "talk_tenant_workers",
        "client_id": "empresa_a",
        "title": "Charla tenant A",
        "month": "9",
        "year": "2026",
        "mandatory": True,
        "expected_user_ids": [
            "worker_a",
            "worker_b",
        ],
    })

    response = await api.get(
        "/v1/talks/talk_tenant_workers/expected-workers",
        headers=auth_headers(
            user_id="admin_a",
            client_id="empresa_a",
            role="admin",
        ),
    )

    assert response.status_code == 200

    data = response.json()

    assert [
        worker["user_id"]
        for worker in data["workers"]
    ] == [
        "worker_a",
    ]

    assert data["missing_user_ids"] == [
        "worker_b",
    ]

    assert all(
        worker["user_id"] != "worker_b"
        for worker in data["workers"]
    )


@pytest.mark.asyncio
async def test_other_tenant_cannot_access_talk_absence_data(
    api,
    db,
    auth_headers,
    seed,
):
    await _create_tenant_a_talk(
        db,
        "talk_private_a",
    )

    headers_b = auth_headers(
        user_id="admin_b",
        client_id="empresa_b",
        role="admin",
    )

    expected_response = await api.get(
        "/v1/talks/talk_private_a/expected-workers",
        headers=headers_b,
    )

    comparison_response = await api.get(
        "/v1/talks/talk_private_a/attendance-comparison",
        headers=headers_b,
    )

    absent_response = await api.get(
        "/v1/talks/talk_private_a/absent-workers",
        headers=headers_b,
    )

    assert expected_response.status_code == 404
    assert comparison_response.status_code == 404
    assert absent_response.status_code == 404


@pytest.mark.asyncio
async def test_attendance_comparison_ignores_other_tenant_records(
    api,
    db,
    auth_headers,
    seed,
):
    talk_id = "talk_tenant_comparison"

    await _create_tenant_a_talk(
        db,
        talk_id,
    )

    await _create_cross_tenant_attendance(
        db,
        talk_id,
    )

    response = await api.get(
        (
            "/v1/talks/"
            f"{talk_id}/"
            "attendance-comparison"
        ),
        headers=auth_headers(
            user_id="admin_a",
            client_id="empresa_a",
            role="admin",
        ),
    )

    assert response.status_code == 200

    data = response.json()

    assert data["expected_user_ids"] == [
        "worker_a",
        "worker_a2",
    ]

    assert data["attended_user_ids"] == [
        "worker_a",
    ]

    assert "worker_a2" not in data[
        "attended_user_ids"
    ]


@pytest.mark.asyncio
async def test_absent_workers_ignore_other_tenant_records(
    api,
    db,
    auth_headers,
    seed,
):
    talk_id = "talk_tenant_absent"

    await _create_tenant_a_talk(
        db,
        talk_id,
    )

    await _create_cross_tenant_attendance(
        db,
        talk_id,
    )

    response = await api.get(
        (
            "/v1/talks/"
            f"{talk_id}/"
            "absent-workers"
        ),
        headers=auth_headers(
            user_id="admin_a",
            client_id="empresa_a",
            role="admin",
        ),
    )

    assert response.status_code == 200

    data = response.json()

    assert data["attended_user_ids"] == [
        "worker_a",
    ]

    assert data["absent_user_ids"] == [
        "worker_a2",
    ]

    assert [
        worker["user_id"]
        for worker in data["absent_workers"]
    ] == [
        "worker_a2",
    ]

    assert data["absence_status"] == (
        "absences_found"
    )
