import { authenticatedFetch } from '../api/client';
import { useState, useEffect } from 'react';
import { Clock, CheckCircle, AlertTriangle, ChevronRight } from 'lucide-react';
import type { Report } from '../api/reports';
import {
  formatReportDate,
  getReportDisplayId,
  getReportEvidenceUrl,
} from '../utils/reportPresentation';

const STATUS_MAP: Record<string, { label: string; color: string }> = {
  sent: { label: 'Enviado', color: '#00C2DB' },
  open: { label: 'Abierto', color: '#3b82f6' },
  reviewing: { label: 'En Revisión', color: '#E8941A' },
  assigned: { label: 'Asignado', color: '#1A5276' },
  en_proceso: { label: 'En Proceso', color: '#E8941A' },
  pending_closure: { label: 'Pendiente de cierre', color: '#8b5cf6' },
  closed: { label: 'Cerrado', color: '#16A34A' },
};

export default function MyIncidents({ userId, reportsApi }: { userId: string; reportsApi: string }) {
  const [reports, setReports] = useState<Report[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<Report | null>(null);

  useEffect(() => {
    const fetchReports = async () => {
      try {
        const res = await authenticatedFetch(
          reportsApi + '/v1/reports',
        );
        if (!res.ok) throw new Error('Error ' + res.status);
        const data = await res.json();
        const mine = data.filter((r: Report) => r.reported_by === userId);
        mine.sort((a: Report, b: Report) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
        setReports(mine);
      } catch (err) {
        console.error(err);
      }
      setLoading(false);
    };
    fetchReports();
  }, [userId, reportsApi]);

  if (loading) return <div className="p-6 text-center themed-text-secondary">Cargando...</div>;

  if (selected) {
    const st = STATUS_MAP[selected.status] || STATUS_MAP.open;
    return (
      <div className="p-4 space-y-4">
        <button onClick={() => setSelected(null)} className="text-sm text-primary">Volver</button>
        <div className="themed-card border rounded-2xl p-5">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold text-lg">#{getReportDisplayId(selected)}</h3>
            <span className="text-xs px-3 py-1 rounded-full font-medium" style={{ background: st.color + '20', color: st.color }}>{st.label}</span>
          </div>
          <p className="text-sm themed-text-secondary mb-1"><strong>Area:</strong> {selected.area_id}</p>
          <p className="text-sm themed-text-secondary mb-1"><strong>Tipo:</strong> {selected.type}</p>
          <p className="text-sm themed-text-secondary mb-1"><strong>Fecha:</strong> {formatReportDate(selected.created_at)}</p>
          {selected.is_iap && <p className="text-sm text-red-400 font-medium mt-2">Alto Potencial (IAP)</p>}
          <p className="text-sm mt-3">{selected.description}</p>
          {getReportEvidenceUrl(selected) && (
            <div className="w-full h-48 themed-photo-placeholder rounded-xl mt-3 overflow-hidden flex items-center justify-center text-5xl">
              <img
                src={getReportEvidenceUrl(selected) || ''}
                alt="Evidencia"
                className="w-full h-full object-cover"
                onError={(e) => {
                  e.currentTarget.style.display = 'none';
                  const parent = e.currentTarget.parentElement;
                  if (parent) parent.textContent = '📸';
                }}
              />
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 space-y-3">
      <h2 className="text-xl font-bold mb-2">Mis Reportes</h2>
      {reports.length === 0 ? (
        <p className="text-center themed-text-secondary py-8">No has creado reportes aun</p>
      ) : (
        reports.map(r => {
          const st = STATUS_MAP[r.status] || STATUS_MAP.open;
          return (
            <button key={r.report_id} onClick={() => setSelected(r)}
              className="w-full themed-card border rounded-xl p-4 text-left flex items-center gap-3">
              <div className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0"
                style={{ background: st.color + '20' }}>
                {r.status === 'closed' ? <CheckCircle size={20} style={{ color: st.color }} /> :
                 r.status === 'en_proceso' ? <Clock size={20} style={{ color: st.color }} /> :
                 <AlertTriangle size={20} style={{ color: st.color }} />}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-medium truncate">{r.description?.slice(0, 40) || 'Sin descripcion'}</p>
                  <span className="text-xs px-2 py-0.5 rounded-full ml-2 flex-shrink-0" style={{ background: st.color + '20', color: st.color }}>{st.label}</span>
                </div>
                <p className="text-xs themed-text-secondary mt-0.5">{r.area_id} - {formatReportDate(r.created_at)}</p>
              </div>
              <ChevronRight size={16} className="themed-text-secondary flex-shrink-0" />
            </button>
          );
        })
      )}
    </div>
  );
}
