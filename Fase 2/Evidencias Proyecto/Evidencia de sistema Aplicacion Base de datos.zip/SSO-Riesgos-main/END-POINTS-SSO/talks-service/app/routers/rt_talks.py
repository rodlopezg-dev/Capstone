import os
import base64
import logging
import secrets
from datetime import datetime, timedelta, timezone
import jwt
import qrcode
from qrcode.image.svg import SvgPathFillImage
from fastapi import APIRouter, Depends, Security, HTTPException, UploadFile, File, Form, Request
from fastapi.responses import Response, StreamingResponse
from fastapi.security import HTTPAuthorizationCredentials
from pydantic import BaseModel, Field
from pymongo.errors import DuplicateKeyError
from ..dep_talks import (
    QR_SIGNING_ALGORITHM,
    QR_SIGNING_SECRET,
    QR_TTL_MINUTES,
    get_db,
    get_current_user,
    security,
)
from ..blob_storage import (
    BlobStorageConfigurationError,
    delete_blob,
    open_blob_stream,
    sanitize_filename,
    upload_attachment,
    upload_attendance_scan,
)
from ..repositories.rep_talks import (
    InvalidAttendanceImage,
    TalksRepository,
)
from ..attendance_export import (
    build_attendance_pdf,
    build_attendance_xlsx,
)

logger = logging.getLogger(__name__)

router = APIRouter()


def _require_open_talk(talk):
    if talk.get("status") == "finished":
        raise HTTPException(409, "La charla está finalizada y no admite nuevos registros.")


def _talk_created_date(talk, fallback_date: str) -> str:
    """La asistencia conserva la fecha original de la charla asociada."""
    created_at = str(talk.get("created_at") or "")
    return created_at[:10] if len(created_at) >= 10 else fallback_date


@router.post("/v1/talks/{talk_id}/finish")
async def finish_talk(talk_id: str, db=Depends(get_db), credentials=Security(security)):
    user = get_current_user(credentials)
    if _normalize_role(user.get("role")) not in {"admin", "supervisor", "jefe de area", "sso manager"}:
        raise HTTPException(403, "No tienes permisos para finalizar la charla.")
    repo = TalksRepository(db)
    existing_talk = await repo.get_talk(user["client_id"], talk_id)
    if existing_talk is None:
        raise HTTPException(404, "Charla no encontrada.")
    member = await db.users.find_one({"client_id": user["client_id"], "user_id": user["user_id"], "status": "active"})
    if member is None:
        raise HTTPException(403, "El usuario no está habilitado para esta empresa.")
    if existing_talk.get("status") == "finished":
        return {
            "talk_id": talk_id,
            "status": existing_talk["status"],
            "finished_at": existing_talk.get("finished_at"),
            "finished_by": existing_talk.get("finished_by"),
            "closure_summary": existing_talk.get("closure_summary"),
        }
    if not await repo.talk_has_registered_people(user["client_id"], talk_id):
        raise HTTPException(409, "No se puede finalizar la charla: aún no hay participantes con asistencia registrada.")
    talk = await repo.finish_talk(user["client_id"], talk_id, user["user_id"])
    return {
        "talk_id": talk_id,
        "status": talk["status"],
        "finished_at": talk["finished_at"],
        "finished_by": talk.get("finished_by"),
        "closure_summary": talk.get("closure_summary"),
    }

OCR_ALLOWED_ROLES = {
    "admin",
    "sso manager",
}
ADMIN_ROLES = OCR_ALLOWED_ROLES
WORKER_ROLES = {"worker", "usuario"}
OCR_CONTENT_TYPES = {
    "image/jpeg",
    "image/png",
    "image/webp",
}
MAX_OCR_IMAGE_BYTES = 10 * 1024 * 1024
MAX_ATTACHMENT_BYTES = 10 * 1024 * 1024


def _normalize_role(value: str) -> str:
    return (
        (value or "")
        .lower()
        .replace("_", " ")
        .strip()
    )


def _require_administrator(user: dict) -> None:
    # Las charlas no tienen un área de autorización persistida: un supervisor
    # no puede recibir acceso global solo por su rol o áreas en el JWT.
    if _normalize_role(user["role"]) not in ADMIN_ROLES:
        raise HTTPException(403, "Ámbito o rol insuficiente.")


def _require_talk_reader(user: dict) -> None:
    if _normalize_role(user["role"]) not in ADMIN_ROLES | WORKER_ROLES:
        raise HTTPException(403, "Ámbito o rol insuficiente.")


UPLOAD_DIR = "/tmp/talks_uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

def _attachment_size(file: UploadFile) -> int:
    if file.size is not None:
        return int(file.size)

    position = file.file.tell()
    file.file.seek(0, 2)
    size = file.file.tell()
    file.file.seek(position)

    return int(size)


async def _store_attachment(
    file: UploadFile,
    *,
    client_id: str,
    category: str,
) -> dict:
    size = _attachment_size(file)

    if size <= 0:
        raise HTTPException(
            422,
            "El archivo está vacío.",
        )

    if size > MAX_ATTACHMENT_BYTES:
        raise HTTPException(
            413,
            "El archivo excede el límite de 10 MB.",
        )

    file_name = sanitize_filename(
        file.filename
    )
    content_type = (
        file.content_type
        or "application/octet-stream"
    )

    await file.seek(0)

    try:
        storage_ref = await upload_attachment(
            client_id=client_id,
            category=category,
            file_name=file_name,
            content_type=content_type,
            stream=file.file,
        )
    except BlobStorageConfigurationError as exc:
        raise HTTPException(
            503,
            "El almacenamiento de archivos no está disponible.",
        ) from exc
    except Exception as exc:
        logger.exception(
            "Falló la carga del archivo a Blob Storage."
        )
        raise HTTPException(
            503,
            "El almacenamiento de archivos no está disponible.",
        ) from exc

    return {
        "file_id": secrets.token_urlsafe(24),
        "file_url": "",
        "file_name": file_name,
        "file_content_type": content_type,
        "file_size": size,
        "file_storage": storage_ref,
    }


def _empty_attachment() -> dict:
    return {
        "file_id": "",
        "file_url": "",
        "file_name": "",
        "file_content_type": "",
        "file_size": 0,
        "file_storage": None,
    }


async def _cleanup_storage(
    storage_ref,
) -> None:
    if not storage_ref:
        return

    try:
        await delete_blob(storage_ref)
    except Exception:
        logger.exception(
            "No se pudo limpiar un archivo de Blob Storage."
        )


async def _attachment_response(record):
    file_name = sanitize_filename(
        record.get("file_name")
    )

    content_type = (
        record.get("file_content_type")
        or "application/octet-stream"
    )

    headers = {
        "Content-Disposition": (
            f'attachment; filename="{file_name}"'
        )
    }

    storage_ref = record.get(
        "file_storage"
    )

    if storage_ref:
        try:
            stream = await open_blob_stream(
                storage_ref
            )
        except BlobStorageConfigurationError as exc:
            raise HTTPException(
                503,
                "El almacenamiento de archivos no está disponible.",
            ) from exc
        except Exception as exc:
            logger.exception(
                "No se pudo descargar el archivo desde Blob Storage."
            )
            raise HTTPException(
                404,
                "Archivo no disponible.",
            ) from exc

        return StreamingResponse(
            stream,
            media_type=content_type,
            headers=headers,
        )

    file_url = record.get(
        "file_url",
        "",
    )

    if (
        isinstance(file_url, str)
        and file_url.startswith("data:")
        and "," in file_url
    ):
        header, encoded = file_url.split(
            ",",
            1,
        )

        legacy_type = (
            header[5:].split(";", 1)[0]
            or content_type
        )

        try:
            content = base64.b64decode(
                encoded
            )
        except Exception as exc:
            raise HTTPException(
                404,
                "Archivo no disponible.",
            ) from exc

        return Response(
            content=content,
            media_type=legacy_type,
            headers=headers,
        )

    raise HTTPException(
        404,
        "No hay archivo adjunto.",
    )

def _parse_expected_user_ids(
    raw_value: str,
) -> list[str]:
    return list(
        dict.fromkeys(
            user_id.strip()
            for user_id in (raw_value or "").split(",")
            if user_id.strip()
        )
    )


async def _validate_expected_user_ids(
    repo: TalksRepository,
    client_id: str,
    user_ids: list[str],
) -> list[str]:
    if not user_ids:
        return []

    workers = await repo.get_workers_by_ids(
        client_id,
        user_ids,
        active_only=True,
    )

    valid_ids = {
        worker["user_id"]
        for worker in workers
    }

    if any(
        user_id not in valid_ids
        for user_id in user_ids
    ):
        raise HTTPException(
            422,
            (
                "Uno o más trabajadores esperados "
                "no son trabajadores activos de esta empresa."
            ),
        )

    return user_ids


# ── TALKS ──
@router.get("/v1/talks")
async def list_talks(
    month: str = "", year: str = "",
    db=Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security),
):
    user = get_current_user(credentials)
    _require_talk_reader(user)
    repo = TalksRepository(db)
    talks = await repo.list_talks(user["client_id"], month or None, year or None)
    if _normalize_role(user["role"]) not in ADMIN_ROLES:
        # La lista pública alimenta el flujo QR móvil; los IDs esperados son
        # población nominativa y se reservan a gestión autorizada.
        return [{key: value for key, value in talk.items()
                 if key != "expected_user_ids"} for talk in talks]
    return talks

@router.post("/v1/talks")
async def create_talk(
    title: str = Form(...),
    month: str = Form(...),
    year: str = Form(...),
    mandatory: bool = Form(False),
    expected_user_ids: str = Form(""),
    file: UploadFile = File(None),
    db=Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security),
):
    user = get_current_user(credentials)
    _require_administrator(user)
    repo = TalksRepository(db)

    title = title.strip()
    if not title or len(title) > 200:
        raise HTTPException(422, "El título debe tener entre 1 y 200 caracteres.")

    if not month.isdigit() or not 1 <= int(month) <= 12 or not year.isdigit():
        raise HTTPException(422, "Mes o año inválido.")

    parsed_expected_user_ids = (
        _parse_expected_user_ids(
            expected_user_ids
        )
    )

    parsed_expected_user_ids = (
        await _validate_expected_user_ids(
            repo,
            user["client_id"],
            parsed_expected_user_ids,
        )
    )

    attachment = _empty_attachment()

    if file:
        attachment = await _store_attachment(
            file,
            client_id=user["client_id"],
            category="talks",
        )

    try:
        talk_id = await repo.create_talk(
            user["client_id"],
            {
                "title": title,
                "month": month,
                "year": year,
                "mandatory": mandatory,
                "expected_user_ids": (
                    parsed_expected_user_ids
                ),
                **attachment,
            },
        )
    except Exception:
        await _cleanup_storage(
            attachment.get("file_storage")
        )
        raise
    return {"ok": True, "talk_id": talk_id}



@router.patch("/v1/talks/{talk_id}")
async def update_talk(
    talk_id: str,
    title: str | None = Form(None),
    month: str | None = Form(None),
    year: str | None = Form(None),
    mandatory: bool | None = Form(None),
    expected_user_ids: str | None = Form(None),
    file: UploadFile | None = File(None),
    remove_file: bool = Form(False),
    db=Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security),
):
    user = get_current_user(credentials)
    _require_administrator(user)
    repo = TalksRepository(db)

    current = await repo.get_talk(user["client_id"], talk_id)
    if current is None:
        raise HTTPException(404, "Charla no encontrada.")

    _require_open_talk(current)

    if await repo.talk_has_attendance(user["client_id"], talk_id):
        raise HTTPException(
            409,
            "La charla ya tiene asistencia registrada y no puede modificarse ni eliminarse.",
        )

    changes = {}

    if title is not None:
        title = title.strip()
        if not title or len(title) > 200:
            raise HTTPException(422, "El título debe tener entre 1 y 200 caracteres.")
        changes["title"] = title

    if month is not None:
        if not month.isdigit() or not 1 <= int(month) <= 12:
            raise HTTPException(422, "Mes inválido.")
        changes["month"] = month

    if year is not None:
        if not year.isdigit():
            raise HTTPException(422, "Año inválido.")
        changes["year"] = year

    if mandatory is not None:
        changes["mandatory"] = mandatory

    if expected_user_ids is not None:
        parsed_expected_user_ids = (
            _parse_expected_user_ids(
                expected_user_ids
            )
        )

        changes["expected_user_ids"] = (
            await _validate_expected_user_ids(
                repo,
                user["client_id"],
                parsed_expected_user_ids,
            )
        )

    if remove_file and file is not None:
        raise HTTPException(
            422,
            "No se puede eliminar y reemplazar el archivo a la vez.",
        )

    new_attachment = None

    if remove_file:
        changes.update(
            _empty_attachment()
        )

    if file:
        new_attachment = await _store_attachment(
            file,
            client_id=user["client_id"],
            category="talks",
        )
        changes.update(
            new_attachment
        )

    if not changes:
        raise HTTPException(
            422,
            "No se enviaron cambios.",
        )

    try:
        updated = await repo.update_talk(
            user["client_id"],
            talk_id,
            changes,
        )
    except Exception:
        if new_attachment:
            await _cleanup_storage(
                new_attachment.get(
                    "file_storage"
                )
            )
        raise

    if not updated:
        if new_attachment:
            await _cleanup_storage(
                new_attachment.get(
                    "file_storage"
                )
            )
        raise HTTPException(
            404,
            "Charla no encontrada.",
        )

    if remove_file or new_attachment:
        await _cleanup_storage(
            current.get("file_storage")
        )

    return {"ok": True, "talk_id": talk_id}





@router.delete("/v1/talks/{talk_id}")
async def delete_talk(
    talk_id: str,
    db=Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security),
):
    user = get_current_user(credentials)
    _require_administrator(user)
    repo = TalksRepository(db)

    current = await repo.get_talk(user["client_id"], talk_id)
    if current is not None:
        _require_open_talk(current)

    if await repo.talk_has_attendance(user["client_id"], talk_id):
        raise HTTPException(
            409,
            "La charla ya tiene asistencia registrada y no puede modificarse ni eliminarse.",
        )

    deleted = await repo.delete_talk(
        user["client_id"],
        talk_id,
    )

    if not deleted:
        raise HTTPException(
            404,
            "Charla no encontrada",
        )

    await _cleanup_storage(
        deleted.get("file_storage")
    )

    return {"ok": True}

@router.get(
    "/v1/talks/{talk_id}/expected-workers"
)
async def get_expected_workers(
    talk_id: str,
    db=Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security),
):
    user = get_current_user(credentials)
    _require_administrator(user)

    if not user.get("client_id"):
        raise HTTPException(
            403,
            "Empresa no válida.",
        )

    repo = TalksRepository(db)

    result = await repo.expected_workers_for_talk(
        user["client_id"],
        talk_id,
    )

    if result is None:
        raise HTTPException(
            404,
            "Charla no encontrada.",
        )

    return result


@router.get(
    "/v1/talks/{talk_id}/attendance-comparison"
)
async def get_attendance_comparison(
    talk_id: str,
    db=Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security),
):
    user = get_current_user(credentials)
    _require_administrator(user)

    if not user.get("client_id"):
        raise HTTPException(
            403,
            "Empresa no válida.",
        )

    repo = TalksRepository(db)

    result = (
        await repo.attendance_comparison_for_talk(
            user["client_id"],
            talk_id,
        )
    )

    if result is None:
        raise HTTPException(
            404,
            "Charla no encontrada.",
        )

    return result


@router.get(
    "/v1/talks/{talk_id}/absent-workers"
)
async def get_absent_workers(
    talk_id: str,
    db=Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security),
):
    user = get_current_user(credentials)
    _require_administrator(user)

    if not user.get("client_id"):
        raise HTTPException(
            403,
            "Empresa no válida.",
        )

    repo = TalksRepository(db)

    result = await repo.absent_workers_for_talk(
        user["client_id"],
        talk_id,
    )

    if result is None:
        raise HTTPException(
            404,
            "Charla no encontrada.",
        )

    return result


@router.get("/v1/talks/{talk_id}/file")
async def download_talk_file(
    talk_id: str,
    db=Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security),
):
    user = get_current_user(credentials)
    _require_talk_reader(user)
    repo = TalksRepository(db)

    talk = await repo.get_talk(
        user["client_id"],
        talk_id,
    )

    if talk is None:
        raise HTTPException(
            404,
            "Charla no encontrada.",
        )

    return await _attachment_response(
        talk
    )


@router.get("/v1/attendance/{attendance_id}/file")
async def download_attendance_file(
    attendance_id: str,
    db=Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security),
):
    user = get_current_user(credentials)
    _require_administrator(user)
    repo = TalksRepository(db)

    attendance = await repo.get_attendance(
        user["client_id"],
        attendance_id,
    )

    if attendance is None:
        raise HTTPException(
            404,
            "Registro de asistencia no encontrado.",
        )

    return await _attachment_response(
        attendance
    )


# --- INICIO: VALIDACION DE ASISTENCIA MEDIANTE QR ---
class QrAttendanceRequest(BaseModel):
    payload: str = Field(min_length=1, max_length=4096)
    talk_id: str | None = None

@router.post("/v1/attendance/scan")
async def register_qr_attendance(
    payload: QrAttendanceRequest,
    db=Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security),
):
    user = get_current_user(credentials)
    _require_talk_reader(user)
    try:
        qr_data = jwt.decode(
            payload.payload,
            QR_SIGNING_SECRET,
            algorithms=[QR_SIGNING_ALGORITHM],
            options={"require": ["exp", "iat", "jti"]},
        )
    except jwt.ExpiredSignatureError as exc:
        raise HTTPException(410, "El código QR expiró. Solicita uno nuevo.") from exc
    except jwt.PyJWTError as exc:
        raise HTTPException(400, "El código QR no es válido.") from exc

    if not isinstance(qr_data, dict) or qr_data.get("type") != "sso-talk-attendance" or qr_data.get("version") != 2:
        raise HTTPException(400, "El código QR no corresponde a una charla de seguridad.")
    if qr_data.get("client_id") != user.get("client_id"):
        raise HTTPException(403, "El código QR pertenece a otra empresa.")
    if not isinstance(qr_data.get("talk_id"), str) or not qr_data["talk_id"]:
        raise HTTPException(400, "El código QR no contiene una charla válida.")
    if payload.talk_id is not None and payload.talk_id != qr_data["talk_id"]:
        raise HTTPException(400, "El código QR no corresponde a la charla seleccionada.")

    now = datetime.now(timezone.utc)
    repo = TalksRepository(db)
    session = await repo.get_active_qr_session(
        user["client_id"],
        qr_data["talk_id"],
        qr_data["jti"],
        now,
    )
    if session is None:
        raise HTTPException(410, "El código QR expiró o fue invalidado.")

    # La identidad y el nombre se obtienen del usuario autenticado, nunca del QR.
    member = await db["users"].find_one({
        "user_id": user.get("user_id"), "client_id": user.get("client_id"), "status": "active",
    })
    if not user.get("user_id") or not user.get("client_id") or member is None:
        raise HTTPException(403, "El usuario no está habilitado para esta empresa.")

    talk = await repo.get_talk(user["client_id"], qr_data.get("talk_id", ""))
    if talk is None:
        raise HTTPException(404, "La charla asociada al código QR no existe.")

    _require_open_talk(talk)

    attendee_name = " ".join(filter(None, [member.get("name"), member.get("last_name")])).strip() or user["user_id"]
    registered = await repo.register_qr_attendance(user["client_id"], talk, user["user_id"], attendee_name)
    return {
        "ok": True,
        "registered": registered,
        "message": "Asistencia registrada correctamente." if registered else "Tu asistencia ya estaba registrada.",
    }
# --- FIN: VALIDACION DE ASISTENCIA MEDIANTE QR ---

# ── ATTENDANCE ──
@router.get("/v1/talks/{talk_id}/qr")
async def view_talk_qr(
    talk_id: str,
    db=Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security),
):
    user = get_current_user(credentials)
    _require_administrator(user)
    if not user.get("client_id"):
        raise HTTPException(403, "Empresa no válida.")
    talk = await TalksRepository(db).get_talk(user["client_id"], talk_id)
    if talk is None:
        raise HTTPException(404, "Charla no encontrada.")
    _require_open_talk(talk)
    now = datetime.now(timezone.utc)
    expires_at = now + timedelta(minutes=QR_TTL_MINUTES)
    jti = secrets.token_urlsafe(32)
    repo = TalksRepository(db)
    await repo.create_qr_session(
        user["client_id"],
        talk_id,
        jti,
        user.get("user_id", ""),
        expires_at,
    )
    signed_payload = jwt.encode({
        "type": "sso-talk-attendance",
        "version": 2,
        "client_id": user["client_id"],
        "talk_id": talk_id,
        "jti": jti,
        "iat": now,
        "exp": expires_at,
    }, QR_SIGNING_SECRET, algorithm=QR_SIGNING_ALGORITHM)
    image = qrcode.make(signed_payload, image_factory=SvgPathFillImage, border=4)
    encoded = base64.b64encode(image.to_string()).decode("ascii")
    return {
        "talk_id": talk_id,
        "title": talk["title"],
        "image": "data:image/svg+xml;base64," + encoded,
        "expires_at": expires_at.isoformat(),
    }


@router.get("/v1/attendance/export/pdf")
async def export_attendance_pdf(
    month: str = "",
    year: str = "",
    db=Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security),
):
    user = get_current_user(credentials)
    _require_administrator(user)

    if not user.get("client_id"):
        raise HTTPException(
            403,
            "Empresa no válida.",
        )

    selected_month = month.strip()
    selected_year = year.strip()

    if selected_month:
        if (
            not selected_month.isdigit()
            or not 1 <= int(selected_month) <= 12
        ):
            raise HTTPException(
                422,
                "Mes inválido.",
            )

        selected_month = str(
            int(selected_month)
        )

    if (
        selected_year
        and not selected_year.isdigit()
    ):
        raise HTTPException(
            422,
            "Año inválido.",
        )

    repo = TalksRepository(db)

    records = await repo.list_attendance_for_export(
        user["client_id"],
        month=selected_month or None,
        year=selected_year or None,
    )

    if not records:
        raise HTTPException(
            404,
            "No hay registros de asistencia para el período seleccionado.",
        )

    try:
        content = build_attendance_pdf(
            records,
            month=selected_month or None,
            year=selected_year or None,
        )
    except Exception as exc:
        logger.exception(
            "Error generando exportación PDF de asistencia "
            "client_id=%s month=%s year=%s",
            user["client_id"],
            selected_month or "-",
            selected_year or "-",
        )

        raise HTTPException(
            500,
            "No fue posible generar la exportación PDF.",
        ) from exc

    filename_parts = [
        "asistencia",
    ]

    if selected_year:
        filename_parts.append(
            selected_year
        )

    if selected_month:
        filename_parts.append(
            f"{int(selected_month):02d}"
        )

    filename = "_".join(
        filename_parts
    ) + ".pdf"

    return Response(
        content=content,
        media_type="application/pdf",
        headers={
            "Content-Disposition": (
                f'attachment; filename="{filename}"'
            ),
        },
    )


@router.get("/v1/attendance/export/xlsx")
async def export_attendance_xlsx(
    month: str = "",
    year: str = "",
    db=Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security),
):
    user = get_current_user(credentials)
    _require_administrator(user)

    if not user.get("client_id"):
        raise HTTPException(
            403,
            "Empresa no válida.",
        )

    selected_month = month.strip()
    selected_year = year.strip()

    if selected_month:
        if (
            not selected_month.isdigit()
            or not 1 <= int(selected_month) <= 12
        ):
            raise HTTPException(
                422,
                "Mes inválido.",
            )

        selected_month = str(
            int(selected_month)
        )

    if (
        selected_year
        and not selected_year.isdigit()
    ):
        raise HTTPException(
            422,
            "Año inválido.",
        )

    repo = TalksRepository(db)

    records = await repo.list_attendance_for_export(
        user["client_id"],
        month=selected_month or None,
        year=selected_year or None,
    )

    if not records:
        raise HTTPException(
            404,
            "No hay registros de asistencia para el período seleccionado.",
        )

    try:
        content = build_attendance_xlsx(
            records,
            month=selected_month or None,
            year=selected_year or None,
        )
    except Exception as exc:
        logger.exception(
            "Error generando exportación Excel de asistencia "
            "client_id=%s month=%s year=%s",
            user["client_id"],
            selected_month or "-",
            selected_year or "-",
        )

        raise HTTPException(
            500,
            "No fue posible generar la exportación Excel.",
        ) from exc

    filename_parts = [
        "asistencia",
    ]

    if selected_year:
        filename_parts.append(
            selected_year
        )

    if selected_month:
        filename_parts.append(
            f"{int(selected_month):02d}"
        )

    filename = "_".join(
        filename_parts
    ) + ".xlsx"

    return Response(
        content=content,
        media_type=(
            "application/vnd.openxmlformats-"
            "officedocument.spreadsheetml.sheet"
        ),
        headers={
            "Content-Disposition": (
                f'attachment; filename="{filename}"'
            ),
        },
    )


@router.get("/v1/attendance/stats/areas")
async def attendance_stats_by_area(
    db=Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security),
):
    user = get_current_user(credentials)
    _require_administrator(user)

    if not user.get("client_id"):
        raise HTTPException(
            403,
            "Empresa no válida.",
        )

    repo = TalksRepository(db)
    return await repo.attendance_stats_by_area(
        user["client_id"]
    )


@router.get("/v1/attendance/stats/months")
async def attendance_stats_by_month(
    year: str = "",
    db=Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security),
):
    user = get_current_user(credentials)
    _require_administrator(user)

    if not user.get("client_id"):
        raise HTTPException(
            403,
            "Empresa no válida.",
        )

    selected_year = year.strip()

    if (
        selected_year
        and not selected_year.isdigit()
    ):
        raise HTTPException(
            422,
            "Año inválido.",
        )

    repo = TalksRepository(db)

    return await repo.attendance_stats_by_month(
        user["client_id"],
        selected_year or None,
    )


@router.get("/v1/attendance")
async def list_attendance(
    talk_id: str = "",
    db=Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security),
):
    user = get_current_user(credentials)
    repo = TalksRepository(db)
    if _normalize_role(user["role"]) in WORKER_ROLES:
        return await repo.list_own_attendance(user["client_id"], user["user_id"], talk_id or None)
    _require_administrator(user)
    records = await repo.list_attendance(user["client_id"], talk_id or None)
    return records

@router.post("/v1/attendance")
async def create_attendance(
    request: Request,
    topic: str = Form(...),
    date: str = Form(...),
    area: str = Form(""),
    talk_id: str | None = Form(None),
    attendees: str = Form(""),
    attendee_user_ids: str = Form(""),
    feedback: str = Form(""),
    file: UploadFile = File(None),
    db=Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security),
):
    user = get_current_user(credentials)
    _require_administrator(user)

    # Form(None) convierte un campo enviado como "" en None; los formularios
    # legacy omiten talk_id, mientras que un campo explícito debe ser válido.
    submitted_form = await request.form()
    if "talk_id" in submitted_form and talk_id is None:
        raise HTTPException(422, "La charla no es válida.")
    if talk_id is not None and not talk_id.strip():
        raise HTTPException(422, "La charla no es válida.")
    talk_id = talk_id.strip() if talk_id is not None else ""
    repo = TalksRepository(db)

    if talk_id:
        related_talk = await repo.get_talk(user["client_id"], talk_id)
        if related_talk is None:
            # Mismo resultado para charla inexistente o de otro tenant.
            raise HTTPException(404, "Charla no encontrada.")
        _require_open_talk(related_talk)
        date = _talk_created_date(related_talk, date)

    attachment = _empty_attachment()

    if file:
        if not talk_id:
            raise HTTPException(
                422,
                "La hoja de asistencia debe estar asociada a una charla.",
            )

        if await repo.talk_has_attendance_file(
            user["client_id"],
            talk_id,
        ):
            raise HTTPException(
                409,
                "Esta charla ya tiene una hoja de asistencia adjunta.",
            )

    if file:
        attachment = await _store_attachment(
            file,
            client_id=user["client_id"],
            category="attendance",
        )

    att_list = (
        [a.strip() for a in attendees.split(",") if a.strip()]
        if attendees
        else []
    )
    attendee_ids = (
        [user_id.strip() for user_id in attendee_user_ids.split(",")]
        if attendee_user_ids
        else []
    )

    if attendee_ids and len(attendee_ids) != len(att_list):
        raise HTTPException(
            422,
            "La identidad de cada asistente debe coincidir con el listado enviado.",
        )

    if attendee_ids:
        active_users = await db.users.count_documents(
            {
                "client_id": user["client_id"],
                "user_id": {"$in": attendee_ids},
                "status": "active",
            }
        )
        if active_users != len(set(attendee_ids)):
            raise HTTPException(
                422,
                "Uno o más asistentes no están activos en esta empresa.",
            )

    accepted_indexes = []
    already_registered_names = []
    if talk_id and attendee_ids:
        for index, (attendee_name, attendee_id) in enumerate(
            zip(att_list, attendee_ids)
        ):
            claimed = await repo.claim_attendance_participant(
                user["client_id"],
                talk_id,
                attendee_id,
                attendee_name,
                "manual",
            )
            if claimed:
                accepted_indexes.append(index)
            else:
                already_registered_names.append(attendee_name)

        if not accepted_indexes:
            raise HTTPException(
                409,
                "Los asistentes seleccionados ya registraron su asistencia en esta charla.",
            )

        att_list = [att_list[index] for index in accepted_indexes]
        attendee_ids = [
            attendee_ids[index]
            for index in accepted_indexes
        ]

    try:
        att_id = await repo.create_attendance(
            user["client_id"],
            {
                "talk_id": talk_id,
                "topic": topic,
                "date": date,
                "area": area,
                "attendees": att_list,
                "attendee_user_ids": attendee_ids,
                "feedback": feedback,
                "source": "sheet" if file else "manual",
                **attachment,
            },
        )
    except DuplicateKeyError as exc:
        await _cleanup_storage(attachment.get("file_storage"))
        raise HTTPException(409, "Esta charla ya tiene una hoja de asistencia adjunta.") from exc
    except Exception:
        await _cleanup_storage(
            attachment.get("file_storage")
        )
        raise

    return {
        "ok": True,
        "attendance_id": att_id,
        "already_registered": already_registered_names,
    }

# --- INICIO: OCR DE ASISTENCIA ---
@router.post("/v1/attendance/ocr")
async def process_attendance_ocr(
    talk_id: str = Form(...),
    file: UploadFile = File(...),
    db=Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(security),
):
    user = get_current_user(credentials)

    if _normalize_role(
        user.get("role", "")
    ) not in OCR_ALLOWED_ROLES:
        raise HTTPException(
            403,
            "No tienes permisos para procesar asistencia mediante OCR.",
        )

    if not user.get("client_id"):
        raise HTTPException(
            403,
            "Empresa no válida.",
        )

    if not user.get("user_id"):
        raise HTTPException(
            403,
            "Usuario no válido.",
        )

    member = await db["users"].find_one(
        {
            "user_id": user["user_id"],
            "client_id": user["client_id"],
            "status": "active",
        },
        {
            "_id": 1,
        },
    )

    if member is None:
        raise HTTPException(
            403,
            "El usuario no está habilitado para esta empresa.",
        )

    talk_id = talk_id.strip()
    if not talk_id:
        raise HTTPException(
            422,
            "La charla es obligatoria.",
        )

    repo = TalksRepository(db)

    talk = await repo.get_talk(
        user["client_id"],
        talk_id,
    )
    if talk is None:
        raise HTTPException(
            404,
            "Charla no encontrada.",
        )

    _require_open_talk(talk)
    content_type = (
        file.content_type
        or ""
    ).lower()

    if content_type not in OCR_CONTENT_TYPES:
        raise HTTPException(
            415,
            "Formato de imagen no soportado. Usa JPG, PNG o WEBP.",
        )

    content = await file.read()

    if not content:
        raise HTTPException(
            422,
            "La imagen está vacía.",
        )

    if len(content) > MAX_OCR_IMAGE_BYTES:
        raise HTTPException(
            413,
            "La imagen excede el límite de 10 MB.",
        )

    try:
        extracted_attendees = (
            await repo.extract_names_from_image(
                user["client_id"],
                content,
            )
        )
    except InvalidAttendanceImage as exc:
        raise HTTPException(
            422,
            "La imagen no es válida o está dañada.",
        ) from exc
    except Exception as exc:
        logger.exception(
            "Fallo durante el procesamiento OCR."
        )
        raise HTTPException(
            500,
            "No fue posible procesar la imagen de asistencia.",
        ) from exc

    safe_file_name = sanitize_filename(
        file.filename
    )

    try:
        storage_ref = await upload_attendance_scan(
            client_id=user["client_id"],
            talk_id=talk_id,
            content=content,
            content_type=content_type,
        )
    except BlobStorageConfigurationError as exc:
        logger.error(
            "Storage OCR no configurado."
        )
        raise HTTPException(
            503,
            "El almacenamiento de imágenes no está disponible.",
        ) from exc
    except Exception as exc:
        logger.exception(
            "Falló la carga de imagen OCR a Blob Storage."
        )
        raise HTTPException(
            503,
            "El almacenamiento de imágenes no está disponible.",
        ) from exc

    try:
        scan_id = await repo.create_attendance_scan(
            client_id=user["client_id"],
            talk_id=talk_id,
            file_name=safe_file_name,
            content_type=content_type,
            size_bytes=len(content),
            storage_ref=storage_ref,
            extracted_attendees=extracted_attendees,
        )
    except Exception as exc:
        try:
            await delete_blob(storage_ref)
        except Exception:
            logger.exception(
                "No se pudo limpiar el blob OCR tras fallar Mongo."
            )

        logger.exception(
            "No se pudo guardar metadata del scan OCR."
        )
        raise HTTPException(
            500,
            "No fue posible guardar el resultado del OCR.",
        ) from exc

    return {
        "ok": True,
        "scan_id": scan_id,
        "talk_id": talk_id,
        "file_name": safe_file_name,
        "extracted_attendees": extracted_attendees,
        "message": (
            "Imagen procesada correctamente. "
            "Revise y confirme la asistencia detectada."
        ),
    }
# --- FIN: OCR DE ASISTENCIA ---
