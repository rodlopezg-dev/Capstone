# Configuración de Base de Datos - Sistema SSO

Este directorio contiene toda la infraestructura para sincronizar datos entre la **App Móvil** (empleados) y la **Plataforma Web** (supervisores/gerentes).

## 📋 Archivos

- **`types.ts`**: Definiciones TypeScript de todos los modelos de datos
- **`config.ts`**: Configuración de conexión a base de datos
- **`api.ts`**: Servicios para comunicarse con la base de datos
- **`schema.sql`**: Script SQL para crear tablas (PostgreSQL/MySQL)
- **`README.md`**: Este archivo

---

## 🗄️ Opciones de Base de Datos Soportadas

Puedes usar cualquiera de estas opciones:

### Opción 1: Supabase (Recomendado - Fácil Setup)
```bash
npm install @supabase/supabase-js
```

**Configuración en `.env`:**
```
SUPABASE_URL=https://tu-proyecto.supabase.co
SUPABASE_ANON_KEY=tu-clave-anonima
```

### Opción 2: PostgreSQL
```bash
npm install pg
```

**Configuración en `.env`:**
```
DB_HOST=localhost
DB_PORT=5432
DB_NAME=sso_database
DB_USER=postgres
DB_PASSWORD=tu_password
```

### Opción 3: MongoDB
```bash
npm install mongodb
```

**Configuración en `.env`:**
```
MONGODB_URI=mongodb://localhost:27017/sso_database
```

### Opción 4: Firebase
```bash
npm install firebase
```

**Configuración en `.env`:**
```
FIREBASE_API_KEY=...
FIREBASE_AUTH_DOMAIN=...
FIREBASE_PROJECT_ID=...
```

### Opción 5: API REST Personalizada
Si ya tienes un backend, simplemente configura:

**Configuración en `.env`:**
```
API_BASE_URL=https://tu-api.com/api
API_KEY=tu-api-key
```

---

## 🚀 Pasos para Configurar

### 1. Crear archivo `.env`

Crea un archivo `.env` en la raíz del proyecto:

```bash
touch .env
```

### 2. Agregar credenciales

Agrega tus credenciales según la opción que elijas (ver arriba).

### 3. Instalar dependencias

```bash
# Para Supabase
npm install @supabase/supabase-js

# Para PostgreSQL
npm install pg

# Para MongoDB
npm install mongodb

# Para Firebase
npm install firebase
```

### 4. Crear tablas en la base de datos

Si usas SQL (PostgreSQL/MySQL), ejecuta el script `schema.sql`:

```bash
psql -U postgres -d sso_database -f src/database/schema.sql
```

### 5. Descomentar el conector en `config.ts`

En `src/database/config.ts`, descomenta la sección correspondiente a tu base de datos.

---

## 📊 Estructura de Datos

### Tablas Principales

#### 1. `reportes`
Almacena todos los hallazgos reportados desde la app móvil.

**Campos clave:**
- `id`, `fecha`, `area`, `linea`, `proceso`
- `tipo` (acto_inseguro / condicion_insegura)
- `es_iap` (boolean)
- `descripcion`, `evidencia_foto_url`
- `reportador_id`, `reportador_nombre`, `reportador_turno`
- `estado` (enviado / en_revision / accion_asignada / cerrado)
- `responsable_asignado`, `feedback_supervisor`
- `sla_vencido`

#### 2. `zonas`
Define las áreas operativas del Gemelo Digital (W-03).

**Campos clave:**
- `id`, `nombre`, `proceso_asociado`
- `coordenadas` (JSON con polígono)
- `score_riesgo` (0-100)
- `nivel_riesgo` (bajo / medio / alto)
- `plano_base_url`

#### 3. `alertas`
Notificaciones generadas automática o manualmente.

**Campos clave:**
- `id`, `tipo` (iap / sla / zona / auto)
- `titulo`, `descripcion`, `area_afectada`
- `activa`, `resuelta`
- `reporte_id`, `zona_id`

#### 4. `usuarios`
Empleados (app móvil) y supervisores (web).

**Campos clave:**
- `id`, `nombre_completo`, `email`, `rol`
- `turno`, `area_asignada`
- `total_reportes`, `reportes_mes_actual`, `efectividad_porcentaje`

#### 5. `notificaciones`
Notificaciones push para app móvil y campana en web.

**Campos clave:**
- `id`, `tipo` (alerta / actualizacion / comentario / resuelto)
- `titulo`, `mensaje`
- `usuario_id`, `leida`
- `reporte_id`, `alerta_id`

---

## 🔄 Flujo de Sincronización

### Desde App Móvil → Base de Datos

1. Empleado crea reporte en app móvil (M-02)
2. App envía POST a `/api/reportes/crear`
3. Backend:
   - Sube foto a storage (S3, Cloudinary, etc.)
   - Crea registro en tabla `reportes`
   - Si `es_iap = true`, crea alerta en tabla `alertas`
   - Crea notificación para supervisor del área
4. App muestra confirmación (M-03)

### Desde Base de Datos → Plataforma Web

1. Web consulta GET `/api/reportes` (W-02)
2. Muestra tabla de incidentes
3. Supervisor actualiza reporte: PATCH `/api/reportes/:id`
4. Backend:
   - Actualiza registro en tabla `reportes`
   - Crea notificación para el empleado que reportó
5. Empleado ve actualización en app móvil (M-03, M-05)

---

## 🎯 Endpoints Requeridos

Tu backend (o Supabase) debe implementar estos endpoints:

### Reportes
- `GET /api/reportes` - Obtener todos los reportes (con filtros)
- `GET /api/reportes/:id` - Obtener reporte específico
- `POST /api/reportes` - Crear nuevo reporte (desde app móvil)
- `PATCH /api/reportes/:id` - Actualizar reporte (desde web)
- `GET /api/reportes/usuario/:userId` - Reportes de un usuario

### Zonas
- `GET /api/zonas` - Obtener todas las zonas
- `POST /api/zonas` - Crear nueva zona (W-03)
- `PATCH /api/zonas/:id` - Actualizar zona
- `DELETE /api/zonas/:id` - Eliminar zona
- `GET /api/zonas/:id/score-riesgo` - Calcular score de riesgo

### Alertas
- `GET /api/alertas` - Obtener alertas (con filtros)
- `POST /api/alertas` - Crear alerta manual (W-02)
- `POST /api/alertas/:id/resolver` - Marcar alerta resuelta

### Notificaciones
- `GET /api/notificaciones/usuario/:userId` - Notificaciones de usuario
- `POST /api/notificaciones/:id/leer` - Marcar como leída
- `POST /api/notificaciones/usuario/:userId/leer-todas` - Marcar todas leídas

### Estadísticas
- `GET /api/estadisticas/globales` - KPIs globales (W-01)
- `GET /api/estadisticas/ranking-areas` - Top 5 áreas críticas (W-01)
- `GET /api/estadisticas/tendencia` - Gráfico de tendencia (W-01)

### Usuarios
- `POST /api/auth/login` - Autenticación
- `GET /api/usuarios/:id` - Perfil de usuario (M-06)

### Exportación
- `GET /api/reportes/exportar` - Generar PDF/Excel/CSV (W-05)

---

## 🔐 Seguridad

### Autenticación
Implementa autenticación basada en JWT o sesiones:

```typescript
// Ejemplo con JWT
headers: {
  'Authorization': 'Bearer <token>'
}
```

### Validación de Datos
Valida todos los datos del lado del servidor antes de guardar en BD.

### Protección de Archivos
Las fotos de evidencia deben almacenarse en storage privado con URLs firmadas.

---

## 📱 Storage de Imágenes

Las fotos capturadas en la app móvil (M-02) deben almacenarse en:

**Opciones:**
- AWS S3
- Cloudinary
- Supabase Storage
- Firebase Storage
- Tu propio servidor

**Flujo sugerido:**
1. App móvil captura foto
2. Convierte a base64 o Blob
3. Envía a endpoint `/api/upload-foto`
4. Backend sube a storage y retorna URL
5. URL se guarda en campo `evidencia_foto_url` de tabla `reportes`

---

## 🧪 Testing con Datos Mock

Mientras configuras tu base de datos real, puedes usar datos mock.

Ver ejemplos en `src/database/mock-data.ts` (crear este archivo).

---

## 📞 Soporte

Si necesitas ayuda configurando la base de datos:
- Email: soporte@sso-sistema.com
- Documentación: [Enlace a docs]

---

## ✅ Checklist de Implementación

- [ ] Crear archivo `.env` con credenciales
- [ ] Instalar dependencia de base de datos (supabase/pg/mongodb/etc)
- [ ] Ejecutar script `schema.sql` para crear tablas
- [ ] Descomentar conector en `config.ts`
- [ ] Implementar endpoints en backend
- [ ] Configurar storage para imágenes
- [ ] Probar flujo: App Móvil → BD → Web
- [ ] Configurar notificaciones push (opcional)
- [ ] Implementar cálculo de score de riesgo
- [ ] Configurar backups automáticos de BD
