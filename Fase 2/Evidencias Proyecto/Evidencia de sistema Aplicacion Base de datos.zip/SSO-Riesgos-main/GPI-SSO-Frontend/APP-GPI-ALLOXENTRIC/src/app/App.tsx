import { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import {
  Home as HomeIcon, FileText, Bell, User, Briefcase,
  Camera, Mic, X, ChevronLeft, AlertCircle, Users, MapPin, AlertTriangle, CheckCircle,
  Send, MicOff,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { translations } from './constants/translations';
import Swal from 'sweetalert2';
import MyIncidents from './components/MyIncidents';
import ManageIncidents from './components/ManageIncidents';
// ─── API ──────────────────────────────────────────────────────────────────────
import {
  login,
  logout as apiLogout,
  restoreSession,
} from './api/auth';
import {
  AUTH_SESSION_INVALIDATED_EVENT,
} from './api/client';
import { getUserProfile, updateUserProfile, updateUserProfilePhoto } from './api/users';
import { resolveLocalEvidenceUrl } from './utils/mediaUrl';
import {
  listenReports,
  createReportIdempotencyKey,
  type ReportCreatePayload,
  type Report,
  type ReportStatus,
} from './api/reports';
import {
  formatWorkerReportTimelineTimestamp,
  getWorkerReportTimelineSteps,
} from './utils/workerReportTimeline';
import {
  formatReportDate,
  getReportDisplayId,
  getReportEvidenceUrl,
} from './utils/reportPresentation';
import SafetyTalksMobile from './pages/SafetyTalksMobile';
import {
  listenNotifications, listenAlerts, alertToNotification,
  getNotifications, markAllNotificationsRead, getWorkerStats,
  type RawAlertDoc,
} from './api/incidents';
import {
  countPendingReports,
} from '../utils/offlineQueue';
import {
  submitReportWithOfflineFallback,
  syncPendingReports,
} from '../utils/offlineReportSync';
import {
  getNetworkConnected,
  subscribeNetworkStatus,
} from '../utils/networkStatus';
import { usePushToTalk } from './hooks/usePushToTalk';
import {
  useLocalNotificationsOnNewItems,
  requestLocalNotificationPermission,
} from './hooks/useLocalNotifications';
// ─── PAGES ────────────────────────────────────────────────────────────────────
import Home from './pages/HomeTemp';
import Reports from './pages/Reports';
import Notifications from './pages/Notifications';
import Profile from './pages/Profile';

const resolveProfilePhotoUrl = (
  photoUrl?: string | null,
): string | null => {
  if (!photoUrl) {
    return null;
  }

  return resolveLocalEvidenceUrl(
    photoUrl,
    import.meta.env.VITE_USERS_API_URL,
  );
};

import '../styles/theme-vars.css';
import '../styles/themed-components.css';
import { INCIDENT_AREAS } from './constants/incidentAreas';

// ─── TYPES ────────────────────────────────────────────────────────────────────

export type NotificationType = 'alert' | 'update' | 'comment' | 'resolved' | 'actualizacion';

export interface Notification {
  id: string; type: NotificationType; title: string; description: string;
  time: string; read: boolean; date: 'today' | 'yesterday';
  timestamp?: number;
}

export interface Alert {
  area: string; level: 'high' | 'critical'; time: string;
}

// ─── CONFIGURACIÓN PERSISTENTE ─────────────────────────────────────────────────
// Se guarda en localStorage para que sobreviva al cerrar la app.

interface AppSettings {
  theme: 'dark' | 'light' | 'system';
  language: 'es' | 'en' | 'fr';
  autoSaveReports: boolean;
  cameraQuality: 'low' | 'medium' | 'high';
  offlineMode: boolean;
}

const APP_SETTINGS_KEY = 'vigia_app_settings';

const DEFAULT_APP_SETTINGS: AppSettings = {
  theme: 'dark',
  language: 'es',
  autoSaveReports: true,
  cameraQuality: 'high',
  offlineMode: true,
};

function loadAppSettings(): AppSettings {
  try {
    const stored = localStorage.getItem(APP_SETTINGS_KEY);
    if (stored) return { ...DEFAULT_APP_SETTINGS, ...JSON.parse(stored) };
  } catch {
    // ignorar JSON corrupto y usar defaults
  }
  return DEFAULT_APP_SETTINGS;
}

interface NotificationSettings {
  criticalAlerts: boolean;
  reportUpdates: boolean;
  shiftReminders: boolean;
  comments: boolean;
}

const NOTIFICATION_SETTINGS_KEY = 'vigia_notification_settings';

const DEFAULT_NOTIFICATION_SETTINGS: NotificationSettings = {
  criticalAlerts: true, reportUpdates: true, shiftReminders: true, comments: true,
};

function loadNotificationSettings(): NotificationSettings {
  try {
    const stored = localStorage.getItem(NOTIFICATION_SETTINGS_KEY);
    if (stored) return { ...DEFAULT_NOTIFICATION_SETTINGS, ...JSON.parse(stored) };
  } catch {
    // ignorar JSON corrupto y usar defaults
  }
  return DEFAULT_NOTIFICATION_SETTINGS;
}

// ─── APP ──────────────────────────────────────────────────────────────────────

export default function App() {

  // ── Auth ──────────────────────────────────────────────────────────────────
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  
  const LOGIN_CLIENTS = [
    {
      clientId: import.meta.env.VITE_CLIENT_A_ID || 'cliente_prueba_123',
      name: 'Cliente Demo A',
    },
    {
      clientId: import.meta.env.VITE_CLIENT_B_ID || 'cliente_prueba_b_123',
      name: 'Cliente Demo B',
    },
  ];

  const DEFAULT_LOGIN_CLIENT_ID =
    LOGIN_CLIENTS.some(
      client =>
        client.clientId ===
        import.meta.env.VITE_CLIENT_ID,
    )
      ? import.meta.env.VITE_CLIENT_ID
      : '';

  const DEMO_USERS = [
    {
      clientId: 'cliente_prueba_123',
      email: 'usuario@demo.com',
      pass: '123456',
      role: 'Usuario A',
      color: '#3b82f6',
      icon: 'UA',
    },
    {
      clientId: 'cliente_prueba_123',
      email: 'supervisor@demo.com',
      pass: '123456',
      role: 'Supervisor A',
      color: '#E8941A',
      icon: 'SA',
    },
    {
      clientId: 'cliente_prueba_123',
      email: 'jefe@demo.com',
      pass: '123456',
      role: 'Jefe A',
      color: '#8b5cf6',
      icon: 'JA',
    },
    {
      clientId: 'cliente_prueba_123',
      email: 'admin@demo.com',
      pass: '123456',
      role: 'Admin A',
      color: '#16A34A',
      icon: 'AA',
    },
    {
      clientId: 'cliente_prueba_b_123',
      email: 'usuariob@demo.com',
      pass: '123456',
      role: 'Usuario B',
      color: '#3b82f6',
      icon: 'UB',
    },
    {
      clientId: 'cliente_prueba_b_123',
      email: 'supervisorb@demo.com',
      pass: '123456',
      role: 'Supervisor B',
      color: '#E8941A',
      icon: 'SB',
    },
    {
      clientId: 'cliente_prueba_b_123',
      email: 'jefeb@demo.com',
      pass: '123456',
      role: 'Jefe B',
      color: '#8b5cf6',
      icon: 'JB',
    },
    {
      clientId: 'cliente_prueba_b_123',
      email: 'adminb@demo.com',
      pass: '123456',
      role: 'Admin B',
      color: '#16A34A',
      icon: 'AB',
    },
  ];

  const [activeTab, setActiveTab] = useState<'home' | 'reports' | 'manage'>('home');

  const [loginForm, setLoginForm] = useState({
    clientId: DEFAULT_LOGIN_CLIENT_ID,
    username: '',
    password: '',
  });
  const [loginError, setLoginError] = useState('');
  const [loginLoading, setLoginLoading] = useState(false);

  // ── Navigation ────────────────────────────────────────────────────────────
  const [currentScreen, setCurrentScreen] = useState<'home' | 'reports' | 'notifications' | 'profile' | 'manage' | 'talks'>('home');
  const [activeModal, setActiveModal] = useState<
    'create' | 'detail' | 'editProfile' | 'notificationSettings' |
    'assignedAreas' | 'help' | 'generalSettings' | null
  >(null);
  const [selectedReport, setSelectedReport] = useState<Report | null>(null);
  const [reportFilter, setReportFilter] = useState<'all' | 'open' | 'closed'>('all');

  // ── Remote data ───────────────────────────────────────────────────────────
  const [reports, setReports] = useState<Report[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [rawAlerts, setRawAlerts] = useState<RawAlertDoc[]>([]);
  const [notificationsReady, setNotificationsReady] = useState(false);
  const [alertsReady, setAlertsReady] = useState(false);
  const [dataLoading, setDataLoading] = useState(false);

  // ── New report form ───────────────────────────────────────────────────────
  const [newReport, setNewReport] = useState({
    photoFile: null as File | null,
    photoPreview: null as string | null,
    worker_type: 'planta',
    area: '', line: '', process: '',
    type: 'unsafe_act' as 'unsafe_act' | 'unsafe_condition',
    causes: [] as string[],
    isIAP: false, description: '',
    location: null as { lat: number; lng: number } | null,
    timestamp: null as string | null,
  });
  const [submitLoading, setSubmitLoading] = useState(false);
  const [feedbackText, setFeedbackText] = useState('');
  const [causeSearch, setCauseSearch] = useState('');
  const [showCauseDropdown, setShowCauseDropdown] = useState(false);
  const AVAILABLE_CAUSES = [
    'No observar el entorno antes o durante la tarea',
    'Ingresar a un area sin autorizacion',
    'No respetar barreras, senalizacion o zonas demarcadas',
    'Ubicarse en linea de fuego',
    'Transitar bajo carga suspendida',
    'Intervenir equipo en movimiento',
    'No aplicar bloqueo o prueba de energia cero',
    'Operar equipo movil sin autorizacion',
    'Operar a velocidad inadecuada',
    'Trasladar carga inestable o mal estibada',
    'Usar herramientas o equipos defectuosos',
    'Usar celular u otro distractor durante la tarea',
    'No usar EPP requerido',
    'Usar EPP inadecuado o en mal estado',
    'Ejecutar trabajo critico sin permiso autorizado',
    'No coordinar trabajos simultaneos',
    'Realizar maniobra de izaje sin planificacion',
    'Realizar trabajo en caliente sin controlar combustibles',
    'Usar andamio o escala sin verificar condicion',
    'Dejar materiales con riesgo de caida',
    'Desviarse del procedimiento o pauta de trabajo',
    'No informar cambios en la tarea',
    'Manipular quimicos sin controles definidos',
    'Usar aire comprimido sobre el cuerpo',
    'Otra conducta subestandar',
  ];
  const [wizardStep, setWizardStep] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [autoClassification, setAutoClassification] = useState('');





  // ── User ──────────────────────────────────────────────────────────────────
  const [servicesReady, setServicesReady] = useState(false);


  useEffect(() => {
    const urls = [
      import.meta.env.VITE_AUTH_API_URL || 'http://localhost:8000',
      import.meta.env.VITE_REPORTS_API_URL || 'http://localhost:8001',
      import.meta.env.VITE_WORKERS_API_URL || 'http://localhost:8005',
    ];
    Promise.allSettled(urls.map(u => fetch(u + '/', { mode: 'no-cors' }).catch(() => null)))
      .then(() => setServicesReady(true));
  }, []);

  const [user, setUser] = useState({
    name: '', lastName: '', email: '', employeeId: '',
    role: '', shift: '', area: '',
    avatar: '', profilePhoto: null as string | null,
    user_id: '',    // ← agregar
    client_id: '',  // ← agregar
    assigned_areas: [] as string[],
    stats: { totalReports: 0, thisMonth: 0, effectiveness: 0 },
  });

  const [editProfileForm, setEditProfileForm] = useState({
    name: '', lastName: '', profilePhoto: null as string | null,
  });
  const [profilePhotoFile, setProfilePhotoFile] =
    useState<File | null>(null);


  // ── Configuración persistente (tema, idioma, notificaciones) ───────────────
  const [notificationSettings, setNotificationSettings] = useState<NotificationSettings>(loadNotificationSettings);
  const [appSettings, setAppSettings] = useState<AppSettings>(loadAppSettings);

  // Guarda automáticamente cada vez que cambian
  useEffect(() => {
    localStorage.setItem(APP_SETTINGS_KEY, JSON.stringify(appSettings));
  }, [appSettings]);

  useEffect(() => {
    localStorage.setItem(NOTIFICATION_SETTINGS_KEY, JSON.stringify(notificationSettings));
  }, [notificationSettings]);

  // ── Sincronización con el tema del sistema operativo ────────────────────────
  const [systemPrefersDark, setSystemPrefersDark] = useState<boolean>(() =>
    typeof window !== 'undefined' && !!window.matchMedia
      ? window.matchMedia('(prefers-color-scheme: dark)').matches
      : true
  );

  useEffect(() => {
    if (typeof window === 'undefined' || !window.matchMedia) return;
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    const handler = (e: MediaQueryListEvent) => setSystemPrefersDark(e.matches);
    mq.addEventListener('change', handler);
    return () => mq.removeEventListener('change', handler);
  }, []);

  // Tema efectivo que realmente se aplica en pantalla (resuelve 'system')
  const effectiveTheme: 'light' | 'dark' =
    appSettings.theme === 'system'
      ? (systemPrefersDark ? 'dark' : 'light')
      : appSettings.theme;

  // ── App settings (resto) ─────────────────────────────────────────────────
  const [pendingSyncCount, setPendingSyncCount] = useState(0);
  const [isOnline, setIsOnline] = useState(
    () =>
      typeof navigator === 'undefined'
        ? true
        : navigator.onLine,
  );
  const [currentLocation, setCurrentLocation] = useState<{ lat: number; lng: number } | null>(null);

  const t = translations[appSettings.language];

  // ── Refs ──────────────────────────────────────────────────────────────────
  const fileInputRef = useRef<HTMLInputElement>(null);
  const profilePhotoInputRef = useRef<HTMLInputElement>(null);
  // Push-to-talk — reemplaza Web Speech API
  const { isRecording, pressHandlers: micPressHandlers } = usePushToTalk({
    language: appSettings.language as 'es' | 'en' | 'fr',
    onTranscript: (text) => {
      setNewReport(prev => ({
        ...prev,
        description: prev.description
          ? prev.description + ' ' + text
          : text,
      }));
    },
    onError: (msg) => toast(msg, 'warning'),
  });
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);

  // ── Derived ───────────────────────────────────────────────────────────────
  const alerts: Alert[] = rawAlerts
    .filter(a => a.status !== 'resolved')
    .map(a => {
      const createdAt = a.created_at && typeof a.created_at === 'object' && '_seconds' in a.created_at
        ? new Date(a.created_at._seconds * 1000)
        : new Date(a.created_at as string);
      return {
        area: a.zone_name || a.zone_id || 'Zona desconocida',
        level: (a.severity === 'critical' || a.type === 'iap') ? 'critical' : 'high',
        time: isNaN(createdAt.getTime())
          ? ''
          : createdAt.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' }),
      } as Alert;
    });

  const combinedNotifications = useMemo(
    () => [...(Array.isArray(notifications) ? notifications : []), ...(Array.isArray(rawAlerts) ? rawAlerts : []).map(alertToNotification)]
      .sort((a, b) => (b.timestamp ?? 0) - (a.timestamp ?? 0)),
    [notifications, rawAlerts]
  );

  const criticalAlert = alerts.find(a => a.level === 'critical') ?? null;
  const unreadCount = combinedNotifications.filter(n => !n.read).length;
  const openReportsCount = reports.filter(r => r.status !== 'closed').length;
  const closedThisMonth = reports.filter(r => r.status === 'closed').length;
  const filteredReports = reports.filter(r =>
    reportFilter === 'open' ? r.status !== 'closed' :
      reportFilter === 'closed' ? r.status === 'closed' : true
  );
  const toast = (title: string, icon: 'success' | 'error' | 'warning' | 'info' = 'info') =>
    Swal.fire({
      title,
      icon,
      background: effectiveTheme === 'light' ? '#ffffff' : '#1a1a1a',
      color: effectiveTheme === 'light' ? '#0f172a' : '#ffffff',
      iconColor: icon === 'success' ? '#16A34A' : icon === 'error' ? '#D72631' : icon === 'warning' ? '#E8941A' : '#00C2DB',
      confirmButtonColor: '#00E5FF',
      confirmButtonText: 'OK',
      backdrop: effectiveTheme === 'light' ? 'rgba(0,0,0,0.4)' : 'rgba(0,0,0,0.7)',
      customClass: { popup: 'rounded-2xl border themed-border' },
    });

  // ── Notificaciones locales (sistema operativo) ──────────────────────────────
  // Solo dispara para los tipos que el usuario tiene activados en Configurar
  // Notificaciones. Esto además hace que ese modal deje de ser decorativo.
  const reportLocalNotificationItems = useMemo(
    () => notifications.map(n => {
      let enabled = true;

      if (
        n.type === 'update' ||
        n.type === 'actualizacion'
      ) {
        enabled = notificationSettings.reportUpdates;
      } else if (n.type === 'comment') {
        enabled = notificationSettings.comments;
      }

      return {
        id: n.id,
        title: n.title,
        description:
          n.description ||
          (n as Notification & { body?: string }).body ||
          '',
        enabled,
      };
    }),
    [notifications, notificationSettings],
  );

  const alertLocalNotificationItems = useMemo(
    () => rawAlerts.map(alert => ({
      id: alert.alert_id,
      title: alert.title,
      description: alert.description,
      enabled: notificationSettings.criticalAlerts,
    })),
    [
      rawAlerts,
      notificationSettings.criticalAlerts,
    ],
  );

  useEffect(() => {
    if (isAuthenticated) requestLocalNotificationPermission();
  }, [isAuthenticated]);

  useLocalNotificationsOnNewItems(
    reportLocalNotificationItems,
    {
      clientId: user.client_id,
      userId: user.user_id,
      channel: 'reports',
      ready:
        isAuthenticated &&
        notificationsReady,
    },
  );

  useLocalNotificationsOnNewItems(
    alertLocalNotificationItems,
    {
      clientId: user.client_id,
      userId: user.user_id,
      channel: 'alerts',
      ready:
        isAuthenticated &&
        alertsReady,
    },
  );

  // ─── EFECTOS ──────────────────────────────────────────────────────────────

  // ── Session persistence ──────────────────────────────────────────────────
  const clearAuthenticatedUi = useCallback(() => {
    localStorage.removeItem(
      'vigia_session',
    );

    setIsAuthenticated(false);

    setLoginForm({
      clientId:
        DEFAULT_LOGIN_CLIENT_ID,
      username: '',
      password: '',
    });

    setUser({
      name: '',
      lastName: '',
      email: '',
      employeeId: '',
      role: '',
      shift: '',
      area: '',
      avatar: '',
      profilePhoto: null,
      user_id: '',
      client_id: '',
      assigned_areas: [],
      stats: {
        totalReports: 0,
        thisMonth: 0,
        effectiveness: 0,
      },
    });

    setEditProfileForm({
      name: '',
      lastName: '',
      profilePhoto: null,
    });

    setProfilePhotoFile(null);
    setReports([]);
    setNotifications([]);
    setRawAlerts([]);
    setNotificationsReady(false);
    setAlertsReady(false);
    setActiveModal(null);
    setCurrentScreen('home');
  }, [DEFAULT_LOGIN_CLIENT_ID]);

  useEffect(() => {
    let cancelled = false;

    const handleInvalidatedSession =
      () => {
        if (!cancelled) {
          clearAuthenticatedUi();
        }
      };

    window.addEventListener(
      AUTH_SESSION_INVALIDATED_EVENT,
      handleInvalidatedSession,
    );

    const restoreStoredSession =
      async () => {
        const stored =
          localStorage.getItem(
            'vigia_session',
          );

        if (!stored) {
          /*
           * Una credencial huérfana no debe
           * reconstruir una sesión sin el
           * estado local correspondiente.
           */
          await apiLogout();
          return;
        }

        try {
          JSON.parse(stored);
        } catch {
          localStorage.removeItem(
            'vigia_session',
          );
          await apiLogout();
          return;
        }

        try {
          const u =
            await restoreSession();

          if (cancelled) {
            return;
          }

          const restoredUser = {
            name: u.name,
            lastName:
              u.last_name,
            email: u.email,
            employeeId:
              u.employee_id,
            role: u.role,
            shift: u.shift,
            area: u.area,
            assigned_areas:
              u.assigned_areas ?? [],
            avatar:
              `${u.name[0] ?? '?'}${u.last_name?.[0] ?? ''}`
                .toUpperCase(),
            profilePhoto:
              resolveProfilePhotoUrl(u.profile_photo_url),
            user_id:
              u.user_id,
            client_id:
              u.client_id,
            stats: {
              totalReports:
                u.stats.total_reports,
              thisMonth:
                u.stats.this_month,
              effectiveness:
                u.stats.effectiveness,
            },
          };

          setUser(restoredUser);
          setIsAuthenticated(true);

          /*
           * El contenido anterior de
           * vigia_session no se utiliza como
           * identidad. Se reemplaza por lo
           * validado por backend.
           */
          localStorage.setItem(
            'vigia_session',
            JSON.stringify({
              user:
                restoredUser,
              expiry:
                Date.now() +
                8 * 60 * 60 * 1000,
            }),
          );

          setTimeout(() => {
            if (!cancelled) {
              void loadRemoteData();
            }
          }, 800);
        } catch (error) {
          /*
           * Si fue 401 definitivo,
           * authenticatedFetch ya limpió la
           * sesión y emitió el evento.
           *
           * Si fue red/5xx, no eliminamos
           * credenciales ni cola offline.
           */
          if (!cancelled) {
            console.warn(
              'No fue posible validar la sesión almacenada:',
              error,
            );
          }
        }
      };

    void restoreStoredSession();

    return () => {
      cancelled = true;

      window.removeEventListener(
        AUTH_SESSION_INVALIDATED_EVENT,
        handleInvalidatedSession,
      );
    };
  }, [clearAuthenticatedUi]);

  useEffect(() => {
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission();
    }
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        p => setCurrentLocation({ lat: p.coords.latitude, lng: p.coords.longitude }),
        () => setCurrentLocation({ lat: -33.4489, lng: -70.6693 }),
      );
    }

    const refreshPendingCount = async () => {
      if (
        !isAuthenticated
        || !user.client_id
        || !user.user_id
      ) {
        setPendingSyncCount(0);
        return;
      }

      const count =
        await countPendingReports(
          user.client_id,
          user.user_id,
        );

      setPendingSyncCount(count);
    };

    const syncPending = async () => {
      if (
        !isAuthenticated
        || !user.client_id
        || !user.user_id
      ) {
        return;
      }

      const connected =
        await getNetworkConnected();

      setIsOnline(connected);

      if (!connected) {
        await refreshPendingCount();
        return;
      }

      try {
        const result =
          await syncPendingReports(
            user.client_id,
            user.user_id,
          );

        setPendingSyncCount(
          result.remaining,
        );

        if (result.synced > 0) {
          await toast(
            `${result.synced} ${t.syncSuccess}`,
            result.failed > 0
              ? 'warning'
              : 'success',
          );
        }
      } catch (error) {
        console.error(
          'Error sincronizando reportes pendientes:',
          error,
        );

        await refreshPendingCount();
      }
    };

    const handleNetworkStatus =
      async (connected: boolean) => {
        setIsOnline(connected);

        if (connected) {
          await syncPending();
        } else {
          await refreshPendingCount();
        }
      };

    const unsubscribeNetwork =
      subscribeNetworkStatus(
        connected => {
          void handleNetworkStatus(
            connected,
          );
        },
      );

    void getNetworkConnected()
      .then(connected => {
        void handleNetworkStatus(
          connected,
        );
      });

    return () => {
      unsubscribeNetwork();
    };
  }, [
    isAuthenticated,
    user.user_id,
    user.client_id,
  ]);

  // Listener reportes en tiempo real
  useEffect(() => {
    if (!isAuthenticated || !user.user_id || !user.client_id) return;
    const unsubscribe = listenReports(user.client_id, user.user_id, setReports);
    return () => unsubscribe();
  }, [isAuthenticated, user.user_id, user.client_id]);

  // Listener notificaciones en tiempo real
  useEffect(() => {
    setNotificationsReady(false);

    if (!isAuthenticated || !user.user_id) return;

    const unsubscribe = listenNotifications(
      user.user_id,
      (data) =>
        setNotifications(
          Array.isArray(data) ? data : [],
        ),
      () => setNotificationsReady(true),
    );

    return () => unsubscribe();
  }, [isAuthenticated, user.user_id]);

  // Listener alertas manuales en tiempo real (creadas desde la WEB)
  useEffect(() => {
    setAlertsReady(false);

    if (!isAuthenticated || !user.client_id) return;

    const unsubscribe = listenAlerts(
      user.client_id,
      (data) =>
        setRawAlerts(
          Array.isArray(data) ? data : [],
        ),
      () => setAlertsReady(true),
    );

    return () => unsubscribe();
  }, [isAuthenticated, user.client_id]);

  // ─── LOAD REMOTE DATA ─────────────────────────────────────────────────────

  const loadRemoteData = useCallback(async () => {
    setDataLoading(true);
    try {
      const [remoteNotifs, remoteStats] = await Promise.allSettled([
        getNotifications(),
        getWorkerStats(),
      ]);

      if (remoteNotifs.status === 'fulfilled') setNotifications(remoteNotifs.value);
      // Stats calculados desde reportes locales
      if (true) {
        const myReports = reports.filter(r => r.reported_by === user.user_id);
        const closed = myReports.filter(r => r.status === 'closed');
        const now = new Date();
        const thisMonth = myReports.filter(r => {
          const d = new Date(r.created_at);
          return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
        });
        setUser(prev => ({
          ...prev,
          stats: {
            totalReports: myReports.length,
            thisMonth: thisMonth.length,
            effectiveness: myReports.length > 0 ? Math.round(closed.length / myReports.length * 100) : 0,
          },
        }));
      }
    } finally {
      setDataLoading(false);
    }
  }, []);

  // ─── HANDLERS ─────────────────────────────────────────────────────────────

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginLoading(true);
    setLoginError(''); // Limpiamos errores previos

    try {
      const clientId = loginForm.clientId.trim();

      if (!clientId) {
        setLoginError(
          'Ingresa el código de organización.',
        );
        setLoginLoading(false);
        return;
      }

      const { user: u } = await login(
        clientId,
        loginForm.username,
        loginForm.password,
      );

      // 1. Validación de ROL: Solo trabajadores pueden entrar
      if (!['usuario', 'supervisor', 'jefe_de_area', 'admin', 'worker', 'sso_manager', 'jefe de area', 'analyst'].includes(u.role)) {
        setLoginError('Acceso denegado: Esta aplicación es solo para trabajadores.');
        setLoginLoading(false);
        return; // Detenemos la ejecución aquí
      }

      // 2. Si el rol es correcto, guardamos el usuario
      setUser({
        name: u.name,
        lastName: u.last_name,
        email: u.email,
        employeeId: u.employee_id,
        role: u.role,
        shift: u.shift,
        area: u.area,
        assigned_areas: u.assigned_areas ?? [],
        avatar: `${u.name[0] ?? '?'}${u.last_name?.[0] ?? ''}`.toUpperCase(),
        profilePhoto:
          resolveProfilePhotoUrl(u.profile_photo_url),
        user_id: u.user_id,
        client_id: u.client_id,
        stats: {
          totalReports: u.stats.total_reports,
          thisMonth: u.stats.this_month,
          effectiveness: u.stats.effectiveness,
        },
      });

      setIsAuthenticated(true);
      localStorage.setItem('vigia_session', JSON.stringify({
        user: {
          name: u.name, lastName: u.last_name, email: u.email,
          employeeId: u.employee_id, role: u.role, shift: u.shift,
          area: u.area, assigned_areas: u.assigned_areas ?? [],
          avatar: `${u.name[0] ?? '?'}${u.last_name?.[0] ?? ''}`.toUpperCase(),
          profilePhoto: resolveProfilePhotoUrl(u.profile_photo_url),
          user_id: u.user_id, client_id: u.client_id,
          stats: { totalReports: u.stats.total_reports, thisMonth: u.stats.this_month, effectiveness: u.stats.effectiveness },
        },
        expiry: Date.now() + 8 * 60 * 60 * 1000, // 8 horas
      }));
      setTimeout(() => loadRemoteData(), 800);

    } catch (err: any) {
      // 3. Mensaje de error fijo para credenciales incorrectas o fallo de conexión
      setLoginError(
        'La organización, el usuario o la contraseña no coinciden. Intenta nuevamente.',
      );
    } finally {
      setLoginLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await apiLogout();
    } catch {
      // El logout local debe continuar.
    }

    clearAuthenticatedUi();
  };

  const handlePhotoCapture = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onloadend = () => {
      setNewReport(prev => ({
        ...prev,
        photoFile: file,
        photoPreview: reader.result as string,
        location: currentLocation,
        timestamp: new Date().toISOString(),
      }));
      if (navigator.vibrate) navigator.vibrate(30);
    };
    reader.readAsDataURL(file);
  };

  const handleCreateReport = async () => {
    if (!newReport.area) return;

    if (
      !user.client_id
      || !user.user_id
    ) {
      await toast(
        'No fue posible identificar la sesión actual.',
        'error',
      );
      return;
    }

    if (navigator.vibrate) {
      navigator.vibrate(50);
    }

    setSubmitLoading(true);

    const typeLabel =
      autoClassification
      || 'Incidente';

    const payload:
      ReportCreatePayload = {
        area_id: newReport.area,
        type: typeLabel,
        causes: newReport.causes,
        is_iap:
          autoClassification === 'IAP'
          || newReport.isIAP,
        description:
          newReport.description,
        shift:
          user.shift || 'Día',
        worker_type:
          newReport.worker_type
          || 'planta',
        evidences: [],
      };

    const idempotencyKey =
      createReportIdempotencyKey();

    try {
      const result =
        await submitReportWithOfflineFallback({
          clientId:
            user.client_id,
          userId:
            user.user_id,
          payload,
          photoFile:
            newReport.photoFile
            ?? undefined,
          shift:
            user.shift || 'Día',
          idempotencyKey,
        });

      setActiveModal(null);
      resetNewReport();

      if (result.status === 'queued') {
        setIsOnline(false);
        setPendingSyncCount(
          result.pendingCount,
        );

        await toast(
          t.offlineWarning,
          'warning',
        );

        return;
      }

      Swal.fire({
        icon: 'success',
        title: 'Reporte enviado',
        text:
          'Tu reporte fue registrado correctamente',
        confirmButtonColor: '#00E5FF',
        timer: 3000,
        timerProgressBar: true,
      });

      await loadRemoteData();
    } catch (error) {
      await toast(
        `${t.sendError}: ${
          error instanceof Error
            ? error.message
            : String(error)
        }`,
        'error',
      );
    } finally {
      setSubmitLoading(false);
    }
  };

  const resetNewReport = () => {
    setNewReport({
      photoFile: null, photoPreview: null, area: '', line: '', process: '',
      type: 'unsafe_act', causes: [], isIAP: false, description: '', location: null, timestamp: null,
    });
    setAudioBlob(null);
    setWizardStep(0);
    setAnswers({});
    setAutoClassification('');
  };

  const markAllRead = async () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
    try { await markAllNotificationsRead(); } catch { }
  };

  const handleProfilePhotoChange = (
    e: React.ChangeEvent<HTMLInputElement>,
  ) => {
    const file = e.target.files?.[0];

    if (!file) return;

    const allowedTypes = [
      'image/jpeg',
      'image/png',
      'image/webp',
    ];

    if (!allowedTypes.includes(file.type)) {
      toast(
        'La foto debe ser JPEG, PNG o WebP.',
        'warning',
      );
      e.target.value = '';
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      toast(
        'La fotografía supera el máximo permitido de 10 MB.',
        'warning',
      );
      e.target.value = '';
      return;
    }

    setProfilePhotoFile(file);

    const reader = new FileReader();

    reader.onloadend = () => {
      setEditProfileForm(prev => ({
        ...prev,
        profilePhoto:
          reader.result as string,
      }));
    };

    reader.readAsDataURL(file);
  };

  const handleSaveProfile = async () => {
    try {
      // Si existe una fotografía nueva, se persiste
      // primero. El Data URL queda solo como preview.
      if (profilePhotoFile) {
        await updateUserProfilePhoto(
          profilePhotoFile,
        );
      }

      const persisted = await updateUserProfile({
        name: editProfileForm.name.trim(),
        last_name:
          editProfileForm.lastName.trim(),
      });

      const persistedLastName =
        persisted.last_name ?? '';

      const persistedPhoto =
        resolveProfilePhotoUrl(persisted.profile_photo_url);

      const updatedAvatar =
        `${persisted.name[0] ?? ''}${persistedLastName[0] ?? ''}`
          .toUpperCase();

      setUser(prev => ({
        ...prev,
        name: persisted.name,
        lastName: persistedLastName,
        profilePhoto: persistedPhoto,
        avatar: updatedAvatar,
      }));

      const stored =
        localStorage.getItem('vigia_session');

      if (stored) {
        try {
          const session = JSON.parse(stored);

          if (
            session &&
            typeof session === 'object' &&
            session.user
          ) {
            localStorage.setItem(
              'vigia_session',
              JSON.stringify({
                ...session,
                user: {
                  ...session.user,
                  name: persisted.name,
                  lastName: persistedLastName,
                  profilePhoto: persistedPhoto,
                  avatar: updatedAvatar,
                },
              }),
            );
          }
        } catch (error) {
          console.error(
            'No se pudo actualizar vigia_session:',
            error,
          );
        }
      }

      setProfilePhotoFile(null);

      await toast(
        t.profileUpdated,
        'success',
      );

      setActiveModal(null);
    } catch (error) {
      console.error(
        'Profile update error:',
        error,
      );

      await toast(
        error instanceof Error
          ? error.message
          : 'No se pudo actualizar el perfil.',
        'error',
      );
    }
  };

  const handleSaveNotificationSettings = async () => {
    await toast(t.notificationsSaved, 'success');
    setActiveModal(null);
  };

  const handleForceSync = async () => {
    if (
      !isAuthenticated
      || !user.client_id
      || !user.user_id
    ) {
      return;
    }

    const connected =
      await getNetworkConnected();

    setIsOnline(connected);

    if (!connected) {
      const count =
        await countPendingReports(
          user.client_id,
          user.user_id,
        );

      setPendingSyncCount(count);

      await toast(
        t.offlineWarning,
        'warning',
      );

      return;
    }

    await toast(
      t.syncing,
      'info',
    );

    try {
      const result =
        await syncPendingReports(
          user.client_id,
          user.user_id,
        );

      setPendingSyncCount(
        result.remaining,
      );

      if (
        result.remaining === 0
        && result.failed === 0
      ) {
        await toast(
          t.syncComplete,
          'success',
        );
      } else {
        await toast(
          `${result.remaining} ${t.pendingReports}`,
          'warning',
        );
      }
    } catch (error) {
      console.error(
        'Error en sincronización manual:',
        error,
      );

      const count =
        await countPendingReports(
          user.client_id,
          user.user_id,
        );

      setPendingSyncCount(count);

      await toast(
        `${t.sendError}: ${
          error instanceof Error
            ? error.message
            : String(error)
        }`,
        'error',
      );
    }
  };

  // toggleRecording reemplazado por usePushToTalk

  const getStatusColor = (status: ReportStatus) => ({
    sent: 'themed-text-secondary',
    open: 'text-[#3b82f6]',
    reviewing: 'text-[#E8941A]',
    assigned: 'text-[#1A5276]',
    en_proceso: 'text-[#E8941A]',
    pending_closure: 'text-[#8b5cf6]',
    closed: 'text-[#16A34A]',
  }[status]);

  const getStatusLabel = (status: ReportStatus) => ({
    sent: t.sent,
    open: t.reportOpen,
    reviewing: t.reviewing,
    assigned: t.assigned,
    en_proceso: 'En Proceso',
    pending_closure: 'Pendiente de cierre',
    closed: t.reportClosed,
  }[status]);

  // ─── LOGIN ────────────────────────────────────────────────────────────────

  if (!isAuthenticated) {
    const languages = [
      { code: 'es', name: 'Español', flag: '🇪🇸' },
      { code: 'en', name: 'English', flag: '🇺🇸' },
      { code: 'fr', name: 'Français', flag: '🇫🇷' },
    ];
    return (
      <div className={`min-h-screen flex items-center justify-center p-2 ${effectiveTheme === 'light' ? 'theme-light' : ''}`}
        style={{ backgroundColor: 'var(--theme-bg)', color: 'var(--theme-text)' }}>
        <div className="w-full max-w-[420px] min-h-screen shadow-2xl overflow-hidden relative flex flex-col items-center justify-center p-8"
          style={{ backgroundColor: 'var(--theme-bg-secondary)' }}>
          <div className="absolute top-6 right-6">
            <select value={appSettings.language}
              onChange={e => setAppSettings(prev => ({ ...prev, language: e.target.value as 'es' | 'en' | 'fr' }))}
              className="themed-input rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#00E5FF] border">
              {languages.map(l => <option key={l.code} value={l.code}>{l.flag} {l.name}</option>)}
            </select>
          </div>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-sm">
            <div className="text-center mb-12">
              <img
                src="/logo-vigia.png"
                alt="Vigía Industrial"
                className="w-24 h-24 mx-auto mb-4 object-contain"
              />
              <h1 className="text-3xl font-bold mb-2">{t.loginTitle}</h1>
              <p className="text-sm themed-text-secondary">{t.loginSubtitle}</p>
            </div>
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="text-sm mb-2 block themed-text-secondary">
                  Código de organización
                </label>
                <select
                  value={loginForm.clientId}
                  onChange={e =>
                    setLoginForm(p => ({
                      ...p,
                      clientId: e.target.value,
                    }))
                  }
                  className="w-full themed-input rounded-xl px-4 py-3 focus:outline-none focus:border-[#00E5FF] border"
                  required
                >
                  <option value="">
                    Selecciona una organización
                  </option>

                  {LOGIN_CLIENTS.map(client => (
                    <option
                      key={client.clientId}
                      value={client.clientId}
                    >
                      {client.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-sm mb-2 block themed-text-secondary">{t.username}</label>
                <input type="text" value={loginForm.username}
                  onChange={e => setLoginForm(p => ({ ...p, username: e.target.value }))}
                  placeholder={t.username}
                  className="w-full themed-input rounded-xl px-4 py-3 focus:outline-none focus:border-[#00E5FF] border"
                  autoComplete="username"
                  required />
              </div>
              <div>
                <label className="text-sm mb-2 block themed-text-secondary">{t.password}</label>
                <input type="password" value={loginForm.password}
                  onChange={e => setLoginForm(p => ({ ...p, password: e.target.value }))}
                  placeholder={t.password}
                  className="w-full themed-input rounded-xl px-4 py-3 focus:outline-none focus:border-[#00E5FF] border"
                  autoComplete="current-password"
                  required />
              </div>
              {loginError && (
                <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}
                  className="bg-[#D72631]/10 border border-[#B71C25] rounded-xl p-3 flex items-center gap-2">
                  <AlertCircle size={16} className="text-[#D72631]" />
                  <p className="text-sm text-[#D72631]">{loginError}</p>
                </motion.div>
              )}

              <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }} type="submit"
                disabled={loginLoading}
                className="w-full bg-gradient-to-r from-[#0097A8] to-[#00E5FF] text-white py-4 rounded-xl font-bold text-lg shadow-lg disabled:opacity-60">
                {loginLoading ? '...' : t.login}
              </motion.button>
            </form>
            <p className="text-xs text-center mt-8 themed-text-tertiary">{t.versionInfo}</p>
          </motion.div>
        </div>
      </div>
    );
  }

  // ─── MAIN APP ─────────────────────────────────────────────────────────────

  return (
    <div className={`min-h-screen flex items-center justify-center ${effectiveTheme === 'light' ? 'theme-light' : ''}`}
      style={{ backgroundColor: 'var(--theme-bg)', color: 'var(--theme-text)' }}>
      <div id="app-container" className="w-full max-w-[420px] min-h-screen overflow-hidden relative flex flex-col"
        style={{ backgroundColor: 'var(--theme-bg-secondary)' }}>

        {/* Offline banner */}
        <AnimatePresence>
          {!isOnline && (
            <motion.div initial={{ y: -50, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: -50, opacity: 0 }}
              className="absolute top-0 left-0 right-0 bg-yellow-600 text-white text-center py-1.5 text-xs font-semibold z-50">
              Sin conexión - Modo offline
            </motion.div>
          )}
        </AnimatePresence>

        {/* Loading overlay */}
        <AnimatePresence>
          {dataLoading && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="absolute inset-0 z-50 flex items-center justify-center"
              style={{ backgroundColor: 'var(--theme-bg-secondary)' }}>
              <div className="flex flex-col items-center gap-3">
                <div className="w-10 h-10 border-4 border-[#00E5FF] border-t-transparent rounded-full animate-spin" />
                <p className="text-sm themed-text-secondary">Cargando datos...</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Barra reportes abiertos */}
        {openReportsCount > 0 && (
          <div className="mx-4 mt-2 p-3 rounded-xl flex items-center justify-between" style={{background: '#3b82f620', border: '1px solid #3b82f650'}}>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-[#3b82f6] animate-pulse" />
              <span className="text-xs font-medium" style={{color: '#3b82f6'}}>{openReportsCount} {openReportsCount === 1 ? 'reporte abierto' : 'reportes abiertos'}</span>
            </div>
            <button onClick={() => setCurrentScreen('reports')} className="text-xs font-bold" style={{color: '#00E5FF'}}>Ver</button>
          </div>
        )}
        {/* Screens */}
        <div className="flex-1 pb-16 overflow-hidden">
          <AnimatePresence mode="wait">
            {currentScreen === 'home' && (
              <Home key="home"
                user={user} t={t} alerts={alerts} criticalAlert={criticalAlert}
                reports={reports} openReportsCount={openReportsCount}
                closedThisMonth={closedThisMonth} unreadCount={unreadCount}
                onNavigateNotifications={() => setCurrentScreen('notifications')}
                onNavigateReports={() => setCurrentScreen('reports')}
                onOpenCreateReport={() => setActiveModal('create')}
                onNavigateTalks={() => setCurrentScreen('talks')}
              />
            )}
            {currentScreen === 'reports' && (
              <Reports key="reports"
                t={t} reports={reports} filteredReports={filteredReports}
                reportFilter={reportFilter} openReportsCount={openReportsCount}
                onFilterChange={setReportFilter}
                onSelectReport={r => { setSelectedReport(r); setActiveModal('detail'); }}
                onOpenCreateReport={() => setActiveModal('create')}
                onNavigateTalks={() => setCurrentScreen('talks')}
                getStatusLabel={getStatusLabel}
              />
            )}
            {currentScreen === 'notifications' && (
              <Notifications key="notifications"
                t={t} notifications={notifications}
                alerts={rawAlerts.map(alertToNotification)}
                onMarkAllRead={markAllRead}
              />
            )}
            {currentScreen === 'manage' && (
              <ManageIncidents key="manage"
                userId={user.user_id}
                userRole={user.role}
                userArea={user.area}
                userAreas={user.assigned_areas}
                reportsApi={import.meta.env.VITE_REPORTS_API_URL || 'http://localhost:8102'}
              />
            )}
            {currentScreen === 'talks' && (
              <SafetyTalksMobile key="talks"
                onBack={() => setCurrentScreen('home')}
                userRole={user.role}
              />
            )}
            {currentScreen === 'profile' && (
              <Profile key="profile"
                t={t} user={user}
                reports={reports}
                onEditProfile={() => {
                  setEditProfileForm({
                    name: user.name,
                    lastName: user.lastName,
                    profilePhoto: user.profilePhoto,
                  });
                  setProfilePhotoFile(null);
                  setActiveModal('editProfile');
                }}
                onNotificationSettings={() => setActiveModal('notificationSettings')}
                onAssignedAreas={() => setActiveModal('assignedAreas')}
                onHelp={() => setActiveModal('help')}
                onGeneralSettings={() => setActiveModal('generalSettings')}
                onLogout={handleLogout}
              />
            )}
          </AnimatePresence>
        </div>

        {/* Bottom Nav */}
        <div className="themed-nav fixed bottom-0 left-0 right-0 max-w-[420px] mx-auto h-16 border-t flex items-center justify-around px-6 z-30">
          {([
            { id: 'home' as const, icon: HomeIcon, label: t.home },
            { id: 'reports' as const, icon: FileText, label: t.reportsList },
            { id: 'notifications' as const, icon: Bell, label: t.alerts, badge: unreadCount },
            ...(['supervisor', 'jefe de area', 'admin', 'sso_manager'].includes(user.role) ? [{ id: 'manage' as const, icon: Briefcase, label: 'Gestionar', badge: 0 }] : []),
            { id: 'profile' as const, icon: User, label: t.profile },
          ]).map(item => (
            <button key={item.id} onClick={() => setCurrentScreen(item.id)}
              className="flex flex-col items-center gap-0.5 relative min-w-[60px]">
              <div className="relative">
                <item.icon size={22} strokeWidth={currentScreen === item.id ? 2.5 : 2}
                  className={currentScreen === item.id ? 'text-[#00C2DB]' : 'themed-text-tertiary'} />
                {item.badge && item.badge > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 bg-[#D72631] text-white text-[9px] min-w-[16px] h-4 rounded-full flex items-center justify-center font-bold px-1">
                    {item.badge}
                  </span>
                )}
              </div>
            </button>
          ))}
        </div>

        {/* ── MODAL: CREAR REPORTE ──────────────────────────────────────────── */}
        <AnimatePresence>
          {activeModal === 'create' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="themed-modal-backdrop absolute inset-0 z-50 flex items-end"
              onClick={() => { setActiveModal(null); resetNewReport(); }}>
              <motion.div initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }}
                transition={{ type: 'spring', damping: 30 }}
                onClick={e => e.stopPropagation()}
                className="w-full max-w-[420px] mx-auto themed-bg-secondary rounded-t-3xl max-h-[90%] overflow-y-auto"
                style={{ backgroundColor: 'var(--theme-bg-secondary)', color: 'var(--theme-text)' }}>
                <div className="sticky top-0 themed-bg-secondary border-b themed-border px-6 py-4 flex items-center justify-between z-10">
                  <button onClick={() => { setActiveModal(null); resetNewReport(); }} className="themed-text-secondary"><X size={24} /></button>
                  <h2 className="text-lg font-bold">{t.newReport}</h2>
                  <button onClick={handleCreateReport}
                    disabled={submitLoading || wizardStep < 5}
                    className="bg-[#00E5FF] text-sm px-4 py-2 rounded-full font-bold disabled:opacity-50">
                    {submitLoading ? '...' : t.send}
                  </button>
                </div>
                <div className="px-6 py-6">
                  {/* === NUEVO FLUJO DE REPORTE === */}

                  {/* PASO 0: 3 Tarjetas principales */}
                  {wizardStep === 0 && (
                    <div className="space-y-3">
                      <div className="themed-card border rounded-2xl p-4 text-center mb-2">
                        <h3 className="text-lg font-bold">Que quieres reportar?</h3>
                        <p className="text-sm themed-text-secondary">Selecciona la opcion que mejor representa lo que observaste</p>
                      </div>

                      {/* Aviso condicion insegura */}
                      <div className="rounded-2xl border border-[#3b82f6]/30 bg-[#3b82f6]/5 p-4 flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-[#3b82f6]/15 flex items-center justify-center flex-shrink-0">
                          <AlertCircle size={20} className="text-[#3b82f6]" />
                        </div>
                        <div>
                          <p className="text-sm font-medium text-[#3b82f6]">Condicion insegura?</p>
                          <p className="text-xs" style={{color:'#888'}}>Las condiciones inseguras se derivan a Fracttal / TPM</p>
                        </div>
                      </div>

                      <button onClick={() => setWizardStep(1)}
                        className="w-full rounded-2xl border-2 border-[#E8941A] bg-[#E8941A]/5 p-5 text-left hover:bg-[#E8941A]/15 transition-all">
                        <div className="flex items-start gap-4">
                          <div className="w-14 h-14 rounded-xl bg-[#E8941A]/15 flex items-center justify-center flex-shrink-0">
                            <AlertTriangle size={28} className="text-[#E8941A]" />
                          </div>
                          <div className="flex-1">
                            <p className="text-base font-bold">Una persona actuo de forma insegura</p>
                            <p className="text-xs themed-text-secondary mt-1">Ejemplo: no uso EPP, cruzo una zona restringida o realizo una tarea insegura</p>
                            <span className="inline-flex items-center gap-1 mt-2 text-xs bg-[#E8941A]/15 text-[#E8941A] px-3 py-1 rounded-full font-medium">
                              <CheckCircle size={12} /> Se reporta aqui
                            </span>
                          </div>
                        </div>
                      </button>



                      <button onClick={() => setWizardStep(2)}
                        className="w-full rounded-2xl border-2 border-[#16A34A] bg-[#16A34A]/5 p-5 text-left hover:bg-[#16A34A]/15 transition-all">
                        <div className="flex items-start gap-4">
                          <div className="w-14 h-14 rounded-xl bg-[#16A34A]/15 flex items-center justify-center flex-shrink-0">
                            <CheckCircle size={28} className="text-[#16A34A]" />
                          </div>
                          <div className="flex-1">
                            <p className="text-base font-bold">Quiero reconocer una buena practica de seguridad</p>
                            <p className="text-xs themed-text-secondary mt-1">Ejemplo: detener una tarea insegura, corregir un riesgo o actuar preventivamente</p>
                            <span className="inline-flex items-center gap-1 mt-2 text-xs bg-[#16A34A]/15 text-[#16A34A] px-3 py-1 rounded-full font-medium">
                              <CheckCircle size={12} /> Reconocimiento
                            </span>
                          </div>
                        </div>
                      </button>

                      <p className="text-xs themed-text-secondary text-center mt-2">El analisis y la clasificacion final se realizan despues</p>
                    </div>
                  )}

                  {/* PASO 1: Reportar conducta insegura - formulario completo */}
                  {wizardStep === 1 && (
                    <div className="space-y-4">
                      <div className="mb-2">
                        <h3 className="text-xl font-bold">Reportar conducta insegura</h3>
                        <p className="text-sm themed-text-secondary">Completa la informacion observada</p>
                      </div>

                      <p className="text-xs font-bold themed-text-secondary uppercase tracking-wide">Seccion 1: Datos del reporte</p>

                      {/* Donde ocurrio */}
                      <button onClick={() => {}} className="w-full themed-card border rounded-xl p-4 flex items-center gap-3 text-left">
                        <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center flex-shrink-0">
                          <MapPin size={20} className="themed-text-secondary" />
                        </div>
                        <div className="flex-1">
                          <p className="text-sm font-medium">Donde ocurrio?</p>
                          <select value={newReport.area} onChange={e => setNewReport(p => ({...p, area: e.target.value}))}
                            className="w-full mt-1 bg-[#0B2E36] border border-[#00E5FF]/30 rounded-lg px-3 py-2 text-sm text-white" onClick={e => e.stopPropagation()}>
                            <option value="" style={{color:"#999"}}>Area / linea / equipo / sector</option>
                            {INCIDENT_AREAS.map(a => <option key={a} value={a}>{a}</option>)}
                          </select>
                        </div>
                      </button>

                      {/* Tipo de trabajador */}
                      <div className="themed-card border rounded-xl p-4">
                        <p className="text-sm font-medium mb-2">Tipo de trabajador</p>
                        <select value={newReport.worker_type} onChange={e => setNewReport(p => ({...p, worker_type: e.target.value}))} className="w-full bg-[#0B2E36] border border-[#00E5FF]/30 rounded-lg px-3 py-2 text-sm text-white">
                          <option value="planta">Planta (interno)</option>
                          <option value="externo">Externo</option>

                        </select>
                      </div>

                      {/* Subir imagen */}
                      <input ref={fileInputRef} type="file" accept="image/*" capture="environment" onChange={handlePhotoCapture} className="hidden" />
                      <button onClick={() => fileInputRef.current?.click()}
                        className="w-full themed-card border rounded-xl p-4 flex items-center gap-3 text-left overflow-hidden">
                        <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center flex-shrink-0">
                          <span className="text-xl font-bold themed-text-secondary">+</span>
                        </div>
                        <div className="flex-1">
                          <p className="text-sm font-medium">Subir imagen</p>
                          <p className="text-xs themed-text-secondary">Foto opcional</p>
                        </div>
                        {newReport.photoPreview && <img src={newReport.photoPreview} alt="Preview" className="w-12 h-12 rounded-lg object-cover" />}
                      </button>

                      {/* Pudo generar lesion grave */}
                      <div className="themed-card border rounded-xl p-4">
                        <p className="text-sm font-medium mb-3">Pudo generar una lesion grave o fatal?</p>
                        <div className="grid grid-cols-3 gap-2">
                          <button onClick={() => setNewReport(p => ({...p, isIAP: true}))}
                            className={"py-3 rounded-lg border-2 text-sm font-medium transition-all " + (newReport.isIAP === true ? "bg-[#D72631]/20 border-[#D72631] text-[#D72631]" : "bg-secondary border-border text-foreground")}>
                            Si
                          </button>
                          <button onClick={() => setNewReport(p => ({...p, isIAP: false}))}
                            className={"py-3 rounded-lg border-2 text-sm font-medium transition-all " + (newReport.isIAP === false ? "bg-[#00E5FF]/20 border-[#00E5FF] text-[#00E5FF]" : "bg-secondary border-border text-foreground")}>
                            No
                          </button>
                          <button onClick={() => setNewReport(p => ({...p, isIAP: true}))}
                            className="py-3 rounded-lg border-2 text-sm font-medium bg-secondary border-border text-foreground">
                            No estoy seguro
                          </button>
                        </div>
                        {newReport.isIAP && (
                          <div className="mt-3 p-3 bg-[#D72631]/10 rounded-lg flex items-start gap-2">
                            <AlertTriangle size={16} className="text-[#D72631] flex-shrink-0 mt-0.5" />
                            <p className="text-xs text-[#D72631]">Si respondes "Si" o "No estoy seguro", queda marcado para revision prioritaria</p>
                          </div>
                        )}
                      </div>

                      {/* Medida inmediata - solo si IAP */}
                      {newReport.isIAP && (
                      <button onClick={() => {}} className="w-full themed-card border rounded-xl p-4 flex items-center gap-3 text-left">
                        <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center flex-shrink-0">
                          <CheckCircle size={20} className="themed-text-secondary" />
                        </div>
                        <div className="flex-1">
                          <p className="text-sm font-medium">Que medida inmediata se tomo?</p>
                          <input type="text" value={feedbackText} onChange={e => setFeedbackText(e.target.value)}
                            placeholder="Ej: detener el trabajo, corregir la conducta" style={{color:"#999"}}
                            className="w-full mt-1 bg-[#0B2E36] border border-[#00E5FF]/30 rounded-lg px-3 py-2 text-sm text-white outline-none" onClick={e => e.stopPropagation()} />
                        </div>
                      </button>
                      )}

                      

                      {/* Descripcion */}
                      <div className="themed-card border rounded-xl p-4">
                        <div className="flex items-start gap-3">
                          <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center flex-shrink-0">
                            <FileText size={20} className="themed-text-secondary" />
                          </div>
                          <div className="flex-1">
                            <p className="text-sm font-medium">Describa lo observado</p>
                            <p className="text-xs themed-text-secondary mb-2">Nombre de la persona observada, tarea realizada y desvio detectado</p>
                            <textarea value={newReport.description} onChange={e => setNewReport(p => ({...p, description: e.target.value}))}
                              placeholder="Ej: Juanito Perez realiza apriete de tuerca sin usar guantes."
                              className="w-full bg-[#0B2E36] border border-[#00E5FF]/30 rounded-lg px-3 py-2 text-sm resize-none h-20 outline-none text-white" />
                          </div>
                        </div>
                      </div>

                      <button onClick={() => { setAutoClassification(newReport.isIAP ? 'IAP' : 'Acto Inseguro'); setNewReport(p => ({...p, type: 'unsafe_act'})); handleCreateReport(); }}
                        disabled={!newReport.area || !newReport.description || submitLoading}
                        className="w-full bg-gradient-to-r from-[#0097A8] to-[#00E5FF] text-white py-4 rounded-2xl font-bold text-lg disabled:opacity-50">
                        {submitLoading ? 'Enviando...' : 'Enviar reporte'}
                      </button>
                      <button onClick={() => { setWizardStep(0); resetNewReport(); }}
                        className="w-full themed-card border py-3 rounded-2xl font-bold">Atras</button>
                    </div>
                  )}

                  {/* PASO 2: Buena practica - reconocimiento */}
                  {wizardStep === 2 && (
                    <div className="space-y-4">
                      <div className="mb-2">
                        <h3 className="text-xl font-bold">Reconocer buena practica</h3>
                        <p className="text-sm themed-text-secondary">Comparte una accion positiva</p>
                      </div>

                      <p className="text-xs font-bold themed-text-secondary uppercase tracking-wide">Seccion 1: Reconocimiento</p>

                      {/* Donde ocurrio */}
                      <button onClick={() => {}} className="w-full themed-card border rounded-xl p-4 flex items-center gap-3 text-left">
                        <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center flex-shrink-0">
                          <MapPin size={20} className="themed-text-secondary" />
                        </div>
                        <div className="flex-1">
                          <p className="text-sm font-medium">Donde ocurrio?</p>
                          <select value={newReport.area} onChange={e => setNewReport(p => ({...p, area: e.target.value}))}
                            className="w-full mt-1 bg-[#0B2E36] border border-[#00E5FF]/30 rounded-lg px-3 py-2 text-sm text-white" onClick={e => e.stopPropagation()}>
                            <option value="" style={{color:"#999"}}>Area / linea / equipo / sector</option>
                            {INCIDENT_AREAS.map(a => <option key={a} value={a}>{a}</option>)}
                          </select>
                        </div>
                      </button>

                      {/* Describa buena practica */}
                      <div className="themed-card border rounded-xl p-4">
                        <p className="text-sm font-medium mb-2">Describa la buena practica</p>
                        <textarea value={newReport.description} onChange={e => setNewReport(p => ({...p, description: e.target.value}))}
                          placeholder="Que accion positiva observo..."
                          className="w-full bg-[#0B2E36] border border-[#00E5FF]/30 rounded-lg px-3 py-2 text-sm resize-none h-20 outline-none text-white" />
                      </div>

                      {/* Nombre de la persona */}
                      <div className="themed-card border rounded-xl p-4 flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center flex-shrink-0">
                          <User size={20} className="themed-text-secondary" />
                        </div>
                        <div className="flex-1">
                          <p className="text-sm font-medium">Nombre de la persona</p>
                          <input type="text" value={feedbackText} onChange={e => setFeedbackText(e.target.value)}
                            placeholder="Nombre completo"
                            className="w-full mt-1 bg-[#0B2E36] border border-[#00E5FF]/30 rounded-lg px-3 py-2 text-sm text-white outline-none" />
                        </div>
                      </div>

                      {/* Equipo */}
                      <div className="themed-card border rounded-xl p-4 flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center flex-shrink-0">
                          <Users size={20} className="themed-text-secondary" />
                        </div>
                        <div className="flex-1">
                          <p className="text-sm font-medium">Equipo al que pertenece</p>
                          <input type="text"
                            placeholder="Ej: Mantenimiento, Operaciones, Logistica"
                            className="w-full mt-1 bg-[#0B2E36] border border-[#00E5FF]/30 rounded-lg px-3 py-2 text-sm text-white outline-none" />
                        </div>
                      </div>

                      {/* Subir imagen */}
                      <input ref={fileInputRef} type="file" accept="image/*" capture="environment" onChange={handlePhotoCapture} className="hidden" />
                      <button onClick={() => fileInputRef.current?.click()}
                        className="w-full themed-card border rounded-xl p-4 flex items-center gap-3 text-left overflow-hidden">
                        <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center flex-shrink-0">
                          <span className="text-xl font-bold themed-text-secondary">+</span>
                        </div>
                        <div className="flex-1">
                          <p className="text-sm font-medium">Subir imagen</p>
                          <p className="text-xs themed-text-secondary">Foto opcional</p>
                        </div>
                        {newReport.photoPreview && <img src={newReport.photoPreview} alt="Preview" className="w-12 h-12 rounded-lg object-cover" />}
                      </button>

                      <button onClick={() => { setAutoClassification('Buena Practica'); handleCreateReport(); }}
                        disabled={!newReport.description || submitLoading}
                        className="w-full bg-[#16A34A] text-white py-4 rounded-2xl font-bold text-lg disabled:opacity-50">
                        {submitLoading ? 'Enviando...' : 'Enviar reconocimiento'}
                      </button>
                      <button onClick={() => { setWizardStep(0); resetNewReport(); }}
                        className="w-full themed-card border py-3 rounded-2xl font-bold">Atras</button>
                    </div>
                  )}

                </div>
              </motion.div>
            </motion.div>
          )}
                </AnimatePresence>
        {/* ── MODAL: DETALLE ────────────────────────────────────────────────── */}
        <AnimatePresence>
          {activeModal === 'detail' && selectedReport && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="themed-modal-backdrop absolute inset-0 z-50" onClick={() => setActiveModal(null)}>
              <motion.div initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }}
                transition={{ type: 'spring', damping: 30 }}
                onClick={e => e.stopPropagation()}
                className="absolute inset-x-0 top-11 bottom-0 max-w-[420px] mx-auto themed-bg-secondary rounded-t-3xl overflow-y-auto">
                <div className="sticky top-0 themed-bg-secondary border-b themed-border px-6 py-4 flex items-center gap-4 z-10">
                  <button onClick={() => setActiveModal(null)} className="themed-text-secondary"><ChevronLeft size={24} /></button>
                  <h2 className="text-lg font-bold">#{getReportDisplayId(selectedReport)}</h2>
                  <span className={`ml-auto text-xs px-3 py-1 rounded-full ${getStatusColor(selectedReport.status)}`}>
                    {getStatusLabel(selectedReport.status)}
                  </span>
                </div>
                <div className="px-6 py-6 space-y-6">
                  <div className="w-full h-48 themed-photo-placeholder rounded-2xl overflow-hidden flex items-center justify-center text-6xl">
                    {getReportEvidenceUrl(selectedReport)
                      ? (
                        <img
                          src={getReportEvidenceUrl(selectedReport) || ''}
                          alt="Evidencia"
                          className="w-full h-full object-cover"
                          onError={(e) => {
                            e.currentTarget.style.display = 'none';
                            const parent = e.currentTarget.parentElement;
                            if (parent) parent.textContent = '📸';
                          }}
                        />
                      )
                      : '📸'}
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div><p className="text-sm themed-text-secondary">Fecha</p><p className="font-semibold">{formatReportDate(selectedReport.created_at)}</p></div>
                    <div><p className="text-sm themed-text-secondary">{t.area}</p><p className="font-semibold">{selectedReport.area_id}</p></div>
                    <div><p className="text-sm themed-text-secondary">Tipo</p><p className="font-semibold">{selectedReport.type === 'unsafe_act' ? t.unsafeAct : t.unsafeCondition}</p></div>
                    <div><p className="text-sm themed-text-secondary">IAP</p><p className="font-semibold">{selectedReport.is_iap ? 'Sí' : 'No'}</p></div>
                  </div>
                  <div>
                    <h3 className="font-bold mb-4">
                      Seguimiento del reporte
                    </h3>

                    <div className="space-y-4">
                      {getWorkerReportTimelineSteps(
                        selectedReport,
                      ).map((step, i, steps) => (
                        <div
                          key={step.key}
                          className="flex gap-3"
                        >
                          <div className="flex flex-col items-center">
                            <div
                              className="w-4 h-4 rounded-full"
                              style={{
                                backgroundColor:
                                  step.active
                                    ? step.color
                                    : '#334155',
                              }}
                            />

                            {i < steps.length - 1 && (
                              <div
                                className="w-0.5 h-8"
                                style={{
                                  backgroundColor:
                                    step.active
                                      ? step.color
                                      : '#334155',
                                }}
                              />
                            )}
                          </div>

                          <div className="flex-1 pb-4">
                            <div className="flex items-center gap-2">
                              <p
                                className={
                                  `font-semibold ${
                                    step.active
                                      ? ''
                                      : 'themed-text-tertiary'
                                  }`
                                }
                              >
                                {step.label}
                              </p>

                              {step.current && (
                                <span
                                  className="text-[10px] px-2 py-0.5 rounded-full"
                                  style={{
                                    background:
                                      step.color + '20',
                                    color: step.color,
                                  }}
                                >
                                  Actual
                                </span>
                              )}
                            </div>

                            {step.timestamp && (
                              <p className="text-xs themed-text-secondary mt-1">
                                {formatWorkerReportTimelineTimestamp(
                                  step.timestamp,
                                )}
                              </p>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  {selectedReport.feedback && (
                    <div className="themed-card border rounded-2xl p-4">
                      <p className="text-sm themed-text-secondary mb-2">Feedback del Supervisor</p>
                      <p className="text-sm">{selectedReport.feedback}</p>
                    </div>
                  )}
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ── MODAL: EDITAR PERFIL ──────────────────────────────────────────── */}
        <AnimatePresence>
          {activeModal === 'editProfile' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="themed-modal-backdrop absolute inset-0 z-50 flex items-end" onClick={() => setActiveModal(null)}>
              <motion.div initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }}
                transition={{ type: 'spring', damping: 30 }}
                onClick={e => e.stopPropagation()}
                className="w-full max-w-[420px] mx-auto themed-bg-secondary rounded-t-3xl max-h-[90%] overflow-y-auto"
                style={{ backgroundColor: 'var(--theme-bg-secondary)', color: 'var(--theme-text)' }}>
                <div className="sticky top-0 themed-bg-secondary border-b themed-border px-6 py-4 flex items-center justify-between z-10">
                  <button onClick={() => setActiveModal(null)} className="themed-text-secondary"><ChevronLeft size={24} /></button>
                  <h2 className="text-lg font-bold">{t.editProfile}</h2>
                  <button onClick={handleSaveProfile} className="bg-[#00E5FF] text-sm px-4 py-2 rounded-full font-bold">{t.save}</button>
                </div>
                <div className="px-6 py-6 space-y-6">
                  <div className="flex flex-col items-center">
                    <div className="w-32 h-32 bg-gradient-to-br from-[#0097A8] to-[#00E5FF] rounded-full flex items-center justify-center text-4xl font-bold mb-4 overflow-hidden">
                      {editProfileForm.profilePhoto
                        ? <img src={editProfileForm.profilePhoto} alt="Profile" className="w-full h-full object-cover" />
                        : `${editProfileForm.name[0] ?? ''}${editProfileForm.lastName[0] ?? ''}`.toUpperCase()}
                    </div>
                    <input ref={profilePhotoInputRef} type="file" accept="image/jpeg,image/png,image/webp" onChange={handleProfilePhotoChange} className="hidden" />
                    <button onClick={() => profilePhotoInputRef.current?.click()}
                      className="themed-card border rounded-xl px-4 py-2 text-sm">{t.changePhoto}</button>
                  </div>
                  {(['name', 'lastName'] as const).map(key => (
                    <div key={key}>
                      <label className="text-sm themed-text-secondary mb-2 block">
                        {key === 'name' ? t.firstName : t.lastName}
                      </label>
                      <input type="text" value={editProfileForm[key] ?? ''}
                        onChange={e => setEditProfileForm(p => ({ ...p, [key]: e.target.value }))}
                        className="w-full themed-card border rounded-xl px-4 py-3" />
                    </div>
                  ))}
                  <div>
                    <label className="text-sm themed-text-secondary mb-2 block">{t.email} ({t.readOnly})</label>
                    <input type="email" value={user.email} disabled className="w-full themed-card border rounded-xl px-4 py-3 themed-text-tertiary cursor-not-allowed" />
                  </div>
                  <div>
                    <label className="text-sm themed-text-secondary mb-2 block">{t.employeeId} ({t.readOnly})</label>
                    <input type="text" value={user.employeeId} disabled className="w-full themed-card border rounded-xl px-4 py-3 themed-text-tertiary cursor-not-allowed" />
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ── MODAL: NOTIFICACIONES ─────────────────────────────────────────── */}
        <AnimatePresence>
          {activeModal === 'notificationSettings' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="themed-modal-backdrop absolute inset-0 z-50 flex items-end" onClick={() => setActiveModal(null)}>
              <motion.div initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }}
                transition={{ type: 'spring', damping: 30 }}
                onClick={e => e.stopPropagation()}
                className="w-full max-w-[420px] mx-auto themed-bg-secondary rounded-t-3xl max-h-[90%] overflow-y-auto"
                style={{ backgroundColor: 'var(--theme-bg-secondary)', color: 'var(--theme-text)' }}>
                <div className="sticky top-0 themed-bg-secondary border-b themed-border px-6 py-4 flex items-center justify-between z-10">
                  <button onClick={() => setActiveModal(null)} className="themed-text-secondary"><ChevronLeft size={24} /></button>
                  <h2 className="text-lg font-bold">{t.configureNotifications}</h2>
                  <button onClick={handleSaveNotificationSettings} className="bg-[#00E5FF] text-sm px-4 py-2 rounded-full font-bold">{t.save}</button>
                </div>
                <div className="px-6 py-6 space-y-4">
                  {([
                    { key: 'criticalAlerts', label: t.criticalAlerts, desc: t.criticalAlertsDesc },
                    { key: 'reportUpdates', label: t.reportUpdates, desc: t.reportUpdatesDesc },
                    { key: 'shiftReminders', label: t.shiftReminders, desc: t.shiftRemindersDesc },
                    { key: 'comments', label: t.commentNotifications, desc: t.commentNotificationsDesc },
                  ] as const).map(({ key, label, desc }) => (
                    <div key={key} className="themed-card border rounded-2xl p-4 flex items-center justify-between">
                      <div className="flex-1"><p className="font-semibold">{label}</p><p className="text-xs themed-text-secondary">{desc}</p></div>
                      <button onClick={() => setNotificationSettings(p => ({ ...p, [key]: !p[key] }))}
                        className={`w-12 h-6 rounded-full relative transition-colors ${notificationSettings[key] ? 'bg-[#00E5FF]' : 'themed-toggle-inactive'}`}>
                        <div className={`absolute top-0.5 w-5 h-5 bg-white rounded-full transition-transform ${notificationSettings[key] ? 'translate-x-6' : 'translate-x-0.5'}`}></div>
                      </button>
                    </div>
                  ))}
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ── MODAL: ÁREAS ASIGNADAS ────────────────────────────────────────── */}
        <AnimatePresence>
          {activeModal === 'assignedAreas' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="themed-modal-backdrop absolute inset-0 z-50 flex items-end" onClick={() => setActiveModal(null)}>
              <motion.div initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }}
                transition={{ type: 'spring', damping: 30 }}
                onClick={e => e.stopPropagation()}
                className="w-full max-w-[420px] mx-auto themed-bg-secondary rounded-t-3xl max-h-[90%] overflow-y-auto"
                style={{ backgroundColor: 'var(--theme-bg-secondary)', color: 'var(--theme-text)' }}>
                <div className="sticky top-0 themed-bg-secondary border-b themed-border px-6 py-4 flex items-center justify-between z-10">
                  <button onClick={() => setActiveModal(null)} className="themed-text-secondary"><ChevronLeft size={24} /></button>
                  <h2 className="text-lg font-bold">{t.myAssignedAreas}</h2>
                  <div className="w-16"></div>
                </div>
                <div className="px-6 py-6 space-y-4">
                  {user.assigned_areas.length === 0 ? (
                    <p className="themed-text-secondary text-sm text-center py-8">
                      No tienes áreas asignadas aún.
                    </p>
                  ) : (
                    user.assigned_areas.map((area, i) => (
                      <motion.div key={i}
                        initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: i * 0.1 }}
                        className="themed-card border rounded-2xl p-4">
                        <h3 className="font-bold text-lg">{area}</h3>
                      </motion.div>
                    ))
                  )}
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ── MODAL: AYUDA ──────────────────────────────────────────────────── */}
        <AnimatePresence>
          {activeModal === 'help' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="themed-modal-backdrop absolute inset-0 z-50 flex items-end" onClick={() => setActiveModal(null)}>
              <motion.div initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }}
                transition={{ type: 'spring', damping: 30 }}
                onClick={e => e.stopPropagation()}
                className="w-full max-w-[420px] mx-auto themed-bg-secondary rounded-t-3xl max-h-[90%] overflow-y-auto"
                style={{ backgroundColor: 'var(--theme-bg-secondary)', color: 'var(--theme-text)' }}>
                <div className="sticky top-0 themed-bg-secondary border-b themed-border px-6 py-4 flex items-center justify-between z-10">
                  <button onClick={() => setActiveModal(null)} className="themed-text-secondary"><ChevronLeft size={24} /></button>
                  <h2 className="text-lg font-bold">{t.helpSupport}</h2>
                  <div className="w-16"></div>
                </div>
                <div className="px-6 py-6 space-y-6">
                  <div>
                    <h3 className="font-bold text-lg mb-4">{t.faqs}</h3>
                    <div className="space-y-3">
                      {[{ q: t.faq1Q, a: t.faq1A }, { q: t.faq2Q, a: t.faq2A }, { q: t.faq3Q, a: t.faq3A }].map(({ q, a }, i) => (
                        <div key={i} className="themed-card border rounded-2xl p-4">
                          <p className="font-semibold mb-2">{q}</p>
                          <p className="text-sm themed-text-secondary">{a}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div>
                    <h3 className="font-bold text-lg mb-4">{t.contactSupport}</h3>
                    <a href={`mailto:${t.supportEmail}`} className="flex items-center gap-3 themed-card border rounded-2xl p-4">
                      <div className="bg-[#00E5FF] rounded-full p-2"><Send size={20} /></div>
                      <div><p className="font-semibold">Email</p><p className="text-sm themed-text-secondary">{t.supportEmail}</p></div>
                    </a>
                  </div>
                  <div>
                    <h3 className="font-bold text-lg mb-4">{t.quickGuide}</h3>
                    <div className="bg-gradient-to-br from-[#0097A8]/20 to-[#00C2DB]/10 border border-[#0097A8]/50 rounded-2xl p-4 space-y-2">
                      {[t.guideStep1, t.guideStep2, t.guideStep3, t.guideStep4].map((s, i) =>
                        <p key={i} className="text-sm">{s}</p>)}
                    </div>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ── MODAL: CONFIGURACIÓN GENERAL ─────────────────────────────────── */}
        <AnimatePresence>
          {activeModal === 'generalSettings' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="themed-modal-backdrop absolute inset-0 z-50 flex items-end" onClick={() => setActiveModal(null)}>
              <motion.div initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }}
                transition={{ type: 'spring', damping: 30 }}
                onClick={e => e.stopPropagation()}
                className="w-full max-w-[420px] mx-auto themed-bg-secondary rounded-t-3xl max-h-[90%] overflow-y-auto"
                style={{ backgroundColor: 'var(--theme-bg-secondary)', color: 'var(--theme-text)' }}>
                <div className="sticky top-0 themed-bg-secondary border-b themed-border px-6 py-4 flex items-center justify-between z-10">
                  <button onClick={() => setActiveModal(null)} className="themed-text-secondary"><ChevronLeft size={24} /></button>
                  <h2 className="text-lg font-bold">{t.generalSettings}</h2>
                  <div className="w-16"></div>
                </div>
                <div className="px-6 py-6 space-y-6">
                  <div>
                    <label className="text-sm themed-text-secondary mb-3 block">{t.theme}</label>
                    <div className="grid grid-cols-3 gap-3">
                      {(['light', 'dark', 'system'] as const).map(th => (
                        <button key={th} onClick={() => setAppSettings(p => ({ ...p, theme: th }))}
                          className={`p-4 rounded-xl border-2 text-sm font-semibold ${appSettings.theme === th ? 'bg-[#00E5FF] border-[#00E5FF] text-white' : 'themed-btn-inactive themed-border'}`}>
                          {th === 'light' ? t.lightMode : th === 'dark' ? t.darkMode : t.systemMode}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="text-sm themed-text-secondary mb-3 block">{t.languageLabel}</label>
                    <select value={appSettings.language} onChange={e => setAppSettings(p => ({ ...p, language: e.target.value as 'es' | 'en' | 'fr' }))}
                      className="w-full themed-input border rounded-xl px-4 py-3">
                      <option value="es">🇪🇸 Español</option>
                      <option value="en">🇺🇸 English</option>
                      <option value="fr">🇫🇷 Français</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-sm themed-text-secondary mb-3 block">{t.cameraQualityLabel}</label>
                    <div className="grid grid-cols-3 gap-3">
                      {(['low', 'medium', 'high'] as const).map(q => (
                        <button key={q} onClick={() => setAppSettings(p => ({ ...p, cameraQuality: q }))}
                          className={`p-4 rounded-xl border-2 text-sm font-semibold ${appSettings.cameraQuality === q ? 'bg-[#00E5FF] border-[#00E5FF] text-white' : 'themed-btn-inactive themed-border'}`}>
                          {q === 'low' ? t.qualityLow : q === 'medium' ? t.qualityMedium : t.qualityHigh}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <h3 className="text-sm themed-text-secondary mb-3">{t.offlineSync}</h3>
                    <div className="themed-card border rounded-2xl p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <p className="font-semibold">{t.pendingReports}</p>
                          <p className="text-sm themed-text-secondary">{pendingSyncCount} {t.pendingReports}</p>
                        </div>
                        <span className="text-2xl font-bold text-[#00C2DB]">{pendingSyncCount}</span>
                      </div>
                      <button onClick={handleForceSync} className="w-full bg-[#00E5FF] text-[#0B1E36] py-3 rounded-xl font-bold">
                        {t.forceSyncButton}
                      </button>
                    </div>
                  </div>
                  <div className="themed-card border rounded-2xl p-4 flex items-center justify-between">
                    <p className="text-sm themed-text-secondary">{t.appVersion}</p>
                    <p className="font-semibold">v1.0.0</p>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

      </div>
    </div>
  );

              <div className="mb-4">
                <p className="text-center text-xs themed-text-secondary mb-2">Acceso rapido (demo)</p>
                <div className="grid grid-cols-2 gap-2">
                  {DEMO_USERS.map(u => (
                    <button
                      key={`${u.clientId}:${u.email}`}
                      onClick={() =>
                        setLoginForm({
                          clientId: u.clientId,
                          username: u.email,
                          password: u.pass,
                        })
                      }
                      className="p-3 rounded-xl border-2 text-center" style={{ borderColor: u.color + '40', background: u.color + '10' }}>
                      <span className="text-xl font-bold" style={{ color: u.color }}>{u.icon}</span>
                      <p className="text-xs font-bold mt-1" style={{ color: u.color }}>{u.role}</p>
                    </button>
                  ))}
                </div>
              </div>
}
