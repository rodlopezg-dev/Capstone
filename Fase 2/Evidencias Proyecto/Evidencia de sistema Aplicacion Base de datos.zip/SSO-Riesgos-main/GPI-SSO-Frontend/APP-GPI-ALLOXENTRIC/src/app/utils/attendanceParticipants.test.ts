import { describe, expect, it } from 'vitest';
import { attendanceParticipants, filterParticipants, registrationDateLabel } from './attendanceParticipants';

describe('attendance participants', () => {
  it('preserves individual QR dates and matches entries by user id', () => {
    const rows = attendanceParticipants({
      attendance_id: 'att_qr_1', source: 'qr', attendees: ['Ana', 'Luis'],
      attended_user_ids: ['a', 'b'], attendance_entries: [
        { user_id: 'b', registered_at: '2026-10-07T14:30:00Z', method: 'qr' },
        { user_id: 'a', registered_at: '2026-10-07T14:00:00Z', method: 'qr' },
      ],
    });
    expect(rows.map(row => row.registeredAt)).toEqual(['2026-10-07T14:00:00Z', '2026-10-07T14:30:00Z']);
  });
  it('does not assign a QR entry to a legacy name without a user id', () => {
    const rows = attendanceParticipants({ attendance_id: 'att_1', attendees: ['Legacy', 'Ana'],
      attended_user_ids: ['a'], attendance_entries: [{ user_id: 'a', method: 'qr' }] });
    expect(rows.map(row => row.method)).toEqual(['manual', 'qr']);
  });
  it('counts only the participants matching each method without changing the original list', () => {
    const rows = attendanceParticipants({ attendance_id: 'att_1', attendees: ['Ana', 'Luis', 'Maria'],
      attendance_entries: [{ name: 'Ana', method: 'qr' }, { name: 'Luis', method: 'manual' }, { name: 'Maria', method: 'sheet' }] });
    expect(filterParticipants(rows, [])).toHaveLength(3);
    expect(filterParticipants(rows, ['qr']).map(row => row.name)).toEqual(['Ana']);
    expect(filterParticipants(rows, ['manual'])).toHaveLength(1);
    expect(filterParticipants(rows, ['sheet'])).toHaveLength(1);
    expect(rows).toHaveLength(3);
  });
  it('does not invent individual timestamps for manual records', () => {
    expect(attendanceParticipants({ attendance_id: 'att_1', source: 'manual', attendees: ['Ana'], date: '2026-10-07' })[0].registeredAt).toBeUndefined();
    expect(registrationDateLabel(undefined, '2026-10-07')).toBe('07-10-2026 · Sin hora individual registrada');
  });
  it('identifies sheet and unknown sources without counting attachments as people', () => {
    expect(attendanceParticipants({ attendance_id: 'sheet1', source: 'sheet', attendees: ['Ana'] })[0].method).toBe('sheet');
    expect(attendanceParticipants({ attendance_id: 'legacy', attendees: ['Ana'] })[0].method).toBe('unknown');
    expect(attendanceParticipants({ attendance_id: 'sheet1', source: 'sheet', attendees: [] })).toEqual([]);
  });
  it('handles invalid and missing dates without showing Invalid Date', () => {
    expect(registrationDateLabel('invalid')).toBe('Sin fecha y hora registradas');
    expect(registrationDateLabel()).toBe('Sin fecha y hora registradas');
  });
});
