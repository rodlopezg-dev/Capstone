"""JWT emission and refresh contract without a database or HTTP service."""

import os
import unittest
from datetime import timedelta
from unittest.mock import patch

import httpx

os.environ.setdefault("JWT_SECRET", "test-secret-for-auth-contract-0123456789")
os.environ.setdefault("INTERNAL_API_KEY", "test-internal-key")

from app.exceptions import InvalidCredentialsError, TokenInvalidError
from app.routers.auth import refresh
from app.repositories.user_api_repo import UserApiRepository
from app.schemas.auth import LoginRequest, RefreshRequest
from app.services.auth_service import AuthService


class FakeRepository:
    def __init__(self, status="active"):
        self.status = status
        self.role = "admin"
        self.client_id = "empresa_a"
        self.areas = ["Planta"]
        self.area = "Planta"
        self.unavailable = False
        self.lookups = []

    async def get_user_for_auth(self, client_id, email):
        return {
            "user_id": "user_a", "client_id": client_id, "role": "admin",
            "status": self.status, "hashed_password": "test-hash",
            "assigned_areas": [],
        }

    async def get_user_by_id(self, client_id, user_id):
        self.lookups.append((client_id, user_id))
        if self.unavailable:
            from fastapi import HTTPException
            raise HTTPException(503, "Users Service unavailable")
        if client_id != self.client_id:
            return None
        return {
            "user_id": user_id, "client_id": self.client_id,
            "role": self.role, "status": self.status,
            "assigned_areas": self.areas, "area": self.area,
        }


class JwtContractTests(unittest.IsolatedAsyncioTestCase):
    async def test_login_emits_explicit_access_and_refresh(self):
        service = AuthService(FakeRepository())
        with patch("app.services.auth_service.pwd_context.verify", return_value=True):
            response = await service.login_user(LoginRequest(
                client_id="empresa_a", email="a@example.com", password="secret"
            ))
        access = service.verify_token(response["access_token"])
        refresh_claims = service.verify_token(response["refresh_token"], check_refresh=True)
        self.assertEqual(access["type"], "access")
        self.assertEqual(refresh_claims["type"], "refresh")
        with self.assertRaises(TokenInvalidError):
            service.verify_token(response["refresh_token"])

    async def test_refresh_emits_access_and_rejects_incomplete_refresh(self):
        repo = FakeRepository()
        repo.areas = []
        repo.area = ""
        service = AuthService(repo)
        token = service.generate_jwt({
            "type": "refresh", "sub": "user_a", "role": "admin",
            "client_id": "empresa_a",
        }, timedelta(minutes=5))
        result = await refresh(RefreshRequest(refresh_token=token), service)
        self.assertEqual(service.verify_token(result.access_token)["type"], "access")
        self.assertEqual(repo.lookups, [("empresa_a", "user_a")])
        bad = service.generate_jwt({
            "type": "refresh", "sub": "user_a", "role": "admin",
            "client_id": "   ",
        }, timedelta(minutes=5))
        with self.assertRaises(TokenInvalidError):
            service.verify_token(bad, check_refresh=True)

    async def test_inactive_user_cannot_login(self):
        service = AuthService(FakeRepository(status="inactive"))
        with self.assertRaises(InvalidCredentialsError):
            await service.login_user(LoginRequest(
                client_id="empresa_a", email="a@example.com", password="secret"
            ))

    async def test_unknown_and_null_token_types_are_rejected(self):
        service = AuthService(FakeRepository())
        for token_type in ("other", None):
            token = service.generate_jwt({
                "type": token_type, "sub": "user_a", "role": "admin",
                "client_id": "empresa_a",
            }, timedelta(minutes=5))
            with self.assertRaises(TokenInvalidError):
                service.verify_token(token)

    async def test_refresh_rejects_deactivated_user(self):
        repo = FakeRepository()
        service = AuthService(repo)
        token = service.generate_jwt({
            "type": "refresh", "sub": "user_a", "role": "admin",
            "client_id": "empresa_a", "areas": ["Planta"], "area": "Planta",
        }, timedelta(minutes=5))
        repo.status = "inactive"
        with self.assertRaises(TokenInvalidError):
            await refresh(RefreshRequest(refresh_token=token), service)

    async def test_refresh_rejects_role_or_scope_change(self):
        for change in ("role", "areas", "area"):
            with self.subTest(change=change):
                repo = FakeRepository()
                service = AuthService(repo)
                token = service.generate_jwt({
                    "type": "refresh", "sub": "user_a", "role": "admin",
                    "client_id": "empresa_a", "areas": ["Planta"], "area": "Planta",
                }, timedelta(minutes=5))
                setattr(repo, change, {"role": "worker", "areas": ["Mina"], "area": "Mina"}[change])
                with self.assertRaises(TokenInvalidError):
                    await refresh(RefreshRequest(refresh_token=token), service)

    async def test_refresh_rejects_tenant_change(self):
        repo = FakeRepository()
        service = AuthService(repo)
        token = service.generate_jwt({
            "type": "refresh", "sub": "user_a", "role": "admin",
            "client_id": "empresa_a", "areas": ["Planta"], "area": "Planta",
        }, timedelta(minutes=5))
        repo.client_id = "empresa_b"
        with self.assertRaises(TokenInvalidError):
            await refresh(RefreshRequest(refresh_token=token), service)
        self.assertEqual(repo.lookups, [("empresa_a", "user_a")])

    async def test_refresh_fails_closed_when_users_service_unavailable(self):
        from fastapi import HTTPException
        repo = FakeRepository()
        repo.unavailable = True
        service = AuthService(repo)
        token = service.generate_jwt({
            "type": "refresh", "sub": "user_a", "role": "admin",
            "client_id": "empresa_a", "areas": ["Planta"], "area": "Planta",
        }, timedelta(minutes=5))
        with self.assertRaises(HTTPException) as error:
            await refresh(RefreshRequest(refresh_token=token), service)
        self.assertEqual(error.exception.status_code, 503)

    async def test_user_lookup_uses_authenticated_internal_route(self):
        requests = []

        def handler(request):
            requests.append(request)
            return httpx.Response(200, json={
                "user_id": "user_a", "client_id": "empresa_a", "role": "admin",
                "status": "active", "assigned_areas": [],
            })

        client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
        with patch("app.repositories.user_api_repo.httpx.AsyncClient", return_value=client):
            result = await UserApiRepository().get_user_by_id("empresa_a", "user_a")
        self.assertEqual(result["status"], "active")
        self.assertEqual(len(requests), 1)
        self.assertTrue(str(requests[0].url).endswith("/v1/internal/users/by-id"))
        self.assertEqual(requests[0].headers["X-Internal-Token"], "test-internal-key")
        self.assertEqual(requests[0].content, b'{"client_id":"empresa_a","user_id":"user_a"}')

    async def test_user_lookup_transport_failure_denies_refresh(self):
        from fastapi import HTTPException

        def handler(request):
            raise httpx.ConnectError("offline", request=request)

        client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
        with patch("app.repositories.user_api_repo.httpx.AsyncClient", return_value=client):
            with self.assertRaises(HTTPException) as error:
                await UserApiRepository().get_user_by_id("empresa_a", "user_a")
        self.assertEqual(error.exception.status_code, 503)


if __name__ == "__main__":
    unittest.main()
