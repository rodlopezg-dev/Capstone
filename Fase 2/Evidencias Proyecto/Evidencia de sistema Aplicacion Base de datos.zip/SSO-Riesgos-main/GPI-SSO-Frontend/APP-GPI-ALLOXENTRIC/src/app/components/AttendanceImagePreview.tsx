
import { useEffect, useMemo, useState } from 'react';

import {
    AlertTriangle,
    CheckCircle2,
    FileImage,
    Loader2,
    Search,
    ShieldCheck,
    Trash2,
    UserPlus,
    X,
} from 'lucide-react';

import {
    filterAttendanceWorkers,
    isWorkerDistinguishable,
    type AttendanceWorker,
} from '../utils/filterAttendanceWorkers';


/**
 * Trabajador encontrado durante el reconocimiento.
 * En esta etapa se mantiene como borrador local.
 */
export type PreviewWorker = {
    localId: string;
    name: string;
    email?: string | null;
    userId?: string | null;
};

export type RegisteredWorker = AttendanceWorker;

type Props = {
    file: File;
    talkTitle: string;
    recognizedWorkers: PreviewWorker[];
    registeredWorkers: RegisteredWorker[];
    processing?: boolean;
    processingError?: string;
    onClose: () => void;
};

export default function AttendanceImagePreview({
    file,
    talkTitle,
    recognizedWorkers,
    registeredWorkers,
    processing = false,
    processingError = '',
    onClose,
}: Props) {
    const [imageUrl, setImageUrl] = useState('');

    const [workers, setWorkers] =
        useState<PreviewWorker[]>(recognizedWorkers);

    const [search, setSearch] = useState('');

    const [selectedId, setSelectedId] =
        useState<string | null>(null);

    const [confirmReviewed, setConfirmReviewed] =
        useState(false);

    // Generar la URL temporal de la imagen.
    useEffect(() => {
        const url = URL.createObjectURL(file);

        setImageUrl(url);

        return () => {
            URL.revokeObjectURL(url);
        };
    }, [file]);

    // Actualizar resultados cuando cambie la respuesta OCR.
    useEffect(() => {
        setWorkers(recognizedWorkers);
        setConfirmReviewed(false);
    }, [recognizedWorkers]);

    /**
     * Utiliza la misma búsqueda del registro manual.
     * Excluye los trabajadores que ya están seleccionados.
     */
    const matchedUsers = useMemo(() => {
        const excludedIds = workers.flatMap(
            worker => worker.userId ? [worker.userId] : []
        );

        return filterAttendanceWorkers(
            registeredWorkers,
            search,
            excludedIds
        );
    }, [registeredWorkers, search, workers]);

    const identifiedCount = workers.filter(
        worker => Boolean(worker.userId)
    ).length;

    const pendingCount =
        workers.length - identifiedCount;

    /**
     * Agregar únicamente una persona existente
     * en el listado proporcionado por la aplicación.
     */

    const addVerifiedWorker = () => {
        const person = registeredWorkers.find(
            user => user.id === selectedId
        );

        if (!person) return;

        if (
            !isWorkerDistinguishable(
                person,
                registeredWorkers
            )
        ) {
            return;
        }

        setWorkers(current => {
            // Evitar agregar dos veces el mismo ID.
            if (
                current.some(
                    worker => worker.userId === person.id
                )
            ) {
                return current;
            }

            return [
                ...current,
                {
                    localId: `manual-${person.id}`,
                    userId: person.id,
                    name: person.name,
                    email: person.email,
                },
            ];
        });

        setSelectedId(null);
        setSearch('');
        setConfirmReviewed(false);
    };


    /**
     * Quitar un trabajador del borrador.
     */
    const removeWorker = (localId: string) => {
        setWorkers(current =>
            current.filter(worker => worker.localId !== localId)
        );

        setConfirmReviewed(false);
    };

    return (
        <div
            className="fixed inset-0 z-[60] bg-black/75 flex items-end justify-center sm:items-center p-0 sm:p-4"
            onClick={onClose}
        >
            <section
                role="dialog"
                aria-modal="true"
                aria-label="Vista previa de hoja de asistencia"
                className="themed-card w-full max-w-xl max-h-[95dvh] overflow-y-auto rounded-t-2xl sm:rounded-2xl p-5 space-y-4"
                onClick={event => event.stopPropagation()}
            >
                {/* Encabezado */}
                <header className="flex justify-between gap-3 items-start">
                    <div className="min-w-0">
                        <h2 className="font-bold text-lg">
                            Vista previa de asistencia
                        </h2>

                        <p className="text-sm themed-text-secondary truncate">
                            {talkTitle}
                        </p>

                        <p className="text-xs text-amber-400">
                            Borrador sin guardar
                        </p>
                    </div>

                    <button
                        type="button"
                        onClick={onClose}
                        aria-label="Cerrar vista previa"
                        className="p-2 themed-btn-inactive rounded-lg"
                    >
                        <X size={20} />
                    </button>
                </header>

                {/* Fotografía original */}
                <div className="themed-card border rounded-xl p-3">
                    <div className="flex items-center gap-2 mb-2">
                        <FileImage size={17} />

                        <span className="text-sm font-medium">
                            Fotografía original
                        </span>
                    </div>

                    {imageUrl && (
                        <img
                            src={imageUrl}
                            alt="Hoja de asistencia seleccionada"
                            className="w-full max-h-72 object-contain rounded-lg bg-black/20"
                        />
                    )}

                    <p className="text-xs themed-text-secondary mt-2 break-all">
                        {file.name}
                    </p>
                </div>

                {/* Contadores */}
                <div className="grid grid-cols-3 gap-2 text-center">
                    <div className="themed-card border rounded-xl p-2">
                        <p className="text-2xl font-semibold">
                            {processing ? '—' : workers.length}
                        </p>

                        <p className="text-xs themed-text-secondary">
                            Detectados/listados
                        </p>
                    </div>

                    <div className="themed-card border rounded-xl p-2">
                        <p className="text-2xl font-semibold text-emerald-400">
                            {identifiedCount}
                        </p>

                        <p className="text-xs themed-text-secondary">
                            Identificados
                        </p>
                    </div>

                    <div className="themed-card border rounded-xl p-2">
                        <p className="text-2xl font-semibold text-amber-400">
                            {pendingCount}
                        </p>

                        <p className="text-xs themed-text-secondary">
                            Sin verificar
                        </p>
                    </div>
                </div>

                {/* Estado de procesamiento */}
                {processing && (
                    <p
                        role="status"
                        className="flex items-center gap-2 text-sm"
                    >
                        <Loader2
                            size={17}
                            className="animate-spin"
                        />

                        Analizando hoja de asistencia...
                    </p>
                )}

                {processingError && (
                    <p
                        role="alert"
                        className="text-sm text-red-400"
                    >
                        {processingError}
                    </p>
                )}

                {/* Sin resultados */}
                {!processing &&
                    !processingError &&
                    workers.length === 0 && (
                        <div className="themed-card border rounded-xl p-4 text-center space-y-2">
                            <AlertTriangle
                                className="mx-auto text-amber-400"
                                size={22}
                            />

                            <p className="text-sm font-medium">
                                Todavía no hay trabajadores reconocidos
                            </p>

                            <p className="text-xs themed-text-secondary">
                                No se detectaron asistentes. Puedes agregar
                                manualmente a quienes figuren en la hoja.
                            </p>
                        </div>
                    )}

                {/* Trabajadores reconocidos */}
                {workers.length > 0 && (
                    <div className="space-y-2">
                        <h3 className="font-semibold text-sm">
                            Trabajadores en revisión
                        </h3>

                        {workers.map(worker => (
                            <div
                                key={worker.localId}
                                className="themed-card border rounded-xl p-3 flex gap-2 items-start"
                            >
                                {worker.userId ? (
                                    <CheckCircle2
                                        size={18}
                                        className="text-emerald-400 shrink-0"
                                    />
                                ) : (
                                    <AlertTriangle
                                        size={18}
                                        className="text-amber-400 shrink-0"
                                    />
                                )}

                                <div className="min-w-0 flex-1">
                                    <p className="font-medium text-sm break-words">
                                        {worker.name}
                                    </p>

                                    <p className="text-xs themed-text-secondary break-all">
                                        {worker.email || 'Sin correo detectado'}
                                    </p>

                                    <p className="text-xs themed-text-secondary">
                                        {worker.userId
                                            ? 'Usuario vinculado (validación final pendiente)'
                                            : 'Identidad no verificada'}
                                    </p>
                                </div>

                                <button
                                    type="button"
                                    aria-label={`Quitar ${worker.name}`}
                                    className="p-2 rounded-lg themed-btn-inactive"
                                    onClick={() =>
                                        removeWorker(worker.localId)
                                    }
                                >
                                    <Trash2 size={16} />
                                </button>
                            </div>
                        ))}
                    </div>
                )}

                {/* Búsqueda manual compartida */}
                <div className="themed-card border rounded-xl p-3 space-y-2">
                    <h3 className="font-semibold text-sm flex items-center gap-2">
                        <ShieldCheck size={17} />

                        Agregar trabajador omitido
                    </h3>

                    <p className="text-xs themed-text-secondary">
                        Sólo puedes seleccionar personas existentes
                        en el registro de la aplicación. Verifica
                        su presencia en la fotografía original.
                    </p>

                    <label className="flex items-center gap-2 themed-card border rounded-lg px-3">
                        <Search size={16} />

                        <input
                            value={search}
                            onChange={event => {
                                setSearch(event.target.value);
                                setSelectedId(null);
                            }}
                            placeholder="Buscar por nombre o correo"
                            className="bg-transparent outline-none text-sm py-3 w-full"
                        />
                    </label>

                    {/* Resultados de búsqueda */}
                    {search.trim() && (
                        matchedUsers.length > 0 ? (
                            <div className="space-y-1 max-h-36 overflow-y-auto">

                                {matchedUsers.map(person => {
                                    const selectable = isWorkerDistinguishable(
                                        person,
                                        registeredWorkers
                                    );

                                    return (
                                        <button
                                            key={person.id}
                                            type="button"
                                            disabled={!selectable}
                                            onClick={() => setSelectedId(person.id)}
                                            className={`w-full text-left p-3 border rounded-lg disabled:opacity-40 ${selectedId === person.id
                                                ? 'border-[#00E5FF] bg-[#00E5FF]/10'
                                                : ''
                                                }`}
                                        >
                                            <p className="text-sm font-medium">
                                                {person.name}
                                            </p>

                                            <p className="text-xs themed-text-secondary mt-1 break-all">
                                                {person.email || 'Correo no disponible'}
                                            </p>

                                            {!selectable && (
                                                <p className="text-xs text-amber-400 mt-1">
                                                    Identidad ambigua: requiere revisión
                                                </p>
                                            )}
                                        </button>
                                    );
                                })}

                            </div>
                        ) : (
                            <p className="text-xs text-amber-400">
                                Sin coincidencias disponibles. No está
                                permitido crear una identidad libre.
                            </p>
                        )
                    )}

                    <button
                        type="button"
                        disabled={!selectedId}
                        onClick={addVerifiedWorker}
                        className="w-full py-2 rounded-xl bg-[#00E5FF] text-[#0B1E36] disabled:opacity-40 text-sm font-semibold flex justify-center items-center gap-2"
                    >
                        <UserPlus size={17} />

                        Agregar del registro
                    </button>
                </div>

                {/* Revisión */}
                <label className="flex items-start gap-2 text-xs themed-text-secondary">
                    <input
                        type="checkbox"
                        checked={confirmReviewed}
                        onChange={event =>
                            setConfirmReviewed(event.target.checked)
                        }
                        className="mt-0.5"
                    />

                    Revisé la fotografía y los datos de los
                    trabajadores listados. Esta marca no
                    guarda la asistencia.
                </label>

                {/* Confirmación deshabilitada en esta etapa */}
                <button
                    type="button"
                    disabled
                    className="w-full py-3 rounded-xl bg-[#00E5FF] text-[#0B1E36] font-semibold disabled:opacity-40"
                >
                    Confirmar asistencia (próxima etapa)
                </button>

                <button
                    type="button"
                    onClick={onClose}
                    className="w-full py-2 rounded-xl themed-card border"
                >
                    Cerrar sin guardar
                </button>
            </section>
        </div>
    );
}
