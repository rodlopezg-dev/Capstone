import pytest


@pytest.mark.asyncio
async def test_finish_preserves_attendance_and_is_idempotent(api, db, seed, auth_headers):
    await db.attendance.insert_one({"attendance_id": "manual", "talk_id": "talk_a", "client_id": "empresa_a", "attendees": ["Ana"]})
    headers = auth_headers("supervisor_a", role="supervisor")
    for _ in range(2):
        response = await api.post("/v1/talks/talk_a/finish", headers=headers)
        assert response.status_code == 200, response.text
        assert response.json()["status"] == "finished"
    assert (await db.talks.find_one({"talk_id": "talk_a"}))["status"] == "finished"
    assert (await db.attendance.find_one({"attendance_id": "manual"}))["attendees"] == ["Ana"]
    assert (await api.get("/v1/talks/talk_a/qr", headers=headers)).status_code == 403
    assert (await api.get(
        "/v1/talks/talk_a/qr",
        headers=auth_headers("admin_a", role="admin"),
    )).status_code == 409


@pytest.mark.asyncio
async def test_finish_checks_tenant_and_role(api, seed, auth_headers):
    assert (await api.post("/v1/talks/talk_a/finish", headers=auth_headers())).status_code == 403
    assert (await api.post("/v1/talks/talk_b/finish", headers=auth_headers("supervisor_a", role="supervisor"))).status_code == 404


@pytest.mark.asyncio
async def test_finished_talk_rejects_manual_attendance(api, db, seed, auth_headers):
    await db.attendance.insert_one({"attendance_id": "manual", "talk_id": "talk_a", "client_id": "empresa_a", "attendees": ["Ana"]})
    headers = auth_headers("supervisor_a", role="supervisor")
    assert (await api.post("/v1/talks/talk_a/finish", headers=headers)).status_code == 200
    attendance_form = {
        "talk_id": "talk_a", "topic": "Charla", "date": "2026-10-07", "attendees": "Ana",
    }
    denied = await api.post("/v1/attendance", headers=headers, data=attendance_form)
    assert denied.status_code == 403, denied.text

    response = await api.post(
        "/v1/attendance",
        headers=auth_headers("admin_a", role="admin"),
        data=attendance_form,
    )
    assert response.status_code == 409, response.text


@pytest.mark.asyncio
@pytest.mark.parametrize('record', [
    None,
    {"attendees": [], "file_id": "sheet"},
    {"attendees": ["", "   "]},
    {"attendees": ["Ana"], "client_id": "empresa_b"},
])
async def test_finish_requires_a_registered_person(api, db, seed, auth_headers, record):
    if record is not None:
        await db.attendance.insert_one({"client_id": "empresa_a", "talk_id": "talk_a", **record})
    response = await api.post('/v1/talks/talk_a/finish', headers=auth_headers('supervisor_a', role='supervisor'))
    assert response.status_code == 409, response.text
    assert (await db.talks.find_one({"talk_id": "talk_a"})).get('status') != 'finished'


@pytest.mark.asyncio
async def test_finish_accepts_qr_identity_without_display_name(api, db, seed, auth_headers):
    await db.attendance.insert_one({"client_id": "empresa_a", "talk_id": "talk_a", "attended_user_ids": ["worker_a"]})
    response = await api.post('/v1/talks/talk_a/finish', headers=auth_headers('supervisor_a', role='supervisor'))
    assert response.status_code == 200, response.text


@pytest.mark.asyncio
async def test_finish_creates_and_persists_closure_summary(api, db, seed, auth_headers):
    await db.talks.update_one(
        {"client_id": "empresa_a", "talk_id": "talk_a"},
        {"$set": {"created_at": "2026-10-07T09:00:00+00:00"}},
    )
    await db.attendance.insert_many([
        {
            "client_id": "empresa_a",
            "talk_id": "talk_a",
            "source": "qr",
            "area": "Producción",
            "attended_user_ids": ["worker_a"],
            "attendees": ["Ana Prueba"],
            "attendance_entries": [
                {"user_id": "worker_a", "name": "Ana Prueba"},
            ],
        },
        {
            "client_id": "empresa_a",
            "talk_id": "talk_a",
            "source": "manual",
            "area": "Producción",
            "attended_user_ids": ["worker_a", "worker_a2"],
            "attendees": ["Ana Prueba", "Luis Prueba"],
            "attendance_entries": [
                {"user_id": "worker_a", "name": "Ana Prueba"},
                {"user_id": "worker_a2", "name": "Luis Prueba"},
            ],
        },
    ])

    response = await api.post(
        "/v1/talks/talk_a/finish",
        headers=auth_headers("supervisor_a", role="supervisor"),
    )

    assert response.status_code == 200, response.text
    summary = response.json()["closure_summary"]
    assert summary["talk_id"] == "talk_a"
    assert summary["client_id"] == "empresa_a"
    assert summary["topic"] == "Charla de prueba"
    assert summary["area"] == "Producción"
    assert summary["date"] == "2026-10-07"
    assert summary["attendee_count"] == 2
    assert summary["closed_by"] == "supervisor_a"
    assert summary["schema_version"] == 1
    assert summary["closed_at"] == response.json()["finished_at"]

    stored_talk = await db.talks.find_one(
        {"client_id": "empresa_a", "talk_id": "talk_a"},
    )
    assert stored_talk["closure_summary"] == summary

    denied = await api.get(
        "/v1/talks",
        headers=auth_headers("supervisor_a", role="supervisor"),
    )
    assert denied.status_code == 403, denied.text

    talks_response = await api.get(
        "/v1/talks",
        headers=auth_headers("admin_a", role="admin"),
    )
    assert talks_response.status_code == 200, talks_response.text
    listed_talk = next(
        talk for talk in talks_response.json() if talk["talk_id"] == "talk_a"
    )
    assert listed_talk["closure_summary"] == summary


@pytest.mark.asyncio
async def test_second_finish_preserves_original_closure_summary(
    api,
    db,
    seed,
    auth_headers,
):
    await db.talks.update_one(
        {"client_id": "empresa_a", "talk_id": "talk_a"},
        {"$set": {"created_at": "2026-10-07T09:00:00+00:00"}},
    )
    await db.attendance.insert_one({
        "client_id": "empresa_a",
        "talk_id": "talk_a",
        "area": "Mantención",
        "attended_user_ids": ["worker_a"],
    })
    headers = auth_headers("supervisor_a", role="supervisor")

    first = await api.post("/v1/talks/talk_a/finish", headers=headers)
    assert first.status_code == 200, first.text
    original_summary = first.json()["closure_summary"]

    await db.attendance.update_one(
        {"client_id": "empresa_a", "talk_id": "talk_a"},
        {"$push": {"attended_user_ids": "worker_a2"}},
    )
    second = await api.post("/v1/talks/talk_a/finish", headers=headers)

    assert second.status_code == 200, second.text
    assert second.json()["closure_summary"] == original_summary
    assert second.json()["finished_at"] == first.json()["finished_at"]
    assert (await db.talks.find_one(
        {"client_id": "empresa_a", "talk_id": "talk_a"},
    ))["closure_summary"] == original_summary


@pytest.mark.asyncio
async def test_finish_summary_does_not_include_other_tenant_attendance(
    api,
    db,
    seed,
    auth_headers,
):
    await db.talks.update_one(
        {"client_id": "empresa_a", "talk_id": "talk_a"},
        {"$set": {"created_at": "2026-10-07T09:00:00+00:00"}},
    )
    await db.attendance.insert_many([
        {
            "client_id": "empresa_a",
            "talk_id": "talk_a",
            "attended_user_ids": ["worker_a"],
        },
        {
            "client_id": "empresa_b",
            "talk_id": "talk_a",
            "attended_user_ids": [
                "other_1",
                "other_2",
                "other_3",
            ],
        },
    ])

    response = await api.post(
        "/v1/talks/talk_a/finish",
        headers=auth_headers("supervisor_a", role="supervisor"),
    )

    assert response.status_code == 200, response.text
    assert response.json()["closure_summary"]["attendee_count"] == 1
