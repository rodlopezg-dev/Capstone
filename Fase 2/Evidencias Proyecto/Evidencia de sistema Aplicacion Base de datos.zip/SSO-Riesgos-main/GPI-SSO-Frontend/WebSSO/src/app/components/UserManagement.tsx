import React, { useState, useEffect } from 'react';
import { HelpTooltip } from './HelpTooltip';
import { useLanguage } from '../context/LanguageContext';
import { Users, MapPin, Plus, Trash2, Edit2, Check, X } from 'lucide-react';

const USERS_API_URL = window.location.origin + '/api/users/v1/admin/users/';
const AREAS_API_URL = (import.meta.env.VITE_AREAS_API_URL || 'https://sso-areas.alloxentric.com') + '/v1/areas/';

interface User {
  user_id:   string;
  name:      string;
  last_name?: string;
  email:     string;
  role:      string;
  status:    string;
  assigned_areas?: string[];
  assigned_zones?: string[];
  areas?: string[];
  area?: string;
}

interface Area {
  id:          string;
  name:        string;
  description?: string;
  is_active:   boolean;
  created_at:  string;
  updated_at:  string;
  client_id:   string;
}

const DEFAULT_AREAS_MAP: Area[] = [
  { id: 'def-linea-1', name: 'Línea 1', description: 'Zona operativa de ensamblaje o producción 1', is_active: true, created_at: '', updated_at: '', client_id: '' },
  { id: 'def-linea-2', name: 'Línea 2', description: 'Zona operativa de cocina o procesamiento 2', is_active: true, created_at: '', updated_at: '', client_id: '' },
  { id: 'def-linea-3', name: 'Línea 3', description: 'Área logística de almacenamiento superior', is_active: true, created_at: '', updated_at: '', client_id: '' },
  { id: 'def-bodega-q', name: 'Bodega Química', description: 'Almacén exclusivo de reactivos e insumos químicos', is_active: true, created_at: '', updated_at: '', client_id: '' },
  { id: 'def-zona-c', name: 'Zona de Carga', description: 'Área de distribución, carga y descarga de materiales', is_active: true, created_at: '', updated_at: '', client_id: '' },
  { id: 'def-area-c', name: 'Área de Corte', description: 'Zona de dimensionado, corte y servicios higiénicos', is_active: true, created_at: '', updated_at: '', client_id: '' }
];

export default function UserManagement() {
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState<'users' | 'areas'>('users');

  // ── Auth (Recuperación segura con normalización de roles) ─────────────────
  const token = localStorage.getItem('sso_token') ?? '';
  
  let currentUserRole = '';
  let tokenClientId = 'cliente_prueba_123';
  
  if (token) {
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      currentUserRole = (payload.role ?? '').toLowerCase().replace(/_/g, ' ').normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim(); 
      tokenClientId = payload.client_id ?? 'cliente_prueba_123';
    } catch (e) {
      console.error("Error parseando el token JWT", e);
    }
  }

  // ── Users state ───────────────────────────────────────────────────────────
  const [users, setUsers]             = useState<User[]>([]);
  const [name, setName]               = useState('');
  const [lastName, setLastName]       = useState('');
  const [email, setEmail]             = useState('');
  const [password, setPassword]       = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Password strength rules
  const pwRules = [
    { id: 'length',   label: 'Mínimo 8 caracteres',              test: (p: string) => p.length >= 8 },
    { id: 'upper',    label: 'Al menos una mayúscula (A-Z)',      test: (p: string) => /[A-Z]/.test(p) },
    { id: 'lower',    label: 'Al menos una minúscula (a-z)',      test: (p: string) => /[a-z]/.test(p) },
    { id: 'number',   label: 'Al menos un número (0-9)',          test: (p: string) => /[0-9]/.test(p) },
    { id: 'special',  label: 'Al menos un símbolo (!@#$%...)',    test: (p: string) => /[^A-Za-z0-9]/.test(p) },
  ];
  const pwScore   = pwRules.filter(r => r.test(password)).length;
  const pwValid   = pwScore === pwRules.length;
  const pwStrength = pwScore <= 1 ? 'Muy débil' : pwScore === 2 ? 'Débil' : pwScore === 3 ? 'Regular' : pwScore === 4 ? 'Fuerte' : 'Muy fuerte';
  const pwColor   = pwScore <= 1 ? '#D72631' : pwScore === 2 ? '#D72631' : pwScore === 3 ? '#E8941A' : pwScore === 4 ? '#00C2DB' : '#16A34A';
  const [role, setRole]               = useState('worker');
  const [shift, setShift]             = useState('Día');
  const [assignedAreas, setAssignedAreas] = useState<string[]>([]);
  const [buscaUsuario, setBuscaUsuario] = useState('');
  const [editUser, setEditUser]         = useState<User | null>(null);
  const [editRoleU, setEditRoleU]       = useState('');
  const [editAreasU, setEditAreasU]     = useState<string[]>([]);
  const [editZonesU, setEditZonesU]     = useState<string[]>([]);
  const [editSaving, setEditSaving]     = useState(false);
  const [editUserError, setEditUserError] = useState<string | null>(null);
  const [userError, setUserError]     = useState<string | null>(null);
  const [userSuccess, setUserSuccess] = useState<string | null>(null);

  // ── Areas state ──────────────────────────────────────────────────────────
  const [areas, setAreas]             = useState<Area[]>(DEFAULT_AREAS_MAP);
  const [areaName, setAreaName]       = useState('');
  const [areaDesc, setAreaDesc]       = useState('');
  const [areaError, setAreaError]     = useState<string | null>(null);
  const [areaSuccess, setAreaSuccess] = useState<string | null>(null);
  const [editingArea, setEditingArea] = useState<Area | null>(null);
  const [editName, setEditName]       = useState('');
  const [editDesc, setEditDesc]       = useState('');
  const [areaLoading, setAreaLoading] = useState(false);

  useEffect(() => {
    setAssignedAreas([]);
  }, [role]);

  // ── Fetch users ───────────────────────────────────────────────────────────
  const fetchUsers = async () => {
    if (!token) return;
    try {
      const res = await fetch(USERS_API_URL, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) setUsers(await res.json());
    } catch { console.error('Error cargando usuarios'); }
  };

  // ── Fetch areas ───────────────────────────────────────────────────────────
  const fetchAreas = async () => {
    if (!token) return; 
    setAreaLoading(true);
    try {
      const res = await fetch(AREAS_API_URL, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const serverAreas: Area[] = await res.json();
        if (serverAreas.length > 0) {
          const merged = [...serverAreas];
          DEFAULT_AREAS_MAP.forEach(defArea => {
            if (!merged.some(a => a.name.toLowerCase() === defArea.name.toLowerCase())) {
              merged.push(defArea);
            }
          });
          setAreas(merged);
        } else {
          setAreas(DEFAULT_AREAS_MAP);
        }
      }
    } catch { 
      console.error('Error cargando áreas, manteniendo áreas por defecto.'); 
      setAreas(DEFAULT_AREAS_MAP);
    } finally { setAreaLoading(false); }
  };

  useEffect(() => { 
    if (token) {
      fetchUsers(); 
      fetchAreas(); 
    }
  }, [token]);

  // ── Handlers users ────────────────────────────────────────────────────────
  const handleAreaToggle = (areaNameString: string) => {
    setAssignedAreas(prev =>
      prev.includes(areaNameString) ? prev.filter(a => a !== areaNameString) : [...prev, areaNameString]
    );
  };

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setUserError(null);
    setUserSuccess(null);
    
    if (!token) {
      setUserError("No se encontró una sesión válida.");
      return;
    }

    try {
      const payloadBody = {
        name,
        last_name: lastName,
        email,
        role, 
        password,
        shift: role === 'worker' ? shift : null,
        client_id: tokenClientId,
        assigned_areas: assignedAreas, 
        areas: assignedAreas,          
        area: assignedAreas.length > 0 ? assignedAreas[0] : "" 
      };

      const res = await fetch(USERS_API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify(payloadBody),
      });

      const result = await res.json();
      if (!res.ok) throw new Error(result.detail ? JSON.stringify(result.detail) : 'Error al crear el perfil');
      
      setUserSuccess(`Perfil de ${name} ${lastName} creado exitosamente como ${getRoleLabel(role)}.`);
      setName(''); setLastName(''); setEmail(''); setPassword('');
      setRole('worker'); setShift('Día'); setAssignedAreas([]);
      fetchUsers();
    } catch (err: any) {
      setUserError(err.message || 'Error de conexión');
    }
  };

  // ── Handlers areas ────────────────────────────────────────────────────────
  const handleCreateArea = async (e: React.FormEvent) => {
    e.preventDefault();
    setAreaError(null);
    setAreaSuccess(null);
    try {
      const res = await fetch(AREAS_API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ name: areaName, description: areaDesc, is_active: true }),
      });
      const result = await res.json();
      if (!res.ok) throw new Error(result.detail ? JSON.stringify(result.detail) : 'Error al crear área');
      setAreaSuccess(`Área "${areaName}" creada exitosamente.`);
      setAreaName(''); setAreaDesc('');
      fetchAreas();
    } catch (err: any) {
      setAreaError(err.message || 'Error de conexión');
    }
  };

  const handleUpdateArea = async (area: Area) => {
    if (area.id.startsWith('def-')) {
      setAreas(prev => prev.map(a => a.id === area.id ? { ...a, name: editName, description: editDesc } : a));
      setEditingArea(null);
      return;
    }
    try {
      const res = await fetch(`${AREAS_API_URL}${area.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ name: editName, description: editDesc }),
      });
      if (!res.ok) throw new Error('Error al actualizar');
      setEditingArea(null);
      fetchAreas();
    } catch (err: any) {
      setAreaError(err.message);
    }
  };

  const handleDeleteArea = async (areaId: string) => {
    if (!confirm('¿Eliminar esta área?')) return;
    if (areaId.startsWith('def-')) {
      setAreas(prev => prev.filter(a => a.id !== areaId));
      return;
    }
    try {
      const res = await fetch(`${AREAS_API_URL}${areaId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error('Error al eliminar');
      fetchAreas();
    } catch (err: any) {
      setAreaError(err.message);
    }
  };

  const handleToggleActive = async (area: Area) => {
    if (area.id.startsWith('def-')) {
      setAreas(prev => prev.map(a => a.id === area.id ? { ...a, is_active: !a.is_active } : a));
      return;
    }
    try {
      const res = await fetch(`${AREAS_API_URL}${area.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ is_active: !area.is_active }),
      });
      if (!res.ok) throw new Error('Error al actualizar');
      fetchAreas();
    } catch (err: any) {
      setAreaError(err.message);
    }
  };

  const usuariosFiltrados = users.filter(u => {
    const q = buscaUsuario.trim().toLowerCase();
    if (!q) return true;
    return [u.name, u.last_name, u.email, u.role, getRoleLabel(u.role)]
      .some(v => (v || '').toLowerCase().includes(q));
  });

  const abrirEdicion = (u: User) => {
    setEditUser(u);
    setEditRoleU(u.role);
    setEditAreasU(u.assigned_areas ?? u.areas ?? []);
    setEditZonesU(u.assigned_zones ?? []);
    setEditUserError(null);
  };

  const zonasDisponibles = (nombres: string[]): string[] =>
    areas.filter(a => nombres.includes(a.name))
         .flatMap(a => (((a as any).zones || []) as string[]));

  const guardarEdicion = async () => {
    if (!editUser) return;
    setEditSaving(true);
    setEditUserError(null);
    try {
      const res = await fetch(`${USERS_API_URL}${editUser.user_id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ role: editRoleU, assigned_areas: editAreasU, assigned_zones: editZonesU }),
      });
      if (!res.ok) {
        const d = await res.json().catch(() => ({}));
        throw new Error(d.detail ? JSON.stringify(d.detail) : 'Error al guardar');
      }
      setEditUser(null);
      fetchUsers();
    } catch (e: any) {
      setEditUserError(e.message || 'Error de conexion');
    } finally {
      setEditSaving(false);
    }
  };

  const getRoleLabel = (roleKey: string) => {
    const cleanKey = roleKey.toLowerCase().trim();
    return {
      'worker':        'Trabajador (App Móvil)',
      'analista':      'Analista de Riesgos',
      'analyst':       'Analista de Riesgos',
      'jefe de area':  'Jefe de Área',
      'admin':         'Administrador',
      'sso_manager':   'Gerente SSO',
      'prevencion':    'Prevención de Riesgos',
      'sso manager':   'Gerente SSO'
    }[cleanKey] || roleKey;
  };

  const activeAreas = areas.filter(a => a.is_active);
  const filteredUsers = users.filter(u => u.role !== 'superadmin');

  return (
    <div className="h-full p-6 overflow-auto bg-[#0B0F19] text-slate-100">

      {/* Header */}
      <div className="mb-6 border-b border-slate-800 pb-5">
        <h1 className="text-4xl mb-2 tracking-tight uppercase"
          style={{ fontFamily: 'var(--font-display)', fontWeight: 800, letterSpacing: '-0.025em' }}>
          GESTIÓN DE PERFILES Y ÁREAS
        </h1>
        <HelpTooltip steps={[
      { icon: '👤', title: 'Crear usuarios', description: 'En la pestaña "Perfiles de Usuario" completa nombre, correo, contraseña temporal y rol. El rol define qué módulos verá el usuario en la app móvil y web.' },
      { icon: '🏷️', title: 'Roles disponibles', description: 'Trabajador (solo app móvil), Jefe de Área (app + incidentes), Analista (web, sin admin), Prevención de Riesgos (valida cierres y recategoriza) y SSO Manager (acceso completo).' },
      { icon: '📍', title: 'Áreas asignadas', description: 'Al crear un usuario, selecciona las áreas operativas donde trabajará. Esto filtra los incidentes y alertas que verá en su cuenta.' },
      { icon: '🏭', title: 'Gestión de áreas', description: 'En la pestaña "Áreas Operativas" puedes crear, editar, activar/desactivar y eliminar las zonas de la planta que aparecerán en toda la plataforma.' },
    ]} />
        <p className="text-slate-400 text-sm">Administración de cuentas y zonas operativas</p>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-8">
        <button onClick={() => setActiveTab('users')}
          className={`flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-semibold transition-all ${
            activeTab === 'users'
              ? 'bg-[#00E5FF] text-[#0B1E36]'
              : 'bg-[#111827] border border-slate-700 text-slate-400 hover:border-slate-500'
          }`}>
          <Users size={16} />
          Perfiles de Usuario
        </button>
        {['sso_manager', 'sso manager', 'admin'].includes(currentUserRole) && (
          <button onClick={() => setActiveTab('areas')}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-semibold transition-all ${
              activeTab === 'areas'
                ? 'bg-[#00E5FF] text-[#0B1E36]'
                : 'bg-[#111827] border border-slate-700 text-slate-400 hover:border-slate-500'
            }`}>
            <MapPin size={16} />
            Áreas Operativas
            {areas.length > 0 && (
              <span className="bg-white/20 text-white text-xs px-1.5 py-0.5 rounded-full">{areas.length}</span>
            )}
          </button>
        )}
      </div>

      {/* ── TAB: USUARIOS ───────────────────────────────────────────────────── */}
      {activeTab === 'users' && (
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-8 items-start">

          {/* Form - Control de accesos según matriz de roles unificada */}
          {['sso_manager', 'sso manager', 'admin', 'jefe de area'].includes(currentUserRole) ? (
            <div className="bg-[#111827] border border-slate-800 rounded-xl p-6 shadow-xl">
              <h2 className="text-lg mb-6 text-[#00E5FF] tracking-wide uppercase flex items-center gap-2"
                style={{ fontFamily: 'var(--font-display)', fontWeight: 600 }}>
                <span className="w-1.5 h-4 bg-[#00E5FF] rounded-sm block"></span>
                {(t as any).userManagement?.createTitle || 'Crear Nuevo Perfil'}
              </h2>

              {userError   && <div className="bg-[#D72631]/10 border border-[#B71C25] text-[#D72631] p-3 rounded-lg mb-5 text-xs">{userError}</div>}
              {userSuccess && <div className="bg-emerald-950/40 border border-emerald-800 text-emerald-400 p-3 rounded-lg mb-5 text-xs">{userSuccess}</div>}

              <form onSubmit={handleCreateUser} className="space-y-5">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Nombre</label>
                    <input type="text" value={name} onChange={e => setName(e.target.value)} required
                      className="w-full px-3.5 py-2 bg-[#102A4C] border border-[#163760]/60 rounded-lg text-slate-100 text-sm focus:outline-none focus:border-[#00E5FF]"
                      placeholder="Ej: Juan" />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Apellido</label>
                    <input type="text" value={lastName} onChange={e => setLastName(e.target.value)} required
                      className="w-full px-3.5 py-2 bg-[#102A4C] border border-[#163760]/60 rounded-lg text-slate-100 text-sm focus:outline-none focus:border-[#00E5FF]"
                      placeholder="Ej: Pérez" />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Correo Electrónico</label>
                  <input type="email" value={email} onChange={e => setEmail(e.target.value)} required
                    className="w-full px-3.5 py-2 bg-[#102A4C] border border-[#163760]/60 rounded-lg text-slate-100 text-sm focus:outline-none focus:border-[#00E5FF]"
                    placeholder="trabajador@empresa.com" />
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Contraseña Temporal</label>

                  {/* Input with show/hide toggle */}
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={e => setPassword(e.target.value)}
                      required
                      className={`w-full px-3.5 py-2 pr-10 bg-[#102A4C] border rounded-lg text-slate-100 text-sm focus:outline-none transition-colors ${
                        password.length === 0
                          ? 'border-[#163760]/60 focus:border-[#00E5FF]'
                          : pwValid
                            ? 'border-[#16A34A]/60 focus:border-[#16A34A]'
                            : 'border-[#E8941A]/60 focus:border-[#E8941A]'
                      }`}
                      placeholder="Ingresa una contraseña segura"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(s => !s)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200 transition-colors"
                      tabIndex={-1}
                    >
                      {showPassword ? (
                        <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94"/><path d="M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19"/><line x1="1" y1="1" x2="23" y2="23"/></svg>
                      ) : (
                        <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                      )}
                    </button>
                  </div>

                  {/* Strength bar + label */}
                  {password.length > 0 && (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex gap-1 flex-1 mr-3">
                          {pwRules.map((_, i) => (
                            <div key={i} className="h-1 flex-1 rounded-full transition-all duration-300"
                              style={{ backgroundColor: i < pwScore ? pwColor : '#163760' }} />
                          ))}
                        </div>
                        <span className="text-xs font-semibold transition-colors" style={{ color: pwColor }}>
                          {pwStrength}
                        </span>
                      </div>

                      {/* Rules checklist */}
                      <div className="bg-[#06121F] rounded-lg px-3 py-2.5 space-y-1.5 border border-[#163760]">
                        {pwRules.map(rule => {
                          const ok = rule.test(password);
                          return (
                            <div key={rule.id} className="flex items-center gap-2">
                              <div className={`w-3.5 h-3.5 rounded-full flex items-center justify-center shrink-0 transition-all ${ok ? 'bg-[#16A34A]/20' : 'bg-[#163760]'}`}>
                                {ok
                                  ? <svg width="8" height="8" viewBox="0 0 12 12" fill="none"><path d="M2 6l3 3 5-5" stroke="#16A34A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
                                  : <div className="w-1 h-1 rounded-full bg-[#5A8CB0]" />
                                }
                              </div>
                              <span className={`text-xs transition-colors ${ok ? 'text-[#16A34A]' : 'text-[#5A8CB0]'}`}>
                                {rule.label}
                              </span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Rol en el Sistema</label>
                  <select value={role} onChange={e => setRole(e.target.value)}
                    className="w-full px-3.5 py-2 bg-[#102A4C] border border-[#163760]/60 rounded-lg text-slate-100 text-sm focus:outline-none focus:border-[#00E5FF]">
                    <option value="worker">Trabajador (App Móvil)</option>
                    <option value="analista">Analista de Riesgos</option>
                    <option value="jefe de area">Jefe de Área</option>
                    <option value="admin">Administrador</option>
                    <option value="prevencion">Prevención de Riesgos</option>
                  </select>
                </div>
                <div>
                  <label className="text-sm text-muted-foreground mb-1 block">Tipo de trabajador</label>
                  <select className="w-full px-3 py-2 bg-secondary border border-border rounded-lg text-sm">
                    <option value="planta">Planta (interno)</option>
                    <option value="externo">Externo</option>
                  </select>
                </div>

                {/* SELECTOR DE ÁREA ASIGNADA */}
                {['jefe de area', 'analista', 'admin', 'analyst'].includes(role) && (
                  <div className="space-y-1.5 border-t border-slate-800 pt-5">
                    <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                      Área Asignada
                    </label>
                    <select 
                      value={assignedAreas[0] ?? ''}
                      onChange={e => setAssignedAreas(e.target.value ? [e.target.value] : [])}
                      className="w-full px-3.5 py-2 bg-[#102A4C] border border-[#163760]/60 rounded-lg text-slate-100 text-sm focus:outline-none focus:border-[#00E5FF]"
                    >
                      <option value="">Sin área específica</option>
                      {areaLoading ? (
                        <option disabled>Cargando áreas...</option>
                      ) : activeAreas.length === 0 ? (
                        <option disabled>No hay áreas disponibles</option>
                      ) : (
                        activeAreas.map(area => (
                          <option key={area.id} value={area.name}>{area.name}</option>
                        ))
                      )}
                    </select>
                  </div>
                )}

                {role === 'worker' && (
                  <div className="space-y-5 border-t border-slate-800 pt-5">
                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Turno Asignado</label>
                      <select value={shift} onChange={e => setShift(e.target.value)}
                        className="w-full px-3.5 py-2 bg-[#102A4C] border border-[#163760]/60 rounded-lg text-slate-100 text-sm focus:outline-none focus:border-[#00E5FF]">
                        <option value="Día">☀️ Día</option>
                        <option value="Noche">🌙 Noche</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Áreas Asignadas</label>
                        <span className="text-[10px] text-slate-500 bg-slate-800/60 px-2 py-0.5 rounded-full">Múltiple</span>
                      </div>
                      <div className="grid grid-cols-2 gap-2 max-h-52 overflow-y-auto pr-1">
                        {areaLoading ? (
                          <p className="col-span-2 text-center text-xs text-slate-500 py-4">Cargando áreas...</p>
                        ) : activeAreas.length === 0 ? (
                          <p className="col-span-2 text-center text-xs text-slate-500 py-4">No hay áreas disponibles</p>
                        ) : (
                          activeAreas.map(area => (
                            <div key={area.id} onClick={() => handleAreaToggle(area.name)}
                              className={`px-3 py-2.5 rounded-lg border text-xs font-medium text-center cursor-pointer transition-all ${
                                assignedAreas.includes(area.name)
                                  ? 'bg-[#00E5FF]/10 border-[#00E5FF] text-[#00E5FF]'
                                  : 'bg-[#1F2937] border-slate-700/70 text-slate-300 hover:border-slate-500'
                              }`}>
                              {area.name}
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  </div>
                )}

                <button type="submit"
                  disabled={!pwValid}
                  title={!pwValid ? 'La contraseña debe cumplir todos los requisitos de seguridad' : ''}
                  className="w-full px-6 py-3 bg-[#00E5FF] text-[#0B1E36] rounded-lg text-sm font-semibold hover:bg-[#0097A8] transition-all mt-4 disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:bg-[#00E5FF]">
                  {pwValid ? 'Registrar Cuenta' : `Contraseña insegura (${pwScore}/5 requisitos)`}
                </button>
              </form>
            </div>
          ) : (
            <div className="bg-[#111827] border border-slate-800 rounded-xl p-6 shadow-xl text-slate-400 text-sm">
              ℹ️ Tu rol actual no cuenta con permisos para crear nuevos usuarios o modificar configuraciones globales del cliente.
            </div>
          )}

          {/* Table */}
          <div className={`${['sso_manager', 'sso manager', 'admin', 'jefe de area'].includes(currentUserRole) ? 'lg:col-span-2' : 'lg:col-span-3'} bg-[#111827] border border-slate-800 rounded-xl p-6 shadow-xl`}>
            <input
              type="text"
              value={buscaUsuario}
              onChange={e => setBuscaUsuario(e.target.value)}
              placeholder="Buscar por nombre, correo o rol..."
              className="w-full mb-4 px-3.5 py-2 bg-[#102A4C] border border-[#163760]/60 rounded-lg text-slate-100 text-sm placeholder:text-slate-500 focus:outline-none focus:border-[#00E5FF]"
            />
            <h2 className="text-lg mb-6 tracking-wide uppercase flex items-center gap-2"
              style={{ fontFamily: 'var(--font-display)', fontWeight: 600 }}>
              <span className="w-1.5 h-4 bg-slate-600 rounded-sm block"></span>
              Usuarios Registrados
            </h2>
            <div className="overflow-x-auto rounded-lg border border-slate-800">
              <table className="w-full border-collapse text-left">
                <thead>
                  <tr className="bg-[#1F2937]/60 border-b border-slate-800">
                    {['Nombre', 'Correo', 'Rol', 'Estado', 'Acciones'].map(h => (
                      <th key={h} className="py-3.5 px-4 text-xs font-bold text-slate-400 uppercase tracking-wider">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {usuariosFiltrados.length === 0 ? (
                    <tr><td colSpan={5} className="text-center py-10 text-slate-500 text-sm">{buscaUsuario ? "Sin resultados para esa busqueda." : "No hay usuarios registrados."}</td></tr>
                  ) : usuariosFiltrados.map(user => (
                    <tr key={user.user_id} className="bg-[#111827] hover:bg-[#1F2937]/30 transition-colors">
                      <td className="py-3.5 px-4 text-sm font-semibold text-slate-200">{user.name} {user.last_name || ''}</td>
                      <td className="py-3.5 px-4 text-sm text-slate-400">{user.email}</td>
                      <td className="py-3.5 px-4">
                        <span className={`px-2.5 py-1 rounded-md text-[11px] font-semibold border ${
                          ['jefe de area', 'admin'].includes(user.role.toLowerCase().trim())
                            ? 'bg-[#D72631]/10 text-[#D72631] border-[#D72631]/20'
                            : 'bg-[#00E5FF]/10 text-[#00E5FF] border-[#00E5FF]/20'
                        }`}>{getRoleLabel(user.role)}</span>
                      </td>
                      <td className="py-3.5 px-4">
                        <span className="text-emerald-400 flex items-center gap-2 text-xs bg-emerald-500/5 border border-emerald-500/10 w-fit px-2.5 py-0.5 rounded-full">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                          {user.status || 'active'}
                        </span>
                      </td>
                      <td className="py-3.5 px-4">
                        <button onClick={() => abrirEdicion(user)}
                          className="px-3 py-1 rounded-md text-[11px] font-semibold border border-[#00E5FF]/40 text-[#00E5FF] hover:bg-[#00E5FF]/10 transition-colors">
                          Editar
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {editUser && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4" onClick={() => setEditUser(null)}>
          <div className="bg-[#111827] border border-slate-800 rounded-xl p-6 w-full max-w-lg max-h-[85vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <h3 className="text-lg font-semibold text-slate-100 mb-1">{editUser.name} {editUser.last_name || ''}</h3>
            <p className="text-xs text-slate-500 mb-5">{editUser.email}</p>

            <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-1.5">Rol</label>
            <select value={editRoleU} onChange={e => setEditRoleU(e.target.value)}
              className="w-full px-3.5 py-2 bg-[#102A4C] border border-[#163760]/60 rounded-lg text-slate-100 text-sm mb-5 focus:outline-none focus:border-[#00E5FF]">
              <option value="usuario">Usuario</option>
              <option value="supervisor">Supervisor</option>
              <option value="jefe de area">Jefe de area</option>
              <option value="admin">Administrador</option>
            </select>

            <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-1.5">Areas asignadas</label>
            <div className="grid grid-cols-2 gap-2 mb-5 max-h-44 overflow-y-auto pr-1">
              {areas.filter(a => a.is_active).map(area => (
                <div key={area.id}
                  onClick={() => setEditAreasU(prev => {
                    const nuevo = prev.includes(area.name) ? prev.filter(x => x !== area.name) : [...prev, area.name];
                    setEditZonesU(z => z.filter(zz => zonasDisponibles(nuevo).includes(zz)));
                    return nuevo;
                  })}
                  className={`px-3 py-2 rounded-lg border text-xs font-medium text-center cursor-pointer transition-all ${
                    editAreasU.includes(area.name)
                      ? 'bg-[#00E5FF]/10 border-[#00E5FF] text-[#00E5FF]'
                      : 'bg-[#1F2937] border-slate-700/70 text-slate-300 hover:border-slate-500'
                  }`}>
                  {area.name}
                </div>
              ))}
            </div>

            <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-1.5">
              Zonas a cargo <span className="text-slate-600 normal-case font-normal">(solo para supervisores)</span>
            </label>
            {zonasDisponibles(editAreasU).length === 0 ? (
              <p className="text-xs text-slate-500 mb-5">Selecciona primero un area con zonas definidas.</p>
            ) : (
              <div className="grid grid-cols-2 gap-2 mb-5 max-h-44 overflow-y-auto pr-1">
                {zonasDisponibles(editAreasU).map(z => (
                  <div key={z}
                    onClick={() => setEditZonesU(prev => prev.includes(z) ? prev.filter(x => x !== z) : [...prev, z])}
                    className={`px-3 py-2 rounded-lg border text-xs font-medium text-center cursor-pointer transition-all ${
                      editZonesU.includes(z)
                        ? 'bg-[#E8941A]/10 border-[#E8941A] text-[#E8941A]'
                        : 'bg-[#1F2937] border-slate-700/70 text-slate-300 hover:border-slate-500'
                    }`}>
                    {z}
                  </div>
                ))}
              </div>
            )}

            <p className="text-[11px] text-slate-500 mb-4">
              Si el supervisor no tiene zonas marcadas, vera todos los incidentes de sus areas.
            </p>

            {editUserError && <p className="text-xs text-[#D72631] mb-3">{editUserError}</p>}

            <div className="flex gap-2">
              <button onClick={guardarEdicion} disabled={editSaving}
                className="flex-1 px-4 py-2.5 bg-[#00E5FF] text-[#0B1E36] rounded-lg text-sm font-semibold hover:bg-[#0097A8] transition-all disabled:opacity-40">
                {editSaving ? 'Guardando...' : 'Guardar cambios'}
              </button>
              <button onClick={() => setEditUser(null)}
                className="px-4 py-2.5 bg-[#1F2937] border border-slate-700 text-slate-300 rounded-lg text-sm hover:border-slate-500 transition-all">
                Cancelar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── TAB: ÁREAS ────────────────────────────────────────────────── */}
      {activeTab === 'areas' && ['sso_manager', 'sso manager', 'admin'].includes(currentUserRole) && (
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-8 items-start">
          {/* Form crear área */}
          <div className="bg-[#111827] border border-slate-800 rounded-xl p-6 shadow-xl">
            <h2 className="text-lg mb-6 text-[#00E5FF] tracking-wide uppercase flex items-center gap-2"
              style={{ fontFamily: 'var(--font-display)', fontWeight: 600 }}>
              <span className="w-1.5 h-4 bg-[#00E5FF] rounded-sm block"></span>
              <Plus size={16} />
              Nueva Área Operativa
            </h2>

            {areaError   && <div className="bg-[#D72631]/10 border border-[#B71C25] text-[#D72631] p-3 rounded-lg mb-5 text-xs">{areaError}</div>}
            {areaSuccess && <div className="bg-emerald-950/40 border border-emerald-800 text-emerald-400 p-3 rounded-lg mb-5 text-xs">{areaSuccess}</div>}

            <form onSubmit={handleCreateArea} className="space-y-5">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Nombre del Área</label>
                <input type="text" value={areaName} onChange={e => setAreaName(e.target.value)} required
                  className="w-full px-3.5 py-2 bg-[#102A4C] border border-[#163760]/60 rounded-lg text-slate-100 text-sm focus:outline-none focus:border-[#00E5FF]"
                  placeholder="Ej: Línea de Producción 4" />
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Descripción (opcional)</label>
                <textarea value={areaDesc} onChange={e => setAreaDesc(e.target.value)} rows={3}
                  className="w-full px-3.5 py-2 bg-[#102A4C] border border-[#163760]/60 rounded-lg text-slate-100 text-sm focus:outline-none focus:border-[#00E5FF] resize-none"
                  placeholder="Descripción del área o zona operativa" />
              </div>
              <button type="submit"
                className="w-full px-6 py-3 bg-[#00E5FF] text-[#0B1E36] rounded-lg text-sm font-semibold hover:bg-[#0097A8] transition-all flex items-center justify-center gap-2">
                <Plus size={16} />
                Crear Área
              </button>
            </form>
          </div>

          {/* Lista de áreas */}
          <div className="lg:col-span-2 bg-[#111827] border border-slate-800 rounded-xl p-6 shadow-xl">
            <h2 className="text-lg mb-6 tracking-wide uppercase flex items-center justify-between"
              style={{ fontFamily: 'var(--font-display)', fontWeight: 600 }}>
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-4 bg-slate-600 rounded-sm block"></span>
                Áreas Registradas
              </div>
              <span className="text-sm font-normal text-slate-400">{areas.length} áreas</span>
            </h2>

            {areaLoading ? (
              <div className="text-center py-10 text-slate-500 text-sm">Cargando áreas...</div>
            ) : areas.length === 0 ? (
              <div className="text-center py-10 text-slate-500 text-sm">No hay áreas registradas aún.</div>
            ) : (
              <div className="space-y-3">
                {areas.map(area => (
                  <div key={area.id} className="bg-[#102A4C] border border-[#163760]/60 rounded-lg p-4">
                    {editingArea?.id === area.id ? (
                      <div className="space-y-3">
                        <input value={editName} onChange={e => setEditName(e.target.value)}
                          className="w-full px-3 py-2 bg-[#102A4C] border border-[#00E5FF] rounded-lg text-slate-100 text-sm focus:outline-none" />
                        <input value={editDesc} onChange={e => setEditDesc(e.target.value)}
                          className="w-full px-3 py-2 bg-[#111827] border border-slate-700 rounded-lg text-slate-100 text-sm focus:outline-none"
                          placeholder="Descripción" />
                        <div className="flex gap-2">
                          <button onClick={() => handleUpdateArea(area)}
                            className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 rounded-lg text-xs font-semibold hover:bg-emerald-500/20 transition-all">
                            <Check size={14} /> Guardar
                          </button>
                          <button onClick={() => setEditingArea(null)}
                            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-700/50 border border-[#163760] text-[#9DBBD2] rounded-lg text-xs font-semibold hover:bg-slate-700 transition-all">
                            <X size={14} /> Cancelar
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-1">
                            <h3 className="font-semibold text-slate-200">{area.name}</h3>
                            <span className={`text-[10px] px-2 py-0.5 rounded-full font-semibold border ${
                              area.is_active
                                ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                                : 'bg-slate-700/50 text-slate-500 border-slate-600'
                            }`}>
                              {area.is_active ? 'Activa' : 'Inactiva'}
                            </span>
                            {area.id.startsWith('def-') && (
                              <span className="text-[9px] bg-[#00E5FF]/20 text-[#00E5FF] px-1.5 py-0.2 rounded border border-[#00E5FF]/30 font-bold uppercase tracking-wider">
                                Default Mapa
                              </span>
                            )}
                          </div>
                          {area.description && (
                            <p className="text-xs text-slate-400">{area.description}</p>
                          )}
                          <p className="text-[10px] text-slate-600 mt-1">
                            ID: {area.id.slice(-8)}
                          </p>
                        </div>
                        <div className="flex items-center gap-2 ml-4">
                          <button onClick={() => handleToggleActive(area)}
                            title={area.is_active ? 'Desactivar' : 'Activar'}
                            className={`p-1.5 rounded-lg border text-xs transition-all ${
                              area.is_active
                                ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400 hover:bg-emerald-500/20'
                                : 'bg-slate-700/50 border-slate-600 text-slate-500 hover:bg-slate-700'
                            }`}>
                            <Check size={14} />
                          </button>
                          <button onClick={() => { setEditingArea(area); setEditName(area.name); setEditDesc(area.description ?? ''); }}
                            className="p-1.5 rounded-lg border border-[#163760] text-[#9DBBD2] hover:border-[#00E5FF] hover:text-[#00E5FF] transition-all">
                            <Edit2 size={14} />
                          </button>
                          <button onClick={() => handleDeleteArea(area.id)}
                            className="p-1.5 rounded-lg border border-[#163760] text-[#9DBBD2] hover:border-[#D72631] hover:text-[#D72631] transition-all">
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}