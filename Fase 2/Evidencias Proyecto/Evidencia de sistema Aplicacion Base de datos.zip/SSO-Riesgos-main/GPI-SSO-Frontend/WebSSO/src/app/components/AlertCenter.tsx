import { HelpTooltip } from './HelpTooltip';
import { useState, useEffect } from 'react';
import { AlertCircle, Clock, MapPin, Zap, RefreshCw, Bell } from 'lucide-react';
import { db } from '../firebase';
import { collection, query, orderBy, onSnapshot } from 'firebase/firestore';

const CLIENT_ID  = import.meta.env.VITE_CLIENT_ID   || 'cliente_prueba_123';
const ALERTS_API = import.meta.env.VITE_ALERTS_API_URL || 'http://localhost:8006';

type AlertType = 'IAP' | 'SLA' | 'ZONA' | 'AUTO' | 'manual';

type Alert = {
  id:          string;
  source:      'alert' | 'report';
  type:        string;
  title:       string;
  description: string;
  area:        string;
  timestamp:   string;
  priority:    'high' | 'medium' | 'low';
  status:      'active' | 'resolved' | 'pending_review';
};

// ─── HELPERS ──────────────────────────────────────────────────────────────────

function mapType(type: string): AlertType {
  if (type === 'iap')                     return 'IAP';
  if (type === 'sla')                     return 'SLA';
  if (type === 'zone' || type === 'zona') return 'ZONA';
  if (type === 'manual')                  return 'manual';
  return 'AUTO';
}

function getToken(): string | null {
  return localStorage.getItem('sso_token');
}

async function apiFetch<T>(url: string, options: RequestInit = {}): Promise<T> {
  const token = getToken();
  const res = await fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...options.headers,
    },
  });
  if (!res.ok) throw new Error(`Error ${res.status}`);
  return res.json();
}

const typeConfig = {
  IAP:    { label: 'IAP',    icon: AlertCircle, color: 'text-[#D72631]',    bgColor: 'bg-[#D72631]/20'    },
  SLA:    { label: 'SLA',    icon: Clock,       color: 'text-[#E8941A]', bgColor: 'bg-[#E8941A]/20' },
  ZONA:   { label: 'Zona',   icon: MapPin,      color: 'text-[#00C2DB]', bgColor: 'bg-[#00C2DB]/20' },
  AUTO:   { label: 'Auto',   icon: Zap,         color: 'text-[#1A5276]',   bgColor: 'bg-[#1A5276]/20'   },
  manual: { label: 'Manual', icon: Bell,        color: 'text-purple-400', bgColor: 'bg-purple-500/20' },
} as const;

// ─── COMPONENTE ───────────────────────────────────────────────────────────────

type Props = { userRole?: string; userAssignedAreas?: string[]; userAssignedZones?: string[] };
export default function AlertCenter({ userRole, userAssignedAreas, userAssignedZones }: Props) {
  // Jefe de área: solo ve alertas de sus áreas asignadas
  const isAreaManager = userRole === 'jefe de area' || userRole === 'jefe de área';
  const isSupervisor = userRole === 'supervisor';
  const zoneFilter = isSupervisor && userAssignedZones && userAssignedZones.length > 0
    ? userAssignedZones.map(z => z.trim().toLowerCase())
    : null;
  const areaFilter = isAreaManager && userAssignedAreas && userAssignedAreas.length > 0
    ? userAssignedAreas.map(a => a.trim().toLowerCase())
    : null;
  const [alerts, setAlerts]               = useState<Alert[]>([]);
  const [expanded, setExpanded]             = useState<Set<string>>(new Set());
  const [loading, setLoading]             = useState(true);

  const toggleExpand = (id: string) => {
    setExpanded(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };
  const [filter, setFilter]               = useState<AlertType | 'ALL'>('ALL');
  const [showManualForm, setShowManualForm] = useState(false);
  const [manualTitle, setManualTitle]     = useState('');
  const [manualBody, setManualBody]       = useState('');
  const [manualZone, setManualZone]       = useState('');
  const [manualArea, setManualArea]       = useState('');
  const [manualSeverity, setManualSeverity] = useState('high');
  const [areasList, setAreasList]         = useState<any[]>([]);
  const [sending, setSending]             = useState(false);
  const [successMsg, setSuccessMsg]       = useState('');
  const [resolvingAlert, setResolvingAlert] = useState<Alert | null>(null);
  const [resolveEvidence, setResolveEvidence] = useState<File | null>(null);
  const [resolveEvidencePreview, setResolveEvidencePreview] = useState<string | null>(null);
  const [resolveNote, setResolveNote] = useState('');

  const [stats, setStats]                 = useState({
    active: 0, pending: 0, resolvedToday: 0, automated: 0,
  });

  // ── Stats calculados localmente desde las alertas ya filtradas por área ─────
  // (reemplaza la llamada a la API global para que los números sean consistentes
  //  con lo que el jefe de área ve en su lista)
  const fetchStats = () => {
    // no-op: los stats se derivan de filteredAlerts más abajo
  };

  // ── Carga desde la API (alerts-service) ───────────────────────────────────
  useEffect(() => {
    let cancelado = false;

    const cargar = async () => {
      try {
        const json: any = await apiFetch(`${ALERTS_API}/v1/alerts/?status=&page_size=100`);
        const data = typeof json?.json === 'function' ? await json.json() : json;
        const lista = Array.isArray(data) ? data : (data?.data || []);
        if (cancelado) return;
        setAlerts(lista.map((a: any) => {
          const createdAt = new Date(a.created_at || Date.now());
          return {
            id: a.id || a.alert_id,
            source: 'alert',
            type: mapType(a.type),
            title: a.title ?? '',
            description: a.body || a.description || '',
            area: a.zone_id || a.zone_name || 'General',
            timestamp: createdAt.toLocaleString('es-CL'),
            priority: (a.severity === 'critical' || a.severity === 'high') ? 'high' : 'medium',
            status: a.status === 'resolved' ? 'resolved' : 'active',
          };
        }));
      } catch (e) {
        console.error('Error cargando alertas:', e);
      } finally {
        if (!cancelado) setLoading(false);
      }
    };

    cargar();
    const intervalo = setInterval(cargar, 30000);
    return () => { cancelado = true; clearInterval(intervalo); };
  }, []);

  // ── Resolver alerta ───────────────────────────────────────────────────────
  const handleResolve = async (alert: Alert) => {
    try {
      if (alert.source === 'report') {
        const REPORTS_API = import.meta.env.VITE_REPORTS_API_URL || 'http://localhost:8001';
        await apiFetch(`${REPORTS_API}/v1/reports/${alert.id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status: 'closed', feedback: 'Resuelta desde plataforma web' }),
        });
      } else {
        await apiFetch(`${ALERTS_API}/v1/alerts/${alert.id}/resolve`, {
          method: 'PATCH',
          body:   JSON.stringify({ resolution_note: 'Resuelta desde plataforma web' }),
        });
      }
      fetchStats();
    } catch (error) {
  window.alert('Error al resolver');
}
  };

  // ── Áreas y zonas para el formulario manual ───────────────────────────────
  useEffect(() => {
    (async () => {
      try {
        const res = await fetch(window.location.origin + '/api/areas/v1/areas/', {
          headers: { 'Authorization': 'Bearer ' + (localStorage.getItem('sso_token') || '') },
        });
        if (!res.ok) return;
        const json = await res.json();
        setAreasList(Array.isArray(json) ? json : (json.data || []));
      } catch { /* sin áreas, el campo queda vacío */ }
    })();
  }, []);

  // ── Crear alerta manual ───────────────────────────────────────────────────
  const handleManualAlert = async () => {
    if (!manualTitle || !manualBody) return;
    setSending(true);
    try {
      await apiFetch(`${ALERTS_API}/v1/alerts/manual`, {
        method: 'POST',
        body:   JSON.stringify({
          title:         manualTitle,
          body:          manualBody,
          zone_id:       manualZone || undefined,
          recipient_ids: undefined,  // el backend lo enviará a todos los de la zona
          severity:      manualSeverity,
        }),
      });
      setManualTitle(''); setManualBody(''); setManualZone(''); setManualArea(''); setManualSeverity('high');
      setShowManualForm(false);
      setSuccessMsg('Alerta enviada exitosamente');
      setTimeout(() => setSuccessMsg(''), 4000);
      fetchStats();
    } catch { alert('Error al enviar la alerta'); }
    finally { setSending(false); }
  };

  // Filtrar por tipo
  const byType = filter === 'ALL' ? alerts : alerts.filter(a => a.type === filter);
  // Filtrar por área asignada si es jefe de área
  const filteredAlerts = zoneFilter
    ? byType.filter(a => zoneFilter.includes((a.area || '').trim().toLowerCase()))
    : areaFilter
    ? byType.filter(a => areaFilter.includes((a.area || '').trim().toLowerCase()))
    : byType;

  // ─── RENDER ───────────────────────────────────────────────────────────────

  return (
    <div className="h-full p-6 overflow-auto">
      {/* Header */}
      <div className="mb-6 flex items-start justify-between pr-32">
        <div>
          <h1 className="text-4xl mb-2 tracking-tight" style={{ fontFamily: 'var(--font-display)', fontWeight: 700 }}>
            CENTRO DE ALERTAS
          </h1>
          <HelpTooltip steps={[
      { icon: '🔔', title: 'Alertas automáticas vs manuales', description: 'Las alertas AUTO se generan automáticamente por el sistema al detectar incidentes IAP o vencimientos SLA. Las manuales las creas tú con el botón "+ Nueva Alerta".' },
      { icon: '📌', title: 'Tipos de alerta', description: 'IAP (alto potencial), SLA (plazo vencido), ZONA (área específica) y AUTO (sistema). Cada tipo tiene su color e ícono para identificarlo rápidamente.' },
      { icon: '✅', title: 'Resolver una alerta', description: 'Haz clic en "Resolver" en cualquier alerta activa para marcarla como resuelta. Las alertas resueltas se mueven al historial.' },
      { icon: '🔍', title: 'Filtrar alertas', description: 'Usa los filtros superiores (Todas, IAP, SLA, Zona, Auto, Manual) para ver solo el tipo de alerta que te interesa.' },
    ]} />
          <p className="text-muted-foreground">
            Notificaciones automáticas y manuales del sistema
            <span className="ml-2 text-xs text-[#16A34A]">● En tiempo real</span>
          </p>
        </div>
        <div className="flex gap-2 mt-1">
          <button onClick={fetchStats}
            className="flex items-center gap-2 px-4 py-2 bg-secondary text-secondary-foreground rounded-lg hover:bg-secondary/80 transition-all">
            <RefreshCw size={16} />
            Actualizar stats
          </button>
          {userRole !== 'analyst' && (
  <button onClick={() => setShowManualForm(true)}
    className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-all">
    <Bell size={16} />
    Generar Alerta
  </button>
)}
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        {[
          { label: 'Alertas Activas',      value: filteredAlerts.filter(a => a.status === 'active').length,   color: 'text-[#D72631]'    },
          { label: 'Pendientes Revisión',  value: filteredAlerts.filter(a => a.status === 'active').length,   color: 'text-[#E8941A]' },
          { label: 'Resueltas Hoy',        value: filteredAlerts.filter(a => {
              if (a.status !== 'resolved') return false;
              const today = new Date().toLocaleDateString('es-ES');
              return a.timestamp?.startsWith(today) || a.timestamp?.includes(today.split('/').reverse().join('-'));
            }).length, color: 'text-[#16A34A]' },
          { label: 'Automáticas Enviadas', value: filteredAlerts.filter(a => a.source === 'alert').length,    color: 'text-[#1A5276]'   },
        ].map(({ label, value, color }) => (
          <div key={label} className="bg-card border border-border rounded-lg p-5">
            <div className="text-sm text-muted-foreground mb-1">{label}</div>
            <div className={`text-3xl font-mono font-semibold ${color}`}>
              {loading ? '...' : value}
            </div>
          </div>
        ))}
      </div>

      <div className="bg-card border border-border rounded-lg p-6">
        {/* Filters */}
        <div className="flex flex-wrap gap-2 mb-6">
          {(['ALL', 'IAP', 'SLA', 'ZONA', 'AUTO', 'manual'] as const).map(f => (
            <button key={f} onClick={() => setFilter(f)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                filter === f
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
              }`}>
              {f === 'ALL' ? 'Todas' : f === 'manual' ? 'Manual' : f}
            </button>
          ))}
        </div>

        {loading && (
          <div className="text-center py-12 text-muted-foreground">
            <RefreshCw size={32} className="animate-spin mx-auto mb-3 opacity-50" />
            Cargando alertas...
          </div>
        )}

        {!loading && (
          <div className="space-y-3">
            {filteredAlerts.map((alert) => {
              const type = typeConfig[alert.type as keyof typeof typeConfig] ?? typeConfig.AUTO;
              const Icon = type.icon;
              return (
                <div key={alert.id}
                  onClick={() => toggleExpand(alert.id)}
                  className={`p-5 rounded-lg border transition-all cursor-pointer ${
                    alert.status === 'active'
                      ? 'bg-secondary/50 border-border hover:border-primary/50'
                      : 'bg-secondary/20 border-border/50 opacity-60'
                  }`}>
                  <div className="flex items-start gap-4">
                    <div className={`p-3 rounded-lg ${type.bgColor} ${alert.status === 'active' ? 'animate-pulse' : ''}`}>
                      <Icon className={type.color} size={24} />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <div className="flex items-center gap-3 mb-1">
                            <span className={`px-2 py-1 rounded text-xs font-medium ${type.bgColor} ${type.color}`}>
                              {type.label}
                            </span>
                            <span className="font-mono text-xs text-muted-foreground">{alert.id?.slice(-8).toUpperCase()}</span>
                            {alert.status === 'resolved' && (
                              <span className="px-2 py-1 rounded text-xs font-medium bg-[#16A34A]/20 text-[#16A34A]">Resuelta</span>
                            )}
                          </div>
                          <h3 className="text-lg font-medium">{alert.title}</h3>
                        </div>
                        <div className="text-right text-xs text-muted-foreground">{alert.timestamp}</div>
                      </div>
                      {expanded.has(alert.id) && (
                      <><p className="text-sm text-muted-foreground mb-3">{alert.description}</p>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 text-sm">
                          <MapPin size={14} className="text-muted-foreground" />
                          <span>{alert.area}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          {alert.priority === 'high' && (
                            <span className="px-3 py-1 rounded-full text-xs font-medium bg-[#D72631]/20 text-[#D72631]">Alta Prioridad</span>
                          )}
                          {alert.priority === 'medium' && (
                            <span className="px-3 py-1 rounded-full text-xs font-medium bg-[#E8941A]/20 text-[#E8941A]">Prioridad Media</span>
                          )}
                          {alert.status === 'active' && userRole !== 'analyst' && (
  <button onClick={(e) => { e.stopPropagation(); setResolvingAlert(alert); }}
    className="px-3 py-1 rounded-full text-xs font-medium bg-[#16A34A]/20 text-[#16A34A] hover:bg-[#16A34A]/40 transition-all">
    Resolver
  </button>
)}
                        </div>
                      </div></>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}

            {filteredAlerts.length === 0 && (
              <div className="text-center py-12 text-muted-foreground">
                No hay alertas del tipo seleccionado
              </div>
            )}
          </div>
        )}
      </div>

      {/* Modal: Generar Alerta Manual */}
      {showManualForm && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50"
          onClick={() => setShowManualForm(false)}>
          <div className="bg-card border border-border rounded-lg p-6 max-w-md w-full mx-4"
            onClick={e => e.stopPropagation()}>
            <h3 className="text-xl mb-4 font-bold">Generar Alerta Manual</h3>
            <div className="space-y-4">
              <div>
                <label className="text-sm text-muted-foreground mb-2 block">Título</label>
                <input type="text" value={manualTitle} onChange={e => setManualTitle(e.target.value)}
                  placeholder="Ej: Zona de riesgo detectada"
                  className="w-full px-3 py-2 bg-secondary border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary" />
              </div>
              <div>
                <label className="text-sm text-muted-foreground mb-2 block">Descripción</label>
                <textarea value={manualBody} onChange={e => setManualBody(e.target.value)}
                  placeholder="Describe la situación..."
                  className="w-full px-3 py-2 bg-secondary border border-border rounded-lg h-24 resize-none focus:outline-none focus:ring-2 focus:ring-primary" />
              </div>
              <div>
                <label className="text-sm text-muted-foreground mb-2 block">Área</label>
                <select value={manualArea} onChange={e => { setManualArea(e.target.value); setManualZone(''); }}
                  className="w-full px-3 py-2 bg-secondary border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary">
                  <option value="">Toda la planta (todas las áreas)</option>
                  {areasList.map((a: any) => (
                    <option key={a.id || a.name} value={a.name || a.id}>{a.name || a.id}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-sm text-muted-foreground mb-2 block">Zona</label>
                <select value={manualZone} onChange={e => setManualZone(e.target.value)} disabled={!manualArea}
                  className="w-full px-3 py-2 bg-secondary border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary disabled:opacity-50">
                  <option value="">{manualArea ? 'Toda el área' : 'Selecciona un área primero'}</option>
                  {(areasList.find((a: any) => (a.name || a.id) === manualArea)?.zones || []).map((z: any) => {
                    const nombre = typeof z === 'string' ? z : (z.name || z.zone || '');
                    return <option key={nombre} value={nombre}>{nombre}</option>;
                  })}
                </select>
              </div>
              <div>
                <label className="text-sm text-muted-foreground mb-2 block">Prioridad</label>
                <select value={manualSeverity} onChange={e => setManualSeverity(e.target.value)}
                  className="w-full px-3 py-2 bg-secondary border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary">
                  <option value="high">Alta</option>
                  <option value="medium">Media</option>
                </select>
              </div>
            </div>
            <div className="flex gap-3 justify-end mt-6">
              <button onClick={() => setShowManualForm(false)}
                className="px-4 py-2 bg-secondary text-secondary-foreground rounded-lg hover:bg-secondary/80">
                Cancelar
              </button>
              <button onClick={handleManualAlert} disabled={sending || !manualTitle || !manualBody}
                className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 disabled:opacity-50 flex items-center gap-2">
                <Bell size={16} />
                {sending ? 'Enviando...' : 'Enviar Alerta'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Resolver Alerta con Evidencia */}
      {resolvingAlert && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50"
          onClick={() => { setResolvingAlert(null); setResolveEvidence(null); setResolveEvidencePreview(null); setResolveNote(''); }}>
          <div className="bg-card border border-border rounded-lg p-6 max-w-md w-full mx-4"
            onClick={e => e.stopPropagation()}>
            <h3 className="text-xl mb-2 font-bold">Resolver Alerta</h3>
            <p className="text-sm text-muted-foreground mb-4">
              #{resolvingAlert.id?.slice(-8).toUpperCase()} — {resolvingAlert.title}
            </p>

            <div className="space-y-4">
              <div>
                <label className="text-sm text-muted-foreground mb-2 block">Nota de resolución</label>
                <textarea value={resolveNote} onChange={e => setResolveNote(e.target.value)}
                  placeholder="Describe cómo se resolvió..."
                  className="w-full px-3 py-2 bg-secondary border border-border rounded-lg h-20 resize-none focus:outline-none focus:ring-2 focus:ring-primary text-sm" />
              </div>

              <div>
                <label className="text-sm text-muted-foreground mb-2 block">
                  Evidencia de cierre <span className="text-[#D72631]">*</span>
                </label>
                <input type="file" accept="image/*,.pdf,.doc,.docx"
                  onChange={e => {
                    const file = e.target.files?.[0];
                    if (!file) return;
                    setResolveEvidence(file);
                    if (file.type.startsWith('image/')) {
                      const reader = new FileReader();
                      reader.onloadend = () => setResolveEvidencePreview(reader.result as string);
                      reader.readAsDataURL(file);
                    } else {
                      setResolveEvidencePreview(null);
                    }
                  }}
                  className="w-full px-3 py-2 bg-secondary border border-border rounded-lg text-sm" />
                {resolveEvidencePreview && (
                  <img src={resolveEvidencePreview} alt="preview" className="w-full h-32 object-cover rounded-lg mt-2" />
                )}
                {resolveEvidence && !resolveEvidencePreview && (
                  <p className="text-xs text-[#16A34A] mt-1">Archivo: {resolveEvidence.name}</p>
                )}
                {!resolveEvidence && (
                  <p className="text-xs text-[#E8941A] mt-1">La evidencia es obligatoria para resolver la alerta</p>
                )}
              </div>
            </div>

            <div className="flex gap-3 justify-end mt-6">
              <button onClick={() => { setResolvingAlert(null); setResolveEvidence(null); setResolveEvidencePreview(null); setResolveNote(''); }}
                className="px-4 py-2 bg-secondary text-secondary-foreground rounded-lg hover:bg-secondary/80">
                Cancelar
              </button>
              <button disabled={!resolveEvidence}
                onClick={async () => {
                  await handleResolve(resolvingAlert);
                  setResolvingAlert(null);
                  setResolveEvidence(null);
                  setResolveEvidencePreview(null);
                  setResolveNote('');
                }}
                className="px-4 py-2 bg-[#16A34A] text-white rounded-lg hover:bg-[#16A34A]/90 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2">
                {resolveEvidence ? 'Confirmar Resolución' : 'Requiere evidencia'}
              </button>
            </div>
          </div>
        </div>
      )}

      {successMsg && (
        <div className="fixed bottom-4 right-4 bg-[#16A34A] text-white px-6 py-3 rounded-lg shadow-lg z-50">
          {successMsg}
        </div>
      )}
    </div>
  );
}