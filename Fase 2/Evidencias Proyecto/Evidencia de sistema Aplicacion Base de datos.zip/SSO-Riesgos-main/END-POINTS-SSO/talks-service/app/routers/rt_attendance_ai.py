
import asyncio
import io
import logging
import unicodedata

from fastapi import (
    APIRouter,
    Depends,
    File,
    Form,
    HTTPException,
    Security,
    UploadFile,
)
from fastapi.security import HTTPAuthorizationCredentials
from PIL import Image, UnidentifiedImageError

from ..dep_talks import (
    get_current_user,
    get_db,
    security,
)
from ..repositories.rep_talks import TalksRepository
from ..ai.attendance_extractor import (
    GeminiNotConfigured,
    UnsupportedAttendanceProvider,
    extract_attendance_image,
)
from ..ai.identity_matcher import match_extracted_workers
from ..ai.schemas import AttendancePreviewResponse


logger = logging.getLogger(__name__)
router = APIRouter()

MAX_IMAGE_BYTES = 10 * 1024 * 1024
MAX_IMAGE_PIXELS = 25_000_000

ALLOWED_IMAGE_TYPES = {
    "image/jpeg": "JPEG",
    "image/png": "PNG",
    "image/webp": "WEBP",
}

ALLOWED_ROLES = {
    "admin",
    "supervisor",
    "jefe de area",
}


def normalize_role(value: str) -> str:
    text = unicodedata.normalize(
        "NFKD",
        value or "",
    )

    text = "".join(
        char
        for char in text
        if not unicodedata.combining(char)
    )

    return text.lower().replace("_", " ").strip()


def validate_image_content(
    content: bytes,
    mime_type: str,
) -> None:
    try:
        with Image.open(io.BytesIO(content)) as image:
            expected_format = ALLOWED_IMAGE_TYPES[
                mime_type
            ]

            if image.format != expected_format:
                raise ValueError(
                    "El formato real no coincide "
                    "con el formato declarado."
                )

            if (
                image.width * image.height
                > MAX_IMAGE_PIXELS
            ):
                raise ValueError(
                    "La resolución de imagen es excesiva."
                )

            image.verify()

    except (
        UnidentifiedImageError,
        OSError,
        Image.DecompressionBombError,
    ) as exc:
        raise ValueError(
            "La imagen está dañada o no es válida."
        ) from exc


@router.post(
    "/v1/attendance/ocr/preview",
    response_model=AttendancePreviewResponse,
)
async def preview_attendance_ocr(
    talk_id: str = Form(...),
    file: UploadFile = File(...),
    db=Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(
        security
    ),
):
    user = get_current_user(credentials)

    client_id = user.get("client_id")
    user_id = user.get("user_id")

    if not client_id or not user_id:
        raise HTTPException(
            403,
            "Usuario o empresa no válidos.",
        )

    if normalize_role(
        user.get("role", "")
    ) not in ALLOWED_ROLES:
        raise HTTPException(
            403,
            "No tienes permisos para utilizar OCR.",
        )

    # Confirmar identidad y rol contra MongoDB.
    member = await db["users"].find_one(
        {
            "user_id": user_id,
            "client_id": client_id,
            "status": "active",
        },
        {
            "_id": 0,
            "role": 1,
        },
    )

    if (
        member is None
        or normalize_role(
            member.get("role", "")
        ) not in ALLOWED_ROLES
    ):
        raise HTTPException(
            403,
            "Usuario no habilitado para OCR.",
        )

    talk_id = talk_id.strip()

    if not talk_id:
        raise HTTPException(
            422,
            "La charla es obligatoria.",
        )

    repo = TalksRepository(db)

    talk = await repo.get_talk(
        client_id,
        talk_id,
    )

    if talk is None:
        raise HTTPException(
            404,
            "Charla no encontrada.",
        )

    mime_type = (
        file.content_type or ""
    ).lower().strip()

    if mime_type not in ALLOWED_IMAGE_TYPES:
        raise HTTPException(
            415,
            "Formato no soportado. Usa JPG, PNG o WEBP.",
        )

    try:
        content = await file.read(
            MAX_IMAGE_BYTES + 1
        )
    finally:
        await file.close()

    if not content:
        raise HTTPException(
            422,
            "La imagen está vacía.",
        )

    if len(content) > MAX_IMAGE_BYTES:
        raise HTTPException(
            413,
            "La imagen supera los 10 MB.",
        )

    try:
        await asyncio.to_thread(
            validate_image_content,
            content,
            mime_type,
        )

    except ValueError as exc:
        raise HTTPException(
            422,
            str(exc),
        ) from exc

    try:
        extracted = await asyncio.wait_for(
            extract_attendance_image(
                content,
                mime_type,
            ),
            timeout=9.0,
        )

    except (
        GeminiNotConfigured,
        UnsupportedAttendanceProvider,
    ) as exc:
        raise HTTPException(
            503,
            "El servicio de análisis no está configurado.",
        ) from exc

    except TimeoutError as exc:
        raise HTTPException(
            504,
            "Se agotó el tiempo de procesamiento OCR.",
        ) from exc

    except Exception as exc:
        logger.error(
            "Error OCR Gemini: %s",
            type(exc).__name__,
        )

        raise HTTPException(
            502,
            "No fue posible procesar la imagen.",
        ) from exc

    registered_workers = (
        await repo.list_active_workers_for_ocr(
            client_id
        )
    )

    matches = match_extracted_workers(
        extracted,
        registered_workers,
    )

    return AttendancePreviewResponse(
        talk_id=talk_id,
        detected_count=len(matches),
        recognized_workers=matches,
        pending_confirmation=True,
    )


@router.get("/v1/attendance/candidates")
async def list_attendance_candidates(
    db=Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Security(
        security
    ),
):
    """Lista trabajadores activos del mismo cliente para asistencia."""
    user = get_current_user(credentials)

    client_id = user.get("client_id")
    user_id = user.get("user_id")

    if not client_id or not user_id:
        raise HTTPException(
            403,
            "Usuario o empresa no válidos.",
        )

    if normalize_role(
        user.get("role", "")
    ) not in ALLOWED_ROLES:
        raise HTTPException(
            403,
            "No tienes permisos para registrar asistencia.",
        )

    member = await db["users"].find_one(
        {
            "user_id": user_id,
            "client_id": client_id,
            "status": "active",
        },
        {
            "_id": 0,
            "role": 1,
        },
    )

    if (
        member is None
        or normalize_role(
            member.get("role", "")
        ) not in ALLOWED_ROLES
    ):
        raise HTTPException(
            403,
            "Usuario no habilitado para registrar asistencia.",
        )

    workers = await TalksRepository(
        db
    ).list_active_workers_for_ocr(client_id)

    return [
        {
            "id": worker["user_id"],
            "name": " ".join(
                part
                for part in (
                    worker.get("name", "").strip(),
                    worker.get("last_name", "").strip(),
                )
                if part
            ),
            "email": worker.get("email"),
        }
        for worker in workers
    ]
