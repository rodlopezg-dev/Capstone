from datetime import datetime, timezone
from typing import Optional
import ulid as ulid_lib

def _now_iso():
    return datetime.now(timezone.utc).isoformat()

class ReportRepository:
    def __init__(self, db):
        self.db = db
        self.reports = db["reports"]
        self.notifications = db["notifications"]
        self.activity_log_col = db["activity_log"]

    _indexes_ensured = False

    async def ensure_indexes(self):
        if type(self)._indexes_ensured:
            return

        await self.reports.create_index(
            [
                ("client_id", 1),
                ("reported_by", 1),
                ("idempotency_key", 1),
            ],
            unique=True,
            partialFilterExpression={
                "idempotency_key": {
                    "$type": "string",
                },
            },
            name="uniq_report_idempotency",
        )

        type(self)._indexes_ensured = True

    async def get_by_idempotency_key(
        self,
        client_id,
        user_id,
        idempotency_key,
    ):
        doc = await self.reports.find_one(
            {
                "client_id": client_id,
                "reported_by": user_id,
                "idempotency_key": idempotency_key,
            }
        )

        if doc:
            doc.pop("_id", None)

        return doc

    async def save(self, client_id, report_id, report_data):
        report_data["report_id"] = report_id
        report_data["client_id"] = client_id
        await self.reports.insert_one(report_data)
        return report_id

    async def get_all(self, client_id, user_id=None):
        results = []
        query = {"client_id": client_id}
        if user_id:
            query["reported_by"] = user_id
        async for doc in self.reports.find(query).sort("created_at", -1):
            doc.pop("_id", None)
            results.append(doc)
        return results

    async def get_by_id(self, client_id, report_id):
        doc = await self.reports.find_one({"report_id": report_id, "client_id": client_id})
        if doc:
            doc.pop("_id", None)
        return doc

    async def update_analysis(
        self,
        client_id,
        report_id,
        analysis_data,
    ):
        result = await self.reports.update_one(
            {
                "report_id": report_id,
                "client_id": client_id,
            },
            {
                "$set": analysis_data,
            },
        )
        return result.modified_count > 0

    async def get_by_user(self, client_id, user_id):
        results = []
        async for doc in self.reports.find({"client_id": client_id, "reported_by": user_id}).sort("created_at", -1):
            doc.pop("_id", None)
            results.append(doc)
        return results

    async def update_status(self, client_id, report_id, status, feedback="", extra_fields=None):
        update = {"$set": {"status": status, f"timeline.{status}": _now_iso()}}
        if feedback:
            update["$set"]["feedback"] = feedback
        if extra_fields:
            for k, v in extra_fields.items():
                if v is not None:
                    update["$set"][k] = v
        result = await self.reports.update_one({"report_id": report_id, "client_id": client_id}, update)
        return result.modified_count > 0

    async def update_closure_evidence(
        self,
        client_id,
        report_id,
        closure_evidence,
    ):
        result = await self.reports.update_one(
            {
                "report_id": report_id,
                "client_id": client_id,
            },
            {
                "$set": {
                    "closure_evidence": closure_evidence,
                }
            },
        )

        matched_count = getattr(
            result,
            "matched_count",
            None,
        )

        if matched_count is not None:
            return matched_count > 0

        return result.modified_count > 0

    async def add_activity_log(self, client_id, report_id, entry):
        log_id = f"log_{ulid_lib.ULID()}"
        entry.update({"id": log_id, "report_id": report_id, "client_id": client_id, "created_at": _now_iso()})
        await self.activity_log_col.insert_one(entry)
        return log_id

    async def get_activity_log(self, client_id, report_id):
        results = []
        async for doc in self.activity_log_col.find({"report_id": report_id, "client_id": client_id}).sort("created_at", -1):
            doc.pop("_id", None)
            results.append(doc)
        return results

    async def create_notification(self, client_id, user_id, notif_data):
        notif_id = f"notif_{ulid_lib.ULID()}"
        notif_data.update({"id": notif_id, "user_id": user_id, "client_id": client_id, "read": False, "created_at": _now_iso()})
        await self.notifications.insert_one(notif_data)
        return notif_id

    async def get_notifications(self, client_id, user_id):
        results = []
        async for doc in self.notifications.find({"client_id": client_id, "user_id": user_id}).sort("created_at", -1).limit(50):
            doc.pop("_id", None)
            results.append(doc)
        return results

    async def mark_notification_read(self, client_id, notif_id):
        result = await self.notifications.update_one({"id": notif_id, "client_id": client_id}, {"$set": {"read": True}})
        return result.modified_count > 0
