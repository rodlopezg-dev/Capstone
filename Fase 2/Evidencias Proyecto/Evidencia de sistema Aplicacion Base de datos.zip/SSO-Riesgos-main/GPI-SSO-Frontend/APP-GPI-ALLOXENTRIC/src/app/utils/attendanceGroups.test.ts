import { expect, it } from 'vitest';
import { groupAttendance } from './attendanceGroups';

it('combines manual and QR registrations only for the same talk and preserves their dates', () => {
  const records = [
    { attendance_id: 'qr1', talk_id: 't1', topic: 'Charla', date: '2026-10-07', source: 'qr', attendees: ['Ana'] },
    { attendance_id: 'manual1', talk_id: 't1', topic: 'Charla', date: '2026-10-08', source: 'manual', attendees: ['Luis'] },
    { attendance_id: 'qr2', talk_id: 't2', topic: 'Charla', date: '2026-10-07', attendees: ['Maria'] },
  ];
  const groups = groupAttendance(records);
  expect(groups).toHaveLength(2);
  expect(groups[0].participants.map(row => [row.name, row.method, row.recordDate])).toEqual([
    ['Ana', 'qr', '2026-10-07'], ['Luis', 'manual', '2026-10-08'],
  ]);
  expect(records).toHaveLength(3);
});

it('does not combine unrelated legacy records by title', () => {
  expect(groupAttendance([
    { attendance_id: 'a', topic: 'Same', attendees: [] },
    { attendance_id: 'b', topic: 'Same', attendees: [] },
  ])).toHaveLength(2);
});
