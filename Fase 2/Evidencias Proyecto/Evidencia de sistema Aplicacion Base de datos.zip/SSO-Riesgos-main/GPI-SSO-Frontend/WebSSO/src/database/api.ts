/**
 * SERVICIOS DE API - SINCRONIZACIÓN CON BASE DE DATOS
 *
 * Este archivo contiene todos los servicios para comunicarse con la base de datos.
 * Implementa endpoints para recibir datos de la app móvil y servir datos a la web.
 *
 * IMPORTANTE: Estos son servicios MOCK/PLACEHOLDER.
 * Debes conectar estos servicios a tu base de datos real.
 */

import type {
  Reporte,
  Zona,
  Alerta,
  Usuario,
  Notificacion,
  EstadisticasGlobales,
  EstadisticasArea,
  EstadoReporte,
} from './types';
import { apiConfig } from './config';

// ============================================
// UTILIDAD: Fetch con manejo de errores
// ============================================

async function apiCall<T>(
  endpoint: string,
  options?: RequestInit
): Promise<T> {
  try {
    const response = await fetch(`${apiConfig.baseUrl}${endpoint}`, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiConfig.apiKey}`,
        ...options?.headers,
      },
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    console.error('API Error:', error);
    throw error;
  }
}

// ============================================
// REPORTES - Desde App Móvil
// ============================================

export const reportesAPI = {
  /**
   * Obtener todos los reportes
   * Usado por: Módulo de Gestión de Incidentes (W-02)
   */
  async getAll(filtros?: {
    estado?: EstadoReporte;
    area?: string;
    es_iap?: boolean;
    fecha_desde?: Date;
    fecha_hasta?: Date;
  }): Promise<Reporte[]> {
    // TODO: Conectar a tu base de datos
    const queryParams = new URLSearchParams();
    if (filtros) {
      Object.entries(filtros).forEach(([key, value]) => {
        if (value !== undefined) {
          queryParams.append(key, value.toString());
        }
      });
    }

    return apiCall<Reporte[]>(`/reportes?${queryParams}`);
  },

  /**
   * Obtener un reporte por ID
   * Usado por: Detalle de Reporte (M-03 en móvil, detalle en web)
   */
  async getById(id: string): Promise<Reporte> {
    // TODO: Conectar a tu base de datos
    return apiCall<Reporte>(`/reportes/${id}`);
  },

  /**
   * Crear nuevo reporte (desde app móvil)
   * Endpoint que recibe datos de la app cuando un empleado reporta un hallazgo
   */
  async crear(data: {
    area: string;
    linea: string;
    proceso: string;
    tipo: 'acto_inseguro' | 'condicion_insegura';
    es_iap: boolean;
    descripcion: string;
    evidencia_foto: File | Blob;
    evidencia_video?: File | Blob;
    reportador_id: string;
  }): Promise<Reporte> {
    // TODO: Conectar a tu base de datos
    // 1. Subir foto/video a storage (S3, Cloudinary, etc.)
    // 2. Crear registro en base de datos
    // 3. Generar alerta si es IAP
    // 4. Notificar a supervisores

    const formData = new FormData();
    Object.entries(data).forEach(([key, value]) => {
      if (value instanceof File || value instanceof Blob) {
        formData.append(key, value);
      } else {
        formData.append(key, String(value));
      }
    });

    return apiCall<Reporte>('/reportes', {
      method: 'POST',
      body: formData,
    });
  },

  /**
   * Actualizar estado del reporte (desde web)
   * Usado por: Supervisores para cambiar estado y agregar feedback
   */
  async actualizar(id: string, data: {
    estado?: EstadoReporte;
    responsable_asignado?: string;
    feedback_supervisor?: string;
  }): Promise<Reporte> {
    // TODO: Conectar a tu base de datos
    return apiCall<Reporte>(`/reportes/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(data),
    });
  },

  /**
   * Obtener reportes por usuario (para app móvil)
   * Usado por: Pantalla "Mis Reportes" (M-04)
   */
  async getPorUsuario(usuarioId: string): Promise<Reporte[]> {
    // TODO: Conectar a tu base de datos
    return apiCall<Reporte[]>(`/reportes/usuario/${usuarioId}`);
  },
};

// ============================================
// ZONAS - Gemelo Digital
// ============================================

export const zonasAPI = {
  /**
   * Obtener todas las zonas configuradas
   * Usado por: Command Center (W-01), Gemelo Digital (W-03)
   */
  async getAll(): Promise<Zona[]> {
    // TODO: Conectar a tu base de datos
    return apiCall<Zona[]>('/zonas');
  },

  /**
   * Crear nueva zona
   * Usado por: Gemelo Digital (W-03) cuando se dibuja una zona
   */
  async crear(data: {
    nombre: string;
    proceso_asociado: string;
    coordenadas: { x: number; y: number }[];
    color_identificacion: string;
    plano_base_url: string;
  }): Promise<Zona> {
    // TODO: Conectar a tu base de datos
    return apiCall<Zona>('/zonas', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  /**
   * Actualizar zona existente
   */
  async actualizar(id: string, data: Partial<Zona>): Promise<Zona> {
    // TODO: Conectar a tu base de datos
    return apiCall<Zona>(`/zonas/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(data),
    });
  },

  /**
   * Eliminar zona
   */
  async eliminar(id: string): Promise<void> {
    // TODO: Conectar a tu base de datos
    return apiCall<void>(`/zonas/${id}`, {
      method: 'DELETE',
    });
  },

  /**
   * Calcular score de riesgo de zona
   * Se calcula basado en los reportes recientes del área
   */
  async calcularScoreRiesgo(zonaId: string): Promise<number> {
    // TODO: Conectar a tu base de datos
    // Algoritmo sugerido:
    // - Cantidad de incidentes últimos 7 días
    // - Severidad (IAP = peso mayor)
    // - Tiempo sin remediación
    // - Historial de capacitaciones
    return apiCall<number>(`/zonas/${zonaId}/score-riesgo`);
  },
};

// ============================================
// ALERTAS
// ============================================

export const alertasAPI = {
  /**
   * Obtener todas las alertas
   * Usado por: Centro de Alertas (W-04)
   */
  async getAll(filtros?: {
    tipo?: string;
    activa?: boolean;
  }): Promise<Alerta[]> {
    // TODO: Conectar a tu base de datos
    const queryParams = new URLSearchParams();
    if (filtros) {
      Object.entries(filtros).forEach(([key, value]) => {
        if (value !== undefined) {
          queryParams.append(key, value.toString());
        }
      });
    }
    return apiCall<Alerta[]>(`/alertas?${queryParams}`);
  },

  /**
   * Crear alerta manual
   * Usado por: Botón "Generar Alerta" en Gestión de Incidentes (W-02)
   */
  async crearManual(data: {
    titulo: string;
    descripcion: string;
    area_afectada: string;
  }): Promise<Alerta> {
    // TODO: Conectar a tu base de datos
    return apiCall<Alerta>('/alertas', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  /**
   * Marcar alerta como resuelta
   */
  async resolver(id: string): Promise<Alerta> {
    // TODO: Conectar a tu base de datos
    return apiCall<Alerta>(`/alertas/${id}/resolver`, {
      method: 'POST',
    });
  },
};

// ============================================
// NOTIFICACIONES
// ============================================

export const notificacionesAPI = {
  /**
   * Obtener notificaciones de un usuario
   * Usado por: App Móvil (M-05), Campana en web
   */
  async getPorUsuario(usuarioId: string): Promise<Notificacion[]> {
    // TODO: Conectar a tu base de datos
    return apiCall<Notificacion[]>(`/notificaciones/usuario/${usuarioId}`);
  },

  /**
   * Marcar notificación como leída
   */
  async marcarLeida(id: string): Promise<void> {
    // TODO: Conectar a tu base de datos
    return apiCall<void>(`/notificaciones/${id}/leer`, {
      method: 'POST',
    });
  },

  /**
   * Marcar todas como leídas
   */
  async marcarTodasLeidas(usuarioId: string): Promise<void> {
    // TODO: Conectar a tu base de datos
    return apiCall<void>(`/notificaciones/usuario/${usuarioId}/leer-todas`, {
      method: 'POST',
    });
  },
};

// ============================================
// ESTADÍSTICAS Y KPIs
// ============================================

export const estadisticasAPI = {
  /**
   * Obtener estadísticas globales
   * Usado por: Command Center (W-01)
   */
  async getGlobales(): Promise<EstadisticasGlobales> {
    // TODO: Conectar a tu base de datos
    return apiCall<EstadisticasGlobales>('/estadisticas/globales');
  },

  /**
   * Obtener ranking de áreas críticas
   * Usado por: Command Center (W-01) - panel lateral
   */
  async getRankingAreas(limite: number = 5): Promise<EstadisticasArea[]> {
    // TODO: Conectar a tu base de datos
    return apiCall<EstadisticasArea[]>(`/estadisticas/ranking-areas?limite=${limite}`);
  },

  /**
   * Obtener tendencia de riesgo
   * Usado por: Command Center (W-01) - gráfico de tendencia
   */
  async getTendenciaRiesgo(dias: number = 7): Promise<{ fecha: string; score: number }[]> {
    // TODO: Conectar a tu base de datos
    return apiCall<{ fecha: string; score: number }[]>(`/estadisticas/tendencia?dias=${dias}`);
  },
};

// ============================================
// USUARIOS
// ============================================

export const usuariosAPI = {
  /**
   * Autenticar usuario
   * Usado por: Login (app móvil y web)
   */
  async login(email: string, password: string): Promise<Usuario & { token: string }> {
    // TODO: Conectar a tu base de datos
    return apiCall<Usuario & { token: string }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
  },

  /**
   * Obtener perfil de usuario
   * Usado por: Perfil (M-06 en móvil)
   */
  async getPerfil(id: string): Promise<Usuario> {
    // TODO: Conectar a tu base de datos
    return apiCall<Usuario>(`/usuarios/${id}`);
  },
};

// ============================================
// EXPORTACIÓN DE REPORTES
// ============================================

export const exportacionAPI = {
  /**
   * Generar reporte en PDF/Excel/CSV
   * Usado por: Reportes y Exportación (W-05)
   */
  async exportar(params: {
    plantilla: string;
    fecha_desde: Date;
    fecha_hasta: Date;
    area?: string;
    formato: 'pdf' | 'excel' | 'csv';
  }): Promise<Blob> {
    // TODO: Conectar a tu base de datos
    const queryParams = new URLSearchParams({
      plantilla: params.plantilla,
      fecha_desde: params.fecha_desde.toISOString(),
      fecha_hasta: params.fecha_hasta.toISOString(),
      formato: params.formato,
      ...(params.area && { area: params.area }),
    });

    const response = await fetch(`${apiConfig.baseUrl}/reportes/exportar?${queryParams}`, {
      headers: {
        'Authorization': `Bearer ${apiConfig.apiKey}`,
      },
    });

    return await response.blob();
  },
};
