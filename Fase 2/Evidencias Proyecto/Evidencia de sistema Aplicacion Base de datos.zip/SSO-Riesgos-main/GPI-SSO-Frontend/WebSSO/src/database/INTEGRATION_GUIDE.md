# Guía de Integración de Base de Datos

Esta guía te muestra cómo usar los servicios de base de datos en tus componentes React.

## 📦 Importar Servicios

```typescript
import {
  reportesAPI,
  zonasAPI,
  alertasAPI,
  notificacionesAPI,
  estadisticasAPI,
  usuariosAPI,
  exportacionAPI
} from '@/database/api';
```

---

## 🎯 Ejemplos de Uso en Componentes

### 1. Command Center (W-01)

```typescript
import { useState, useEffect } from 'react';
import { estadisticasAPI, zonasAPI } from '@/database/api';

function CommandCenter() {
  const [kpis, setKpis] = useState(null);
  const [zonas, setZonas] = useState([]);
  const [ranking, setRanking] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function cargarDatos() {
      try {
        // Obtener KPIs globales
        const estadisticas = await estadisticasAPI.getGlobales();
        setKpis(estadisticas);

        // Obtener zonas para mapa de calor
        const zonasData = await zonasAPI.getAll();
        setZonas(zonasData);

        // Obtener ranking de áreas críticas
        const rankingData = await estadisticasAPI.getRankingAreas(5);
        setRanking(rankingData);

        setLoading(false);
      } catch (error) {
        console.error('Error cargando datos:', error);
      }
    }

    cargarDatos();
  }, []);

  if (loading) return <div>Cargando...</div>;

  return (
    <div>
      {/* Mapa de Calor */}
      <HeatMap zonas={zonas} />

      {/* KPIs */}
      <div className="grid grid-cols-3 gap-4">
        <KPICard label="Total Reportes" value={kpis.total_reportes} />
        <KPICard label="IAP Activos" value={kpis.iap_activos} />
        <KPICard label="Variación" value={`${kpis.variacion_porcentual}%`} />
      </div>

      {/* Ranking de Áreas */}
      <AreaRanking areas={ranking} />
    </div>
  );
}
```

### 2. Gestión de Incidentes (W-02)

```typescript
import { useState, useEffect } from 'react';
import { reportesAPI } from '@/database/api';

function IncidentManagement() {
  const [reportes, setReportes] = useState([]);
  const [filtro, setFiltro] = useState('todos');

  useEffect(() => {
    async function cargarReportes() {
      try {
        let filtros = {};

        if (filtro === 'pendientes') {
          filtros = { estado: 'en_revision' };
        } else if (filtro === 'iap') {
          filtros = { es_iap: true };
        } else if (filtro === 'vencidos') {
          filtros = { estado: 'vencido' };
        }

        const data = await reportesAPI.getAll(filtros);
        setReportes(data);
      } catch (error) {
        console.error('Error cargando reportes:', error);
      }
    }

    cargarReportes();
  }, [filtro]);

  async function actualizarReporte(id, nuevoEstado) {
    try {
      await reportesAPI.actualizar(id, {
        estado: nuevoEstado,
        feedback_supervisor: 'Comentario del supervisor...'
      });

      // Recargar reportes
      const data = await reportesAPI.getAll();
      setReportes(data);
    } catch (error) {
      console.error('Error actualizando reporte:', error);
    }
  }

  return (
    <div>
      {/* Filtros */}
      <div className="flex gap-2 mb-4">
        <button onClick={() => setFiltro('todos')}>Todos</button>
        <button onClick={() => setFiltro('pendientes')}>Pendientes</button>
        <button onClick={() => setFiltro('iap')}>IAP</button>
        <button onClick={() => setFiltro('vencidos')}>Vencidos</button>
      </div>

      {/* Tabla de Reportes */}
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Área</th>
            <th>Estado</th>
            <th>IAP</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {reportes.map((reporte) => (
            <tr key={reporte.id}>
              <td>{reporte.id}</td>
              <td>{reporte.area}</td>
              <td>{reporte.estado}</td>
              <td>{reporte.es_iap ? '⚠️' : ''}</td>
              <td>
                <button onClick={() => actualizarReporte(reporte.id, 'cerrado')}>
                  Cerrar
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
```

### 3. Gemelo Digital (W-03)

```typescript
import { useState, useEffect } from 'react';
import { zonasAPI } from '@/database/api';

function DigitalTwin() {
  const [zonas, setZonas] = useState([]);
  const [planoUrl, setPlanoUrl] = useState('');

  async function subirPlano(archivo) {
    // 1. Subir archivo a storage (S3, Cloudinary, etc.)
    const formData = new FormData();
    formData.append('plano', archivo);

    const response = await fetch('/api/upload-plano', {
      method: 'POST',
      body: formData
    });

    const { url } = await response.json();
    setPlanoUrl(url);
  }

  async function crearZona(zonaData) {
    try {
      await zonasAPI.crear({
        nombre: zonaData.nombre,
        proceso_asociado: zonaData.proceso,
        coordenadas: zonaData.coordenadas,
        color_identificacion: zonaData.color,
        plano_base_url: planoUrl
      });

      // Recargar zonas
      const zonasActualizadas = await zonasAPI.getAll();
      setZonas(zonasActualizadas);
    } catch (error) {
      console.error('Error creando zona:', error);
    }
  }

  async function eliminarZona(id) {
    try {
      await zonasAPI.eliminar(id);

      // Recargar zonas
      const zonasActualizadas = await zonasAPI.getAll();
      setZonas(zonasActualizadas);
    } catch (error) {
      console.error('Error eliminando zona:', error);
    }
  }

  return (
    <div>
      {/* Subir Plano */}
      <input
        type="file"
        accept="image/*,application/pdf"
        onChange={(e) => subirPlano(e.target.files[0])}
      />

      {/* Editor de Zonas */}
      {planoUrl && (
        <MapEditor
          planoUrl={planoUrl}
          zonas={zonas}
          onCrearZona={crearZona}
          onEliminarZona={eliminarZona}
        />
      )}

      {/* Lista de Zonas */}
      <ul>
        {zonas.map((zona) => (
          <li key={zona.id}>
            {zona.nombre} - Score: {zona.score_riesgo}
            <button onClick={() => eliminarZona(zona.id)}>Eliminar</button>
          </li>
        ))}
      </ul>
    </div>
  );
}
```

### 4. Centro de Alertas (W-04)

```typescript
import { useState, useEffect } from 'react';
import { alertasAPI } from '@/database/api';

function AlertCenter() {
  const [alertas, setAlertas] = useState([]);
  const [filtro, setFiltro] = useState('todas');

  useEffect(() => {
    async function cargarAlertas() {
      try {
        let filtros = {};

        if (filtro === 'iap') {
          filtros = { tipo: 'iap' };
        } else if (filtro === 'activas') {
          filtros = { activa: true };
        }

        const data = await alertasAPI.getAll(filtros);
        setAlertas(data);
      } catch (error) {
        console.error('Error cargando alertas:', error);
      }
    }

    cargarAlertas();
  }, [filtro]);

  async function crearAlertaManual(formData) {
    try {
      await alertasAPI.crearManual({
        titulo: formData.titulo,
        descripcion: formData.descripcion,
        area_afectada: formData.area
      });

      // Recargar alertas
      const data = await alertasAPI.getAll();
      setAlertas(data);
    } catch (error) {
      console.error('Error creando alerta:', error);
    }
  }

  async function resolverAlerta(id) {
    try {
      await alertasAPI.resolver(id);

      // Recargar alertas
      const data = await alertasAPI.getAll();
      setAlertas(data);
    } catch (error) {
      console.error('Error resolviendo alerta:', error);
    }
  }

  return (
    <div>
      {/* Filtros */}
      <div className="flex gap-2 mb-4">
        <button onClick={() => setFiltro('todas')}>Todas</button>
        <button onClick={() => setFiltro('iap')}>IAP</button>
        <button onClick={() => setFiltro('activas')}>Activas</button>
      </div>

      {/* Lista de Alertas */}
      <ul>
        {alertas.map((alerta) => (
          <li key={alerta.id} className={alerta.activa ? 'font-bold' : ''}>
            <h3>{alerta.titulo}</h3>
            <p>{alerta.descripcion}</p>
            <span>Área: {alerta.area_afectada}</span>
            {alerta.activa && !alerta.resuelta && (
              <button onClick={() => resolverAlerta(alerta.id)}>
                Resolver
              </button>
            )}
          </li>
        ))}
      </ul>

      {/* Formulario Nueva Alerta */}
      <button onClick={() => crearAlertaManual({
        titulo: 'Alerta Manual',
        descripcion: 'Descripción...',
        area: 'Línea 3'
      })}>
        Generar Alerta
      </button>
    </div>
  );
}
```

### 5. Reportes y Exportación (W-05)

```typescript
import { useState } from 'react';
import { exportacionAPI } from '@/database/api';

function Reports() {
  const [loading, setLoading] = useState(false);

  async function exportarReporte(params) {
    try {
      setLoading(true);

      const blob = await exportacionAPI.exportar({
        plantilla: params.plantilla,
        fecha_desde: new Date('2025-04-01'),
        fecha_hasta: new Date('2025-04-17'),
        area: params.area,
        formato: params.formato
      });

      // Descargar archivo
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `reporte_${params.formato}.${params.formato}`;
      a.click();

      setLoading(false);
    } catch (error) {
      console.error('Error exportando reporte:', error);
      setLoading(false);
    }
  }

  return (
    <div>
      <button
        onClick={() => exportarReporte({
          plantilla: 'ejecutivo_semanal',
          formato: 'pdf'
        })}
        disabled={loading}
      >
        {loading ? 'Generando...' : 'Exportar PDF'}
      </button>

      <button
        onClick={() => exportarReporte({
          plantilla: 'detalle_incidentes',
          formato: 'excel'
        })}
        disabled={loading}
      >
        {loading ? 'Generando...' : 'Exportar Excel'}
      </button>
    </div>
  );
}
```

---

## 🔄 Manejo de Datos en Tiempo Real

Si usas Supabase, puedes escuchar cambios en tiempo real:

```typescript
import { useEffect } from 'react';
import { supabase } from '@/database/config';

function RealtimeComponent() {
  useEffect(() => {
    // Suscribirse a cambios en tabla reportes
    const subscription = supabase
      .channel('reportes-changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'reportes' },
        (payload) => {
          console.log('Cambio detectado:', payload);
          // Actualizar estado de la UI
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(subscription);
    };
  }, []);

  return <div>Escuchando cambios en tiempo real...</div>;
}
```

---

## ⚡ Usando Datos Mock durante Desarrollo

```typescript
import { reportesMock } from '@/database/mock-data';

function DevelopmentComponent() {
  // Usa datos mock si no hay API disponible
  const [reportes, setReportes] = useState(reportesMock);

  // O alterna entre mock y API real
  const useMockData = process.env.NODE_ENV === 'development';

  useEffect(() => {
    if (useMockData) {
      setReportes(reportesMock);
    } else {
      reportesAPI.getAll().then(setReportes);
    }
  }, []);

  return <div>{/* Tu componente */}</div>;
}
```

---

## 🎨 Custom Hooks para Reutilizar Lógica

```typescript
// hooks/useReportes.ts
import { useState, useEffect } from 'react';
import { reportesAPI } from '@/database/api';

export function useReportes(filtros = {}) {
  const [reportes, setReportes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function cargar() {
      try {
        setLoading(true);
        const data = await reportesAPI.getAll(filtros);
        setReportes(data);
        setError(null);
      } catch (err) {
        setError(err);
      } finally {
        setLoading(false);
      }
    }

    cargar();
  }, [JSON.stringify(filtros)]);

  return { reportes, loading, error };
}

// Uso:
function MiComponente() {
  const { reportes, loading, error } = useReportes({ es_iap: true });

  if (loading) return <div>Cargando...</div>;
  if (error) return <div>Error: {error.message}</div>;

  return <div>{reportes.length} reportes IAP</div>;
}
```

---

## 🔥 Próximos Pasos

1. ✅ Configurar base de datos (seguir `README.md`)
2. ✅ Crear tablas con `schema.sql`
3. ✅ Configurar `.env` con credenciales
4. ✅ Implementar endpoints en backend
5. ✅ Integrar servicios en componentes React
6. ✅ Probar sincronización App Móvil ↔ Web
