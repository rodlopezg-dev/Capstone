import unittest

from app.services.report_manager_selector import (
    select_report_managers,
)


class ReportManagerSelectorTests(unittest.TestCase):

    def test_selects_global_and_area_managers(self):
        users = [
            {
                "user_id": "supervisor_area_1",
                "client_id": "tenant_a",
                "role": "supervisor",
                "status": "active",
                "assigned_areas": ["Linea 1"],
            },
            {
                "user_id": "supervisor_area_2",
                "client_id": "tenant_a",
                "role": "supervisor",
                "status": "active",
                "assigned_areas": ["Linea 2"],
            },
            {
                "user_id": "jefe_area_1",
                "client_id": "tenant_a",
                "role": "jefe_de_area",
                "status": "active",
                "assigned_areas": ["Linea 1"],
            },
            {
                "user_id": "admin_a",
                "client_id": "tenant_a",
                "role": "admin",
                "status": "active",
                "assigned_areas": [],
            },
            {
                "user_id": "manager_a",
                "client_id": "tenant_a",
                "role": "sso_manager",
                "status": "active",
                "assigned_areas": [],
            },
            {
                "user_id": "worker_a",
                "client_id": "tenant_a",
                "role": "worker",
                "status": "active",
                "assigned_areas": ["Linea 1"],
            },
        ]

        result = select_report_managers(
            users,
            client_id="tenant_a",
            area_id="Linea 1",
        )

        self.assertEqual(
            [item["user_id"] for item in result],
            [
                "supervisor_area_1",
                "jefe_area_1",
                "admin_a",
                "manager_a",
            ],
        )

    def test_enforces_tenant_status_and_exclusion(self):
        users = [
            {
                "user_id": "creator",
                "client_id": "tenant_a",
                "role": "admin",
                "status": "active",
            },
            {
                "user_id": "admin_inactive",
                "client_id": "tenant_a",
                "role": "admin",
                "status": "inactive",
            },
            {
                "user_id": "admin_other_tenant",
                "client_id": "tenant_b",
                "role": "admin",
                "status": "active",
            },
            {
                "user_id": "admin_valid",
                "client_id": "tenant_a",
                "role": "admin",
                "status": "active",
            },
        ]

        result = select_report_managers(
            users,
            client_id="tenant_a",
            area_id="Linea 1",
            exclude_user_id="creator",
        )

        self.assertEqual(
            [item["user_id"] for item in result],
            ["admin_valid"],
        )

    def test_supports_legacy_area_and_normalization(self):
        users = [
            {
                "user_id": "legacy_boss",
                "client_id": "tenant_a",
                "role": "Jefe_de_Area",
                "status": "ACTIVE",
                "area": "Línea 1",
            },
            {
                "user_id": "duplicate",
                "client_id": "tenant_a",
                "role": "supervisor",
                "status": "active",
                "assigned_areas": ["LINEA 1"],
            },
            {
                "user_id": "duplicate",
                "client_id": "tenant_a",
                "role": "supervisor",
                "status": "active",
                "assigned_areas": ["Linea 1"],
            },
        ]

        result = select_report_managers(
            users,
            client_id="tenant_a",
            area_id="Linea 1",
        )

        self.assertEqual(
            [item["user_id"] for item in result],
            [
                "legacy_boss",
                "duplicate",
            ],
        )


if __name__ == "__main__":
    unittest.main()
