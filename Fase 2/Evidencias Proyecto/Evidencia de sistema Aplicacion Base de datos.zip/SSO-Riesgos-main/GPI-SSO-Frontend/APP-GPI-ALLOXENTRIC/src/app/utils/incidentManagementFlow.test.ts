import {
  describe,
  expect,
  it,
} from 'vitest';

import type { Report } from '../api/reports';

import {
  getIncidentManagementStageState,
  isIncidentManagementStageAccessible,
} from './incidentManagementStages';

import {
  canApproveIncidentClosure,
  canChangeIncidentToProcess,
  canRequestIncidentClosure,
} from './incidentStatus';

import {
  getWorkerReportTimelineSteps,
} from './workerReportTimeline';

function report(
  overrides: Partial<Report> = {},
): Report {
  return {
    report_id: '15',
    area_id: 'Bodega Quimica',
    type: 'Condición Insegura',
    status: 'open',
    is_iap: false,
    description: 'Reporte de prueba',
    created_at: '2026-09-30T12:00:00Z',
    ...overrides,
  };
}

describe('incident management flow - HU-15', () => {
  it('starts a new open report in review', () => {
    const current = report();

    const stage =
      getIncidentManagementStageState(current);

    expect(stage.workflowStage).toBe('review');
    expect(stage.readOnly).toBe(false);

    expect(
      isIncidentManagementStageAccessible(
        stage,
        'review',
      ),
    ).toBe(true);

    expect(
      isIncidentManagementStageAccessible(
        stage,
        'analysis',
      ),
    ).toBe(true);

    expect(
      isIncidentManagementStageAccessible(
        stage,
        'treatment',
      ),
    ).toBe(false);
  });

  it('moves an analysed open report to analysis presentation', () => {
    const current = report({
      causes: ['Falta de capacitación'],
      probable_consequence: 'Atrapamiento',
      analysis: 'Análisis realizado',
    });

    const stage =
      getIncidentManagementStageState(current);

    const timeline =
      getWorkerReportTimelineSteps(current);

    expect(stage.workflowStage).toBe('analysis');

    expect(
      timeline.find(step => step.key === 'assigned')
        ?.current,
    ).toBe(true);
  });

  it('allows only supervisor or area manager to move open to process', () => {
    expect(
      canChangeIncidentToProcess(
        'open',
        'supervisor',
      ),
    ).toBe(true);

    expect(
      canChangeIncidentToProcess(
        'open',
        'jefe_de_area',
      ),
    ).toBe(true);

    expect(
      canChangeIncidentToProcess(
        'open',
        'admin',
      ),
    ).toBe(false);

    expect(
      canChangeIncidentToProcess(
        'en_proceso',
        'supervisor',
      ),
    ).toBe(false);
  });

  it('shows en_proceso in treatment', () => {
    const current = report({
      status: 'en_proceso',
      control_measures: [
        'Instalar señalización',
      ],
    });

    const stage =
      getIncidentManagementStageState(current);

    const timeline =
      getWorkerReportTimelineSteps(current);

    expect(stage.workflowStage).toBe('treatment');

    expect(
      timeline.find(
        step => step.key === 'en_proceso',
      )?.current,
    ).toBe(true);
  });

  it('only requests closure from en_proceso with authorized role', () => {
    expect(
      canRequestIncidentClosure(
        'en_proceso',
        'supervisor',
      ),
    ).toBe(true);

    expect(
      canRequestIncidentClosure(
        'en_proceso',
        'jefe de area',
      ),
    ).toBe(true);

    expect(
      canRequestIncidentClosure(
        'open',
        'supervisor',
      ),
    ).toBe(false);

    expect(
      canRequestIncidentClosure(
        'en_proceso',
        'admin',
      ),
    ).toBe(false);
  });

  it('shows closure stage when en_proceso treatment is complete', () => {
    const current = report({
      status: 'en_proceso',
      control_measures: [
        'Instalar señalización',
      ],
      training: 'Capacitación realizada',
      deadline: '2026-10-11',
      feedback: 'Trabajador informado',
      closure_evidence: {
        url: '/closure.pdf',
        filename: 'closure.pdf',
        content_type: 'application/pdf',
        size: 100,
        uploaded_by: 'usr_test',
        uploaded_at: '2026-09-30T13:00:00Z',
      },
    });

    const stage =
      getIncidentManagementStageState(current);

    expect(stage.workflowStage).toBe('closure');

    expect(
      isIncidentManagementStageAccessible(
        stage,
        'closure',
      ),
    ).toBe(true);

    expect(
      isIncidentManagementStageAccessible(
        stage,
        'validation',
      ),
    ).toBe(false);
  });

  it('shows pending closure in read-only validation', () => {
    const current = report({
      status: 'pending_closure',
    });

    const stage =
      getIncidentManagementStageState(current);

    const timeline =
      getWorkerReportTimelineSteps(current);

    expect(stage.workflowStage).toBe('validation');
    expect(stage.readOnly).toBe(true);

    expect(
      timeline.find(
        step => step.key === 'pending_closure',
      )?.current,
    ).toBe(true);
  });

  it('only allows admin or SSO manager to approve pending closure', () => {
    expect(
      canApproveIncidentClosure(
        'pending_closure',
        'admin',
      ),
    ).toBe(true);

    expect(
      canApproveIncidentClosure(
        'pending_closure',
        'sso_manager',
      ),
    ).toBe(true);

    expect(
      canApproveIncidentClosure(
        'pending_closure',
        'supervisor',
      ),
    ).toBe(false);

    expect(
      canApproveIncidentClosure(
        'en_proceso',
        'admin',
      ),
    ).toBe(false);
  });

  it('marks a closed report as complete and read-only', () => {
    const current = report({
      status: 'closed',
    });

    const stage =
      getIncidentManagementStageState(current);

    const timeline =
      getWorkerReportTimelineSteps(current);

    expect(stage.workflowStage).toBe('validation');
    expect(stage.readOnly).toBe(true);
    expect(stage.completedThroughIndex).toBe(4);

    expect(
      timeline.every(step => step.active),
    ).toBe(true);

    expect(
      timeline.at(-1)?.current,
    ).toBe(true);

    expect(
      canApproveIncidentClosure(
        'closed',
        'admin',
      ),
    ).toBe(false);
  });

  it('does not alter report management data while deriving stages', () => {
    const current = report({
      causes: ['Falta de capacitación'],
      probable_consequence: 'Atrapamiento',
      analysis: 'Lorem ipsum',
      feedback: 'Feedback de prueba',
    });

    const snapshot = structuredClone(current);

    getIncidentManagementStageState(current);
    getWorkerReportTimelineSteps(current);

    expect(current).toEqual(snapshot);
  });
});
