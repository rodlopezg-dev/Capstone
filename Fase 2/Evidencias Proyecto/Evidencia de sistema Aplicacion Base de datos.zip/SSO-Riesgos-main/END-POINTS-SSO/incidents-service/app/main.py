import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routers import rt_incidents
from dotenv import load_dotenv

load_dotenv()

app = FastAPI(
    title="SSO API - Microservicio de Incidentes",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://sso-dashboard.alloxentric.com", "https://sso-app.alloxentric.com", "http://localhost:5173", "http://localhost:5174", "http://localhost", "https://localhost", "capacitor://localhost"] + [origin.strip() for origin in os.getenv("CORS_ORIGINS", "").split(",") if origin.strip()],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(rt_incidents.router, prefix="/v1")


@app.get("/health", tags=["System"])
def health_check():
    return {"status": "ok", "service": "incidents-service"}