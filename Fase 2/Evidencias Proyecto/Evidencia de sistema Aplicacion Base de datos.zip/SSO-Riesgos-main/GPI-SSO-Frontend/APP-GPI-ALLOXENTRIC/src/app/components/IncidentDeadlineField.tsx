import {
  getDeadlineRange,
  getDaysUntilDeadline,
} from '../utils/incidentDeadline';

interface IncidentDeadlineFieldProps {
  value: string;
  onChange: (value: string) => void;
  disabled?: boolean;
  today?: Date;
}

export default function IncidentDeadlineField({
  value,
  onChange,
  disabled = false,
  today = new Date(),
}: IncidentDeadlineFieldProps) {
  const { min, max } = getDeadlineRange(today);
  const daysRemaining = getDaysUntilDeadline(
    value,
    today
  );

  return (
    <div>
      <p className="text-sm font-medium mb-1">
        Plazo para medida de control
      </p>

      <input
        type="date"
        value={value}
        min={min}
        max={max}
        disabled={disabled}
        onChange={event => onChange(event.target.value)}
        className="w-full rounded-xl px-4 py-3 text-sm outline-none"
        style={{
          background: '#0B2E36',
          border: '1px solid rgba(0,229,255,0.3)',
          color: 'white',
        }}
      />

      <p
        className="text-xs mt-1"
        style={{ color: '#888' }}
      >
        Rango: 3 a 30 días desde hoy
      </p>

      {daysRemaining !== null && (
        <div
          className="mt-2 p-2 rounded-lg text-center"
          style={{
            background: '#00E5FF15',
            color: '#00E5FF',
          }}
        >
          <span className="text-sm font-medium">
            {daysRemaining} día(s) restante(s)
          </span>
        </div>
      )}
    </div>
  );
}
