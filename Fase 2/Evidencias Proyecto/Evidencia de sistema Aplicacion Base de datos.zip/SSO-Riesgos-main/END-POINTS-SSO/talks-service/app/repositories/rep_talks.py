import asyncio
import hashlib
import io
import re
import unicodedata
from datetime import datetime, timezone

import pytesseract
import ulid as ulid_lib
from PIL import Image, UnidentifiedImageError
from pymongo.errors import DuplicateKeyError

class InvalidAttendanceImage(ValueError):
    pass


def _normalize_person_name(value: str) -> str:
    normalized = unicodedata.normalize(
        "NFKD",
        value or "",
    )
    normalized = "".join(
        char
        for char in normalized
        if not unicodedata.combining(char)
    ).lower()

    normalized = re.sub(
        r"[^a-z0-9' -]+",
        " ",
        normalized,
    )

    return re.sub(
        r"\s+",
        " ",
        normalized,
    ).strip()


def _ocr_image_text(image_content: bytes) -> str:
    try:
        with Image.open(io.BytesIO(image_content)) as probe:
            probe.verify()

        with Image.open(io.BytesIO(image_content)) as image:
            prepared = image.convert("RGB")
            return pytesseract.image_to_string(
                prepared,
                lang="spa",
            )

    except (
        UnidentifiedImageError,
        OSError,
        ValueError,
        Image.DecompressionBombError,
    ) as exc:
        raise InvalidAttendanceImage(
            "La imagen no es válida o está dañada."
        ) from exc


def _now_iso():
    return datetime.now(timezone.utc).isoformat()

def _public_file_record(doc):
    doc.pop("_id", None)
    doc.pop("file_storage", None)

    file_url = doc.get(
        "file_url",
        "",
    )

    if (
        isinstance(file_url, str)
        and file_url.startswith("data:")
    ):
        doc["file_id"] = (
            doc.get("file_id")
            or "legacy"
        )
        doc["file_url"] = ""

    return doc

class TalksRepository:
    def __init__(self, db):
        self.talks = db["talks"]
        self.attendance = db["attendance"]
        self.qr_sessions = db["talk_qr_sessions"]
        self.attendance_scans = db["attendance_scans"]
        self.users = db["users"]


    async def list_active_workers_for_ocr(
        self,
        client_id: str,
    ) -> list[dict]:
        """
        Obtiene trabajadores activos de una empresa
        para proponer coincidencias OCR.

        Nunca consulta usuarios de otros clientes.
        """
        workers = []

        cursor = self.users.find(
            {
                "client_id": client_id,
                "status": "active",
            },
            {
                "_id": 0,
                "user_id": 1,
                "name": 1,
                "last_name": 1,
                "email": 1,
                "role": 1,
            },
        )

        async for worker in cursor:
            role = (
                worker.get("role") or ""
            ).strip().lower()

            if role not in {"worker", "usuario"}:
                continue

            if not worker.get("user_id"):
                continue

            workers.append(worker)

        return workers




    # ── TALKS (dialogos de seguridad) ──
    async def get_workers_by_ids(
        self,
        client_id,
        user_ids,
        *,
        active_only=False,
    ):
        """
        Obtiene usuarios pertenecientes al cliente solicitado.

        La validación al configurar una charla puede exigir trabajadores
        activos. La consulta histórica de una charla no exige que sigan
        activos, ya que la población esperada corresponde al momento en
        que la charla fue configurada.
        """
        unique_ids = list(
            dict.fromkeys(
                str(user_id).strip()
                for user_id in user_ids
                if str(user_id).strip()
            )
        )

        if not unique_ids:
            return []

        query = {
            "client_id": client_id,
            "user_id": {"$in": unique_ids},
        }

        if active_only:
            query["status"] = "active"

        workers_by_id = {}

        async for worker in self.users.find(
            query,
            {
                "_id": 0,
                "user_id": 1,
                "name": 1,
                "last_name": 1,
                "email": 1,
                "role": 1,
                "status": 1,
                "assigned_areas": 1,
            },
        ):
            role = (
                worker.get("role") or ""
            ).strip().lower()

            if active_only and role not in {
                "worker",
                "usuario",
            }:
                continue

            workers_by_id[
                worker["user_id"]
            ] = worker

        return [
            workers_by_id[user_id]
            for user_id in unique_ids
            if user_id in workers_by_id
        ]

    async def expected_workers_for_talk(
        self,
        client_id,
        talk_id,
    ):
        talk = await self.get_talk(
            client_id,
            talk_id,
        )

        if talk is None:
            return None

        expected_user_ids = list(
            dict.fromkeys(
                str(user_id).strip()
                for user_id in talk.get(
                    "expected_user_ids",
                    [],
                )
                if str(user_id).strip()
            )
        )

        workers = await self.get_workers_by_ids(
            client_id,
            expected_user_ids,
        )

        found_ids = {
            worker["user_id"]
            for worker in workers
        }

        return {
            "talk_id": talk_id,
            "title": talk.get("title", ""),
            "mandatory": bool(
                talk.get("mandatory", False)
            ),
            "expected_workers_configured": (
                "expected_user_ids" in talk
            ),
            "expected_user_ids": expected_user_ids,
            "workers": workers,
            "missing_user_ids": [
                user_id
                for user_id in expected_user_ids
                if user_id not in found_ids
            ],
        }


    async def attendance_comparison_for_talk(
        self,
        client_id,
        talk_id,
    ):
        """
        Compara la población esperada de una charla con sus registros
        almacenados de asistencia.

        Las identidades persistidas en attended_user_ids son autoritativas.
        Los registros manuales legacy solo se relacionan por nombre cuando
        existe una única coincidencia dentro de la población esperada.
        """
        population = await self.expected_workers_for_talk(
            client_id,
            talk_id,
        )

        if population is None:
            return None

        expected_user_ids = population[
            "expected_user_ids"
        ]

        expected_user_id_set = set(
            expected_user_ids
        )

        workers = population["workers"]

        resolved_expected_user_ids = [
            worker["user_id"]
            for worker in workers
        ]

        names_to_ids = {}

        for worker in workers:
            canonical_name = " ".join(
                filter(
                    None,
                    [
                        worker.get("name"),
                        worker.get("last_name"),
                    ],
                )
            ).strip()

            normalized_name = (
                _normalize_person_name(
                    canonical_name
                )
            )

            if not normalized_name:
                continue

            names_to_ids.setdefault(
                normalized_name,
                set(),
            ).add(
                worker["user_id"]
            )

        attended_user_ids = set()

        async for record in self.attendance.find(
            {
                "client_id": client_id,
                "talk_id": talk_id,
            },
            {
                "_id": 0,
                "source": 1,
                "attendees": 1,
                "attended_user_ids": 1,
            },
        ):
            raw_direct_ids = record.get(
                "attended_user_ids",
                [],
            )

            direct_ids = (
                raw_direct_ids
                if isinstance(
                    raw_direct_ids,
                    list,
                )
                else []
            )

            for user_id in direct_ids:
                if user_id in expected_user_id_set:
                    attended_user_ids.add(
                        user_id
                    )

            source = str(
                record.get("source") or ""
            ).strip().lower()

            # Un registro QR utiliza solamente la identidad
            # persistida. No se debe reinterpretar por nombre.
            if source == "qr" or direct_ids:
                continue

            raw_attendees = record.get(
                "attendees",
                [],
            )

            if not isinstance(
                raw_attendees,
                list,
            ):
                continue

            for attendee_name in raw_attendees:
                normalized_name = (
                    _normalize_person_name(
                        str(attendee_name)
                    )
                )

                matches = names_to_ids.get(
                    normalized_name,
                    set(),
                )

                if len(matches) == 1:
                    attended_user_ids.update(
                        matches
                    )

        return {
            "talk_id": talk_id,
            "title": population["title"],
            "mandatory": population[
                "mandatory"
            ],
            "expected_workers_configured": population[
                "expected_workers_configured"
            ],
            "expected_user_ids": (
                expected_user_ids
            ),
            "resolved_expected_user_ids": (
                resolved_expected_user_ids
            ),
            "missing_expected_user_ids": (
                population["missing_user_ids"]
            ),
            "attended_user_ids": [
                user_id
                for user_id in expected_user_ids
                if user_id in attended_user_ids
            ],
        }


    async def absent_workers_for_talk(
        self,
        client_id,
        talk_id,
    ):
        """
        Genera el listado de trabajadores esperados que no poseen
        una asistencia válida para la charla indicada.

        Los expected_user_ids que no puedan resolverse como usuarios
        del cliente se mantienen como datos faltantes y no se clasifican
        automáticamente como ausentes.
        """
        comparison = (
            await self.attendance_comparison_for_talk(
                client_id,
                talk_id,
            )
        )

        if comparison is None:
            return None

        resolved_expected_user_ids = comparison[
            "resolved_expected_user_ids"
        ]

        attended_user_ids = set(
            comparison["attended_user_ids"]
        )

        absent_user_ids = [
            user_id
            for user_id in resolved_expected_user_ids
            if user_id not in attended_user_ids
        ]

        workers = await self.get_workers_by_ids(
            client_id,
            resolved_expected_user_ids,
        )

        workers_by_id = {
            worker["user_id"]: worker
            for worker in workers
        }

        absent_workers = [
            workers_by_id[user_id]
            for user_id in absent_user_ids
            if user_id in workers_by_id
        ]

        if not comparison[
            "expected_workers_configured"
        ]:
            absence_status = "insufficient_data"
        elif comparison[
            "missing_expected_user_ids"
        ]:
            absence_status = "insufficient_data"
        elif not comparison[
            "expected_user_ids"
        ]:
            absence_status = "no_expected_workers"
        elif not absent_user_ids:
            absence_status = "no_absences"
        else:
            absence_status = "absences_found"

        return {
            "talk_id": comparison["talk_id"],
            "title": comparison["title"],
            "mandatory": comparison["mandatory"],
            "expected_workers_configured": comparison[
                "expected_workers_configured"
            ],
            "expected_user_ids": comparison[
                "expected_user_ids"
            ],
            "resolved_expected_user_ids": (
                resolved_expected_user_ids
            ),
            "missing_expected_user_ids": comparison[
                "missing_expected_user_ids"
            ],
            "attended_user_ids": comparison[
                "attended_user_ids"
            ],
            "absent_user_ids": absent_user_ids,
            "absent_workers": absent_workers,
            "absence_status": absence_status,
        }


    async def create_talk(self, client_id, data):
        talk_id = f"talk_{ulid_lib.ULID()}"
        doc = {
            "talk_id": talk_id,
            "client_id": client_id,
            "title": data["title"],
            "month": data["month"],
            "year": data["year"],
            "mandatory": bool(
                data.get("mandatory", False)
            ),
            "expected_user_ids": list(
                data.get("expected_user_ids", [])
            ),
            "file_id": data.get("file_id", ""),
            "file_url": data.get("file_url", ""),
            "file_name": data.get("file_name", ""),
            "file_content_type": data.get(
                "file_content_type",
                "",
            ),
            "file_size": data.get(
                "file_size",
                0,
            ),
            "file_storage": data.get(
                "file_storage",
            ),
            "created_at": _now_iso(),
        }
        await self.talks.insert_one(doc)
        return talk_id

    async def list_talks(self, client_id, month=None, year=None):
        query = {"client_id": client_id}
        if month: query["month"] = month
        if year: query["year"] = year
        results = []
        async for doc in self.talks.find(query).sort("created_at", -1):
            results.append(
                _public_file_record(doc)
            )
        return results

    async def get_talk(self, client_id, talk_id):
        return await self.talks.find_one({"talk_id": talk_id, "client_id": client_id})

    async def update_talk(self, client_id, talk_id, changes):
        changes["updated_at"] = _now_iso()
        result = await self.talks.update_one(
            {"talk_id": talk_id, "client_id": client_id},
            {"$set": changes},
        )
        return result.matched_count > 0

    async def delete_talk(self, client_id, talk_id):
        return await self.talks.find_one_and_delete(
            {"talk_id": talk_id, "client_id": client_id}
        )

    # ── ATTENDANCE (registro de asistencia) ──
    async def create_attendance(self, client_id, data):
        att_id = f"att_{ulid_lib.ULID()}"
        doc = {
            "attendance_id": att_id,
            "client_id": client_id,
            "talk_id": data.get("talk_id", ""),
            "topic": data["topic"],
            "date": data["date"],
            "area": data.get("area", ""),
            "attendees": data.get("attendees", []),
            "feedback": data.get("feedback", ""),
            "source": data.get("source", "manual"),
            "file_id": data.get("file_id", ""),
            "file_url": data.get("file_url", ""),
            "file_name": data.get("file_name", ""),
            "file_content_type": data.get(
                "file_content_type",
                "",
            ),
            "file_size": data.get(
                "file_size",
                0,
            ),
            "file_storage": data.get(
                "file_storage",
            ),
            "created_at": _now_iso(),
        }
        if doc["talk_id"] and doc["file_id"]:
            identity = hashlib.sha256(
                (client_id + "\x00" + doc["talk_id"]).encode()
            ).hexdigest()
            doc["_id"] = "attendance_file_" + identity
        await self.attendance.insert_one(doc)
        return att_id

    async def talk_has_attendance_file(self, client_id, talk_id):
        return await self.attendance.find_one(
            {
                "client_id": client_id,
                "talk_id": talk_id,
                "$or": [
                    {"file_id": {"$type": "string", "$ne": ""}},
                    {"file_url": {"$type": "string", "$ne": ""}},
                ],
            },
            {"_id": 1},
        ) is not None

    async def get_attendance(self, client_id, attendance_id):
        return await self.attendance.find_one({"client_id": client_id, "attendance_id": attendance_id})

    async def talk_has_attendance(self, client_id, talk_id):
        return await self.attendance.find_one(
            {"client_id": client_id, "talk_id": talk_id},
            {"_id": 1},
        ) is not None

    async def ensure_indexes(self):
        await self.qr_sessions.create_index(
            [("expires_at", 1)],
            expireAfterSeconds=0,
            name="qr_sessions_expires_at_ttl",
        )
        await self.attendance_scans.create_index(
            [
                ("client_id", 1),
                ("talk_id", 1),
                ("created_at", -1),
            ],
            name="attendance_scans_tenant_talk_created",
        )

    async def create_qr_session(self, client_id, talk_id, jti, created_by, expires_at):
        await self.qr_sessions.insert_one({
            "jti": jti,
            "client_id": client_id,
            "talk_id": talk_id,
            "created_by": created_by,
            "created_at": _now_iso(),
            "expires_at": expires_at,
            "active": True,
        })

    async def get_active_qr_session(self, client_id, talk_id, jti, now):
        return await self.qr_sessions.find_one({
            "jti": jti,
            "client_id": client_id,
            "talk_id": talk_id,
            "active": True,
            "expires_at": {"$gt": now},
        })

    async def list_attendance(self, client_id, talk_id=None):
        query = {"client_id": client_id}
        if talk_id: query["talk_id"] = talk_id
        results = []
        async for doc in self.attendance.find(query).sort("created_at", -1):
            results.append(
                _public_file_record(doc)
            )
        return results

    async def list_own_attendance(self, client_id, user_id, talk_id=None):
        """Estado QR del sujeto autenticado, sin nombres ni IDs de terceros."""
        query = {
            "client_id": client_id,
            "source": "qr",
            "attended_user_ids": user_id,
        }
        if talk_id:
            query["talk_id"] = talk_id
        projection = {
            "_id": 0,
            "attendance_id": 1,
            "talk_id": 1,
            "topic": 1,
            "date": 1,
            "area": 1,
            "source": 1,
        }
        records = []
        async for doc in self.attendance.find(query, projection).sort("created_at", -1):
            records.append({**doc, "attended_user_ids": [user_id]})
        return records

    async def list_attendance_for_export(
        self,
        client_id,
        month=None,
        year=None,
    ):
        """
        Devuelve registros de asistencia del cliente para exportación.

        Si se solicita período, se priorizan month/year de la charla
        asociada. Para registros legacy sin una charla resoluble se usa
        attendance.date como fallback.
        """
        selected_month = (
            str(int(month))
            if month not in (None, "")
            else None
        )
        selected_year = (
            str(year).strip()
            if year not in (None, "")
            else None
        )

        talks_by_id = {}

        async for talk in self.talks.find(
            {"client_id": client_id},
            {
                "_id": 0,
                "talk_id": 1,
                "title": 1,
                "month": 1,
                "year": 1,
            },
        ):
            talk_id = str(
                talk.get("talk_id") or ""
            ).strip()

            if talk_id:
                talks_by_id[talk_id] = talk

        results = []

        async for doc in self.attendance.find(
            {"client_id": client_id}
        ).sort("created_at", -1):
            talk_id = str(
                doc.get("talk_id") or ""
            ).strip()
            talk = talks_by_id.get(talk_id)

            period_month = ""
            period_year = ""

            if talk:
                talk_month = str(
                    talk.get("month") or ""
                ).strip()
                talk_year = str(
                    talk.get("year") or ""
                ).strip()

                if (
                    talk_month.isdigit()
                    and 1 <= int(talk_month) <= 12
                    and talk_year.isdigit()
                ):
                    period_month = str(
                        int(talk_month)
                    )
                    period_year = talk_year

            if not period_month or not period_year:
                attendance_date = str(
                    doc.get("date") or ""
                ).strip()

                match = re.match(
                    r"^(\d{4})-(\d{2})-\d{2}",
                    attendance_date,
                )

                if match:
                    period_year = match.group(1)
                    period_month = str(
                        int(match.group(2))
                    )

            if (
                selected_month
                and period_month != selected_month
            ):
                continue

            if (
                selected_year
                and period_year != selected_year
            ):
                continue

            record = _public_file_record(doc)

            record["talk_title"] = (
                str(talk.get("title") or "")
                if talk
                else ""
            )
            record["export_period_month"] = (
                period_month
            )
            record["export_period_year"] = (
                period_year
            )

            results.append(record)

        return results


    async def attendance_stats_by_area(self, client_id):
        """
        Calcula cobertura observada de asistencia por área.

        La población corresponde a trabajadores activos del cliente agrupados
        según assigned_areas. Un trabajador cuenta como asistente del área si
        existe al menos un registro de asistencia donde su identidad puede
        determinarse de forma inequívoca.

        Los registros QR utilizan attended_user_ids. Los registros sin IDs
        solo se relacionan por nombre cuando existe una única
        coincidencia entre los trabajadores activos del área indicada.

        Esta métrica representa cobertura observada, no cumplimiento de
        charlas obligatorias; mandatory y expected_user_ids se evalúan por
        charla en attendance_comparison_for_talk.
        """
        worker_roles = {
            "worker",
            "usuario",
        }

        workers_by_id = {}
        workers_by_area = {}
        names_by_area = {}

        async for worker in self.users.find(
            {
                "client_id": client_id,
                "status": "active",
            },
            {
                "_id": 0,
                "user_id": 1,
                "name": 1,
                "last_name": 1,
                "role": 1,
                "assigned_areas": 1,
            },
        ):
            role = (worker.get("role") or "").strip().lower()
            if role not in worker_roles:
                continue

            user_id = worker.get("user_id")
            if not user_id:
                continue

            areas = {
                area.strip()
                for area in worker.get("assigned_areas", [])
                if isinstance(area, str) and area.strip()
            }
            if not areas:
                continue

            worker_data = {
                "user_id": user_id,
                "areas": areas,
            }
            workers_by_id[user_id] = worker_data

            canonical_name = " ".join(
                filter(
                    None,
                    [
                        worker.get("name"),
                        worker.get("last_name"),
                    ],
                )
            ).strip()
            normalized_name = _normalize_person_name(canonical_name)

            for area in areas:
                workers_by_area.setdefault(area, set()).add(user_id)

                if normalized_name:
                    names_by_area.setdefault(
                        area,
                        {},
                    ).setdefault(
                        normalized_name,
                        set(),
                    ).add(user_id)

        attended_by_area = {
            area: set()
            for area in workers_by_area
        }

        async for record in self.attendance.find(
            {"client_id": client_id},
            {
                "_id": 0,
                "source": 1,
                "area": 1,
                "attendees": 1,
                "attended_user_ids": 1,
            },
        ):
            record_area = (
                record.get("area")
                or ""
            ).strip()

            # Registros con identidad persistida, principalmente QR.
            #
            # Si el registro indica un área que pertenece al trabajador,
            # se utiliza esa área. Cuando el registro no indica área solo
            # es seguro atribuir la asistencia si el trabajador posee una
            # única área asignada. Un usuario multiárea sin contexto de área
            # queda sin atribución para evitar contabilizar una misma
            # asistencia en varias áreas.
            direct_ids = record.get("attended_user_ids")
            if not isinstance(direct_ids, list):
                direct_ids = []

            for user_id in direct_ids:
                worker = workers_by_id.get(user_id)
                if worker is None:
                    continue

                worker_areas = worker["areas"]

                if (
                    record_area
                    and record_area in worker_areas
                ):
                    attended_by_area.setdefault(
                        record_area,
                        set(),
                    ).add(user_id)
                elif (
                    not record_area
                    and len(worker_areas) == 1
                ):
                    area = next(iter(worker_areas))
                    attended_by_area.setdefault(
                        area,
                        set(),
                    ).add(user_id)

            # Compatibilidad con registros manuales/hojas sin IDs:
            # solo se acepta una coincidencia única dentro del área declarada.
            if str(record.get("source") or "").strip().lower() == "qr" or direct_ids:
                continue

            area = record_area
            if not area or area not in workers_by_area:
                continue

            area_names = names_by_area.get(area, {})

            for attendee_name in record.get("attendees", []):
                normalized_name = _normalize_person_name(
                    attendee_name
                )
                matches = area_names.get(
                    normalized_name,
                    set(),
                )

                if len(matches) == 1:
                    attended_by_area[area].update(matches)

        stats = []

        for area in sorted(workers_by_area):
            active_workers = len(
                workers_by_area[area]
            )
            attendance_count = len(
                attended_by_area.get(area, set())
            )

            percentage = (
                attendance_count / active_workers * 100
                if active_workers
                else 0
            )

            stats.append(
                {
                    "area": area,
                    "active_workers": active_workers,
                    "attendance_count": attendance_count,
                    "attendance_percentage": round(
                        min(max(percentage, 0), 100),
                        2,
                    ),
                }
            )

        return stats

    async def attendance_stats_by_month(
        self,
        client_id,
        year=None,
    ):
        """
        Calcula cobertura observada de asistencia agrupada por mes.

        La población corresponde a los trabajadores activos del cliente.
        Cada trabajador identificado cuenta una sola vez por mes, aunque
        tenga múltiples registros de asistencia durante ese período.

        Para determinar el período se priorizan month/year de la charla
        asociada mediante talk_id. Los registros legacy cuya charla no pueda
        resolverse utilizan attendance.date como compatibilidad.

        Esta métrica representa cobertura observada mensual, no cumplimiento
        de todas las charlas obligatorias del período.
        """
        worker_roles = {
            "worker",
            "usuario",
        }

        workers_by_id = {}
        workers_by_name = {}

        async for worker in self.users.find(
            {
                "client_id": client_id,
                "status": "active",
            },
            {
                "_id": 0,
                "user_id": 1,
                "name": 1,
                "last_name": 1,
                "role": 1,
            },
        ):
            role = (
                worker.get("role")
                or ""
            ).strip().lower()

            if role not in worker_roles:
                continue

            user_id = worker.get("user_id")
            if not user_id:
                continue

            workers_by_id[user_id] = worker

            canonical_name = " ".join(
                filter(
                    None,
                    [
                        worker.get("name"),
                        worker.get("last_name"),
                    ],
                )
            ).strip()

            normalized_name = _normalize_person_name(
                canonical_name
            )

            if normalized_name:
                workers_by_name.setdefault(
                    normalized_name,
                    set(),
                ).add(user_id)

        active_workers = len(workers_by_id)

        talks_by_id = {}

        async for talk in self.talks.find(
            {"client_id": client_id},
            {
                "_id": 0,
                "talk_id": 1,
                "month": 1,
                "year": 1,
            },
        ):
            talk_id = talk.get("talk_id")
            if talk_id:
                talks_by_id[talk_id] = talk

        attended_by_period = {}
        periods_seen = set()

        async for record in self.attendance.find(
            {"client_id": client_id},
            {
                "_id": 0,
                "source": 1,
                "talk_id": 1,
                "date": 1,
                "attendees": 1,
                "attended_user_ids": 1,
            },
        ):
            period = None

            talk = talks_by_id.get(
                record.get("talk_id")
            )

            if talk is not None:
                talk_month = str(
                    talk.get("month")
                    or ""
                ).strip()
                talk_year = str(
                    talk.get("year")
                    or ""
                ).strip()

                if (
                    talk_month.isdigit()
                    and 1 <= int(talk_month) <= 12
                    and talk_year.isdigit()
                ):
                    period = (
                        talk_year,
                        int(talk_month),
                    )

            if period is None:
                date_value = str(
                    record.get("date")
                    or ""
                ).strip()

                match = re.match(
                    r"^(\d{4})-(\d{2})-\d{2}",
                    date_value,
                )

                if match:
                    parsed_year = match.group(1)
                    parsed_month = int(
                        match.group(2)
                    )

                    if 1 <= parsed_month <= 12:
                        period = (
                            parsed_year,
                            parsed_month,
                        )

            if period is None:
                continue

            period_year, _ = period

            if (
                year is not None
                and period_year != str(year)
            ):
                continue

            periods_seen.add(period)

            attended = attended_by_period.setdefault(
                period,
                set(),
            )

            # Registros con identidad persistida, principalmente QR.
            direct_ids = record.get("attended_user_ids")
            if not isinstance(direct_ids, list):
                direct_ids = []

            for user_id in direct_ids:
                if user_id in workers_by_id:
                    attended.add(user_id)

            # Compatibilidad con registros manuales/hojas sin IDs.
            # El nombre solo se acepta cuando identifica de forma única
            # a un trabajador activo dentro del cliente.
            if str(record.get("source") or "").strip().lower() == "qr" or direct_ids:
                continue

            for attendee_name in record.get(
                "attendees",
                [],
            ):
                normalized_name = _normalize_person_name(
                    attendee_name
                )

                matches = workers_by_name.get(
                    normalized_name,
                    set(),
                )

                if len(matches) == 1:
                    attended.update(matches)

        stats = []

        for period_year, period_month in sorted(
            periods_seen
        ):
            attendance_count = len(
                attended_by_period.get(
                    (period_year, period_month),
                    set(),
                )
            )

            percentage = (
                attendance_count
                / active_workers
                * 100
                if active_workers
                else 0
            )

            stats.append(
                {
                    "year": period_year,
                    "month": str(period_month),
                    "active_workers": active_workers,
                    "attendance_count": attendance_count,
                    "attendance_percentage": round(
                        min(
                            max(percentage, 0),
                            100,
                        ),
                        2,
                    ),
                }
            )

        return stats

    # --- INICIO: OCR DE ASISTENCIA ---
    async def extract_names_from_image(
        self,
        client_id: str,
        image_content: bytes,
    ):
        raw_text = await asyncio.to_thread(
            _ocr_image_text,
            image_content,
        )

        extracted_lines = []
        seen_lines = set()

        for raw_line in raw_text.splitlines():
            line = re.sub(r"\s+", " ", raw_line).strip()
            normalized = _normalize_person_name(line)

            if len(normalized) < 3:
                continue

            if normalized in seen_lines:
                continue

            seen_lines.add(normalized)
            extracted_lines.append((line, normalized))

        members_by_name = {}

        async for member in self.users.find(
            {
                "client_id": client_id,
                "status": "active",
            },
            {
                "_id": 0,
                "user_id": 1,
                "name": 1,
                "last_name": 1,
            },
        ):
            canonical_name = " ".join(
                filter(
                    None,
                    [
                        member.get("name"),
                        member.get("last_name"),
                    ],
                )
            ).strip()

            normalized = _normalize_person_name(
                canonical_name
            )

            if not normalized:
                continue

            members_by_name.setdefault(
                normalized,
                [],
            ).append(
                {
                    "user_id": member.get("user_id"),
                    "name": canonical_name,
                }
            )

        attendees = []

        for original, normalized in extracted_lines:
            matches = members_by_name.get(
                normalized,
                [],
            )

            if len(matches) == 1:
                attendee = matches[0]
                attendees.append(
                    {
                        "name": attendee["name"],
                        "matched": True,
                        "user_id": attendee["user_id"],
                    }
                )
            else:
                attendees.append(
                    {
                        "name": original,
                        "matched": False,
                        "user_id": None,
                    }
                )

        return attendees

    async def create_attendance_scan(
        self,
        *,
        client_id: str,
        talk_id: str,
        file_name: str,
        content_type: str,
        size_bytes: int,
        storage_ref: dict,
        extracted_attendees: list,
    ):
        scan_id = f"scan_{ulid_lib.ULID()}"

        document = {
            "scan_id": scan_id,
            "client_id": client_id,
            "talk_id": talk_id,
            "file_name": file_name,
            "content_type": content_type,
            "size_bytes": size_bytes,
            "storage": {
                "provider": storage_ref["provider"],
                "container": storage_ref["container"],
                "blob_name": storage_ref["blob_name"],
            },
            "extracted_count": len(
                extracted_attendees
            ),
            "matched_count": sum(
                1
                for attendee in extracted_attendees
                if attendee.get("matched")
            ),
            "created_at": _now_iso(),
        }

        await self.attendance_scans.insert_one(
            document
        )

        return scan_id
    # --- FIN: OCR DE ASISTENCIA ---

    # --- INICIO: REGISTRO DE ASISTENCIA MEDIANTE QR ---
    async def register_qr_attendance(self, client_id, talk, user_id, attendee_name):
        # Hora del servidor: se conserva el primer registro de cada persona.
        registered_at = _now_iso()
        # Un mismo documento por empresa y charla, incluso con escaneos simultáneos.
        identity = hashlib.sha256((client_id + "\x00" + talk["talk_id"]).encode()).hexdigest()
        record_id = "qr_" + identity
        doc = {
            "source": "qr",
            "attendance_id": "att_qr_" + identity,
            "client_id": client_id,
            "talk_id": talk["talk_id"],
            "topic": talk["title"],
            "date": registered_at[:10],
            "area": "",
            "attendees": [],
            "attended_user_ids": [],
            "attendance_entries": [],
            "feedback": "",
            "file_url": "",
            "file_name": "",
            "created_at": registered_at,
        }
        try:
            await self.attendance.update_one(
                {"_id": record_id, "client_id": client_id},
                {"$setOnInsert": doc},
                upsert=True,
            )
        except DuplicateKeyError:
            pass  # Otro escaneo creó el documento mientras se procesaba este.
        result = await self.attendance.update_one(
            {"_id": record_id, "client_id": client_id, "attended_user_ids": {"$ne": user_id}},
            {"$push": {"attended_user_ids": user_id, "attendees": attendee_name,
                       "attendance_entries": {"user_id": user_id, "name": attendee_name,
                                              "registered_at": registered_at, "method": "qr"}},
             "$set": {"updated_at": registered_at}},
        )
        return result.modified_count == 1
    # --- FIN: REGISTRO DE ASISTENCIA MEDIANTE QR ---