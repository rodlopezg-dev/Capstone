/**
 * CONFIGURACIÓN DE BASE DE DATOS
 *
 * Este archivo contiene la configuración para conectar con tu base de datos.
 * Puedes usar cualquier base de datos: PostgreSQL, MySQL, MongoDB, Supabase, Firebase, etc.
 *
 * INSTRUCCIONES:
 * 1. Crea un archivo .env en la raíz del proyecto
 * 2. Agrega tus credenciales de base de datos
 * 3. Descomenta y configura el conector que uses
 */

// ============================================
// VARIABLES DE ENTORNO
// ============================================

export const dbConfig = {
  // Opción 1: PostgreSQL / MySQL
  host: process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.DB_PORT || '5432'),
  database: process.env.DB_NAME || 'sso_database',
  user: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASSWORD || '',

  // Opción 2: Supabase
  supabaseUrl: process.env.SUPABASE_URL || '',
  supabaseKey: process.env.SUPABASE_ANON_KEY || '',

  // Opción 3: Firebase
  firebaseConfig: {
    apiKey: process.env.FIREBASE_API_KEY || '',
    authDomain: process.env.FIREBASE_AUTH_DOMAIN || '',
    projectId: process.env.FIREBASE_PROJECT_ID || '',
    storageBucket: process.env.FIREBASE_STORAGE_BUCKET || '',
    messagingSenderId: process.env.FIREBASE_MESSAGING_SENDER_ID || '',
    appId: process.env.FIREBASE_APP_ID || '',
  },

  // Opción 4: MongoDB
  mongoUri: process.env.MONGODB_URI || '',
};

// ============================================
// EJEMPLO: Conexión con Supabase
// ============================================
/*
import { createClient } from '@supabase/supabase-js';

export const supabase = createClient(
  dbConfig.supabaseUrl,
  dbConfig.supabaseKey
);
*/

// ============================================
// EJEMPLO: Conexión con PostgreSQL (node-postgres)
// ============================================
/*
import { Pool } from 'pg';

export const pool = new Pool({
  host: dbConfig.host,
  port: dbConfig.port,
  database: dbConfig.database,
  user: dbConfig.user,
  password: dbConfig.password,
});
*/

// ============================================
// EJEMPLO: Conexión con MongoDB
// ============================================
/*
import { MongoClient } from 'mongodb';

let client: MongoClient;

export async function connectToDatabase() {
  if (!client) {
    client = new MongoClient(dbConfig.mongoUri);
    await client.connect();
  }
  return client.db(dbConfig.database);
}
*/

// ============================================
// PLACEHOLDER: API REST para Base de Datos
// ============================================

/**
 * Si prefieres conectar a una API REST que maneje la base de datos,
 * configura la URL base aquí
 */
export const apiConfig = {
  baseUrl: process.env.API_BASE_URL || 'http://localhost:3001/api',
  apiKey: process.env.API_KEY || '',
};

export default dbConfig;
