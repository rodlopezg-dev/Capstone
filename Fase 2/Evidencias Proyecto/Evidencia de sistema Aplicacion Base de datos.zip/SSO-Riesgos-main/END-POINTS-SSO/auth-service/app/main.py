import os

from fastapi import FastAPI
from slowapi import _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from app.rate_limit import limiter
from fastapi.middleware.cors import CORSMiddleware
from app.routers import auth
from dotenv import load_dotenv

load_dotenv()  # Esto busca un archivo .env y lo carga en la memoria

app = FastAPI(

    title="Auth Service - SSO Alloxentric",
    description="Microservicio de autenticación para el sistema SSO de Alloxentric",
    version="1.0.0",
)
# Middleware estándar para permitir peticiones desde el Frontend
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

default_cors_origins = [
    "https://sso-dashboard.alloxentric.com",
    "https://sso-app.alloxentric.com",
    "http://localhost:5173",
    "http://localhost:5174",
    "http://localhost",
    "https://localhost",
    "capacitor://localhost",
]

extra_cors_origins = [
    origin.strip()
    for origin in os.getenv("CORS_ORIGINS", "").split(",")
    if origin.strip()
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=default_cors_origins + extra_cors_origins,
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Registramos nuestros endpoints
app.include_router(auth.router)


# Endpoint básico de salud (Health Check) para Cloud Run
@app.get("/health", tags=["System"])
def health_check():
    return {"status": "ok", "service": "auth-service"}
