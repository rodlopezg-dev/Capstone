from datetime import datetime, timezone

class WorkersRepository:
    def __init__(self, db):
        self.db = db
        self.reports = db["reports"]
        self.notifications = db["notifications"]

    async def get_worker_stats(self, client_id, user_id):
        total = await self.reports.count_documents({"client_id": client_id, "reported_by": user_id})
        closed = await self.reports.count_documents({"client_id": client_id, "reported_by": user_id, "status": "closed"})
        iap = await self.reports.count_documents({"client_id": client_id, "reported_by": user_id, "is_iap": True})
        return {
            "total_reports": total,
            "closed_reports": closed,
            "iap_reports": iap,
            "effectiveness_rate": round((closed / total * 100) if total > 0 else 0, 1),
        }

    async def get_worker_reports(self, client_id, user_id):
        results = []
        async for doc in self.reports.find({"client_id": client_id, "reported_by": user_id}).sort("created_at", -1):
            doc.pop("_id", None)
            results.append(doc)
        return results

    async def get_notifications(self, client_id, user_id):
        results = []
        async for doc in self.notifications.find({"client_id": client_id, "user_id": user_id}).sort("created_at", -1).limit(50):
            doc.pop("_id", None)
            results.append(doc)
        return results
