import jwt
import os
from fastapi import HTTPException, Security, Depends, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from motor.motor_asyncio import AsyncIOMotorClient
from typing import Callable
from app.schemas.user import CurrentUser
from app.config import settings

MONGO_URI = os.getenv("MONGO_URI")
MONGO_DB = os.getenv("MONGO_DB", "sso_riesgo")
_db_client = None
security_bearer = HTTPBearer(auto_error=False)

def get_db():
    global _db_client
    if _db_client is None:
        client = AsyncIOMotorClient(MONGO_URI)
        _db_client = client[MONGO_DB]
    return _db_client

async def get_current_user(credentials: HTTPAuthorizationCredentials | None = Security(security_bearer)) -> CurrentUser:
    if credentials is None:
        raise HTTPException(status_code=401, detail="Token invalido.")
    try:
        payload = jwt.decode(credentials.credentials, settings.JWT_SECRET, algorithms=[settings.JWT_ALGORITHM], options={"require": ["exp"]})
    except jwt.PyJWTError as exc:
        raise HTTPException(status_code=401, detail="Token invalido.") from exc
    if ("type" in payload and payload["type"] != "access") or any(
        not isinstance(payload.get(claim), str) or not payload[claim].strip()
        for claim in ("sub", "role", "client_id")
    ):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Token invalido.")
    return CurrentUser(id=payload["sub"], role=payload["role"], client_id=payload["client_id"])

def verify_role(*allowed_roles: str) -> Callable:
    async def role_checker(current_user: CurrentUser = Depends(get_current_user)):
        if current_user.role not in allowed_roles:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Rol insuficiente.")
        return current_user
    return role_checker
