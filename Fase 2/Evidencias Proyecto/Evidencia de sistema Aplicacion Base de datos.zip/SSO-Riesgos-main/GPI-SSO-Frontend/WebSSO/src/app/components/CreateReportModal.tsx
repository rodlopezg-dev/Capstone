import { useState, useEffect } from 'react';
import Swal from 'sweetalert2';
import { X, Camera, Send } from 'lucide-react';

const REPORTS_API = import.meta.env.VITE_REPORTS_API_URL || 'http://localhost:8102';


const SHIFTS = ['Día', 'Noche'];
const TYPES = ['Acto Inseguro', 'Buena Practica'];
const WORKER_TYPES = ['Planta', 'Externo'];

type Props = {
  onClose: () => void;
  onCreated: () => void;
  userAssignedAreas?: string[];
};

export default function CreateReportModal({ onClose, onCreated, userAssignedAreas }: Props) {
  const [type, setType] = useState('');
  const [workerType, setWorkerType] = useState('');
  const [areaId, setAreaId] = useState('');
  // Turno oculto en la UI: se asigna solo segun la hora (diurno / nocturno)
  const [shift, setShift] = useState(() => {
    const h = new Date().getHours();
    return (SHIFTS.length > 1 && (h < 8 || h >= 20)) ? SHIFTS[SHIFTS.length - 1] : SHIFTS[0];
  });
  const [description, setDescription] = useState('');
  const [isIap, setIsIap] = useState(false);
  const [photos, setPhotos] = useState<File[]>([]);
  const [photoPreviews, setPhotoPreviews] = useState<string[]>([]);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState('');

  const [apiAreas, setApiAreas] = useState<{name: string, zones: string[], jefe?: string, zone_details?: {name: string, responsable: string, email: string}[]}[]>([]);
  const [selectedZone, setSelectedZone] = useState('');
  const [zoneResponsable, setZoneResponsable] = useState('');
  useEffect(() => {
    if (selectedZone && areaId) {
      const area = apiAreas.find(a => a.name === areaId);
      const zd = area?.zone_details?.find((z: any) => z.name === selectedZone);
      setZoneResponsable(zd?.responsable || '');
    } else { setZoneResponsable(''); }
  }, [selectedZone, areaId, apiAreas]);
  
  useEffect(() => {
    const fetchAreas = async () => {
      try {
        const token = localStorage.getItem('sso_token');
        const res = await fetch(window.location.origin + '/api/areas/v1/areas/', {
          headers: { 'Authorization': 'Bearer ' + token }
        });
        if (res.ok) {
          const data = await res.json();
          setApiAreas((Array.isArray(data) ? data : data.data || []).map((a: any) => ({name: a.name, zones: a.zones || [], jefe: a.jefe || '', zone_details: a.zone_details || []})));
        }
      } catch (e) { console.error(e); }
    };
    fetchAreas();
  }, []);

  const areaNames = apiAreas.length > 0 ? apiAreas.map(a => a.name) : (userAssignedAreas || []);
  const currentZones = apiAreas.find(a => a.name === areaId)?.zones || [];

  const handlePhoto = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;
    setPhotos(prev => [...prev, ...files]);
    files.forEach(file => {
      const reader = new FileReader();
      reader.onload = (ev) => setPhotoPreviews(prev => [...prev, ev.target?.result as string]);
      reader.readAsDataURL(file);
    });
  };

  const handleSubmit = async () => {
    if (!type || !areaId || !shift || !description || !workerType) {
      setError('Completa todos los campos obligatorios');
      return;
    }
    setSending(true);
    setError('');
    try {
      const token = localStorage.getItem('sso_token') ?? '';
      const formData = new FormData();
      formData.append('type', type);
      formData.append('area_id', areaId);
      formData.append('shift', shift);
      formData.append('description', description);
      formData.append('is_iap', isIap ? 'true' : 'false');
      formData.append('causes', '[]');
      if (workerType) formData.append('worker_type', workerType);
      if (selectedZone) formData.append('zone_id', selectedZone);
      if (photos.length > 0) {
        photos.forEach(p => formData.append('files', p));
      }

      const res = await fetch(`${REPORTS_API}/v1/reports`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
        body: formData,
      });

      if (!res.ok) throw new Error(`Error ${res.status}`);

      onCreated();
      onClose();
      Swal.fire({
        icon: 'success',
        title: 'Reporte enviado',
        text: 'Tu reporte fue registrado exitosamente.',
        confirmButtonColor: '#00E5FF',
        background: '#0B1E36',
        color: '#fff',
      });
    } catch (err) {
      setError('Error al enviar el reporte. Verifica la conexión.');
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-card border border-border rounded-xl p-6 w-full max-w-lg max-h-[90vh] overflow-y-auto"
        onClick={e => e.stopPropagation()}>

        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold">Nuevo Reporte</h2>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground">
            <X size={20} />
          </button>
        </div>

        {/* Tipo de hallazgo */}
        <div className="mb-4">
          <label className="text-sm text-muted-foreground mb-2 block">Tipo de hallazgo *</label>
          <div className="grid grid-cols-3 gap-2">
            {TYPES.map(t => (
              <button key={t} onClick={() => setType(t)}
                className={`p-3 rounded-lg border text-sm font-medium transition-all ${
                  type === t
                    ? 'bg-primary/20 border-primary text-primary'
                    : 'bg-secondary border-border hover:border-primary/50'
                }`}>
                {t === 'Acto Inseguro' ? '⚠️' : '✅'} {t}
              </button>
            ))}
            <div className="p-3 rounded-lg border text-sm font-medium bg-[#E8941A]/10 border-[#E8941A]/30 text-[#E8941A] flex flex-col items-center justify-center gap-1 text-center">
              Condición Insegura
              <span className="text-[10px] opacity-70 leading-tight">Elaborar TPM o canalizar con supervisor directo</span>
            </div>
          </div>
        </div>

        {/* Área */}
        <div className="mb-4">
          <label className="text-sm text-muted-foreground mb-2 block">Área *</label>
          <select value={areaId} onChange={e => { setAreaId(e.target.value); setSelectedZone(''); setZoneResponsable(''); }}
            className="w-full px-3 py-2 bg-secondary border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary">
            <option value="">Seleccionar área...</option>
            {areaNames.map(a => <option key={a} value={a}>{a}</option>)}
          </select>

        </div>

        {/* Sub-zona */}
        {currentZones.length > 0 && (
          <div className="mb-4">
            <label className="text-sm text-muted-foreground mb-2 block">Donde ocurrió *</label>
            <select value={selectedZone} onChange={e => setSelectedZone(e.target.value)}
              className="w-full px-3 py-2 bg-secondary border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary">
              <option value="">Seleccionar ubicación...</option>
              {currentZones.map(z => <option key={z} value={z}>{z}</option>)}
            </select>
            {zoneResponsable && <p className="text-xs text-[#E8941A] mt-1">Responsable: {zoneResponsable}</p>}
          </div>
        )}

        {/* Turno: oculto a pedido del cliente */}
        {false && (
        <div className="mb-4">
          <label className="text-sm text-muted-foreground mb-2 block">Turno *</label>
          <div className="grid grid-cols-2 gap-2">
            {SHIFTS.map(s => (
              <button key={s} onClick={() => setShift(s)}
                className={`px-3 py-2 rounded-lg border text-sm transition-all ${
                  shift === s
                    ? 'bg-primary/20 border-primary text-primary'
                    : 'bg-secondary border-border hover:border-primary/50'
                }`}>
                {s}
              </button>
            ))}
          </div>

        </div>
        )}

        {/* Tipo de trabajador */}
        <div className="mb-4">
          <label className="text-sm text-muted-foreground mb-2 block">Tipo de trabajador *</label>
          <div className="grid grid-cols-2 gap-2">
            {WORKER_TYPES.map(w => (
              <button key={w} onClick={() => setWorkerType(w)}
                className={`px-3 py-2 rounded-lg border text-sm transition-all ${
                  workerType === w
                    ? 'bg-primary/20 border-primary text-primary'
                    : 'bg-secondary border-border hover:border-primary/50'
                }`}>
                {w}
              </button>
            ))}
          </div>
        </div>

        {/* Descripción */}
        <div className="mb-4">
          <label className="text-sm text-muted-foreground mb-2 block">Descripción *</label>
          <textarea value={description} onChange={e => setDescription(e.target.value)}
            rows={4} placeholder="Describe el hallazgo..."
            className="w-full px-3 py-2 bg-secondary border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary resize-none" />
        </div>

        {/* IAP */}
        {type === 'Acto Inseguro' && (
          <div className="mb-4">
            <label className="flex items-center gap-3 p-3 bg-secondary border border-border rounded-lg cursor-pointer hover:border-primary/50 transition-all">
              <input type="checkbox" checked={isIap} onChange={e => setIsIap(e.target.checked)}
                className="rounded border-border" />
              <div>
                <span className="text-sm font-medium">¿Es un Incidente de Alto Potencial (IAP)?</span>
                <p className="text-xs text-muted-foreground">Puede causar lesión grave, fatalidad o incendio</p>
              </div>
            </label>
          </div>
        )}

        {/* Foto */}
        <div className="mb-4">
          <label className="text-sm text-muted-foreground mb-2 block">Foto (opcional)</label>
          <label className="w-full flex items-center gap-2 p-3 rounded-lg cursor-pointer bg-secondary border border-border hover:border-primary transition-colors">
            <Camera size={18} className="text-primary" />
            <span className="text-sm text-primary">{photos.length ? photos.length + ' foto(s)' : 'Subir foto de evidencia'}</span>
            <input type="file" accept="image/*" multiple className="hidden" onChange={handlePhoto} />
          </label>
          {photoPreviews.length > 0 && (
            <div className="flex gap-2 mt-2 overflow-x-auto">
              {photoPreviews.map((p, i) => (
                <div key={i} className="relative flex-shrink-0">
                  <img src={p} alt={"preview " + i} className="w-24 h-24 object-cover rounded-lg" />
                  <button onClick={(e) => { e.preventDefault(); setPhotos(prev => prev.filter((_, j) => j !== i)); setPhotoPreviews(prev => prev.filter((_, j) => j !== i)); }}
                    className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white rounded-full text-xs flex items-center justify-center">x</button>
                </div>
              ))}
            </div>
          )}
        </div>

        {error && (
          <div className="mb-4 p-3 bg-[#D72631]/20 border border-[#D72631]/50 rounded-lg text-sm text-[#D72631]">
            {error}
          </div>
        )}

        <button onClick={handleSubmit} disabled={sending}
          className="w-full py-3 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90 transition-all disabled:opacity-50 flex items-center justify-center gap-2">
          <Send size={18} />
          {sending ? 'Enviando...' : 'Enviar Reporte'}
        </button>
      </div>
    </div>
  );
}
