import { useEffect } from 'react';
import { Capacitor } from '@capacitor/core';
import { LocalNotifications } from '@capacitor/local-notifications';
import {
  buildLocalNotificationStorageKey,
  parseLocalNotificationState,
  reconcileLocalNotificationState,
  type LocalNotificationChannel,
  type LocalNotificationItem,
} from '../utils/localNotificationState';

/**
 * Pide permiso de notificaciones locales.
 * Seguro de llamar en web: no realiza ninguna acción.
 */
export async function requestLocalNotificationPermission() {
  if (!Capacitor.isNativePlatform()) return;

  try {
    const { display } = await LocalNotifications.checkPermissions();

    if (display !== 'granted') {
      await LocalNotifications.requestPermissions();
    }
  } catch (err) {
    console.error(
      '[local-notif] Error solicitando permisos:',
      err,
    );
  }
}

interface LocalNotificationOptions {
  clientId: string;
  userId: string;
  channel: LocalNotificationChannel;
  ready: boolean;
}

function androidNotificationId(id: string): number {
  let hash = 0;

  for (let i = 0; i < id.length; i += 1) {
    hash = ((hash * 31) + id.charCodeAt(i)) | 0;
  }

  const positive = hash & 0x7fffffff;

  return positive || 1;
}

/**
 * Publica únicamente elementos que todavía no hayan sido procesados.
 *
 * La primera carga completa se considera baseline y no genera
 * notificaciones del sistema.
 *
 * Los IDs procesados se persisten por cliente + usuario para evitar
 * reemitir el historial después de reiniciar la aplicación.
 */
export function useLocalNotificationsOnNewItems(
  items: LocalNotificationItem[],
  {
    clientId,
    userId,
    channel,
    ready,
  }: LocalNotificationOptions,
) {
  useEffect(() => {
    if (!Capacitor.isNativePlatform()) return;
    if (!ready || !clientId || !userId) return;

    const storageKey =
      buildLocalNotificationStorageKey(
        clientId,
        userId,
        channel,
      );

    let previousState = null;

    try {
      previousState = parseLocalNotificationState(
        localStorage.getItem(storageKey),
      );
    } catch (err) {
      console.error(
        '[local-notif] Error leyendo estado local:',
        err,
      );
    }

    const {
      newItems,
      nextState,
    } = reconcileLocalNotificationState(
      previousState,
      items,
    );

    try {
      localStorage.setItem(
        storageKey,
        JSON.stringify(nextState),
      );
    } catch (err) {
      console.error(
        '[local-notif] Error persistiendo estado local:',
        err,
      );
    }

    if (newItems.length === 0) return;

    LocalNotifications.schedule({
      notifications: newItems.map(item => ({
          // ID determinista: si por algún error el mismo evento intenta
          // programarse nuevamente, Android reutiliza el mismo ID.
          id: androidNotificationId(item.id),
          title: item.title,
          body: item.description || '',
        })),
    }).catch(err =>
      console.error(
        '[local-notif] Error al programar:',
        err,
      ),
    );
  }, [
    items,
    clientId,
    userId,
    channel,
    ready,
  ]);
}
