import {
  describe,
  expect,
  it,
} from 'vitest';

import {
  findAttendanceSheet,
  localAttendanceDate,
  MAX_ATTENDANCE_SHEET_BYTES,
  validateAttendanceSheet,
} from './attendanceSheet';

describe('attendance sheet helpers', () => {
  it('uses local calendar date', () => {
    const date = new Date(
      2026,
      8,
      28,
      23,
      45,
      0,
    );

    expect(
      localAttendanceDate(date),
    ).toBe('2026-09-28');
  });

  it('accepts supported image', () => {
    expect(
      validateAttendanceSheet({
        type: 'image/jpeg',
        size: 100,
      } as File),
    ).toBeNull();
  });

  it('rejects unsupported type', () => {
    expect(
      validateAttendanceSheet({
        type: 'application/pdf',
        size: 100,
      } as File),
    ).toMatch(/Formato no permitido/);
  });

  it('rejects files over 10 MB', () => {
    expect(
      validateAttendanceSheet({
        type: 'image/png',
        size: MAX_ATTENDANCE_SHEET_BYTES + 1,
      } as File),
    ).toMatch(/10 MB/);
  });

  it('finds sheet associated with talk', () => {
    const sheet = findAttendanceSheet(
      [
        {
          talk_id: 'talk-a',
        },
        {
          talk_id: 'talk-b',
          file_id: 'file-b',
        },
      ],
      'talk-b',
    );

    expect(sheet?.file_id).toBe('file-b');
  });
});
