
import base64
import os

from functools import lru_cache

from langchain_core.messages import HumanMessage
from langchain_google_genai import ChatGoogleGenerativeAI

from .prompts import ATTENDANCE_OCR_PROMPT
from .schemas import ExtractedAttendance


class GeminiNotConfigured(RuntimeError):
    pass


class UnsupportedAttendanceProvider(RuntimeError):
    pass


@lru_cache(maxsize=1)
def get_attendance_chain():
    provider = os.getenv(
        "ATTENDANCE_AI_PROVIDER",
        "gemini",
    ).strip().lower()

    providers = {
        "gemini": get_gemini_attendance_chain,
    }

    try:
        return providers[provider]()
    except KeyError as exc:
        raise UnsupportedAttendanceProvider(
            "Proveedor de OCR no soportado."
        ) from exc


def get_gemini_attendance_chain():
    api_key = os.getenv(
        "GEMINI_API_KEY", ""
    ).strip()

    if not api_key:
        raise GeminiNotConfigured(
            "GEMINI_API_KEY no está configurada."
        )

    model_name = os.getenv(
        "GEMINI_MODEL",
        "gemini-3.8-flash"
    ).strip()

    model = ChatGoogleGenerativeAI(
        model=model_name,
        api_key=api_key,
        vertexai=False,
        timeout=8.0,
        max_retries=0,
    )

    return model.with_structured_output(
    ExtractedAttendance,
    method="json_schema",
)


async def extract_attendance_image(
    content: bytes,
    mime_type: str,
    chain=None,
) -> ExtractedAttendance:


    # Convertir la fotografía a Base64.
    image_base64 = base64.b64encode(
        content
    ).decode("utf-8")

    # Construir mensaje multimodal para Gemini.
    message = HumanMessage(
        content=[
            {
                "type": "text",
                "text": ATTENDANCE_OCR_PROMPT,
            },
            {
                "type": "image_url",
                "image_url": {
                    "url": (
                        f"data:{mime_type};base64,"
                        f"{image_base64}"
                    )
                },
            },
        ]
    )


    selected_chain = (
        chain
        if chain is not None
        else get_attendance_chain()
    )

    result = await selected_chain.ainvoke(
        [message]
    )

    if isinstance(result, ExtractedAttendance):
        return result

    return ExtractedAttendance.model_validate(
        result
    )
