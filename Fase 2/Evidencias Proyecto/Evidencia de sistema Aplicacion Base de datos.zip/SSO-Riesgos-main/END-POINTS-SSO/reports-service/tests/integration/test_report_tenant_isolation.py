"""Integration tests for SCRUM-79 - report tenant isolation."""

from copy import deepcopy

import pytest
from fastapi.testclient import TestClient

from app.main import app
from app.routers import rt_reports
from app.services import azure_blob_service


TENANT_A = "tenant_a"
TENANT_B = "tenant_b"


class FakeCursor:
    def __init__(self, documents):
        self.documents = deepcopy(documents)

    def sort(self, field, direction):
        self.documents.sort(
            key=lambda item: item.get(field, ""),
            reverse=direction < 0,
        )
        return self

    def limit(self, amount):
        self.documents = self.documents[:amount]
        return self

    def __aiter__(self):
        self._iterator = iter(self.documents)
        return self

    async def __anext__(self):
        try:
            return next(self._iterator)
        except StopIteration:
            raise StopAsyncIteration


class FakeCollection:
    def __init__(self, documents=None):
        self.documents = deepcopy(documents or [])

    @staticmethod
    def _matches(document, query):
        return all(
            document.get(key) == value
            for key, value in query.items()
        )

    def find(self, query):
        return FakeCursor([
            document
            for document in self.documents
            if self._matches(document, query)
        ])


class FakeDB:
    def __init__(self, reports):
        self.collections = {
            "reports": FakeCollection(reports),
            "notifications": FakeCollection(),
            "activity_log": FakeCollection(),
        }

    def __getitem__(self, name):
        if name not in self.collections:
            self.collections[name] = FakeCollection()

        return self.collections[name]


def report_fixture(
    report_id,
    client_id,
    created_at,
):
    return {
        "report_id": report_id,
        "client_id": client_id,
        "area_id": "Linea 1",
        "type": "Acto Inseguro",
        "description": report_id,
        "status": "open",
        "is_iap": False,
        "reported_by": "worker_test",
        "created_at": created_at,
        "shift": "Dia",
    }


@pytest.fixture
def fake_db():
    return FakeDB([
        report_fixture(
            "report_tenant_a",
            TENANT_A,
            "2026-09-14T10:00:00+00:00",
        ),
        report_fixture(
            "report_tenant_b",
            TENANT_B,
            "2026-09-14T11:00:00+00:00",
        ),
    ])


@pytest.fixture
def client_factory(fake_db, monkeypatch):
    clients = []

    def _factory(client_id):
        app.dependency_overrides[
            rt_reports.get_db
        ] = lambda: fake_db

        monkeypatch.setattr(
            rt_reports,
            "get_current_user",
            lambda credentials: {
                "user_id": "user_test",
                "client_id": client_id,
                "role": "supervisor",
            },
        )

        client = TestClient(app)
        clients.append(client)
        return client

    yield _factory

    for client in clients:
        client.close()

    app.dependency_overrides.clear()


@pytest.mark.parametrize(
    ("tenant", "expected", "forbidden"),
    [
        (
            TENANT_A,
            "report_tenant_a",
            "report_tenant_b",
        ),
        (
            TENANT_B,
            "report_tenant_b",
            "report_tenant_a",
        ),
    ],
)
def test_admin_report_list_is_isolated_by_client_id(
    client_factory,
    tenant,
    expected,
    forbidden,
):
    client = client_factory(tenant)

    response = client.get(
        "/v1/admin/reports",
        headers={
            "Authorization": "Bearer fake_token"
        },
    )

    assert response.status_code == 200

    reports = response.json()

    assert len(reports) == 1
    assert reports[0]["report_id"] == expected
    assert reports[0]["client_id"] == tenant

    assert all(
        report["report_id"] != forbidden
        for report in reports
    )


@pytest.mark.parametrize(
    ("tenant", "expected", "forbidden"),
    [
        (
            TENANT_A,
            "report_tenant_a",
            "report_tenant_b",
        ),
        (
            TENANT_B,
            "report_tenant_b",
            "report_tenant_a",
        ),
    ],
)
def test_csv_export_is_isolated_by_client_id(
    client_factory,
    tenant,
    expected,
    forbidden,
):
    client = client_factory(tenant)

    response = client.get(
        "/v1/export/csv",
        headers={
            "Authorization": "Bearer fake_token"
        },
    )

    assert response.status_code == 200

    csv_text = response.text

    assert expected in csv_text
    assert forbidden not in csv_text

    assert (
        response.headers["content-type"]
        .startswith("text/csv")
    )


def evidence_report_fixture(
    client_id,
    *,
    report_id="1",
):
    image_url = (
        "/local-report-evidence/"
        f"reports/{client_id}/{report_id}/"
        "evidence.jpg"
    )

    closure_url = (
        "/local-report-evidence/"
        f"reports/{client_id}/{report_id}/"
        "closure-evidence/cierre.pdf"
    )

    return {
        "report_id": report_id,
        "client_id": client_id,
        "area_id": "Linea 1",
        "type": "Acto Inseguro",
        "description": f"Reporte {client_id}",
        "status": "en_proceso",
        "is_iap": False,
        "reported_by": "worker_test",
        "created_at": (
            "2026-10-06T20:00:00+00:00"
        ),
        "shift": "Dia",
        "image_url": image_url,
        "evidences": [image_url],
        "closure_evidence": {
            "url": closure_url,
            "filename": "cierre.pdf",
            "content_type": "application/pdf",
            "size": 1024,
            "uploaded_by": "supervisor_test",
            "uploaded_at": (
                "2026-10-06T20:10:00+00:00"
            ),
        },
    }


def test_same_report_id_evidence_is_isolated_and_signed(
    monkeypatch,
):
    fake_db = FakeDB([
        evidence_report_fixture(TENANT_A),
        evidence_report_fixture(TENANT_B),
    ])

    persisted_before = deepcopy(
        fake_db["reports"].documents
    )

    monkeypatch.setattr(
        azure_blob_service,
        "BLOB_BASE_URL",
        "/local-report-evidence",
    )

    def fake_generate_read_url(
        reference,
        client_id,
        report_id,
    ):
        expected_prefix = (
            "/local-report-evidence/"
            f"reports/{client_id}/{report_id}/"
        )

        assert reference.startswith(
            expected_prefix
        )

        return (
            f"{reference}"
            f"?sp=r&sig={client_id}"
        )

    monkeypatch.setattr(
        azure_blob_service,
        "generate_read_url",
        fake_generate_read_url,
    )

    app.dependency_overrides[
        rt_reports.get_db
    ] = lambda: fake_db

    try:
        for tenant, forbidden_tenant in (
            (TENANT_A, TENANT_B),
            (TENANT_B, TENANT_A),
        ):
            monkeypatch.setattr(
                rt_reports,
                "get_current_user",
                lambda credentials, tenant=tenant: {
                    "user_id": "worker_test",
                    "client_id": tenant,
                    "role": "worker",
                },
            )

            with TestClient(app) as client:
                response = client.get(
                    "/v1/reports",
                    headers={
                        "Authorization": (
                            "Bearer fake_token"
                        ),
                    },
                )

            assert response.status_code == 200

            reports = response.json()

            assert len(reports) == 1

            report = reports[0]

            assert report["report_id"] == "1"
            assert report["client_id"] == tenant

            assert (
                f"/reports/{tenant}/1/"
                in report["image_url"]
            )
            assert (
                f"sig={tenant}"
                in report["image_url"]
            )

            assert (
                f"sig={tenant}"
                in report["evidences"][0]
            )

            assert (
                f"sig={tenant}"
                in report[
                    "closure_evidence"
                ]["url"]
            )

            serialized = str(report)

            assert (
                f"/reports/{forbidden_tenant}/1/"
                not in serialized
            )

        # La firma existe sólo en la respuesta HTTP.
        assert (
            fake_db["reports"].documents
            == persisted_before
        )

        assert all(
            "?sig=" not in str(document)
            for document
            in fake_db["reports"].documents
        )

    finally:
        app.dependency_overrides.clear()


def test_report_list_preserves_legacy_evidence_url(
    monkeypatch,
):
    legacy_url = (
        "/local-evidence/"
        "reports/1/evidence.jpg"
    )

    report = evidence_report_fixture(
        TENANT_A,
        report_id="legacy-1",
    )

    report["image_url"] = legacy_url
    report["evidences"] = [legacy_url]
    report.pop("closure_evidence", None)

    fake_db = FakeDB([report])

    monkeypatch.setattr(
        azure_blob_service,
        "BLOB_BASE_URL",
        "/local-report-evidence",
    )

    app.dependency_overrides[
        rt_reports.get_db
    ] = lambda: fake_db

    monkeypatch.setattr(
        rt_reports,
        "get_current_user",
        lambda credentials: {
            "user_id": "worker_test",
            "client_id": TENANT_A,
            "role": "worker",
        },
    )

    try:
        with TestClient(app) as client:
            response = client.get(
                "/v1/reports",
                headers={
                    "Authorization": (
                        "Bearer fake_token"
                    ),
                },
            )

        assert response.status_code == 200

        reports = response.json()

        assert len(reports) == 1
        assert reports[0]["image_url"] == (
            legacy_url
        )
        assert reports[0]["evidences"] == [
            legacy_url
        ]

        assert (
            fake_db["reports"]
            .documents[0]["image_url"]
            == legacy_url
        )

    finally:
        app.dependency_overrides.clear()
