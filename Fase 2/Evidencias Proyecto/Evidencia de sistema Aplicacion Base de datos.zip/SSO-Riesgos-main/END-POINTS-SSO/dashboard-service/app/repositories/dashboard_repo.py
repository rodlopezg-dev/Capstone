from datetime import datetime, timezone, timedelta

class DashboardRepository:
    def __init__(self, db):
        self.reports = db["reports"]
        self.alerts = db["alerts"]

    async def get_stats(self, client_id):
        total = await self.reports.count_documents({"client_id": client_id})
        iap = await self.reports.count_documents({"client_id": client_id, "is_iap": True, "status": {"$ne": "closed"}})
        open_reports = await self.reports.count_documents({"client_id": client_id, "status": {"$ne": "closed"}})
        alerts = await self.alerts.count_documents({"client_id": client_id, "status": "active"})
        return {"total_reports": total, "iap_active": iap, "open_reports": open_reports, "active_alerts": alerts}

    async def get_reports(self, client_id):
        results = []
        async for doc in self.reports.find({"client_id": client_id}).sort("created_at", -1):
            doc.pop("_id", None)
            results.append(doc)
        return results

    async def get_zone_data(self, client_id):
        pipeline = [
            {"$match": {"client_id": client_id}},
            {"$group": {"_id": "$area_id", "total": {"$sum": 1}, "open": {"$sum": {"$cond": [{"$ne": ["$status", "closed"]}, 1, 0]}}, "iap": {"$sum": {"$cond": ["$is_iap", 1, 0]}}}},
        ]
        results = []
        async for doc in self.reports.aggregate(pipeline):
            results.append({"area": doc["_id"], "total": doc["total"], "open": doc["open"], "iap": doc["iap"]})
        return results
