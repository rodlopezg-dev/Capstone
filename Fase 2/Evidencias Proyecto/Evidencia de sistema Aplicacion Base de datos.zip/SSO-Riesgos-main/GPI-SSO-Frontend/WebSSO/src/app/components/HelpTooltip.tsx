import { useState } from "react";
import { HelpCircle, X, ChevronRight, ChevronLeft } from "lucide-react";

interface HelpStep {
  title: string;
  description: string;
  icon?: string;
}

interface HelpTooltipProps {
  steps: HelpStep[];
}

export function HelpTooltip({ steps }: HelpTooltipProps) {
  const [open, setOpen]       = useState(false);
  const [current, setCurrent] = useState(0);

  return (
    <>
      {/* Botón Ayuda */}
      <button
        onClick={() => { setOpen(true); setCurrent(0); }}
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#163760] bg-[#102A4C] hover:bg-[#163760] hover:border-[#00E5FF]/50 text-[#9DBBD2] hover:text-[#00E5FF] transition-all text-sm"
      >
        <HelpCircle size={15} />
        <span className="font-medium">Ayuda</span>
      </button>

      {/* Overlay + Modal centrado */}
      {open && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center"
          style={{ backgroundColor: 'rgba(6, 18, 31, 0.85)', backdropFilter: 'blur(3px)' }}
          onClick={() => setOpen(false)}
        >
          {/* Panel — click no propaga */}
          <div
            className="relative w-full max-w-md mx-4 rounded-2xl overflow-hidden shadow-2xl"
            style={{ border: '1px solid #163760', background: 'linear-gradient(145deg, #0B1E36 0%, #06121F 100%)' }}
            onClick={e => e.stopPropagation()}
          >
            {/* Línea de acento cian arriba */}
            <div className="h-0.5 w-full" style={{ background: 'linear-gradient(90deg, #00E5FF, #0097A8)' }} />

            {/* Header */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-[#163760]">
              <div className="flex items-center gap-2">
                <HelpCircle size={16} className="text-[#00E5FF]" />
                <span className="text-sm font-bold tracking-widest uppercase text-[#00E5FF]"
                  style={{ fontFamily: 'var(--font-display)' }}>
                  Guía Rápida
                </span>
                <span className="text-xs text-[#5A8CB0] ml-1">
                  {current + 1} / {steps.length}
                </span>
              </div>
              <button
                onClick={() => setOpen(false)}
                className="p-1.5 rounded-lg hover:bg-[#163760] text-[#5A8CB0] hover:text-white transition-all"
              >
                <X size={15} />
              </button>
            </div>

            {/* Contenido del paso */}
            <div className="px-6 py-6 min-h-[140px] flex items-start gap-4">
              <span className="text-3xl leading-none shrink-0 mt-0.5">{steps[current].icon ?? '📌'}</span>
              <div>
                <p className="text-base font-semibold text-white mb-2">{steps[current].title}</p>
                <p className="text-sm text-[#9DBBD2] leading-relaxed">{steps[current].description}</p>
              </div>
            </div>

            {/* Footer */}
            <div className="flex items-center justify-between px-5 py-4 border-t border-[#163760]"
              style={{ background: 'rgba(6,18,31,0.5)' }}>
              {/* Dots */}
              <div className="flex gap-2 items-center">
                {steps.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setCurrent(i)}
                    className={`rounded-full transition-all duration-200 ${
                      i === current
                        ? 'w-5 h-2 bg-[#00E5FF]'
                        : 'w-2 h-2 bg-[#163760] hover:bg-[#9DBBD2]'
                    }`}
                  />
                ))}
              </div>

              {/* Nav buttons */}
              <div className="flex gap-2">
                <button
                  onClick={() => setCurrent(c => Math.max(0, c - 1))}
                  disabled={current === 0}
                  className="p-2 rounded-lg border border-[#163760] text-[#9DBBD2] hover:border-[#00E5FF]/40 hover:text-[#00E5FF] disabled:opacity-25 disabled:cursor-not-allowed transition-all"
                >
                  <ChevronLeft size={14} />
                </button>
                <button
                  onClick={() => current < steps.length - 1 ? setCurrent(c => c + 1) : setOpen(false)}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-lg font-medium text-sm transition-all"
                  style={{
                    background: current < steps.length - 1
                      ? 'rgba(0,229,255,0.12)'
                      : 'rgba(22,163,74,0.15)',
                    border: current < steps.length - 1
                      ? '1px solid rgba(0,229,255,0.35)'
                      : '1px solid rgba(22,163,74,0.4)',
                    color: current < steps.length - 1 ? '#00E5FF' : '#16A34A',
                  }}
                >
                  {current < steps.length - 1
                    ? <><span>Siguiente</span><ChevronRight size={13} /></>
                    : <span>Entendido ✓</span>
                  }
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
