export type AttendanceMethod =
  'qr' |
  'manual' |
  'sheet' |
  'unknown';

export const ATTENDANCE_FILTER_METHODS =
  ['qr', 'manual', 'sheet'] as const;

export type AttendanceMethodFilter =
  typeof ATTENDANCE_FILTER_METHODS[number];

export type AttendanceEntry = {
  user_id?: string;
  name?: string;
  registered_at?: string;
  method?: string;
};

type AttendanceRecord = {
  attendance_id: string;
  source?: string;
  date?: string;
  attendees?: string[];
  attended_user_ids?: string[];
  attendance_entries?: AttendanceEntry[];
};

export type AttendanceParticipant = {
  name: string;
  method: AttendanceMethod;
  registeredAt?: string;
  recordDate?: string;
};

export const ATTENDANCE_METHOD_LABELS = {
  all: 'Todos los participantes',
  qr: 'Código QR',
  manual: 'Registro manual',
  sheet: 'Hoja de asistencia',
  unknown: 'Sin identificar',
};

export function attendanceParticipants(record: AttendanceRecord): AttendanceParticipant[] {
  const names = record.attendees ?? [];
  const ids = record.attended_user_ids ?? [];
  const entries = record.attendance_entries ?? [];
  const offset = names.length - ids.length;
  return names.map((name, index) => {
    const id = index >= offset ? ids[index - offset] : undefined;
    const entry = (id ? entries.find(row => row.user_id === id) : undefined)
      ?? entries.find(row => row.name === name);
    const source = entry?.method || record.source;
    const method: AttendanceMethod = source === 'qr' || source === 'manual' || source === 'sheet'
      ? source
      : !source && record.attendance_id.startsWith('att_') ? 'manual' : 'unknown';
    return { name, method, registeredAt: entry?.registered_at };
  });
}

export function filterParticipants(
  rows: AttendanceParticipant[],
  filters: AttendanceMethodFilter[],
) {
  if (filters.length === 0) {
    return rows;
  }

  return rows.filter(
    row =>
      row.method !== 'unknown' &&
      filters.includes(row.method),
  );
}

export function registrationDateLabel(timestamp?: string, recordDate?: string) {
  if (timestamp) {
    const parsed = new Date(timestamp);
    if (!Number.isNaN(parsed.getTime())) return parsed.toLocaleString('es-CL');
  }
  if (recordDate && /^\d{4}-\d{2}-\d{2}$/.test(recordDate)) {
    return `${recordDate.split('-').reverse().join('-')} · Sin hora individual registrada`;
  }
  return 'Sin fecha y hora registradas';
}
