import { describe, expect, it } from 'vitest';
import { renderToStaticMarkup } from 'react-dom/server';

import WorkerFeedbackField from './WorkerFeedbackField';

describe('WorkerFeedbackField - SCRUM-77', () => {
  it('renders the worker feedback label', () => {
    const html = renderToStaticMarkup(
      <WorkerFeedbackField
        value=""
        onChange={() => undefined}
      />
    );

    expect(html).toContain('Feedback al trabajador');
  });

  it('renders the expected placeholder', () => {
    const html = renderToStaticMarkup(
      <WorkerFeedbackField
        value=""
        onChange={() => undefined}
      />
    );

    expect(html).toContain(
      'Escribir feedback para el trabajador...'
    );
  });

  it('renders the current feedback value', () => {
    const html = renderToStaticMarkup(
      <WorkerFeedbackField
        value="Se reforzó el procedimiento de trabajo seguro."
        onChange={() => undefined}
      />
    );

    expect(html).toContain(
      'Se reforzó el procedimiento de trabajo seguro.'
    );
  });

  it('renders the supporting description', () => {
    const html = renderToStaticMarkup(
      <WorkerFeedbackField
        value=""
        onChange={() => undefined}
      />
    );

    expect(html).toContain(
      'Registra las observaciones que se comunicarán al trabajador.'
    );
  });

  it('can be disabled', () => {
    const html = renderToStaticMarkup(
      <WorkerFeedbackField
        value=""
        onChange={() => undefined}
        disabled
      />
    );

    expect(html).toContain('disabled');
  });
});
