export const INCIDENT_AREAS = [
  'Linea 1',
  'Linea 2',
  'Linea 3',
  'Bodega Quimica',
  'Zona de Carga',
  'Area de Corte',
] as const;
