# Arquitectura del Sistema SSO

## 📐 Diagrama de Flujo de Datos

```
┌─────────────────────────────────────────────────────────────────────┐
│                        APLICACIÓN MÓVIL (Empleados)                 │
│                                                                     │
│  ┌──────────┐   ┌──────────┐   ┌──────────┐   ┌──────────┐        │
│  │  Inicio  │   │  Crear   │   │   Mis    │   │  Perfil  │        │
│  │  (M-01)  │   │ Reporte  │   │ Reportes │   │  (M-06)  │        │
│  │          │   │  (M-02)  │   │  (M-04)  │   │          │        │
│  └─────┬────┘   └─────┬────┘   └─────┬────┘   └─────┬────┘        │
│        │              │              │              │              │
│        └──────────────┴──────────────┴──────────────┘              │
│                            │                                        │
│                            ▼                                        │
│                   ┌──────────────────┐                             │
│                   │  API REST / SDK  │                             │
│                   └────────┬─────────┘                             │
└────────────────────────────┼──────────────────────────────────────┘
                             │
                             │  HTTPS / JSON
                             │
                    ┌────────▼─────────┐
                    │                  │
                    │   BASE DE DATOS  │
                    │                  │
                    │  ┌────────────┐  │
                    │  │  Reportes  │  │
                    │  │   Zonas    │  │
                    │  │  Alertas   │  │
                    │  │  Usuarios  │  │
                    │  │Notificac.  │  │
                    │  └────────────┘  │
                    │                  │
                    └────────┬─────────┘
                             │
                             │  HTTPS / JSON
                             │
┌────────────────────────────┼──────────────────────────────────────┐
│                            ▼                                       │
│                   ┌──────────────────┐                            │
│                   │  API REST / SDK  │                            │
│                   └────────┬─────────┘                            │
│                            │                                       │
│        ┌───────────────────┼───────────────────┐                  │
│        │                   │                   │                  │
│   ┌────▼────┐       ┌──────▼──────┐     ┌─────▼──────┐           │
│   │ Command │       │  Gestión de │     │   Gemelo   │           │
│   │ Center  │       │ Incidentes  │     │  Digital   │           │
│   │ (W-01)  │       │   (W-02)    │     │   (W-03)   │           │
│   └─────────┘       └─────────────┘     └────────────┘           │
│                                                                    │
│                  PLATAFORMA WEB (Supervisores)                     │
└────────────────────────────────────────────────────────────────────┘
```

---

## 🔄 Flujo de Sincronización Detallado

### 1. Empleado Reporta Hallazgo (App Móvil → Base de Datos)

```
App Móvil (M-02)
      │
      │ 1. Captura foto
      │ 2. Selecciona ubicación (Área/Línea/Proceso)
      │ 3. Clasifica tipo (Acto/Condición Insegura)
      │ 4. Marca IAP (sí/no)
      │ 5. Agrega descripción
      │
      ▼
POST /api/reportes/crear
      │
      │ Payload:
      │ {
      │   area: "Línea 3",
      │   tipo: "condicion_insegura",
      │   es_iap: true,
      │   descripcion: "Cable expuesto",
      │   evidencia_foto: <File>,
      │   reportador_id: "user-001"
      │ }
      │
      ▼
Backend
      │
      ├─► 1. Sube foto a storage (S3/Cloudinary)
      │      └─► Retorna URL: https://storage.com/foto123.jpg
      │
      ├─► 2. Crea registro en tabla `reportes`
      │      INSERT INTO reportes (...)
      │
      ├─► 3. SI es_iap = true:
      │      └─► Crea alerta en tabla `alertas`
      │          INSERT INTO alertas (tipo='iap', reporte_id=...)
      │
      └─► 4. Crea notificación para supervisor del área
             INSERT INTO notificaciones (
               usuario_id='supervisor-del-area',
               tipo='alerta',
               mensaje='Nuevo IAP en Línea 3'
             )
```

### 2. Supervisor Revisa y Actualiza (Web → Base de Datos)

```
Plataforma Web (W-02)
      │
      │ GET /api/reportes?estado=en_revision
      │
      ▼
Backend retorna lista de reportes
      │
      ▼
Supervisor selecciona reporte y actualiza
      │
      ▼
PATCH /api/reportes/:id
      │
      │ Payload:
      │ {
      │   estado: "accion_asignada",
      │   responsable_asignado: "María González",
      │   feedback_supervisor: "Se asignó reparación"
      │ }
      │
      ▼
Backend
      │
      ├─► 1. Actualiza registro en tabla `reportes`
      │      UPDATE reportes SET estado=... WHERE id=...
      │
      └─► 2. Crea notificación para empleado que reportó
             INSERT INTO notificaciones (
               usuario_id='user-001',
               tipo='actualizacion',
               mensaje='Tu reporte fue actualizado'
             )
```

### 3. Empleado Ve Actualización (Base de Datos → App Móvil)

```
App Móvil (M-03 - Detalle de Reporte)
      │
      │ GET /api/reportes/:id
      │
      ▼
Backend retorna reporte actualizado
      │
      │ Response:
      │ {
      │   id: "rep-001",
      │   estado: "accion_asignada",
      │   responsable_asignado: "María González",
      │   feedback_supervisor: "Se asignó reparación",
      │   timeline: [...]
      │ }
      │
      ▼
App muestra timeline de estado y feedback
```

### 4. Notificaciones Push (Opcional)

```
Base de Datos
      │
      │ Trigger cuando se inserta en tabla `notificaciones`
      │
      ▼
Servicio de Notificaciones
      │
      ├─► Firebase Cloud Messaging (FCM)
      │   └─► Push a dispositivo móvil
      │
      └─► WebSocket / Server-Sent Events
          └─► Actualización en tiempo real en web
```

---

## 🏗️ Arquitectura de Capas

```
┌─────────────────────────────────────────────────────────┐
│                  CAPA DE PRESENTACIÓN                   │
│                                                         │
│  ┌─────────────────┐         ┌─────────────────┐      │
│  │   App Móvil     │         │  Plataforma Web │      │
│  │  React Native   │         │   React + TS    │      │
│  └─────────────────┘         └─────────────────┘      │
└─────────────┬──────────────────────┬───────────────────┘
              │                      │
              │  HTTP/REST          │  HTTP/REST
              │                      │
┌─────────────▼──────────────────────▼───────────────────┐
│                   CAPA DE API                          │
│                                                        │
│  ┌──────────────────────────────────────────────┐    │
│  │  API REST / GraphQL                          │    │
│  │  (Express, Fastify, Next.js API, etc.)       │    │
│  │                                              │    │
│  │  Endpoints:                                  │    │
│  │  • POST /api/reportes                        │    │
│  │  • GET  /api/reportes                        │    │
│  │  • PATCH /api/reportes/:id                   │    │
│  │  • GET  /api/zonas                           │    │
│  │  • POST /api/alertas                         │    │
│  │  • GET  /api/estadisticas/*                  │    │
│  └──────────────────────────────────────────────┘    │
│                                                        │
│  ┌──────────────────────────────────────────────┐    │
│  │  Servicios de Negocio                        │    │
│  │  • Cálculo de Score de Riesgo                │    │
│  │  • Generación de Alertas Automáticas         │    │
│  │  • Validación de SLA                         │    │
│  │  • Notificaciones Push                       │    │
│  └──────────────────────────────────────────────┘    │
└─────────────┬──────────────────────────────────────────┘
              │
              │  SQL Queries / ORM
              │
┌─────────────▼──────────────────────────────────────────┐
│                CAPA DE PERSISTENCIA                    │
│                                                        │
│  ┌──────────────────────────────────────────────┐    │
│  │         BASE DE DATOS SQL                    │    │
│  │  (PostgreSQL, MySQL, Supabase)               │    │
│  │                                              │    │
│  │  Tablas:                                     │    │
│  │  • reportes                                  │    │
│  │  • zonas                                     │    │
│  │  • alertas                                   │    │
│  │  • usuarios                                  │    │
│  │  • notificaciones                            │    │
│  └──────────────────────────────────────────────┘    │
│                                                        │
│  ┌──────────────────────────────────────────────┐    │
│  │         STORAGE DE ARCHIVOS                  │    │
│  │  (S3, Cloudinary, Supabase Storage)          │    │
│  │                                              │    │
│  │  • Fotos de evidencia                        │    │
│  │  • Videos                                    │    │
│  │  • Planos de planta                          │    │
│  └──────────────────────────────────────────────┘    │
└────────────────────────────────────────────────────────┘
```

---

## 📊 Modelo de Datos Relacional

```
┌─────────────┐
│  usuarios   │
├─────────────┤
│ id (PK)     │◄────────┐
│ nombre      │         │
│ email       │         │
│ rol         │         │
│ area        │         │
└─────────────┘         │
                        │
                        │ reportador_id
                        │
┌─────────────┐         │
│  reportes   │─────────┘
├─────────────┤
│ id (PK)     │◄────────┐
│ area        │         │
│ tipo        │         │ reporte_id
│ es_iap      │         │
│ estado      │         ├─────────────────┐
│ descripcion │         │                 │
│ foto_url    │         │                 │
│ reportador  │         │                 │
└─────────────┘         │                 │
                        │                 │
┌─────────────┐         │                 │
│   alertas   │─────────┘                 │
├─────────────┤                           │
│ id (PK)     │◄──────────────────────────┤
│ tipo        │                           │
│ activa      │                           │
│ reporte_id  │                           │
│ zona_id     │                           │
└─────────────┘                           │
                                          │
┌─────────────┐                           │
│notificacion │───────────────────────────┘
├─────────────┤
│ id (PK)     │
│ tipo        │
│ usuario_id  │
│ reporte_id  │
│ leida       │
└─────────────┘

┌─────────────┐
│   zonas     │
├─────────────┤
│ id (PK)     │
│ nombre      │
│ coordenadas │
│ score_riesgo│
│ nivel_riesgo│
└─────────────┘
```

---

## 🔐 Seguridad

### Autenticación y Autorización

```
Cliente (App/Web)
      │
      │ 1. POST /api/auth/login
      │    { email, password }
      │
      ▼
Backend
      │
      ├─► Valida credenciales con bcrypt
      │
      ├─► Genera JWT Token
      │   {
      │     userId: "user-001",
      │     rol: "empleado",
      │     exp: timestamp
      │   }
      │
      └─► Retorna token
             └─► Cliente guarda en localStorage/SecureStorage

Solicitudes subsecuentes:
      │
      │ GET /api/reportes
      │ Headers: { Authorization: "Bearer <token>" }
      │
      ▼
Backend Middleware
      │
      ├─► Verifica token JWT
      ├─► Extrae userId y rol
      └─► Autoriza según permisos
          • Empleado: solo sus reportes
          • Supervisor: reportes de su área
          • Gerente SSO: todos los reportes
```

---

## 📈 Escalabilidad

### Optimizaciones Recomendadas

1. **Caché de Lecturas Frecuentes**
   ```
   Redis/Memcached
   ├─► Caché de estadísticas globales (TTL: 5 min)
   ├─► Caché de zonas (TTL: 1 hora)
   └─► Caché de ranking de áreas (TTL: 10 min)
   ```

2. **Cola de Trabajos**
   ```
   Bull/RabbitMQ
   ├─► Procesamiento de imágenes (resize, optimización)
   ├─► Envío de notificaciones push
   ├─► Cálculo de scores de riesgo
   └─► Generación de reportes PDF/Excel
   ```

3. **CDN para Archivos Estáticos**
   ```
   CloudFront/Cloudflare
   └─► Fotos de evidencia
   └─► Planos de planta
   ```

---

## 🔄 Sincronización Offline (App Móvil)

```
App Móvil sin conexión
      │
      │ Empleado crea reporte
      │
      ▼
SQLite Local
      │
      │ Guarda reporte en cola
      │ { id, data, status: "pending" }
      │
      ▼
Servicio Background
      │
      │ Detecta conexión restaurada
      │
      ▼
      │ 1. Lee reportes pending
      │ 2. POST /api/reportes (con retry)
      │ 3. Marca como "synced" en SQLite
      │
      ▼
Backend recibe reportes retrasados
```

---

## 📝 Resumen

| Componente | Tecnología Sugerida | Responsabilidad |
|------------|---------------------|-----------------|
| App Móvil | React Native | UI empleados, captura reportes |
| Web | React + TypeScript | UI supervisores, gestión |
| API Backend | Node.js + Express | Lógica de negocio, endpoints |
| Base de Datos | PostgreSQL / Supabase | Persistencia de datos |
| Storage | S3 / Cloudinary | Almacenamiento de imágenes |
| Auth | JWT + bcrypt | Autenticación y autorización |
| Push Notifications | Firebase FCM | Notificaciones móviles |
| Real-time | WebSocket / Supabase Realtime | Actualizaciones en vivo |
| Queue | Bull / RabbitMQ | Tareas asíncronas |
| Cache | Redis | Optimización de lecturas |
