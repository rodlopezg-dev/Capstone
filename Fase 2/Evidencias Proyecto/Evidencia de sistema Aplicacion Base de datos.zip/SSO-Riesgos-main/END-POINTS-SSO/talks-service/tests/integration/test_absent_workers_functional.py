import pytest


async def _configure_worker(db, user_id):
    await db["users"].update_one(
        {
            "user_id": user_id,
            "client_id": "empresa_a",
        },
        {
            "$set": {
                "role": "worker",
                "status": "active",
            },
        },
    )


async def _create_talk(
    db,
    talk_id,
    expected_user_ids,
):
    await db["talks"].insert_one({
        "talk_id": talk_id,
        "client_id": "empresa_a",
        "title": f"Charla {talk_id}",
        "month": "9",
        "year": "2026",
        "mandatory": True,
        "expected_user_ids": expected_user_ids,
    })


async def _register_qr_attendance(
    db,
    talk_id,
    attended_user_ids,
):
    await db["attendance"].insert_one({
        "attendance_id": f"att_{talk_id}",
        "client_id": "empresa_a",
        "talk_id": talk_id,
        "source": "qr",
        "attended_user_ids": attended_user_ids,
        "attendees": [],
    })


@pytest.mark.asyncio
async def test_functional_attending_worker_is_not_absent(
    api,
    db,
    auth_headers,
    seed,
):
    await _configure_worker(db, "worker_a")

    await _create_talk(
        db,
        "talk_functional_attendee",
        ["worker_a"],
    )

    await _register_qr_attendance(
        db,
        "talk_functional_attendee",
        ["worker_a"],
    )

    response = await api.get(
        "/v1/talks/talk_functional_attendee/absent-workers",
        headers=auth_headers(
            user_id="admin_a",
            role="admin",
        ),
    )

    assert response.status_code == 200

    data = response.json()

    assert data["attended_user_ids"] == [
        "worker_a",
    ]
    assert data["absent_user_ids"] == []
    assert data["absence_status"] == (
        "no_absences"
    )


@pytest.mark.asyncio
async def test_functional_missing_attendance_marks_worker_absent(
    api,
    db,
    auth_headers,
    seed,
):
    await _configure_worker(db, "worker_a")

    await _create_talk(
        db,
        "talk_functional_absent",
        ["worker_a"],
    )

    response = await api.get(
        "/v1/talks/talk_functional_absent/absent-workers",
        headers=auth_headers(
            user_id="admin_a",
            role="admin",
        ),
    )

    assert response.status_code == 200

    data = response.json()

    assert data["attended_user_ids"] == []
    assert data["absent_user_ids"] == [
        "worker_a",
    ]

    assert [
        worker["user_id"]
        for worker in data["absent_workers"]
    ] == [
        "worker_a",
    ]

    assert data["absence_status"] == (
        "absences_found"
    )


@pytest.mark.asyncio
async def test_functional_multiple_workers_are_compared(
    api,
    db,
    auth_headers,
    seed,
):
    await _configure_worker(db, "worker_a")
    await _configure_worker(db, "worker_a2")

    await _create_talk(
        db,
        "talk_functional_multiple",
        [
            "worker_a",
            "worker_a2",
        ],
    )

    await _register_qr_attendance(
        db,
        "talk_functional_multiple",
        ["worker_a"],
    )

    response = await api.get(
        "/v1/talks/talk_functional_multiple/absent-workers",
        headers=auth_headers(
            user_id="admin_a",
            role="admin",
        ),
    )

    assert response.status_code == 200

    data = response.json()

    assert data["attended_user_ids"] == [
        "worker_a",
    ]

    assert data["absent_user_ids"] == [
        "worker_a2",
    ]

    assert data["absence_status"] == (
        "absences_found"
    )


@pytest.mark.asyncio
async def test_functional_no_absences_when_everyone_attended(
    api,
    db,
    auth_headers,
    seed,
):
    await _configure_worker(db, "worker_a")
    await _configure_worker(db, "worker_a2")

    await _create_talk(
        db,
        "talk_functional_complete",
        [
            "worker_a",
            "worker_a2",
        ],
    )

    await _register_qr_attendance(
        db,
        "talk_functional_complete",
        [
            "worker_a",
            "worker_a2",
        ],
    )

    response = await api.get(
        "/v1/talks/talk_functional_complete/absent-workers",
        headers=auth_headers(
            user_id="admin_a",
            role="admin",
        ),
    )

    assert response.status_code == 200

    data = response.json()

    assert data["absent_user_ids"] == []
    assert data["absent_workers"] == []
    assert data["absence_status"] == (
        "no_absences"
    )


@pytest.mark.asyncio
async def test_functional_insufficient_data_for_legacy_talk(
    api,
    db,
    auth_headers,
    seed,
):
    await db["talks"].insert_one({
        "talk_id": "talk_functional_legacy",
        "client_id": "empresa_a",
        "title": "Charla legacy",
        "month": "9",
        "year": "2026",
        "mandatory": True,
    })

    response = await api.get(
        "/v1/talks/talk_functional_legacy/absent-workers",
        headers=auth_headers(
            user_id="admin_a",
            role="admin",
        ),
    )

    assert response.status_code == 200

    data = response.json()

    assert data[
        "expected_workers_configured"
    ] is False

    assert data["absence_status"] == (
        "insufficient_data"
    )


@pytest.mark.asyncio
async def test_functional_uses_only_selected_talk(
    api,
    db,
    auth_headers,
    seed,
):
    await _configure_worker(db, "worker_a")
    await _configure_worker(db, "worker_a2")

    await _create_talk(
        db,
        "talk_functional_selected",
        [
            "worker_a",
            "worker_a2",
        ],
    )

    await _create_talk(
        db,
        "talk_functional_other",
        [
            "worker_a",
            "worker_a2",
        ],
    )

    await _register_qr_attendance(
        db,
        "talk_functional_selected",
        ["worker_a"],
    )

    await _register_qr_attendance(
        db,
        "talk_functional_other",
        ["worker_a2"],
    )

    response = await api.get(
        "/v1/talks/talk_functional_selected/absent-workers",
        headers=auth_headers(
            user_id="admin_a",
            role="admin",
        ),
    )

    assert response.status_code == 200

    data = response.json()

    assert data["talk_id"] == (
        "talk_functional_selected"
    )

    assert data["attended_user_ids"] == [
        "worker_a",
    ]

    assert data["absent_user_ids"] == [
        "worker_a2",
    ]
