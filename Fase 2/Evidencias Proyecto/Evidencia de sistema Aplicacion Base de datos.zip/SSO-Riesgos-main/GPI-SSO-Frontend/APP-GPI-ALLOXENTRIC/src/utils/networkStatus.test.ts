import {
  afterEach,
  beforeEach,
  describe,
  expect,
  it,
  vi,
} from 'vitest';

const mocks = vi.hoisted(() => ({
  isNativePlatform: vi.fn(),
  getStatus: vi.fn(),
  addListener: vi.fn(),
}));

vi.mock('@capacitor/core', () => ({
  Capacitor: {
    isNativePlatform:
      mocks.isNativePlatform,
  },
}));

vi.mock('@capacitor/network', () => ({
  Network: {
    getStatus:
      mocks.getStatus,
    addListener:
      mocks.addListener,
  },
}));

import {
  getNetworkConnected,
} from './networkStatus';

describe('getNetworkConnected', () => {
  beforeEach(() => {
    mocks.isNativePlatform
      .mockReset();
    mocks.getStatus
      .mockReset();
  });

  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it(
    'usa Capacitor Network en plataforma nativa',
    async () => {
      mocks.isNativePlatform
        .mockReturnValue(true);

      mocks.getStatus
        .mockResolvedValue({
          connected: false,
          connectionType: 'none',
        });

      await expect(
        getNetworkConnected(),
      ).resolves.toBe(false);
    },
  );

  it(
    'usa navigator.onLine en web',
    async () => {
      mocks.isNativePlatform
        .mockReturnValue(false);

      vi.stubGlobal(
        'navigator',
        { onLine: false },
      );

      await expect(
        getNetworkConnected(),
      ).resolves.toBe(false);

      expect(
        mocks.getStatus,
      ).not.toHaveBeenCalled();
    },
  );
});
