import {
  apiFetch,
  authenticatedFetch,
  setToken,
  setRefreshToken,
  clearAuthTokens,
} from './client';

import { getUserProfile } from './users';

export interface LoginResponse {
  access_token: string;
  refresh_token: string;
  token_type: string;
  user_id: string;
  role: string;
  areas?: string[];
  area?: string;
}

export interface AuthMeResponse {
  user_id: string;
  client_id: string;
  role: string;
  areas?: string[];
  area?: string;
}

export interface UserMe {
  user_id: string;
  name: string;
  last_name: string;
  profile_photo_url: string | null;
  email: string;
  employee_id: string;
  role: string;
  shift: string;
  area: string;
  client_id: string;
  plan_tier: string;
  assigned_areas: string[];
  stats: {
    total_reports: number;
    this_month: number;
    effectiveness: number;
  };
}

export async function login(
  clientId: string,
  username: string,
  password: string,
): Promise<{ user: UserMe } & LoginResponse> {
  const requestedClientId = clientId.trim();

  if (!requestedClientId) {
    throw new Error('ORGANIZATION_REQUIRED');
  }

  const data = await apiFetch<LoginResponse>(
    '/v1/auth/login',
    {
      method: 'POST',
      base: 'auth',
      auth: false,
      body: JSON.stringify({
        client_id: requestedClientId,
        email: username.trim(),
        password,
      }),
    },
  );

  setToken(data.access_token);
  setRefreshToken(
    data.refresh_token,
  );

  let me: AuthMeResponse;
  let profile;

  try {
    me = await getMe();

    if (!me.client_id) {
      throw new Error('INVALID_TENANT_SESSION');
    }

    profile = await getUserProfile();
  } catch (error) {
    clearAuthTokens();
    throw error;
  }

  let stats = {
    total_reports: 0,
    this_month: 0,
    effectiveness: 0,
  };

  try {
    const REPORTS_API =
      import.meta.env.VITE_REPORTS_API_URL ||
      'http://localhost:8102';

    const reportsRes = await authenticatedFetch(
      REPORTS_API + '/v1/reports',
      {
        headers: {
          Authorization:
            'Bearer ' + data.access_token,
        },
      },
    );

    if (reportsRes.ok) {
      const reports = await reportsRes.json();

      const mine = reports.filter(
        (r: any) =>
          r.reported_by === data.user_id,
      );

      const closed = mine.filter(
        (r: any) =>
          r.status === 'closed',
      );

      const now = new Date();

      const thisMonth = mine.filter(
        (r: any) => {
          const d = new Date(
            r.created_at,
          );

          return (
            d.getMonth() ===
              now.getMonth() &&
            d.getFullYear() ===
              now.getFullYear()
          );
        },
      );

      stats = {
        total_reports: mine.length,
        this_month: thisMonth.length,
        effectiveness:
          mine.length > 0
            ? Math.round(
                closed.length /
                  mine.length *
                  100,
              )
            : 0,
      };
    }
  } catch (error) {
    console.error(
      'Stats error:',
      error,
    );
  }

  const effectiveUserId =
    me.user_id || data.user_id;

  const effectiveAreas =
    me.areas ??
    data.areas ??
    [];

  return {
    ...data,

    user: {
      user_id: effectiveUserId,

      name: profile.name,

      last_name:
        profile.last_name ?? '',

      profile_photo_url:
        profile.profile_photo_url ?? null,

      email: profile.email,

      employee_id:
        effectiveUserId,

      role:
        me.role ||
        data.role,

      shift: 'Día',

      area:
        me.area ||
        effectiveAreas[0] ||
        data.area ||
        data.areas?.[0] ||
        'Sin area',

      assigned_areas:
        effectiveAreas,

      // El tenant efectivo siempre viene
      // del JWT validado por el backend.
      client_id: me.client_id,

      plan_tier:
        'professional',

      stats,
    },
  };
}

export async function restoreSession():
Promise<UserMe> {
  const me = await getMe();

  if (!me.client_id) {
    throw new Error(
      'INVALID_TENANT_SESSION',
    );
  }

  const profile =
    await getUserProfile();

  const effectiveAreas =
    me.areas ?? [];

  return {
    user_id:
      me.user_id,

    name:
      profile.name,

    last_name:
      profile.last_name ?? '',

    profile_photo_url:
      profile.profile_photo_url ??
      null,

    email:
      profile.email,

    employee_id:
      me.user_id,

    role:
      me.role,

    shift:
      'Día',

    area:
      me.area ||
      effectiveAreas[0] ||
      'Sin area',

    client_id:
      me.client_id,

    plan_tier:
      'professional',

    assigned_areas:
      effectiveAreas,

    stats: {
      total_reports: 0,
      this_month: 0,
      effectiveness: 0,
    },
  };
}


export async function logout(): Promise<void> {
  clearAuthTokens();
}

export async function getMe(): Promise<AuthMeResponse> {
  return apiFetch<AuthMeResponse>(
    '/v1/auth/me',
    {
      base: 'auth',
    },
  );
}
