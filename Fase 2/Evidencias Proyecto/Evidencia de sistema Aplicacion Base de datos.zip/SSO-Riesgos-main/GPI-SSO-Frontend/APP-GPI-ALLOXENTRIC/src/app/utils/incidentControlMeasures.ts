export const CONTROL_MEASURE_OPTIONS = [
  'Elaborar y capacitar en procedimiento o instructivo',
  'Actualizar y capacitar en procedimiento o instructivo',
  'Reinstruir en procedimiento o instructivo',
  'Aplicar medida disciplinaria segun reglamento',
  'Corregir o reparar condicion fisica insegura',
  'Instalar o mejorar senalizacion o demarcacion',
  'Implementar barrera fisica o control de ingenieria',
  'Reemplazar equipo, herramienta o EPP defectuoso',
  'Realizar mantencion correctiva o preventiva',
  'Reforzar supervision o acompanamiento en terreno',
  'Derivar a comite paritario o prevencion de riesgos',
  'Otra medida de control',
] as const;

export const toggleControlMeasure = (
  selectedMeasures: string[],
  measure: string
) =>
  selectedMeasures.includes(measure)
    ? selectedMeasures.filter(item => item !== measure)
    : [...selectedMeasures, measure];
