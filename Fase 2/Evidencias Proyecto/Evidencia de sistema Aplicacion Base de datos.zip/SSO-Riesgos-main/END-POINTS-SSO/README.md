# GPI Backend — Vigía Industrial

Backend del sistema GPI (Gestión de Prevención de Incidentes / SSO) desarrollado para
Alloxentric. Compuesto por **9 microservicios independientes** en Python/FastAPI, que en
conjunto dan soporte al dashboard web de supervisores y a la app móvil de trabajadores
("Vigía Industrial").

---

## Índice

- [Arquitectura general](#arquitectura-general)
- [Estructura del repositorio](#estructura-del-repositorio)
- [Stack tecnológico](#stack-tecnológico)
- [Requisitos previos](#requisitos-previos)
- [Configuración de Firebase](#configuración-de-firebase-paso-obligatorio)
- [Variables de entorno](#variables-de-entorno)
- [Cómo correr un servicio individual](#cómo-correr-un-servicio-individual)
- [Cómo correr todo junto con Docker Compose](#cómo-correr-todo-junto-con-docker-compose)
- [Estructura interna de cada microservicio](#estructura-interna-de-cada-microservicio)
- [Despliegue en Render](#despliegue-en-render)
- [Documentación automática (Swagger)](#documentación-automática-swagger)
- [Seguridad y buenas prácticas](#seguridad-y-buenas-prácticas)
- [Problemas comunes](#problemas-comunes)

---

## Arquitectura general

```
┌─────────────────┐        ┌──────────────────┐
│   App Móvil       │        │   Dashboard Web    │
│  (Vigía Industrial)│        │   (Supervisores)    │
└─────────┬────────┘        └─────────┬─────────┘
          │                            │
          │           HTTPS            │
          ▼                            ▼
┌───────────────────────────────────────────────┐
│              9 Microservicios (este repo)       │
│                                                   │
│  auth-service        → login, emisión de JWT      │
│  users-service       → gestión de usuarios         │
│  workers-service     → perfil y stats del trabajador│
│  reports-service     → reportes, cambios de estado  │
│  alerts-service      → alertas manuales y auto (IAP)│
│  areas-service       → áreas/zonas de la planta     │
│  incidents-service   → gestión de incidentes         │
│  dashboard-service   → KPIs y datos agregados         │
│  digital-twin-service→ gemelo digital de la planta     │
└──────────────────────┬────────────────────────┘
                        │
                        ▼
          ┌───────────────────────────┐
          │   Firebase Firestore        │
          │   (multi-tenant, tiempo real)│
          └───────────────────────────┘
```

Cada microservicio:
- Es **independiente**: su propio `pyproject.toml`, `Dockerfile` y proceso.
- Comparte el **mismo proyecto de Firestore**, aislando los datos de cada cliente mediante
  un campo `client_id` obligatorio en cada documento (arquitectura *multi-tenant*).
- Se autentica mediante **JSON Web Tokens (JWT)** emitidos por `auth-service` y validados
  de forma independiente (*stateless*) por cada servicio.

---

## Estructura del repositorio

```
API-GPI-FINALES/
├── auth-service/
│   ├── app/
│   │   ├── main.py          ← punto de entrada (instancia FastAPI)
│   │   ├── config.py
│   │   ├── routers/
│   │   ├── services/
│   │   └── repositories/
│   ├── pyproject.toml
│   ├── Dockerfile
│   ├── .env                 ← NO se versiona (ver .gitignore)
│   └── service-account.json ← NO se versiona (ver .gitignore)
├── users-service/            (misma estructura)
├── workers-service/           (misma estructura)
├── reports-service/           (misma estructura)
├── alerts-service/             (misma estructura)
├── areas-service/               (misma estructura)
├── incidents-service/            (misma estructura)
├── dashboard-service/              (misma estructura)
├── digital-twin-service/            (misma estructura)
└── docker-compose.yml         ← levanta los 9 servicios juntos en local
```

> ⚠️ **Importante:** cada servicio espera su `main.py` dentro de `app/` (es decir,
> `<servicio>/app/main.py`), no en la raíz del servicio. El `Dockerfile` solo copia la
> carpeta `app/` a la imagen — si `main.py` queda fuera de esa carpeta, el contenedor
> arranca pero falla con `Could not import module "app.main"`.

---

## Stack tecnológico

| Componente | Tecnología |
|---|---|
| Lenguaje | Python 3.12 |
| Framework web | FastAPI |
| Validación de datos | Pydantic v2 |
| Base de datos | Firebase Firestore (`google-cloud-firestore`) |
| Autenticación | JWT propio (`pyjwt`), sin proveedor externo tipo Keycloak/Auth0 |
| Gestor de paquetes | [`uv`](https://docs.astral.sh/uv/) |
| Contenerización | Docker (`python:3.12-slim`, build multi-stage) |
| Hosting | [Render](https://render.com) (Web Service por microservicio) |
| Almacenamiento de evidencias | Azure Blob Storage (usado por `reports-service`) |

---

## Requisitos previos

- [Python 3.12](https://www.python.org/downloads/)
- [uv](https://docs.astral.sh/uv/) → `pip install uv`
- [Docker](https://www.docker.com/) (opcional, recomendado para correr todo junto)
- Cuenta de [Firebase](https://console.firebase.google.com) con Firestore activado
- Cuenta de [Render](https://render.com) (para desplegar)

---

## Configuración de Firebase (paso obligatorio)

Todos los microservicios comparten el mismo proyecto de Firestore.

1. En [Firebase Console](https://console.firebase.google.com), activar **Firestore
   Database** (modo producción).
2. En ⚙️ **Configuración del proyecto → Cuentas de servicio → Generar nueva clave
   privada**, descargar el archivo `service-account.json`.
3. Copiar ese archivo dentro de **cada una** de las 9 carpetas de servicio (junto a su
   `pyproject.toml`). Este archivo es secreto — nunca se sube al repositorio (ya está
   excluido vía `.gitignore`).
4. Anotar el **Project ID** de Firebase — se usa como valor de `SSO_FIRESTORE_PROJECT`
   en cada `.env`.

---

## Variables de entorno

Cada servicio necesita su propio archivo `.env` en su carpeta. Ninguno se versiona en Git.

### Comunes a todos los servicios

| Variable | Descripción |
|---|---|
| `JWT_SECRET` | Clave secreta para firmar/verificar tokens. **Debe ser idéntica en todos los servicios.** |
| `JWT_ALGORITHM` | `HS256` |
| `INTERNAL_API_KEY` | Clave para llamadas servicio-a-servicio (ej. `reports-service` → `alerts-service`) |
| `SSO_FIRESTORE_PROJECT` | Project ID de Firebase |
| `SSO_ENVIRONMENT` | `development` o `production` |
| `GOOGLE_APPLICATION_CREDENTIALS` | Ruta al `service-account.json` (normalmente `service-account.json`) |

### Específicas por servicio

| Servicio | Variable | Descripción |
|---|---|---|
| `auth-service` | `USERS_SERVICE_URL` | URL de `users-service`, para validar usuarios al hacer login |
| `reports-service` | `ALERTS_SERVICE_URL` | URL de `alerts-service`, para disparar alertas automáticas de IAP |
| `reports-service` | `AZURE_STORAGE_CONNECTION_STRING` | Conexión a Azure Blob Storage para evidencias |
| `reports-service` | `AZURE_STORAGE_CONTAINER` | Contenedor de evidencias |
| `reports-service` | `BLOB_BASE_URL` | URL base estable de los blobs |
| `reports-service` | `AZURE_STORAGE_AUTO_CREATE_CONTAINER` | Permite crear el contenedor automáticamente cuando corresponde |
| `digital-twin-service` | `GCS_BUCKET_NAME` | Bucket de Google Cloud Storage para el modelo del gemelo digital |
| `talks-service` | `QR_SIGNING_SECRET` | Clave exclusiva y aleatoria para firmar los códigos QR de asistencia. No debe reutilizar `JWT_SECRET` |
| `talks-service` | `QR_SIGNING_ALGORITHM` | Algoritmo de firma de los códigos QR (configuración actual: `HS256`) |
| `talks-service` | `QR_TTL_MINUTES` | Minutos durante los cuales un código QR de asistencia permanece válido; debe ser un entero mayor que cero |

> `areas-service` e `incidents-service` no requieren `.env` obligatorio para desarrollo
> local (traen valores por defecto en su código), pero en producción conviene definir al
> menos `JWT_SECRET`, `INTERNAL_API_KEY` y `SSO_FIRESTORE_PROJECT` explícitamente.

### Ejemplo de `.env` (`alerts-service`)

```env
JWT_SECRET=<generar-una-clave-larga-y-aleatoria>
INTERNAL_API_KEY=<generar-otra-clave>
GOOGLE_APPLICATION_CREDENTIALS=service-account.json
SSO_FIRESTORE_PROJECT=<project-id-de-firebase>
SSO_ENVIRONMENT=development
```

### Variables QR de `talks-service`

```env
QR_SIGNING_SECRET=<generar-una-clave-larga-aleatoria-y-distinta-de-jwt-secret>
QR_SIGNING_ALGORITHM=HS256
QR_TTL_MINUTES=15
```

`QR_SIGNING_SECRET` y `JWT_SECRET` deben ser diferentes para poder rotar o revocar la
firma de los QR sin invalidar las sesiones de autenticación. El valor real de la clave
QR nunca debe incluirse en el repositorio.

---

## Cómo correr un servicio individual

```bash
cd alerts-service
uv pip install --system -e .
uvicorn app.main:app --reload --port 8080
```

Repetir para cada servicio, usando un puerto distinto si se van a correr varios a la vez
en la misma máquina (ver la tabla de puertos en la sección de Docker Compose).

Para confirmar que quedó arriba, abrir en el navegador:
```
http://localhost:8080/docs
```

---

## Cómo correr todo junto con Docker Compose

El repositorio incluye un `docker-compose.yml` que levanta los 9 servicios en una sola
red local, resolviendo automáticamente las URLs internas entre servicios (no hace falta
tocar los `.env` para eso).

**Antes de correrlo:**
1. Cada carpeta de servicio debe tener su `.env` (aunque sea vacío: `touch areas-service/.env`)
2. Cada carpeta debe tener su `service-account.json`

**Levantar todo:**
```bash
docker compose up --build
```

**Ver logs de un servicio puntual:**
```bash
docker compose logs -f auth-service
```

**Apagar todo:**
```bash
docker compose down
```

### Puertos asignados (host → contenedor interno 8080)

| Servicio | Puerto local |
|---|---|
| `auth-service` | 8081 |
| `users-service` | 8082 |
| `workers-service` | 8083 |
| `reports-service` | 8084 |
| `alerts-service` | 8085 |
| `areas-service` | 8086 |
| `incidents-service` | 8087 |
| `dashboard-service` | 8088 |
| `digital-twin-service` | 8089 |

---

## Estructura interna de cada microservicio

Todos siguen el mismo patrón (arquitectura en capas):

```
<servicio>/
└── app/
    ├── main.py          → crea la instancia de FastAPI e incluye los routers
    ├── config.py        → carga variables de entorno (Settings)
    ├── dependencies.py  → dependencias inyectables (ej. usuario autenticado desde el JWT)
    ├── routers/         → define los endpoints HTTP (capa de presentación)
    ├── services/        → lógica de negocio
    ├── repositories/     → acceso a Firestore (capa de datos)
    └── schemas/          → modelos Pydantic de entrada/salida
```

---

## Despliegue en Render

Cada uno de los 9 servicios se despliega como un **Web Service** independiente:

1. En [Render Dashboard](https://dashboard.render.com) → **New → Web Service**.
2. Conectar el repositorio (Render detecta el `Dockerfile` automáticamente).
3. Cargar las variables de entorno de la sección anterior.
4. Para `GOOGLE_APPLICATION_CREDENTIALS`: usar **Secret Files** de Render para subir el
   `service-account.json` a `/etc/secrets/service-account.json`, y apuntar la variable a
   esa ruta en vez de subir el archivo al repo.
5. Una vez desplegado, Render entrega una URL pública (`https://<servicio>-xxxx.onrender.com`).
   Anotar las 9 URLs — las necesitan el dashboard web y la app móvil.
6. Actualizar `USERS_SERVICE_URL` y `ALERTS_SERVICE_URL` con las URLs públicas reales de
   Render (no `localhost`) en los servicios que las usan.

---

## Documentación automática (Swagger)

FastAPI genera documentación interactiva automáticamente para cada servicio, disponible en:

```
http://localhost:<puerto>/docs        (desarrollo local)
https://<servicio>-xxxx.onrender.com/docs   (producción)
```

Ahí se puede probar cada endpoint directamente desde el navegador, sin necesidad de
Postman u otra herramienta externa.

---

## Asistencia QR y pruebas reproducibles

La arquitectura, las reglas de seguridad, el comportamiento de expiración y las
limitaciones actuales del flujo QR están documentadas en
[`talks-service/README.md`](talks-service/README.md).

La suite de integración utiliza una MongoDB temporal y aislada. Se ejecuta desde esta
carpeta con:

```powershell
docker compose -p sso-qr-tests -f docker-compose.test.yml up --build --abort-on-container-exit --exit-code-from talks-service-test
```

Después de la ejecución, los contenedores temporales se eliminan con:

```powershell
docker compose -p sso-qr-tests -f docker-compose.test.yml down --volumes
```

La interfaz web disponible en `dashboard-service/static/` es un artefacto compilado cuyo
código fuente no se encuentra actualmente en el repositorio. Sus limitaciones y la deuda
técnica asociada están documentadas en
[`dashboard-service/README.md`](dashboard-service/README.md).

---

## Seguridad y buenas prácticas

- **Nunca** subir `.env` ni `service-account.json` al repositorio (ya cubierto por
  `.gitignore` en cada servicio).
- `JWT_SECRET` debe ser idéntico en todos los servicios; si difiere entre uno y otro, la
  validación de tokens falla de forma silenciosa entre microservicios.
- Los servicios que se llaman entre sí deben apuntar a la **URL pública de Render** del
  otro servicio en producción — nunca a `localhost`.
- Rotar `JWT_SECRET` e `INTERNAL_API_KEY` si alguna vez se filtran (por ejemplo, si se
  subieron por error a un commit antes de tener `.gitignore` configurado).
- Mantener `QR_SIGNING_SECRET` separado de `JWT_SECRET` y rotarlo si se expone. La
  rotación invalida los QR emitidos con la clave anterior, pero no las sesiones de los
  usuarios.

---

## Problemas comunes

| Síntoma | Causa | Solución |
|---|---|---|
| `Error loading ASGI app. Could not import module "app.main"` | El `main.py` del servicio quedó fuera de la carpeta `app/` | Mover el archivo a `<servicio>/app/main.py` |
| Error de autenticación entre microservicios | `JWT_SECRET` distinto entre servicios | Verificar que todos los `.env` usen exactamente la misma clave |
| `reports-service` no logra disparar alertas automáticas de IAP | `ALERTS_SERVICE_URL` mal configurada o apuntando a `localhost` en producción | Actualizar con la URL pública real de Render |
| Contenedor no encuentra `service-account.json` al correr con Docker | El archivo no se copia en el build; Docker Compose lo monta como volumen | Confirmar que el archivo existe en la carpeta del servicio antes de `docker compose up` |
| Servicio suspendido por inactividad en Render | Plan gratuito de Render duerme servicios sin tráfico | Configurar un cron job de "keep-alive" que haga ping periódico a cada servicio |

---

*Repositorio del backend del proyecto GPI / Vigía Industrial, desarrollado para Alloxentric.*
