
import {
    authRequest,
    clearAuthTokens,
    getRefreshToken,
    getToken,
    setAuthTokens,
} from './client';

export interface SessionUser {
    user_id: string;
    role: string;
    client_id: string;
    area?: string;
    assigned_areas?: string[];
    assigned_zones?: string[];
}

export interface LoginCredentials {
    client_id: string;
    email: string;
    password: string;
}

interface LoginResponse {
    access_token: string;
    refresh_token: string;
    token_type: string;
    user_id: string;
    role: string;
    areas?: string[];
    area?: string;
}

export interface AuthMeResponse {
    user_id: string;
    client_id: string;
    role: string;
    areas?: string[];
    area?: string;
}

export interface AuthSession {
    token: string;
    user: SessionUser;
}

const WEB_ROLES = new Set([
    'admin',
    'supervisor',
    'jefe de area',
    'sso_manager',
]);

export function normalizeWebRole(role: string): string {
    const normalized = role
        .trim()
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/[_-]+/g, ' ')
        .replace(/\s+/g, ' ');

    return normalized === 'sso manager'
        ? 'sso_manager'
        : normalized;
}

export function isWebRole(role: string): boolean {
    return WEB_ROLES.has(normalizeWebRole(role));
}

function buildSessionUser(
    me: AuthMeResponse,
): SessionUser {
    if (!me.user_id || !me.client_id || !me.role) {
        throw new Error(
            'El backend devolvió una identidad incompleta.',
        );
    }

    const role = normalizeWebRole(me.role);

    if (!isWebRole(role)) {
        throw new Error(
            'Tu rol no está autorizado para acceder a WebSSO.',
        );
    }

    const areas = me.areas ?? [];

    return {
        user_id: me.user_id,
        client_id: me.client_id,
        role,
        area: me.area ?? areas[0],
        assigned_areas: areas,
        assigned_zones: [],
    };
}

export async function getMe(): Promise<AuthMeResponse> {
    return authRequest<AuthMeResponse>('/v1/auth/me');
}

export async function signIn(
    credentials: LoginCredentials,
): Promise<AuthSession> {
    const clientId = credentials.client_id.trim();
    const email = credentials.email.trim();

    if (!clientId) {
        throw new Error('Debes indicar la organización.');
    }

    if (!email || !credentials.password) {
        throw new Error(
            'Debes ingresar correo y contraseña.',
        );
    }

    const response = await authRequest<LoginResponse>(
        '/v1/auth/login',
        {
            method: 'POST',
            auth: false,
            body: JSON.stringify({
                client_id: clientId,
                email,
                password: credentials.password,
            }),
        },
    );

    if (!response.access_token || !response.refresh_token) {
        throw new Error(
            'Auth no devolvió los tokens necesarios.',
        );
    }

    setAuthTokens(
        response.access_token,
        response.refresh_token,
    );

    try {
        const me = await getMe();

        const user = buildSessionUser(me);
        const token = getToken();

        if (!token) {
            throw new Error('No se pudo establecer la sesión.');
        }

        return { token, user };
    } catch (error) {
        clearSession();
        throw error;
    }
}

export async function restoreSession():
    Promise<AuthSession | null> {
    if (!getToken() && !getRefreshToken()) {
        return null;
    }

    const me = await getMe();
    const user = buildSessionUser(me);
    const token = getToken();

    if (!token) {
        return null;
    }

    return { token, user };
}

export function clearSession(): void {
    clearAuthTokens();

    // Limpieza de la versión web anterior.
    localStorage.removeItem('sso_user');
}
