// Barrel de la capa API — importa todo desde aquí
export * from './client';
export * from './auth';
export * from './reports';
export * from './incidents';
