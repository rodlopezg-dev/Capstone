import {
  Capacitor,
} from '@capacitor/core';

import {
  Network,
} from '@capacitor/network';

function browserNetworkStatus(): boolean {
  if (
    typeof navigator === 'undefined'
  ) {
    return true;
  }

  return navigator.onLine;
}

export async function getNetworkConnected():
Promise<boolean> {
  if (!Capacitor.isNativePlatform()) {
    return browserNetworkStatus();
  }

  try {
    const status =
      await Network.getStatus();

    return status.connected;
  } catch {
    return browserNetworkStatus();
  }
}

export function subscribeNetworkStatus(
  callback: (
    connected: boolean,
  ) => void,
): () => void {
  let disposed = false;
  let nativeHandle:
    { remove: () => Promise<void> }
    | null = null;

  const handleOnline = () => {
    if (!disposed) {
      callback(true);
    }
  };

  const handleOffline = () => {
    if (!disposed) {
      callback(false);
    }
  };

  if (
    typeof window !== 'undefined'
  ) {
    window.addEventListener(
      'online',
      handleOnline,
    );

    window.addEventListener(
      'offline',
      handleOffline,
    );
  }

  if (Capacitor.isNativePlatform()) {
    void Network.addListener(
      'networkStatusChange',
      status => {
        if (!disposed) {
          callback(status.connected);
        }
      },
    )
      .then(handle => {
        if (disposed) {
          void handle.remove();
          return;
        }

        nativeHandle = handle;
      })
      .catch(error => {
        console.warn(
          '[Network] No se pudo registrar listener nativo:',
          error,
        );
      });
  }

  return () => {
    disposed = true;

    if (
      typeof window !== 'undefined'
    ) {
      window.removeEventListener(
        'online',
        handleOnline,
      );

      window.removeEventListener(
        'offline',
        handleOffline,
      );
    }

    if (nativeHandle) {
      void nativeHandle.remove();
    }
  };
}
