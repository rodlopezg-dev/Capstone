import asyncio
import os

from datetime import datetime, timedelta, timezone
from uuid import uuid4

from azure.core.exceptions import ResourceExistsError
from azure.storage.blob import (
    BlobSasPermissions,
    BlobServiceClient,
    ContentSettings,
    generate_blob_sas,
)


AZURE_CONN_STR = os.getenv(
    "AZURE_STORAGE_CONNECTION_STRING",
    "",
)

AZURE_CONTAINER = os.getenv(
    "AZURE_STORAGE_CONTAINER",
    "sso-report-evidence",
)

BLOB_BASE_URL = os.getenv(
    "BLOB_BASE_URL",
    (
        "https://ssoevidencias.blob.core.windows.net/"
        f"{AZURE_CONTAINER}"
    ),
).rstrip("/")

AZURE_STORAGE_AUTO_CREATE_CONTAINER = (
    os.getenv(
        "AZURE_STORAGE_AUTO_CREATE_CONTAINER",
        "false",
    )
    .strip()
    .lower()
    == "true"
)

AZURE_STORAGE_READ_SAS_TTL_MINUTES = os.getenv(
    "AZURE_STORAGE_READ_SAS_TTL_MINUTES",
    "10",
)


def _connection_string_value(name: str) -> str:
    expected = name.strip().lower()

    for part in AZURE_CONN_STR.split(";"):
        if "=" not in part:
            continue

        key, value = part.split("=", 1)

        if key.strip().lower() == expected:
            return value.strip()

    return ""


def _read_sas_ttl_minutes() -> int:
    try:
        ttl = int(
            AZURE_STORAGE_READ_SAS_TTL_MINUTES
        )
    except (TypeError, ValueError):
        return 10

    return max(1, ttl)


def _sync_upload(
    file_bytes: bytes,
    blob_name: str,
    content_type: str = "image/jpeg",
) -> str:
    blob_service = (
        BlobServiceClient.from_connection_string(
            AZURE_CONN_STR
        )
    )

    container_client = (
        blob_service.get_container_client(
            AZURE_CONTAINER
        )
    )

    if AZURE_STORAGE_AUTO_CREATE_CONTAINER:
        try:
            # Sin public_access:
            # el contenedor se crea privado.
            container_client.create_container()
        except ResourceExistsError:
            pass

    blob_client = container_client.get_blob_client(
        blob_name
    )

    blob_client.upload_blob(
        file_bytes,
        overwrite=True,
        content_settings=ContentSettings(
            content_type=content_type
        ),
    )

    # Esta referencia es estable y puede persistirse.
    # No contiene credenciales ni SAS.
    return f"{BLOB_BASE_URL}/{blob_name}"


def generate_read_url(
    reference: str,
    client_id: str,
    report_id: str,
) -> str:
    """
    Genera una URL SAS temporal sólo para evidencias nuevas
    pertenecientes al contenedor privado de Reports.

    Referencias históricas con otro BLOB_BASE_URL se mantienen
    intactas para conservar compatibilidad.
    """
    if not reference:
        return reference

    base_url = BLOB_BASE_URL.rstrip("/")

    expected_prefix = (
        f"{base_url}/reports/"
        f"{client_id}/{report_id}/"
    )

    # Compatibilidad histórica y defensa multitenant.
    if not reference.startswith(expected_prefix):
        return reference

    account_name = _connection_string_value(
        "AccountName"
    )
    account_key = _connection_string_value(
        "AccountKey"
    )

    if not account_name or not account_key:
        raise RuntimeError(
            "No fue posible generar acceso temporal "
            "a la evidencia de Reports"
        )

    stable_reference = reference.split("?", 1)[0]

    blob_name = stable_reference[
        len(base_url) + 1:
    ]

    now = datetime.now(timezone.utc)

    sas = generate_blob_sas(
        account_name=account_name,
        container_name=AZURE_CONTAINER,
        blob_name=blob_name,
        account_key=account_key,
        permission=BlobSasPermissions(read=True),
        start=now - timedelta(minutes=1),
        expiry=(
            now
            + timedelta(
                minutes=_read_sas_ttl_minutes()
            )
        ),
    )

    return f"{stable_reference}?{sas}"


def sign_report_evidence_urls(
    report: dict,
) -> dict:
    """
    Crea una copia del reporte preparada para respuesta HTTP.

    Mongo conserva referencias estables; sólo la copia de salida
    recibe URLs SAS temporales.
    """
    if not isinstance(report, dict):
        return report

    result = dict(report)

    client_id = str(
        result.get("client_id") or ""
    )
    report_id = str(
        result.get("report_id") or ""
    )

    if not client_id or not report_id:
        return result

    image_url = result.get("image_url")

    if isinstance(image_url, str):
        result["image_url"] = generate_read_url(
            image_url,
            client_id,
            report_id,
        )

    evidences = result.get("evidences")

    if isinstance(evidences, list):
        result["evidences"] = [
            generate_read_url(
                evidence,
                client_id,
                report_id,
            )
            if isinstance(evidence, str)
            else evidence
            for evidence in evidences
        ]

    closure_evidence = result.get(
        "closure_evidence"
    )

    if isinstance(closure_evidence, dict):
        closure_copy = dict(closure_evidence)

        closure_url = closure_copy.get("url")

        if isinstance(closure_url, str):
            closure_copy["url"] = (
                generate_read_url(
                    closure_url,
                    client_id,
                    report_id,
                )
            )

        result["closure_evidence"] = (
            closure_copy
        )

    return result


async def upload_image(
    file_bytes: bytes,
    client_id: str,
    report_id: str,
) -> str:
    blob_name = (
        f"reports/{client_id}/"
        f"{report_id}/evidence.jpg"
    )

    try:
        url = await asyncio.to_thread(
            _sync_upload,
            file_bytes,
            blob_name,
            "image/jpeg",
        )

        print(
            "[INFO] Imagen subida a Azure Blob: "
            f"{url}"
        )

        return url
    except Exception as exc:
        print(
            "[ERROR] Fallo al subir a Azure Blob: "
            f"{exc}"
        )
        raise


async def upload_closure_evidence(
    file_bytes: bytes,
    client_id: str,
    report_id: str,
    content_type: str = "image/jpeg",
) -> str:
    """
    Sube evidencia de cierre tenant-scoped sin sobrescribir
    la evidencia original.
    """
    extension = {
        "image/jpeg": "jpg",
        "image/png": "png",
        "image/webp": "webp",
        "application/pdf": "pdf",
    }.get(
        content_type,
        "bin",
    )

    blob_name = (
        f"reports/{client_id}/{report_id}/"
        "closure-evidence/"
        f"{uuid4().hex}.{extension}"
    )

    try:
        url = await asyncio.to_thread(
            _sync_upload,
            file_bytes,
            blob_name,
            content_type,
        )

        print(
            "[INFO] Evidencia de cierre subida "
            f"a Azure Blob: {url}"
        )

        return url
    except Exception as exc:
        print(
            "[ERROR] Fallo al subir evidencia "
            f"de cierre: {exc}"
        )
        raise
