-- ============================================
-- SCRIPT SQL PARA CREAR TABLAS
-- Sistema SSO - Base de Datos
-- Compatible con PostgreSQL y MySQL
-- ============================================

-- TABLA: usuarios
-- Empleados (app móvil) y supervisores (web)
CREATE TABLE usuarios (
  id VARCHAR(36) PRIMARY KEY,
  nombre_completo VARCHAR(255) NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  rol VARCHAR(50) NOT NULL CHECK (rol IN ('empleado', 'supervisor', 'jefe_area', 'gerente_sso', 'analista')),

  -- Para empleados móviles
  turno VARCHAR(20) CHECK (turno IN ('manana', 'tarde', 'noche')),
  area_asignada VARCHAR(100),

  -- Estadísticas
  total_reportes INTEGER DEFAULT 0,
  reportes_mes_actual INTEGER DEFAULT 0,
  efectividad_porcentaje DECIMAL(5,2) DEFAULT 0,

  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

  INDEX idx_email (email),
  INDEX idx_rol (rol)
);

-- TABLA: zonas
-- Gemelo Digital - Áreas operativas de la planta
CREATE TABLE zonas (
  id VARCHAR(36) PRIMARY KEY,
  nombre VARCHAR(255) NOT NULL,
  proceso_asociado VARCHAR(255) NOT NULL,

  -- Geometría (almacenado como JSON)
  coordenadas JSON NOT NULL,

  -- Riesgo calculado
  score_riesgo DECIMAL(5,2) DEFAULT 0 CHECK (score_riesgo >= 0 AND score_riesgo <= 100),
  nivel_riesgo VARCHAR(20) CHECK (nivel_riesgo IN ('bajo', 'medio', 'alto')),

  -- Metadata
  color_identificacion VARCHAR(7),
  plano_base_url TEXT,

  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

  INDEX idx_nivel_riesgo (nivel_riesgo),
  INDEX idx_score_riesgo (score_riesgo)
);

-- TABLA: reportes
-- Hallazgos reportados desde la app móvil
CREATE TABLE reportes (
  id VARCHAR(36) PRIMARY KEY,
  fecha TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  -- Ubicación
  area VARCHAR(100) NOT NULL,
  linea VARCHAR(100),
  proceso VARCHAR(100),

  -- Clasificación
  tipo VARCHAR(50) NOT NULL CHECK (tipo IN ('acto_inseguro', 'condicion_insegura')),
  es_iap BOOLEAN DEFAULT FALSE,

  -- Contenido
  descripcion TEXT NOT NULL,
  evidencia_foto_url TEXT NOT NULL,
  evidencia_video_url TEXT,

  -- Reportador (desde app móvil)
  reportador_id VARCHAR(36) NOT NULL,
  reportador_nombre VARCHAR(255) NOT NULL,
  reportador_turno VARCHAR(20) CHECK (reportador_turno IN ('manana', 'tarde', 'noche')),
  reportador_area_asignada VARCHAR(100),

  -- Gestión (desde plataforma web)
  estado VARCHAR(50) NOT NULL DEFAULT 'enviado' CHECK (estado IN ('enviado', 'en_revision', 'accion_asignada', 'cerrado', 'vencido')),
  responsable_asignado VARCHAR(255),
  feedback_supervisor TEXT,
  fecha_revision TIMESTAMP,
  fecha_asignacion TIMESTAMP,
  fecha_cierre TIMESTAMP,

  -- SLA
  tiempo_sin_remediacion_horas INTEGER,
  sla_vencido BOOLEAN DEFAULT FALSE,

  -- Metadata
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

  FOREIGN KEY (reportador_id) REFERENCES usuarios(id),

  INDEX idx_fecha (fecha),
  INDEX idx_area (area),
  INDEX idx_estado (estado),
  INDEX idx_es_iap (es_iap),
  INDEX idx_reportador (reportador_id),
  INDEX idx_sla_vencido (sla_vencido)
);

-- TABLA: alertas
-- Notificaciones automáticas y manuales
CREATE TABLE alertas (
  id VARCHAR(36) PRIMARY KEY,
  tipo VARCHAR(20) NOT NULL CHECK (tipo IN ('iap', 'sla', 'zona', 'auto')),

  -- Contenido
  titulo VARCHAR(255) NOT NULL,
  descripcion TEXT NOT NULL,
  area_afectada VARCHAR(100) NOT NULL,

  -- Estado
  activa BOOLEAN DEFAULT TRUE,
  resuelta BOOLEAN DEFAULT FALSE,
  fecha_resolucion TIMESTAMP,

  -- Relaciones
  reporte_id VARCHAR(36),
  zona_id VARCHAR(36),

  -- Metadata
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

  FOREIGN KEY (reporte_id) REFERENCES reportes(id),
  FOREIGN KEY (zona_id) REFERENCES zonas(id),

  INDEX idx_tipo (tipo),
  INDEX idx_activa (activa),
  INDEX idx_area_afectada (area_afectada)
);

-- TABLA: notificaciones
-- Notificaciones push para usuarios
CREATE TABLE notificaciones (
  id VARCHAR(36) PRIMARY KEY,
  tipo VARCHAR(50) NOT NULL CHECK (tipo IN ('alerta', 'actualizacion', 'comentario', 'resuelto')),

  titulo VARCHAR(255) NOT NULL,
  mensaje TEXT NOT NULL,

  -- Destinatario
  usuario_id VARCHAR(36) NOT NULL,
  leida BOOLEAN DEFAULT FALSE,

  -- Relaciones
  reporte_id VARCHAR(36),
  alerta_id VARCHAR(36),

  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

  FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
  FOREIGN KEY (reporte_id) REFERENCES reportes(id),
  FOREIGN KEY (alerta_id) REFERENCES alertas(id),

  INDEX idx_usuario (usuario_id),
  INDEX idx_leida (leida),
  INDEX idx_created_at (created_at)
);

-- ============================================
-- TRIGGERS Y FUNCIONES
-- ============================================

-- Trigger: Actualizar updated_at automáticamente
-- (PostgreSQL)
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
   NEW.updated_at = CURRENT_TIMESTAMP;
   RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_usuarios_updated_at BEFORE UPDATE ON usuarios
FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_zonas_updated_at BEFORE UPDATE ON zonas
FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_reportes_updated_at BEFORE UPDATE ON reportes
FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_alertas_updated_at BEFORE UPDATE ON alertas
FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- VISTAS ÚTILES
-- ============================================

-- Vista: Reportes con información del reportador
CREATE VIEW v_reportes_completos AS
SELECT
  r.*,
  u.email as reportador_email,
  u.rol as reportador_rol
FROM reportes r
LEFT JOIN usuarios u ON r.reportador_id = u.id;

-- Vista: Estadísticas por área
CREATE VIEW v_estadisticas_areas AS
SELECT
  area,
  COUNT(*) as total_incidentes,
  SUM(CASE WHEN estado IN ('enviado', 'en_revision', 'accion_asignada') THEN 1 ELSE 0 END) as incidentes_abiertos,
  SUM(CASE WHEN es_iap = TRUE THEN 1 ELSE 0 END) as total_iap,
  AVG(tiempo_sin_remediacion_horas) as promedio_tiempo_resolucion
FROM reportes
GROUP BY area;

-- Vista: Alertas activas por tipo
CREATE VIEW v_alertas_activas AS
SELECT
  tipo,
  COUNT(*) as total,
  COUNT(CASE WHEN resuelta = FALSE THEN 1 END) as pendientes
FROM alertas
WHERE activa = TRUE
GROUP BY tipo;

-- ============================================
-- DATOS INICIALES (SEED)
-- ============================================

-- Usuario admin por defecto
INSERT INTO usuarios (id, nombre_completo, email, password_hash, rol, created_at, updated_at)
VALUES (
  'admin-001',
  'Administrador Sistema',
  'admin@sso-sistema.com',
  -- Contraseña: admin123 (debes usar bcrypt en producción)
  '$2a$10$example.hash.placeholder',
  'gerente_sso',
  CURRENT_TIMESTAMP,
  CURRENT_TIMESTAMP
);

-- Áreas ejemplo
INSERT INTO zonas (id, nombre, proceso_asociado, coordenadas, score_riesgo, nivel_riesgo, created_at, updated_at)
VALUES
  ('zona-001', 'Línea de Producción 1', 'Ensamblaje', '[]', 0, 'bajo', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('zona-002', 'Almacén de Químicos', 'Almacenamiento', '[]', 0, 'bajo', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('zona-003', 'Área de Empaque', 'Empaque', '[]', 0, 'bajo', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);

-- ============================================
-- ÍNDICES ADICIONALES PARA PERFORMANCE
-- ============================================

-- Búsquedas por rango de fechas
CREATE INDEX idx_reportes_fecha_estado ON reportes(fecha, estado);

-- Consultas de dashboard
CREATE INDEX idx_reportes_area_fecha ON reportes(area, fecha DESC);

-- Notificaciones no leídas por usuario
CREATE INDEX idx_notificaciones_usuario_leida ON notificaciones(usuario_id, leida, created_at DESC);

-- ============================================
-- COMENTARIOS EN TABLAS
-- ============================================

COMMENT ON TABLE reportes IS 'Hallazgos de seguridad reportados desde la app móvil';
COMMENT ON TABLE zonas IS 'Áreas operativas configuradas en el Gemelo Digital';
COMMENT ON TABLE alertas IS 'Alertas automáticas y manuales del sistema';
COMMENT ON TABLE notificaciones IS 'Notificaciones push para usuarios';
COMMENT ON TABLE usuarios IS 'Empleados y supervisores del sistema';

COMMENT ON COLUMN reportes.es_iap IS 'Incidente de Alto Potencial (requiere atención inmediata)';
COMMENT ON COLUMN reportes.sla_vencido IS 'Indica si el tiempo de resolución superó el SLA';
COMMENT ON COLUMN zonas.score_riesgo IS 'Score de 0-100 calculado por cantidad y severidad de incidentes';
