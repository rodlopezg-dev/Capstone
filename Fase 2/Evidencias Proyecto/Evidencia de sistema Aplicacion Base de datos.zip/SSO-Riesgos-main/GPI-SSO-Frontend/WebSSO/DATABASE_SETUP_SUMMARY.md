# 📋 Resumen de Configuración de Base de Datos - Sistema SSO

## ✅ Lo que se ha agregado al código

He agregado toda la infraestructura necesaria para conectar tu plataforma web con una base de datos que sincroniza datos con la aplicación móvil.

---

## 📁 Archivos Creados

### 1. `/src/database/types.ts`
**Qué es:** Definiciones TypeScript de todos los modelos de datos.

**Contiene:**
- ✅ Tipo `Reporte` (hallazgos desde app móvil)
- ✅ Tipo `Zona` (áreas del gemelo digital)
- ✅ Tipo `Alerta` (notificaciones)
- ✅ Tipo `Usuario` (empleados y supervisores)
- ✅ Tipo `Notificacion` (push notifications)
- ✅ Tipos de estadísticas y KPIs

**Para qué sirve:** Define la estructura exacta de los datos que se sincronizan entre la app y la web.

---

### 2. `/src/database/config.ts`
**Qué es:** Configuración de conexión a base de datos.

**Soporta:**
- ✅ Supabase (recomendado - fácil)
- ✅ PostgreSQL
- ✅ MySQL
- ✅ MongoDB
- ✅ Firebase
- ✅ API REST personalizada

**Para qué sirve:** Define cómo conectarse a tu base de datos. Solo necesitas descomentar la sección que uses.

---

### 3. `/src/database/api.ts`
**Qué es:** Servicios para comunicarse con la base de datos.

**Contiene endpoints para:**
- ✅ `reportesAPI` - Crear, leer, actualizar reportes
- ✅ `zonasAPI` - Gestionar zonas del gemelo digital
- ✅ `alertasAPI` - Crear y resolver alertas
- ✅ `notificacionesAPI` - Gestionar notificaciones
- ✅ `estadisticasAPI` - Obtener KPIs y tendencias
- ✅ `usuariosAPI` - Login y perfiles
- ✅ `exportacionAPI` - Generar reportes PDF/Excel/CSV

**Para qué sirve:** Son las funciones que usas en tus componentes React para obtener o enviar datos.

---

### 4. `/src/database/schema.sql`
**Qué es:** Script SQL para crear todas las tablas en la base de datos.

**Crea las siguientes tablas:**
- ✅ `usuarios` (empleados y supervisores)
- ✅ `reportes` (hallazgos de seguridad)
- ✅ `zonas` (áreas operativas)
- ✅ `alertas` (notificaciones del sistema)
- ✅ `notificaciones` (push para usuarios)

**Incluye:**
- ✅ Índices para performance
- ✅ Vistas útiles
- ✅ Triggers automáticos
- ✅ Datos iniciales (usuario admin)

**Para qué sirve:** Ejecuta este archivo en tu base de datos (PostgreSQL/MySQL) para crear todas las tablas.

---

### 5. `/src/database/mock-data.ts`
**Qué es:** Datos de prueba para desarrollo.

**Contiene:**
- ✅ 3 usuarios ejemplo
- ✅ 4 reportes ejemplo
- ✅ 4 zonas ejemplo
- ✅ 3 alertas ejemplo
- ✅ Estadísticas ejemplo

**Para qué sirve:** Úsalo mientras configuras tu base de datos real. Así puedes probar la UI sin backend.

---

### 6. `/src/database/README.md`
**Qué es:** Documentación completa de configuración.

**Explica:**
- ✅ Cómo conectar cada tipo de base de datos
- ✅ Qué variables de entorno necesitas
- ✅ Estructura de las tablas
- ✅ Flujo de sincronización App ↔ Web
- ✅ Endpoints requeridos
- ✅ Checklist de implementación

---

### 7. `/src/database/INTEGRATION_GUIDE.md`
**Qué es:** Guía práctica de cómo usar los servicios en tus componentes React.

**Incluye ejemplos de:**
- ✅ Cómo cargar datos en Command Center (W-01)
- ✅ Cómo actualizar reportes en Gestión de Incidentes (W-02)
- ✅ Cómo crear zonas en Gemelo Digital (W-03)
- ✅ Cómo generar alertas en Centro de Alertas (W-04)
- ✅ Cómo exportar reportes (W-05)
- ✅ Custom hooks reutilizables

---

### 8. `/src/database/ARCHITECTURE.md`
**Qué es:** Documentación de arquitectura del sistema.

**Incluye:**
- ✅ Diagrama de flujo de datos
- ✅ Arquitectura de capas
- ✅ Modelo de datos relacional
- ✅ Flujo de sincronización detallado
- ✅ Seguridad y autenticación
- ✅ Recomendaciones de escalabilidad

---

### 9. `/.env.example`
**Qué es:** Plantilla de archivo de variables de entorno.

**Incluye placeholders para:**
- ✅ Credenciales de Supabase
- ✅ Credenciales de PostgreSQL
- ✅ Credenciales de MongoDB
- ✅ Credenciales de Firebase
- ✅ URL de API REST
- ✅ Configuración de storage (S3/Cloudinary)
- ✅ Secret de JWT

**Para qué sirve:** Copia este archivo a `.env` y completa tus credenciales reales.

---

### 10. `/.gitignore`
**Qué es:** Configuración de Git para ignorar archivos sensibles.

**Ignora:**
- ✅ `.env` (nunca subir credenciales a GitHub)
- ✅ `node_modules`
- ✅ Archivos de base de datos local

---

## 🎯 Datos que se Sincronizan (según los manuales)

### Desde App Móvil → Base de Datos:
1. **Reportes de Hallazgos**
   - Foto de evidencia ✅
   - Ubicación (Área/Línea/Proceso) ✅
   - Tipo (Acto/Condición Insegura) ✅
   - Es IAP (sí/no) ✅
   - Descripción ✅
   - Datos del reportador ✅

### Desde Base de Datos → Plataforma Web:
1. **Lista de Reportes** (W-02)
   - Todos los hallazgos reportados ✅
   - Filtros por estado, área, IAP ✅
   - Información del reportador ✅

2. **Mapa de Calor** (W-01)
   - Zonas configuradas ✅
   - Score de riesgo por zona ✅
   - Colores según nivel de riesgo ✅

3. **Alertas** (W-04)
   - Alertas de IAP ✅
   - Alertas de SLA vencido ✅
   - Alertas de zonas críticas ✅

4. **Estadísticas** (W-01)
   - Total de reportes ✅
   - IAP activos ✅
   - Ranking de áreas críticas ✅
   - Tendencia de riesgo ✅

### Desde Plataforma Web → Base de Datos:
1. **Actualización de Reportes** (W-02)
   - Cambio de estado ✅
   - Asignación de responsable ✅
   - Feedback del supervisor ✅

2. **Configuración de Zonas** (W-03)
   - Subir plano de planta ✅
   - Dibujar polígonos de zonas ✅
   - Nombrar zonas ✅

3. **Creación de Alertas Manuales** (W-02)
   - Generar alerta para área ✅

---

## 🚀 Próximos Pasos para Ti

### 1. Elegir Base de Datos
Decide cuál usar:
- **Supabase** (recomendado) - Fácil, incluye storage, auth y real-time
- **PostgreSQL** - Potente, requiere servidor
- **MongoDB** - NoSQL, flexible
- **Firebase** - Real-time nativo
- **API REST propia** - Si ya tienes backend

### 2. Configurar Credenciales
```bash
# Copia el archivo de ejemplo
cp .env.example .env

# Edita .env y agrega tus credenciales
```

### 3. Crear Tablas en Base de Datos
```bash
# Si usas PostgreSQL/MySQL:
psql -U postgres -d sso_database -f src/database/schema.sql

# Si usas Supabase:
# Copia el contenido de schema.sql al SQL Editor en Supabase
```

### 4. Instalar Dependencias
```bash
# Para Supabase:
npm install @supabase/supabase-js

# Para PostgreSQL:
npm install pg

# Para MongoDB:
npm install mongodb

# Para Firebase:
npm install firebase
```

### 5. Descomentar Conector
En `src/database/config.ts`, descomenta la sección de tu base de datos.

### 6. Probar con Datos Mock
Mientras configuras el backend, puedes usar los datos mock:
```typescript
import { reportesMock } from '@/database/mock-data';
```

### 7. Implementar Endpoints en Backend
Crea los endpoints listados en `README.md` sección "Endpoints Requeridos".

### 8. Integrar en Componentes
Usa los ejemplos de `INTEGRATION_GUIDE.md` para conectar tus componentes.

---

## 📖 Documentación de Referencia

| Archivo | Para Qué Leerlo |
|---------|-----------------|
| `README.md` | Configuración inicial y setup |
| `INTEGRATION_GUIDE.md` | Cómo usar en componentes React |
| `ARCHITECTURE.md` | Entender el sistema completo |
| `schema.sql` | Estructura de las tablas |
| `types.ts` | Qué datos maneja el sistema |

---

## ✅ Checklist de Implementación

- [ ] 1. Crear archivo `.env` con credenciales
- [ ] 2. Instalar dependencia de base de datos
- [ ] 3. Ejecutar `schema.sql` para crear tablas
- [ ] 4. Descomentar conector en `config.ts`
- [ ] 5. Implementar endpoints en backend
- [ ] 6. Configurar storage para imágenes
- [ ] 7. Probar POST `/api/reportes/crear` desde app móvil
- [ ] 8. Probar GET `/api/reportes` desde web
- [ ] 9. Probar actualización de reporte desde web
- [ ] 10. Verificar notificaciones funcionan

---

## 🆘 Si Necesitas Ayuda

1. **Lee primero:** `/src/database/README.md`
2. **Ejemplos de código:** `/src/database/INTEGRATION_GUIDE.md`
3. **Arquitectura:** `/src/database/ARCHITECTURE.md`

---

## 💡 Resumen en 3 Pasos

1. **Configura tu base de datos**
   - Crea cuenta en Supabase (o instala PostgreSQL)
   - Ejecuta `schema.sql` para crear tablas
   - Completa archivo `.env` con credenciales

2. **Conecta el código**
   - Descomenta conector en `config.ts`
   - Instala dependencia (`@supabase/supabase-js` o `pg`)

3. **Usa en componentes**
   - Importa servicios: `import { reportesAPI } from '@/database/api'`
   - Llama funciones: `await reportesAPI.getAll()`
   - Sigue ejemplos en `INTEGRATION_GUIDE.md`

---

**¡Listo!** Toda la infraestructura de base de datos está preparada. Solo falta que conectes con tu base de datos real siguiendo las instrucciones en `/src/database/README.md`.
