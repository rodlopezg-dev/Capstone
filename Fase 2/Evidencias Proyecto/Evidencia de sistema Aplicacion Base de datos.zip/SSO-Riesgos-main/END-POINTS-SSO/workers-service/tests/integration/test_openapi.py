import pytest
from fastapi.testclient import TestClient

from app.main import app


@pytest.fixture
def client():
    """Fixture que provee el TestClient de FastAPI."""
    return TestClient(app)


def test_openapi_schema_generation(client: TestClient):
    """
    ST-129: Valida que el esquema OpenAPI se genere sin excepciones (PydanticUserError, etc.)
    y que contenga las rutas principales de Workers Service.
    """
    # 1. Consultar el endpoint de OpenAPI
    response = client.get("/openapi.json")

    # 2. Verificar que responda 200 OK
    assert response.status_code == 200, f"Error al obtener openapi.json: {response.text}"

    # 3. Parsear el esquema JSON
    schema = response.json()

    # 4. Validar estructura básica de OpenAPI
    assert "openapi" in schema
    assert "paths" in schema

    paths = schema["paths"]

    # 5. Verificar la presencia de los endpoints principales de Workers Service
    expected_endpoints = [
        "/v1/workers/me/stats",
        "/v1/workers/me/notifications",
        "/v1/workers/me/notifications/{notification_id}/read",
    ]

    for endpoint in expected_endpoints:
        assert endpoint in paths, f"El endpoint {endpoint} no fue encontrado en el esquema OpenAPI"