import os
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .dep_talks import get_db
from .repositories.rep_talks import TalksRepository
from .routers.rt_talks import router
from .routers.rt_attendance_ai import (
    router as attendance_ai_router
)

DEFAULT_CORS_ORIGINS = (
    "https://" "sso-dashboard.alloxentric.com",
    "https://" "sso-app.alloxentric.com",
    "http://" "localhost:5173",
    "http://" "localhost:5174",
    "http://" "localhost",
    "https://" "localhost",
    "capacitor://localhost",
)


def get_cors_origins():
    configured = os.getenv("CORS_ORIGINS", "")
    origins = tuple(
        origin.strip()
        for origin in configured.split(",")
        if origin.strip()
    )
    return origins or DEFAULT_CORS_ORIGINS


@asynccontextmanager
async def lifespan(_app: FastAPI):
    repository = TalksRepository(get_db())
    await repository.ensure_indexes()
    yield


app = FastAPI(title="Talks Service", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=get_cors_origins(),
    allow_credentials=True,
    allow_origin_regex=os.getenv("CORS_ORIGIN_REGEX") or None,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.include_router(router)
app.include_router(attendance_ai_router)
@app.get("/")
async def root():
    return {"status": "ok"}

@app.get("/health")
async def health():
    return {"status": "ok", "service": "talks-service"}