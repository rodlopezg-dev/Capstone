import {
  PROBABLE_CONSEQUENCE_OPTIONS,
} from '../utils/incidentProbableConsequences';

interface ProbableConsequenceFieldProps {
  value: string;
  onChange: (value: string) => void;
  disabled?: boolean;
}

export default function ProbableConsequenceField({
  value,
  onChange,
  disabled = false,
}: ProbableConsequenceFieldProps) {
  return (
    <div>
      <p className="text-sm font-medium mb-1">
        Consecuencia probable
      </p>

      <select
        aria-label="Consecuencia probable"
        value={value}
        disabled={disabled}
        onChange={event => onChange(event.target.value)}
        className="w-full rounded-xl px-4 py-3 text-sm"
        style={{
          background: '#0B2E36',
          border: '1px solid rgba(0,229,255,0.3)',
          color: 'white',
        }}
      >
        <option value="">
          Seleccionar consecuencia probable
        </option>

        {PROBABLE_CONSEQUENCE_OPTIONS.map(option => (
          <option
            key={option}
            value={option}
          >
            {option}
          </option>
        ))}
      </select>
    </div>
  );
}
