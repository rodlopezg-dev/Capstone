import { describe, expect, it } from 'vitest';
import { renderToStaticMarkup } from 'react-dom/server';

import ClosureEvidencePdfPicker, {
  formatEvidenceFileSize,
  isPdfEvidenceFile,
} from './ClosureEvidencePdfPicker';

describe('ClosureEvidencePdfPicker - SCRUM-84', () => {
  it('renders the PDF selection action', () => {
    const html = renderToStaticMarkup(
      <ClosureEvidencePdfPicker
        file={null}
        onChange={() => undefined}
      />
    );

    expect(html).toContain('Elegir PDF');
    expect(html).toContain(
      'accept="application/pdf,.pdf"'
    );
  });

  it('recognizes PDF by MIME type', () => {
    const file = new File(
      ['pdf'],
      'evidencia',
      { type: 'application/pdf' },
    );

    expect(isPdfEvidenceFile(file)).toBe(true);
  });

  it('recognizes PDF by extension', () => {
    const file = new File(
      ['pdf'],
      'EVIDENCIA.PDF',
      { type: '' },
    );

    expect(isPdfEvidenceFile(file)).toBe(true);
  });

  it('rejects non-PDF evidence', () => {
    const file = new File(
      ['image'],
      'evidencia.jpg',
      { type: 'image/jpeg' },
    );

    expect(isPdfEvidenceFile(file)).toBe(false);
  });

  it('renders selected PDF metadata', () => {
    const file = new File(
      [new Uint8Array(2048)],
      'cierre.pdf',
      { type: 'application/pdf' },
    );

    const html = renderToStaticMarkup(
      <ClosureEvidencePdfPicker
        file={file}
        onChange={() => undefined}
      />
    );

    expect(html).toContain(
      'PDF seleccionado: cierre.pdf'
    );
    expect(html).toContain('2.0 KB');
    expect(
      formatEvidenceFileSize(2048)
    ).toBe('2.0 KB');
  });
});
