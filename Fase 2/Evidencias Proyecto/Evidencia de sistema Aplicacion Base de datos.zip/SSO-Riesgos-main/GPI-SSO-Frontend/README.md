# GPI Frontend — Vigía Industrial

Monorepo con las dos interfaces del sistema GPI (Gestión de Prevención de Incidentes) desarrollado para Alloxentric: la aplicación móvil para trabajadores y el dashboard web para supervisores de seguridad industrial.

## Estructura del repositorio

```
GPI-Frontend/
├── APP-GPI-ALLOXENTRIC/    → App móvil (React + Capacitor → Android)
└── WebSSO/                 → Dashboard web (React + Vite)
```

Cada carpeta es un proyecto independiente, con su propio `package.json`, `.env` y ciclo de despliegue. Consulta el `README.md` de cada una para detalles específicos de esa parte.

## ¿Qué hace cada proyecto?

### 📱 `APP-GPI-ALLOXENTRIC` — App móvil (trabajadores)

Permite al trabajador de planta:
- Reportar actos y condiciones inseguras con evidencia fotográfica y geolocalización
- Registrar hallazgos por voz (push-to-talk)
- Ver en tiempo real el estado de sus reportes (enviado → en revisión → asignado → cerrado)
- Recibir alertas de zonas de riesgo activas
- Operar sin conexión, sincronizando automáticamente al recuperar internet

**Stack:** React, TypeScript, Capacitor (compilación a Android), Tailwind CSS.

### 💻 `WebSSO` — Dashboard web (supervisores)

Permite al encargado de seguridad industrial:
- Visualizar y gestionar los reportes recibidos desde la app móvil
- Administrar áreas de la planta y usuarios
- Emitir alertas manuales a los trabajadores
- Ver el centro de mando (Command Center) y el gemelo digital de la planta

**Stack:** React, TypeScript, Vite, Tailwind CSS.

## Backend

Ambos proyectos consumen los mismos 9 microservicios (FastAPI + Firestore), desplegados por separado en Render. El repositorio del backend y su documentación de despliegue no viven en este monorepo.

## Puesta en marcha rápida

### 1. Clonar y entrar al proyecto que necesites

```bash
git clone https://github.com/HAKAGOD/GPI-SSO-Alloxentric.git
cd GPI-SSO-Alloxentric/APP-GPI-ALLOXENTRIC   # o WebSSO
```

### 2. Instalar dependencias

```bash
npm install
```

### 3. Configurar variables de entorno

Cada proyecto necesita su propio `.env` en la raíz (no se versiona por seguridad). Como mínimo:

```env
VITE_CLIENT_ID=cliente_prueba_123
VITE_AUTH_SERVICE_URL=https://auth-service-xxxx.onrender.com
VITE_REPORTS_SERVICE_URL=https://reports-service-xxxx.onrender.com
VITE_ALERTS_SERVICE_URL=https://alerts-service-xxxx.onrender.com
# ...resto de URLs y configuración de microservicios
```

> Ver el Manual de Instalación del proyecto para el detalle completo de variables por servicio.

### 4. Correr en desarrollo

```bash
npm run dev
```

### 5. App móvil — compilar a Android

Solo aplica dentro de `APP-GPI-ALLOXENTRIC`:

```bash
npm run build
npx cap sync android
npx cap open android
```

Esto abre el proyecto en Android Studio para correr en un dispositivo/emulador o generar el APK firmado.

## Docker

Ambos proyectos incluyen `Dockerfile` para generar una imagen de producción (build estático servido con nginx). Ver `docker-compose.yml` en la documentación de instalación para levantar el ecosistema completo (backend + frontend) en un solo comando.

## Despliegue

| Proyecto | Plataforma | Disparador |
|---|---|---|
| `WebSSO` | [Vercel](https://vercel.com) | Automático en cada `push` a `main` |
| `APP-GPI-ALLOXENTRIC` | Compilación manual → APK/AAB | Vía Android Studio |

## Documentación relacionada

- 📘 Manual de instalación completo (backend + frontend + app móvil)
- 🔧 `docker-compose.yml` del backend (9 microservicios)

## Convenciones del repositorio

- Las variables de entorno (`.env`) y credenciales (`service-account.json`, keystores) **nunca** se versionan — ver `.gitignore` de cada subproyecto.
- Cada subproyecto mantiene su propio `package-lock.json` / `pnpm-lock.yaml`; evitar mezclar gestores de paquetes dentro de un mismo proyecto.

## Organización

Desarrollado para **Alloxentric** como parte del sistema GPI / Vigía Industrial.
