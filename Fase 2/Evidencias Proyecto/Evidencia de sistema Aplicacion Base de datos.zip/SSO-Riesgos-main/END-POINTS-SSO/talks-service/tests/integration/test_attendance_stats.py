import pytest

from app.repositories.rep_talks import TalksRepository


async def seed_workers(db):
    await db["users"].insert_many([
        {
            "user_id": "worker_a1",
            "client_id": "empresa_a",
            "status": "active",
            "role": "worker",
            "name": "Ana",
            "last_name": "Prueba",
            "assigned_areas": ["Produccion"],
        },
        {
            "user_id": "worker_a2",
            "client_id": "empresa_a",
            "status": "active",
            "role": "worker",
            "name": "Luis",
            "last_name": "Prueba",
            "assigned_areas": ["Produccion"],
        },
        {
            "user_id": "worker_a3",
            "client_id": "empresa_a",
            "status": "active",
            "role": "worker",
            "name": "Carla",
            "last_name": "Seguridad",
            "assigned_areas": ["Seguridad"],
        },
        {
            "user_id": "inactive_a",
            "client_id": "empresa_a",
            "status": "inactive",
            "role": "worker",
            "name": "Inactivo",
            "last_name": "Prueba",
            "assigned_areas": ["Produccion"],
        },
        {
            "user_id": "supervisor_a",
            "client_id": "empresa_a",
            "status": "active",
            "role": "supervisor",
            "name": "Supervisor",
            "last_name": "Prueba",
            "assigned_areas": ["Produccion"],
        },
        {
            "user_id": "worker_b1",
            "client_id": "empresa_b",
            "status": "active",
            "role": "worker",
            "name": "Beatriz",
            "last_name": "Externa",
            "assigned_areas": ["Produccion"],
        },
    ])


@pytest.mark.asyncio
async def test_stats_by_area_resolves_qr_attendance(db):
    await seed_workers(db)

    await db["attendance"].insert_one({
        "attendance_id": "att_qr_a",
        "client_id": "empresa_a",
        "source": "qr",
        "talk_id": "talk_a",
        "area": "",
        "attendees": ["Ana Prueba"],
        "attended_user_ids": ["worker_a1"],
    })

    stats = await TalksRepository(
        db
    ).attendance_stats_by_area("empresa_a")

    by_area = {
        item["area"]: item
        for item in stats
    }

    assert by_area["Produccion"] == {
        "area": "Produccion",
        "active_workers": 2,
        "attendance_count": 1,
        "attendance_percentage": 50.0,
    }

    assert by_area["Seguridad"] == {
        "area": "Seguridad",
        "active_workers": 1,
        "attendance_count": 0,
        "attendance_percentage": 0.0,
    }


@pytest.mark.asyncio
async def test_stats_by_area_supports_unambiguous_manual_attendance(db):
    await seed_workers(db)

    await db["attendance"].insert_one({
        "attendance_id": "att_manual_a",
        "client_id": "empresa_a",
        "source": "manual",
        "talk_id": "talk_a",
        "area": "Seguridad",
        "attendees": ["Carla Seguridad"],
    })

    stats = await TalksRepository(
        db
    ).attendance_stats_by_area("empresa_a")

    seguridad = next(
        item
        for item in stats
        if item["area"] == "Seguridad"
    )

    assert seguridad["active_workers"] == 1
    assert seguridad["attendance_count"] == 1
    assert seguridad["attendance_percentage"] == 100.0


@pytest.mark.asyncio
async def test_stats_by_area_does_not_duplicate_worker(db):
    await seed_workers(db)

    await db["attendance"].insert_many([
        {
            "attendance_id": "att_1",
            "client_id": "empresa_a",
            "source": "qr",
            "talk_id": "talk_a",
            "area": "",
            "attendees": ["Ana Prueba"],
            "attended_user_ids": ["worker_a1"],
        },
        {
            "attendance_id": "att_2",
            "client_id": "empresa_a",
            "source": "qr",
            "talk_id": "talk_b",
            "area": "",
            "attendees": ["Ana Prueba"],
            "attended_user_ids": ["worker_a1"],
        },
    ])

    stats = await TalksRepository(
        db
    ).attendance_stats_by_area("empresa_a")

    produccion = next(
        item
        for item in stats
        if item["area"] == "Produccion"
    )

    assert produccion["active_workers"] == 2
    assert produccion["attendance_count"] == 1
    assert produccion["attendance_percentage"] == 50.0


@pytest.mark.asyncio
async def test_stats_by_area_ignores_other_tenant_and_inactive_users(db):
    await seed_workers(db)

    await db["attendance"].insert_many([
        {
            "attendance_id": "att_other_tenant",
            "client_id": "empresa_b",
            "source": "qr",
            "area": "",
            "attended_user_ids": ["worker_b1"],
        },
        {
            "attendance_id": "att_inactive",
            "client_id": "empresa_a",
            "source": "qr",
            "area": "",
            "attended_user_ids": ["inactive_a"],
        },
    ])

    stats = await TalksRepository(
        db
    ).attendance_stats_by_area("empresa_a")

    produccion = next(
        item
        for item in stats
        if item["area"] == "Produccion"
    )

    assert produccion["active_workers"] == 2
    assert produccion["attendance_count"] == 0
    assert produccion["attendance_percentage"] == 0.0


@pytest.mark.asyncio
async def test_stats_by_area_ignores_ambiguous_manual_name(db):
    await seed_workers(db)

    await db["users"].insert_one({
        "user_id": "worker_a4",
        "client_id": "empresa_a",
        "status": "active",
        "role": "worker",
        "name": "Ana",
        "last_name": "Prueba",
        "assigned_areas": ["Produccion"],
    })

    await db["attendance"].insert_one({
        "attendance_id": "att_manual_ambiguous",
        "client_id": "empresa_a",
        "source": "manual",
        "area": "Produccion",
        "attendees": ["Ana Prueba"],
    })

    stats = await TalksRepository(
        db
    ).attendance_stats_by_area("empresa_a")

    produccion = next(
        item
        for item in stats
        if item["area"] == "Produccion"
    )

    assert produccion["active_workers"] == 3
    assert produccion["attendance_count"] == 0
    assert produccion["attendance_percentage"] == 0.0


@pytest.mark.asyncio
async def test_stats_by_area_endpoint_uses_authenticated_client(
    api,
    db,
    auth_headers,
):
    await seed_workers(db)

    await db["attendance"].insert_many([
        {
            "attendance_id": "att_empresa_a",
            "client_id": "empresa_a",
            "source": "qr",
            "area": "",
            "attended_user_ids": ["worker_a1"],
        },
        {
            "attendance_id": "att_empresa_b",
            "client_id": "empresa_b",
            "source": "qr",
            "area": "",
            "attended_user_ids": ["worker_b1"],
        },
    ])

    response = await api.get(
        "/v1/attendance/stats/areas",
        headers=auth_headers(
            "admin_a",
            "empresa_a",
            "admin",
        ),
    )

    assert response.status_code == 200

    data = response.json()
    by_area = {
        item["area"]: item
        for item in data
    }

    assert by_area["Produccion"]["active_workers"] == 2
    assert by_area["Produccion"]["attendance_count"] == 1
    assert by_area["Produccion"]["attendance_percentage"] == 50.0


@pytest.mark.asyncio
async def test_stats_by_area_does_not_guess_area_for_multi_area_qr_worker(db):
    await db["users"].insert_one({
        "user_id": "worker_multi",
        "client_id": "empresa_a",
        "status": "active",
        "role": "worker",
        "name": "Mario",
        "last_name": "Multi",
        "assigned_areas": [
            "Produccion",
            "Seguridad",
        ],
    })

    await db["attendance"].insert_one({
        "attendance_id": "att_multi",
        "client_id": "empresa_a",
        "source": "qr",
        "talk_id": "talk_a",
        "area": "",
        "attendees": ["Mario Multi"],
        "attended_user_ids": ["worker_multi"],
    })

    stats = await TalksRepository(
        db
    ).attendance_stats_by_area("empresa_a")

    by_area = {
        item["area"]: item
        for item in stats
    }

    assert by_area["Produccion"]["active_workers"] == 1
    assert by_area["Produccion"]["attendance_count"] == 0
    assert by_area["Produccion"]["attendance_percentage"] == 0.0

    assert by_area["Seguridad"]["active_workers"] == 1
    assert by_area["Seguridad"]["attendance_count"] == 0
    assert by_area["Seguridad"]["attendance_percentage"] == 0.0


@pytest.mark.asyncio
async def test_stats_by_area_returns_empty_list_without_active_workers(db):
    await db["users"].insert_many([
        {
            "user_id": "inactive_worker",
            "client_id": "empresa_a",
            "status": "inactive",
            "role": "worker",
            "name": "Usuario",
            "last_name": "Inactivo",
            "assigned_areas": ["Produccion"],
        },
        {
            "user_id": "other_tenant_worker",
            "client_id": "empresa_b",
            "status": "active",
            "role": "worker",
            "name": "Otro",
            "last_name": "Cliente",
            "assigned_areas": ["Produccion"],
        },
    ])

    stats = await TalksRepository(
        db
    ).attendance_stats_by_area("empresa_a")

    assert stats == []


@pytest.mark.asyncio
async def test_stats_by_month_groups_attendance_using_talk_period(db):
    await seed_workers(db)

    await db["talks"].insert_many([
        {
            "talk_id": "talk_sep",
            "client_id": "empresa_a",
            "title": "Charla septiembre",
            "month": "9",
            "year": "2026",
        },
        {
            "talk_id": "talk_oct",
            "client_id": "empresa_a",
            "title": "Charla octubre",
            "month": "10",
            "year": "2026",
        },
    ])

    await db["attendance"].insert_many([
        {
            "attendance_id": "att_sep",
            "client_id": "empresa_a",
            "talk_id": "talk_sep",
            "date": "2026-09-15",
            "attended_user_ids": [
                "worker_a1",
                "worker_a2",
            ],
            "attendees": [],
        },
        {
            "attendance_id": "att_oct",
            "client_id": "empresa_a",
            "talk_id": "talk_oct",
            "date": "2026-10-15",
            "attended_user_ids": [
                "worker_a3",
            ],
            "attendees": [],
        },
    ])

    stats = await TalksRepository(
        db
    ).attendance_stats_by_month(
        "empresa_a",
        "2026",
    )

    assert stats == [
        {
            "year": "2026",
            "month": "9",
            "active_workers": 3,
            "attendance_count": 2,
            "attendance_percentage": 66.67,
        },
        {
            "year": "2026",
            "month": "10",
            "active_workers": 3,
            "attendance_count": 1,
            "attendance_percentage": 33.33,
        },
    ]


@pytest.mark.asyncio
async def test_stats_by_month_deduplicates_worker_within_same_month(db):
    await seed_workers(db)

    await db["talks"].insert_many([
        {
            "talk_id": "talk_sep_1",
            "client_id": "empresa_a",
            "title": "Charla 1",
            "month": "9",
            "year": "2026",
        },
        {
            "talk_id": "talk_sep_2",
            "client_id": "empresa_a",
            "title": "Charla 2",
            "month": "9",
            "year": "2026",
        },
    ])

    await db["attendance"].insert_many([
        {
            "attendance_id": "att_sep_1",
            "client_id": "empresa_a",
            "talk_id": "talk_sep_1",
            "date": "2026-09-10",
            "attended_user_ids": ["worker_a1"],
            "attendees": [],
        },
        {
            "attendance_id": "att_sep_2",
            "client_id": "empresa_a",
            "talk_id": "talk_sep_2",
            "date": "2026-09-20",
            "attended_user_ids": ["worker_a1"],
            "attendees": [],
        },
    ])

    stats = await TalksRepository(
        db
    ).attendance_stats_by_month(
        "empresa_a",
        "2026",
    )

    assert len(stats) == 1
    assert stats[0]["attendance_count"] == 1
    assert stats[0]["attendance_percentage"] == 33.33


@pytest.mark.asyncio
async def test_stats_by_month_prefers_talk_period_over_attendance_date(db):
    await seed_workers(db)

    await db["talks"].insert_one({
        "talk_id": "talk_sep",
        "client_id": "empresa_a",
        "title": "Charla septiembre",
        "month": "9",
        "year": "2026",
    })

    await db["attendance"].insert_one({
        "attendance_id": "att_date_october",
        "client_id": "empresa_a",
        "talk_id": "talk_sep",
        "date": "2026-10-01",
        "attended_user_ids": ["worker_a1"],
        "attendees": [],
    })

    stats = await TalksRepository(
        db
    ).attendance_stats_by_month(
        "empresa_a",
        "2026",
    )

    assert len(stats) == 1
    assert stats[0]["month"] == "9"
    assert stats[0]["attendance_count"] == 1


@pytest.mark.asyncio
async def test_stats_by_month_uses_date_for_legacy_attendance_without_talk(db):
    await seed_workers(db)

    await db["attendance"].insert_one({
        "attendance_id": "att_legacy",
        "client_id": "empresa_a",
        "talk_id": "",
        "date": "2026-08-12",
        "attended_user_ids": ["worker_a2"],
        "attendees": [],
    })

    stats = await TalksRepository(
        db
    ).attendance_stats_by_month(
        "empresa_a",
        "2026",
    )

    assert stats == [
        {
            "year": "2026",
            "month": "8",
            "active_workers": 3,
            "attendance_count": 1,
            "attendance_percentage": 33.33,
        }
    ]


@pytest.mark.asyncio
async def test_stats_by_month_supports_unique_manual_attendee(db):
    await seed_workers(db)

    await db["attendance"].insert_one({
        "attendance_id": "att_manual_month",
        "client_id": "empresa_a",
        "talk_id": "",
        "date": "2026-09-05",
        "attendees": ["Carla Seguridad"],
    })

    stats = await TalksRepository(
        db
    ).attendance_stats_by_month(
        "empresa_a",
        "2026",
    )

    assert stats[0]["attendance_count"] == 1
    assert stats[0]["attendance_percentage"] == 33.33


@pytest.mark.asyncio
async def test_stats_by_month_ignores_ambiguous_manual_attendee(db):
    await seed_workers(db)

    await db["users"].insert_one({
        "user_id": "worker_duplicate",
        "client_id": "empresa_a",
        "status": "active",
        "role": "worker",
        "name": "Ana",
        "last_name": "Prueba",
        "assigned_areas": ["Otra"],
    })

    await db["attendance"].insert_one({
        "attendance_id": "att_ambiguous_month",
        "client_id": "empresa_a",
        "talk_id": "",
        "date": "2026-09-05",
        "attendees": ["Ana Prueba"],
    })

    stats = await TalksRepository(
        db
    ).attendance_stats_by_month(
        "empresa_a",
        "2026",
    )

    assert stats[0]["active_workers"] == 4
    assert stats[0]["attendance_count"] == 0
    assert stats[0]["attendance_percentage"] == 0.0


@pytest.mark.asyncio
async def test_stats_by_month_filters_year_and_tenant(db):
    await seed_workers(db)

    await db["attendance"].insert_many([
        {
            "attendance_id": "att_a_2026",
            "client_id": "empresa_a",
            "talk_id": "",
            "date": "2026-09-05",
            "attended_user_ids": ["worker_a1"],
            "attendees": [],
        },
        {
            "attendance_id": "att_a_2025",
            "client_id": "empresa_a",
            "talk_id": "",
            "date": "2025-09-05",
            "attended_user_ids": ["worker_a2"],
            "attendees": [],
        },
        {
            "attendance_id": "att_b_2026",
            "client_id": "empresa_b",
            "talk_id": "",
            "date": "2026-09-05",
            "attended_user_ids": ["worker_b1"],
            "attendees": [],
        },
    ])

    stats = await TalksRepository(
        db
    ).attendance_stats_by_month(
        "empresa_a",
        "2026",
    )

    assert len(stats) == 1
    assert stats[0]["year"] == "2026"
    assert stats[0]["attendance_count"] == 1


@pytest.mark.asyncio
async def test_stats_by_month_endpoint_uses_authenticated_client(db, api, auth_headers):
    await seed_workers(db)

    await db["attendance"].insert_many([
        {
            "attendance_id": "att_a",
            "client_id": "empresa_a",
            "talk_id": "",
            "date": "2026-09-10",
            "attended_user_ids": ["worker_a1"],
            "attendees": [],
        },
        {
            "attendance_id": "att_b",
            "client_id": "empresa_b",
            "talk_id": "",
            "date": "2026-09-10",
            "attended_user_ids": ["worker_b1"],
            "attendees": [],
        },
    ])

    response = await api.get(
        "/v1/attendance/stats/months?year=2026",
        headers=auth_headers(
            "admin_a",
            "empresa_a",
            "admin",
        ),
    )

    assert response.status_code == 200

    data = response.json()

    assert len(data) == 1
    assert data[0]["year"] == "2026"
    assert data[0]["month"] == "9"
    assert data[0]["active_workers"] == 3
    assert data[0]["attendance_count"] == 1
    assert data[0]["attendance_percentage"] == 33.33


@pytest.mark.asyncio
async def test_stats_by_month_returns_empty_without_attendance(db):
    await seed_workers(db)

    stats = await TalksRepository(
        db
    ).attendance_stats_by_month(
        "empresa_a",
        "2026",
    )

    assert stats == []
