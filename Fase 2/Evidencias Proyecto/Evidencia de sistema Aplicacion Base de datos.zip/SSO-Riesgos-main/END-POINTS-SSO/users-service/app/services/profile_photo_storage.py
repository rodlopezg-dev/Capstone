import asyncio
import os
from urllib.parse import quote
from uuid import uuid4

from azure.core.exceptions import (
    ResourceExistsError,
    ResourceNotFoundError,
)
from azure.storage.blob import (
    BlobServiceClient,
    ContentSettings,
)


AZURE_CONNECTION_STRING = os.getenv(
    "AZURE_STORAGE_CONNECTION_STRING",
    "",
)

AZURE_CONTAINER = os.getenv(
    "AZURE_STORAGE_CONTAINER",
    "sso-evidencias",
)

BLOB_BASE_URL = os.getenv(
    "BLOB_BASE_URL",
    "",
).rstrip("/")

AUTO_CREATE_CONTAINER = (
    os.getenv(
        "AZURE_STORAGE_AUTO_CREATE_CONTAINER",
        "false",
    )
    .strip()
    .lower()
    == "true"
)

MAX_PROFILE_PHOTO_BYTES = 10 * 1024 * 1024

PROFILE_PHOTO_TYPES = {
    "image/jpeg": "jpg",
    "image/png": "png",
    "image/webp": "webp",
}


class UnsupportedProfilePhotoType(ValueError):
    pass


class EmptyProfilePhoto(ValueError):
    pass


class ProfilePhotoTooLarge(ValueError):
    pass


def _detect_image_type(
    file_bytes: bytes,
) -> str | None:
    if file_bytes.startswith(
        b"\xff\xd8\xff"
    ):
        return "image/jpeg"

    if file_bytes.startswith(
        b"\x89PNG\r\n\x1a\n"
    ):
        return "image/png"

    if (
        len(file_bytes) >= 12
        and file_bytes[:4] == b"RIFF"
        and file_bytes[8:12] == b"WEBP"
    ):
        return "image/webp"

    return None


def validate_profile_photo(
    content_type: str,
    file_bytes: bytes,
) -> str:
    normalized_type = (
        content_type or ""
    ).strip().lower()

    extension = PROFILE_PHOTO_TYPES.get(
        normalized_type
    )

    if not extension:
        raise UnsupportedProfilePhotoType(
            "La foto debe ser JPEG, PNG o WebP."
        )

    if not file_bytes:
        raise EmptyProfilePhoto(
            "La fotografía está vacía."
        )

    if (
        len(file_bytes)
        > MAX_PROFILE_PHOTO_BYTES
    ):
        raise ProfilePhotoTooLarge(
            "La fotografía supera el máximo "
            "permitido de 10 MB."
        )

    detected_type = _detect_image_type(
        file_bytes
    )

    if detected_type != normalized_type:
        raise UnsupportedProfilePhotoType(
            "El contenido del archivo no "
            "corresponde a una imagen "
            "JPEG, PNG o WebP válida."
        )

    return extension

def _create_container_if_needed(
    blob_service: BlobServiceClient,
) -> None:
    if not AUTO_CREATE_CONTAINER:
        return

    container = blob_service.get_container_client(
        AZURE_CONTAINER
    )

    try:
        container.create_container(
            public_access="blob"
        )
    except ResourceExistsError:
        pass


def _sync_upload_profile_photo(
    file_bytes: bytes,
    client_id: str,
    user_id: str,
    content_type: str,
) -> dict:
    if not AZURE_CONNECTION_STRING:
        raise RuntimeError(
            "AZURE_STORAGE_CONNECTION_STRING "
            "no está configurada."
        )

    if not BLOB_BASE_URL:
        raise RuntimeError(
            "BLOB_BASE_URL no está configurada."
        )

    extension = validate_profile_photo(
        content_type,
        file_bytes,
    )

    client_segment = quote(
        client_id,
        safe="",
    )

    user_segment = quote(
        user_id,
        safe="",
    )

    blob_name = (
        f"profiles/{client_segment}/"
        f"{user_segment}/"
        f"{uuid4().hex}.{extension}"
    )

    blob_service = (
        BlobServiceClient.from_connection_string(
            AZURE_CONNECTION_STRING
        )
    )

    _create_container_if_needed(blob_service)

    blob = blob_service.get_blob_client(
        container=AZURE_CONTAINER,
        blob=blob_name,
    )

    blob.upload_blob(
        file_bytes,
        overwrite=False,
        content_settings=ContentSettings(
            content_type=content_type,
        ),
    )

    return {
        "provider": "azure_blob",
        "container": AZURE_CONTAINER,
        "blob_name": blob_name,
        "content_type": content_type,
        "size": len(file_bytes),
        "url": f"{BLOB_BASE_URL}/{blob_name}",
    }


async def upload_profile_photo(
    file_bytes: bytes,
    client_id: str,
    user_id: str,
    content_type: str,
) -> dict:
    return await asyncio.to_thread(
        _sync_upload_profile_photo,
        file_bytes,
        client_id,
        user_id,
        content_type,
    )


def _sync_delete_profile_photo(
    storage_ref: dict | None,
) -> None:
    if (
        not storage_ref
        or storage_ref.get("provider")
        != "azure_blob"
    ):
        return

    blob_name = storage_ref.get("blob_name")

    if not blob_name:
        return

    if not AZURE_CONNECTION_STRING:
        return

    container = (
        storage_ref.get("container")
        or AZURE_CONTAINER
    )

    blob_service = (
        BlobServiceClient.from_connection_string(
            AZURE_CONNECTION_STRING
        )
    )

    blob = blob_service.get_blob_client(
        container=container,
        blob=blob_name,
    )

    try:
        blob.delete_blob(
            delete_snapshots="include"
        )
    except ResourceNotFoundError:
        pass


async def delete_profile_photo(
    storage_ref: dict | None,
) -> None:
    await asyncio.to_thread(
        _sync_delete_profile_photo,
        storage_ref,
    )
