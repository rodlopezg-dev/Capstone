import type {
  ReportCreatePayload,
} from '../app/api/reports';

const DB_NAME = 'gpi_offline';
const DB_VERSION = 2;
const STORE = 'pending_reports';
const OWNER_INDEX = 'by_owner';

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(
      DB_NAME,
      DB_VERSION,
    );

    req.onupgradeneeded = () => {
      const db = req.result;
      const tx = req.transaction;

      let store: IDBObjectStore;

      if (!db.objectStoreNames.contains(STORE)) {
        store = db.createObjectStore(
          STORE,
          {
            keyPath: 'localId',
            autoIncrement: true,
          },
        );
      } else {
        if (!tx) {
          throw new Error(
            'No fue posible migrar la cola offline',
          );
        }

        store = tx.objectStore(STORE);
      }

      if (!store.indexNames.contains(OWNER_INDEX)) {
        store.createIndex(
          OWNER_INDEX,
          ['clientId', 'userId'],
          { unique: false },
        );
      }
    };

    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export interface PendingReport {
  localId?: number;
  clientId: string;
  userId: string;
  idempotencyKey: string;
  payload: ReportCreatePayload;
  photoBase64: string | null;
  photoName: string | null;
  photoType: string | null;
  shift: string;
  createdAt: string;
  attempts: number;
  lastAttemptAt?: string;
  lastError?: string;
}

export async function savePendingReport(
  report: PendingReport,
): Promise<void> {
  const db = await openDB();
  const tx = db.transaction(
    STORE,
    'readwrite',
  );

  tx.objectStore(STORE).add(report);

  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function getPendingReports(
  clientId: string,
  userId: string,
): Promise<PendingReport[]> {
  const db = await openDB();
  const tx = db.transaction(
    STORE,
    'readonly',
  );

  const index = tx
    .objectStore(STORE)
    .index(OWNER_INDEX);

  return new Promise((resolve, reject) => {
    const req = index.getAll(
      IDBKeyRange.only([
        clientId,
        userId,
      ]),
    );

    req.onsuccess = () => {
      resolve(
        (req.result as PendingReport[])
          .sort(
            (a, b) =>
              a.createdAt.localeCompare(
                b.createdAt,
              ),
          ),
      );
    };

    req.onerror = () => reject(req.error);
  });
}

export async function countPendingReports(
  clientId: string,
  userId: string,
): Promise<number> {
  const db = await openDB();
  const tx = db.transaction(
    STORE,
    'readonly',
  );

  const index = tx
    .objectStore(STORE)
    .index(OWNER_INDEX);

  return new Promise((resolve, reject) => {
    const req = index.count(
      IDBKeyRange.only([
        clientId,
        userId,
      ]),
    );

    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function deletePendingReport(
  localId: number,
): Promise<void> {
  const db = await openDB();
  const tx = db.transaction(
    STORE,
    'readwrite',
  );

  tx.objectStore(STORE).delete(localId);

  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function updatePendingReport(
  localId: number,
  patch: Partial<
    Omit<PendingReport, 'localId'>
  >,
): Promise<void> {
  const db = await openDB();
  const tx = db.transaction(
    STORE,
    'readwrite',
  );
  const store = tx.objectStore(STORE);

  return new Promise((resolve, reject) => {
    const getReq = store.get(localId);

    getReq.onerror = () => reject(getReq.error);

    getReq.onsuccess = () => {
      const current =
        getReq.result as PendingReport | undefined;

      if (!current) {
        reject(
          new Error(
            `Reporte pendiente ${localId} no encontrado`,
          ),
        );
        return;
      }

      store.put({
        ...current,
        ...patch,
        localId,
      });
    };

    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}
