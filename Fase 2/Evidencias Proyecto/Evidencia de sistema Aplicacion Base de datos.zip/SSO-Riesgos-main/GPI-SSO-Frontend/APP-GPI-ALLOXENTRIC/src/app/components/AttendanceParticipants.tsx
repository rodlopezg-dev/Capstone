import { FileText, Hand, HelpCircle, QrCode, Users } from 'lucide-react';
import {
  ATTENDANCE_FILTER_METHODS,
  ATTENDANCE_METHOD_LABELS,
  filterParticipants,
  registrationDateLabel,
  type AttendanceMethodFilter,
  type AttendanceParticipant,
} from '../utils/attendanceParticipants';

const METHOD_ICONS = { all: Users, qr: QrCode, manual: Hand, sheet: FileText, unknown: HelpCircle };

export default function AttendanceParticipants({
  participants,
  filters,
  onFiltersChange,
  date,
}: {
  participants: AttendanceParticipant[];
  filters: AttendanceMethodFilter[];
  onFiltersChange: (
    filters: AttendanceMethodFilter[]
  ) => void;
  date?: string;
}) {
  const visible =
    filterParticipants(participants, filters);

  const toggleFilter = (
    method: 'all' | AttendanceMethodFilter,
  ) => {
    if (method === 'all') {
      onFiltersChange([]);
      return;
    }

    const nextFilters = filters.includes(method)
      ? filters.filter(
        current => current !== method
      )
      : [...filters, method];

    // Ninguno seleccionado = Todos.
    if (nextFilters.length === 0) {
      onFiltersChange([]);
      return;
    }

    // Los tres seleccionados = Todos.
    if (
      nextFilters.length ===
      ATTENDANCE_FILTER_METHODS.length
    ) {
      onFiltersChange([]);
      return;
    }

    onFiltersChange(nextFilters);
  };
  return (
    <div className="mt-4 pt-4 border-t border-white/10">
      <p className="text-xs font-medium mb-3">Participantes · fecha y hora de registro (hora local)</p>
      <div
        role="group"
        aria-label="Filtrar participantes por forma de registro"
        className="flex justify-center gap-2 mb-3"
      >
        {(
          [
            'all',
            ...ATTENDANCE_FILTER_METHODS,
          ] as const
        ).map(method => {
          const Icon = METHOD_ICONS[method];

          const isActive =
            method === 'all'
              ? filters.length === 0
              : filters.includes(method);

          return (
            <button
              key={method}
              type="button"
              aria-label={
                ATTENDANCE_METHOD_LABELS[method]
              }
              title={
                ATTENDANCE_METHOD_LABELS[method]
              }
              aria-pressed={isActive}
              onClick={() => toggleFilter(method)}
              className={
                'p-3 rounded-lg border ' +
                'focus-visible:outline ' +
                'focus-visible:outline-2 ' +
                'focus-visible:outline-[#00E5FF] ' +
                (
                  isActive
                    ? 'border-[#00E5FF] bg-[#00E5FF]/20 text-[#00E5FF]'
                    : 'themed-card themed-text-secondary'
                )
              }
            >
              <Icon
                size={18}
                aria-hidden="true"
              />
            </button>
          );
        })}
      </div>
      {visible.length === 0 ? (
        <p className="text-sm themed-text-secondary text-center py-3">
          {participants.length === 0 ? 'Esta charla aún no tiene participantes registrados.' : 'No hay participantes con esta forma de registro.'}
        </p>
      ) : (
        <div className="space-y-2">
          {visible.map((row, index) => {
            const Icon = METHOD_ICONS[row.method];
            return (
              <div key={`${row.name}-${index}`} className="themed-card border rounded-lg px-3 py-2 flex items-start gap-3">
                <span title={ATTENDANCE_METHOD_LABELS[row.method]} aria-label={ATTENDANCE_METHOD_LABELS[row.method]}
                  className="shrink-0 rounded-lg bg-[#00E5FF]/10 text-[#00E5FF] p-2">
                  <Icon size={18} aria-hidden="true" />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="text-sm break-words">{row.name}</p>
                  <p className="text-xs themed-text-secondary">{ATTENDANCE_METHOD_LABELS[row.method]}</p>
                  <time dateTime={row.registeredAt || row.recordDate || date} className="block text-xs themed-text-secondary mt-1">
                    {registrationDateLabel(row.registeredAt, row.recordDate || date)}
                  </time>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
