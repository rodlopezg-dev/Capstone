export const formatDateInput = (date: Date) => {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');

  return `${year}-${month}-${day}`;
};

export const addDaysToDateInput = (
  baseDate: Date,
  days: number
) => {
  const result = new Date(baseDate);
  result.setDate(result.getDate() + days);

  return formatDateInput(result);
};

export const getDeadlineRange = (today = new Date()) => ({
  min: addDaysToDateInput(today, 3),
  max: addDaysToDateInput(today, 30),
});

export const getDaysUntilDeadline = (
  deadline: string,
  today = new Date()
) => {
  if (!deadline) {
    return null;
  }

  const [year, month, day] = deadline
    .split('-')
    .map(Number);

  if (!year || !month || !day) {
    return null;
  }

  const target = new Date(year, month - 1, day);
  const start = new Date(
    today.getFullYear(),
    today.getMonth(),
    today.getDate()
  );

  const millisecondsPerDay = 24 * 60 * 60 * 1000;

  return Math.ceil(
    (target.getTime() - start.getTime()) /
      millisecondsPerDay
  );
};
