import logging
logger = logging.getLogger("auth")

from datetime import datetime, timedelta, timezone
import jwt
from passlib.context import CryptContext
from app.config import settings
from app.repositories.user_api_repo import UserApiRepository
from app.schemas.auth import LoginRequest
from app.exceptions import InvalidCredentialsError, TokenExpiredError, TokenInvalidError

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


class AuthService:
    def __init__(self, repo: UserApiRepository):
        self.repo = repo

    def generate_jwt(self, payload: dict, expires_delta: timedelta) -> str:
        """
        Genera un token JWT empaquetando el payload y calculando su expiración.
        """
        to_encode = payload.copy()
        expire = datetime.now(timezone.utc) + expires_delta
        to_encode.update({"exp": expire})
        return jwt.encode(
            to_encode, settings.JWT_SECRET, algorithm=settings.JWT_ALGORITHM
        )

    async def login_user(self, login_data: LoginRequest) -> dict:
        """
        Busca al usuario en Firestore utilizando el repositorio, valida la contraseña 
        e inyecta el 'role', 'client_id' y las 'areas' requeridas por el ecosistema.
        """
        # 1. Extraemos los campos de las credenciales de forma segura desde el esquema
        client_id = login_data.client_id
        email = login_data.email
        password = login_data.password

        # 2. Buscamos el usuario en Firestore pasando los parámetros limpios
        user_doc = await self.repo.get_user_for_auth(client_id, email)
        
        if not user_doc:
            logger.warning(f"Login fallido para {email} desde cliente {client_id}")
            raise InvalidCredentialsError()

        if user_doc.get("status") != "active":
            raise InvalidCredentialsError()

        # 3. Verificamos que la contraseña ingresada coincida con el hash de Firestore
        if not pwd_context.verify(password, user_doc.get("hashed_password")):
            logger.warning(f"Login fallido para {email} desde cliente {client_id}")
            raise InvalidCredentialsError()

        # 🌟 EXTRACCIÓN SEGURA DE ÁREAS DESDE FIRESTORE
        # Extraemos 'areas' (por si es array) o 'area' (por si es string plano) para no romper nada
        user_areas = user_doc.get("assigned_areas", user_doc.get("areas", []))
        user_area = user_doc.get("area", "")

        # 4. 🌟 SECCIÓN CRÍTICA CORREGIDA: Empaquetamos las áreas geográficas dentro del Token
        access_payload = {
            "type": "access",
            "sub": user_doc.get("user_id"),
            "client_id": user_doc.get("client_id"),
            "role": user_doc.get("role"),
            "areas": user_areas,  # 👈 Inyección crítica para el filtro de incidentes
            "area": user_area     # 👈 Clave secundaria para retrocompatibilidad
        }

        # 5. Generamos los tokens de acceso utilizando los settings del sistema
        access_token = self.generate_jwt(
            payload=access_payload, 
            expires_delta=timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
        )

        refresh_payload = {
            "sub":       user_doc.get("user_id"),
            "client_id": user_doc.get("client_id"),
            "role":      user_doc.get("role"),
            "areas":     user_areas, # 👈 Se añaden también al refresh para evitar pérdidas en la renovación
            "area":      user_area,
            "type":      "refresh",
        }
        refresh_token = self.generate_jwt(
            payload=refresh_payload,
            expires_delta=timedelta(days=7),
        )

        # Retornamos los datos planos en el JSON de respuesta que recibe el frontend inmediatamente al loguearse
        return {
            "access_token":  access_token,
            "refresh_token": refresh_token,
            "token_type":    "bearer",
            "user_id":       user_doc.get("user_id"),
            "role":          user_doc.get("role"),
            "areas":         user_areas, # 👈 Envío directo en la respuesta HTTP
            "area":          user_area,
        }

    def verify_token(self, token: str, check_refresh: bool = False) -> dict:
        """
        Decodifica y valida las firmas del token JWT.
        """
        try:
            payload = jwt.decode(
                token, settings.JWT_SECRET, algorithms=[settings.JWT_ALGORITHM],
                options={"require": ["exp"]},
            )
            if (check_refresh and payload.get("type") != "refresh") or (
                not check_refresh and "type" in payload and payload["type"] != "access"
            ):
                raise TokenInvalidError()
            if any(
                not isinstance(payload.get(claim), str) or not payload[claim].strip()
                for claim in ("sub", "role", "client_id")
            ):
                raise TokenInvalidError()
            return payload
        except jwt.ExpiredSignatureError:
            raise TokenExpiredError()
        except jwt.PyJWTError:
            raise TokenInvalidError()

    async def refresh_user_session(self, refresh_token: str) -> dict:
        claims = self.verify_token(refresh_token, check_refresh=True)
        current = await self.repo.get_user_by_id(claims["client_id"], claims["sub"])
        if not isinstance(current, dict) or current.get("status") != "active":
            raise TokenInvalidError()

        areas = current.get("assigned_areas", current.get("areas", []))
        area = current.get("area", "")
        if (
            not isinstance(areas, list)
            or any(not isinstance(value, str) or not value.strip() for value in areas)
            or not isinstance(area, str)
            or any(
                not isinstance(current.get(name), str) or not current[name].strip()
                for name in ("user_id", "client_id", "role")
            )
        ):
            raise TokenInvalidError()

        # El refresh identifica la sesión, pero la autoridad procede del
        # documento actual de Users Service. Una variación exige login nuevo.
        if (
            current["user_id"] != claims["sub"]
            or current["client_id"] != claims["client_id"]
            or current["role"] != claims["role"]
            or areas != claims.get("areas", [])
            or area != claims.get("area", "")
        ):
            raise TokenInvalidError()

        new_access = self.generate_jwt(
            {
                "type": "access",
                "sub": current["user_id"],
                "client_id": current["client_id"],
                "role": current["role"],
                "areas": areas,
                "area": area,
            },
            timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES),
        )
        return {
            "access_token": new_access,
            "refresh_token": refresh_token,
            "user_id": current["user_id"],
            "role": current["role"],
        }
