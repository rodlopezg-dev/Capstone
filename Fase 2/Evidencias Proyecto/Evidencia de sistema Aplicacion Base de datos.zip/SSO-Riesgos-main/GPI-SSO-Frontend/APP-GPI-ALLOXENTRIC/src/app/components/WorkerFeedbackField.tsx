interface WorkerFeedbackFieldProps {
  value: string;
  onChange: (value: string) => void;
  disabled?: boolean;
}

export default function WorkerFeedbackField({
  value,
  onChange,
  disabled = false,
}: WorkerFeedbackFieldProps) {
  return (
    <div>
      <p className="text-sm font-medium mb-1">
        Feedback al trabajador
      </p>

      <textarea
        value={value}
        onChange={event => onChange(event.target.value)}
        disabled={disabled}
        placeholder="Escribir feedback para el trabajador..."
        className="w-full rounded-xl px-4 py-3 text-sm resize-none h-24 outline-none"
        style={{
          background: '#0B2E36',
          border: '1px solid rgba(0,229,255,0.3)',
          color: 'white',
        }}
      />

      <p
        className="text-xs mt-1"
        style={{ color: '#888' }}
      >
        Registra las observaciones que se comunicarán al trabajador.
      </p>
    </div>
  );
}
