import type { Report } from '../api/reports';
import { resolveLocalEvidenceUrl } from './mediaUrl';

export function getReportDisplayId(report: Report): string {
  return report.report_id?.slice(-6).toUpperCase() || '';
}

export function formatReportDate(createdAt?: string): string {
  if (!createdAt) return '';

  const date = new Date(createdAt);

  if (Number.isNaN(date.getTime())) {
    return '';
  }

  return date.toLocaleDateString('es-CL');
}

export function resolveReportEvidenceUrl(
  evidenceUrl: string,
  reportsApiUrl?: string,
): string {
  return resolveLocalEvidenceUrl(
    evidenceUrl,
    reportsApiUrl,
  );
}

export function getReportEvidenceUrl(report: Report): string | null {
  const evidenceUrl =
    report.evidences?.find(url => Boolean(url)) || null;

  if (!evidenceUrl) {
    return null;
  }

  return resolveReportEvidenceUrl(
    evidenceUrl,
    import.meta.env.VITE_REPORTS_API_URL,
  );
}
