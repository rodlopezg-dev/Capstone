import { describe, expect, it } from 'vitest';

import {
  buildAttendanceExportUrl,
  resolveAttendanceExportFilename,
} from './attendanceExport';

describe('attendanceExport - SCRUM-113', () => {
  it('builds a PDF export URL with period filters', () => {
    expect(
      buildAttendanceExportUrl(
        'http://localhost/api/talks',
        'pdf',
        '9',
        '2026',
      ),
    ).toBe(
      'http://localhost/api/talks/v1/attendance/export/pdf?month=9&year=2026',
    );
  });

  it('builds an XLSX export URL with period filters', () => {
    expect(
      buildAttendanceExportUrl(
        'http://localhost/api/talks',
        'xlsx',
        '10',
        '2026',
      ),
    ).toBe(
      'http://localhost/api/talks/v1/attendance/export/xlsx?month=10&year=2026',
    );
  });

  it('uses the server filename when available', () => {
    expect(
      resolveAttendanceExportFilename(
        'attachment; filename="asistencia_2026_09.pdf"',
        'pdf',
        '9',
        '2026',
      ),
    ).toBe('asistencia_2026_09.pdf');
  });

  it('builds a fallback filename when header is absent', () => {
    expect(
      resolveAttendanceExportFilename(
        null,
        'xlsx',
        '9',
        '2026',
      ),
    ).toBe('asistencia_2026_09.xlsx');
  });
});
