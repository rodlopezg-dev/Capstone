"""Integration tests for SCRUM-78 - incident analysis persistence."""

import pytest
from fastapi.testclient import TestClient

from app.main import app
from app.routers import rt_reports
from tests.integration.test_report_category import FakeDB


REPORT_ID = "report_scrum78"
TENANT_A = "tenant_a"
TENANT_B = "tenant_b"
SUPERVISOR_ID = "supervisor_scrum78"


def report_fixture():
    return {
        "report_id": REPORT_ID,
        "client_id": TENANT_A,
        "type": "Acto Inseguro",
        "is_iap": False,
        "status": "open",
        "causes": ["Falta de EPP"],
        "probable_consequence": "Atrapamiento",
        "analysis": "Análisis inicial",
        "control_measures": [
            "Reinstruir en procedimiento o instructivo"
        ],
        "deadline": "2026-09-20",
        "feedback": "Feedback inicial",
    }


@pytest.fixture
def fake_db():
    return FakeDB([report_fixture()])


@pytest.fixture
def client_factory(fake_db, monkeypatch):
    clients = []

    def _factory(
        *,
        role="supervisor",
        client_id=TENANT_A,
        user_id=SUPERVISOR_ID,
    ):
        app.dependency_overrides[
            rt_reports.get_db
        ] = lambda: fake_db

        monkeypatch.setattr(
            rt_reports,
            "get_current_user",
            lambda credentials: {
                "user_id": user_id,
                "client_id": client_id,
                "role": role,
            },
        )

        client = TestClient(app)
        clients.append(client)
        return client

    yield _factory

    for client in clients:
        client.close()

    app.dependency_overrides.clear()


def full_payload():
    return {
        "causes": [
            "Falta de capacitación",
            "Condición del entorno",
        ],
        "probable_consequence": "Caída al mismo nivel",
        "analysis": (
            "Se detecta desviación del procedimiento."
        ),
        "control_measures": [
            "Reinstruir en procedimiento o instructivo",
            "Reforzar supervision o acompanamiento en terreno",
        ],
        "deadline": "2026-09-25",
        "feedback": (
            "Se reforzó el procedimiento con el trabajador."
        ),
    }


def test_supervisor_can_persist_all_analysis_fields(
    fake_db,
    client_factory,
):
    client = client_factory()

    response = client.patch(
        f"/v1/reports/{REPORT_ID}/analysis",
        headers={
            "Authorization": "Bearer fake_token"
        },
        json=full_payload(),
    )

    assert response.status_code == 200

    body = response.json()
    assert body["ok"] is True
    assert body["changed"] is True

    saved = fake_db["reports"].documents[0]

    for key, value in full_payload().items():
        assert saved[key] == value

    # Guardar análisis no debe cambiar el estado.
    assert saved["status"] == "open"

    # Tampoco debe generar una notificación.
    assert fake_db["notifications"].documents == []


@pytest.mark.parametrize(
    "role",
    [
        "supervisor",
        "jefe_de_area",
        "jefe de area",
    ],
)
def test_allowed_roles_can_update_analysis(
    client_factory,
    role,
):
    client = client_factory(role=role)

    response = client.patch(
        f"/v1/reports/{REPORT_ID}/analysis",
        headers={
            "Authorization": "Bearer fake_token"
        },
        json={"analysis": "Nuevo análisis"},
    )

    assert response.status_code == 200


@pytest.mark.parametrize(
    "role",
    [
        "worker",
        "usuario",
        "admin",
        "sso_manager",
    ],
)
def test_other_roles_cannot_update_analysis(
    client_factory,
    role,
):
    client = client_factory(role=role)

    response = client.patch(
        f"/v1/reports/{REPORT_ID}/analysis",
        headers={
            "Authorization": "Bearer fake_token"
        },
        json={"analysis": "No autorizado"},
    )

    assert response.status_code == 403
    assert response.json()["detail"] == (
        "No tiene permisos para gestionar "
        "el análisis del incidente"
    )


def test_report_from_another_tenant_is_not_accessible(
    client_factory,
):
    client = client_factory(client_id=TENANT_B)

    response = client.patch(
        f"/v1/reports/{REPORT_ID}/analysis",
        headers={
            "Authorization": "Bearer fake_token"
        },
        json={"analysis": "Tenant incorrecto"},
    )

    assert response.status_code == 404


def test_missing_report_returns_404(client_factory):
    client = client_factory()

    response = client.patch(
        "/v1/reports/report_missing/analysis",
        headers={
            "Authorization": "Bearer fake_token"
        },
        json={"analysis": "No existe"},
    )

    assert response.status_code == 404


def test_explicit_empty_values_clear_existing_data(
    fake_db,
    client_factory,
):
    client = client_factory()

    response = client.patch(
        f"/v1/reports/{REPORT_ID}/analysis",
        headers={
            "Authorization": "Bearer fake_token"
        },
        json={
            "causes": [],
            "probable_consequence": "",
            "analysis": "",
            "control_measures": [],
            "deadline": "",
            "feedback": "",
        },
    )

    assert response.status_code == 200
    assert response.json()["changed"] is True

    saved = fake_db["reports"].documents[0]

    assert saved["causes"] == []
    assert saved["probable_consequence"] == ""
    assert saved["analysis"] == ""
    assert saved["control_measures"] == []
    assert saved["deadline"] == ""
    assert saved["feedback"] == ""


def test_partial_patch_preserves_unsent_fields(
    fake_db,
    client_factory,
):
    client = client_factory()

    before = dict(fake_db["reports"].documents[0])

    response = client.patch(
        f"/v1/reports/{REPORT_ID}/analysis",
        headers={
            "Authorization": "Bearer fake_token"
        },
        json={"analysis": "Solo cambia análisis"},
    )

    assert response.status_code == 200

    saved = fake_db["reports"].documents[0]

    assert saved["analysis"] == "Solo cambia análisis"
    assert saved["causes"] == before["causes"]
    assert (
        saved["probable_consequence"]
        == before["probable_consequence"]
    )
    assert (
        saved["control_measures"]
        == before["control_measures"]
    )
    assert saved["deadline"] == before["deadline"]
    assert saved["feedback"] == before["feedback"]


def test_same_analysis_is_idempotent(
    fake_db,
    client_factory,
):
    client = client_factory()

    response = client.patch(
        f"/v1/reports/{REPORT_ID}/analysis",
        headers={
            "Authorization": "Bearer fake_token"
        },
        json={
            "causes": ["Falta de EPP"],
            "probable_consequence": "Atrapamiento",
            "analysis": "Análisis inicial",
            "control_measures": [
                "Reinstruir en procedimiento o instructivo"
            ],
            "deadline": "2026-09-20",
            "feedback": "Feedback inicial",
        },
    )

    assert response.status_code == 200
    assert response.json()["changed"] is False
    assert fake_db["activity_log"].documents == []


def test_real_change_creates_activity_log(
    fake_db,
    client_factory,
):
    client = client_factory(
        user_id=SUPERVISOR_ID
    )

    response = client.patch(
        f"/v1/reports/{REPORT_ID}/analysis",
        headers={
            "Authorization": "Bearer fake_token"
        },
        json={"analysis": "Análisis actualizado"},
    )

    assert response.status_code == 200

    logs = fake_db["activity_log"].documents
    assert len(logs) == 1

    entry = logs[0]

    assert entry["action"] == "analysis_updated"
    assert entry["report_id"] == REPORT_ID
    assert entry["client_id"] == TENANT_A
    assert entry["user_id"] == SUPERVISOR_ID
    assert "analysis" in entry["detail"]



def test_probable_consequence_is_persisted(
    fake_db,
    client_factory,
):
    client = client_factory()

    response = client.patch(
        f"/v1/reports/{REPORT_ID}/analysis",
        headers={
            "Authorization": "Bearer fake_token"
        },
        json={
            "probable_consequence":
                "Contacto con energía eléctrica"
        },
    )

    assert response.status_code == 200

    body = response.json()
    assert body["changed"] is True
    assert (
        body["probable_consequence"]
        == "Contacto con energía eléctrica"
    )

    saved = fake_db["reports"].documents[0]

    assert (
        saved["probable_consequence"]
        == "Contacto con energía eléctrica"
    )

    logs = fake_db["activity_log"].documents
    assert len(logs) == 1
    assert "probable_consequence" in logs[0]["detail"]


def test_invalid_probable_consequence_is_rejected(
    fake_db,
    client_factory,
):
    client = client_factory()

    before = dict(fake_db["reports"].documents[0])

    response = client.patch(
        f"/v1/reports/{REPORT_ID}/analysis",
        headers={
            "Authorization": "Bearer fake_token"
        },
        json={
            "probable_consequence":
                "Golpe o contusion"
        },
    )

    assert response.status_code == 422
    assert response.json()["detail"] == (
        "Consecuencia probable no válida"
    )

    saved = fake_db["reports"].documents[0]

    assert (
        saved["probable_consequence"]
        == before["probable_consequence"]
    )

    assert fake_db["activity_log"].documents == []
