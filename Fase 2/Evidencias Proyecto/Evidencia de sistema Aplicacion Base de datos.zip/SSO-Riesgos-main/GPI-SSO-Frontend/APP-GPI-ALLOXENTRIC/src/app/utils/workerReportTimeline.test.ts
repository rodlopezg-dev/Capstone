import {
  describe,
  expect,
  it,
} from 'vitest';

import type { Report } from '../api/reports';

import {
  formatWorkerReportTimelineTimestamp,
  getWorkerReportTimelineSteps,
} from './workerReportTimeline';

function report(
  overrides: Partial<Report> = {},
): Report {
  return {
    report_id: '15',
    area_id: 'Bodega Quimica',
    type: 'Condición Insegura',
    status: 'open',
    is_iap: false,
    description: 'Reporte de prueba',
    created_at: '2026-09-29T12:00:00Z',
    ...overrides,
  };
}

describe('workerReportTimeline', () => {
  it('shows a new open report in review', () => {
    const steps =
      getWorkerReportTimelineSteps(report());

    expect(steps[0].active).toBe(true);
    expect(steps[1].active).toBe(true);
    expect(steps[1].current).toBe(true);
    expect(steps[2].active).toBe(false);
  });

  it('shows an analysed open report in analysis', () => {
    const steps = getWorkerReportTimelineSteps(
      report({
        status: 'open',
        causes: ['Falta de capacitación'],
        probable_consequence: 'Atrapamiento',
        analysis: 'Análisis realizado',
      }),
    );

    expect(steps[1].active).toBe(true);
    expect(steps[1].current).toBe(false);

    expect(steps[2].label).toBe('Análisis');
    expect(steps[2].active).toBe(true);
    expect(steps[2].current).toBe(true);
  });

  it('uses legacy assigned as analysis presentation', () => {
    const steps = getWorkerReportTimelineSteps(
      report({
        timeline: {
          assigned: '2026-09-29T13:00:00Z',
        },
      }),
    );

    expect(steps[2].label).toBe('Análisis');
    expect(steps[2].current).toBe(true);
    expect(steps[2].timestamp).toBe(
      '2026-09-29T13:00:00Z',
    );
  });

  it('derives treatment from en_proceso', () => {
    const steps = getWorkerReportTimelineSteps(
      report({
        status: 'en_proceso',
        timeline: {
          en_proceso: '2026-09-29T14:00:00Z',
        },
      }),
    );

    expect(
      steps.find(step => step.key === 'assigned')
        ?.active,
    ).toBe(true);

    expect(
      steps.find(step => step.key === 'en_proceso')
        ?.current,
    ).toBe(true);
  });

  it('derives closure validation from pending closure', () => {
    const steps = getWorkerReportTimelineSteps(
      report({
        status: 'pending_closure',
      }),
    );

    const step = steps.find(
      item => item.key === 'pending_closure',
    );

    expect(step?.label).toBe(
      'Cierre en validación',
    );
    expect(step?.current).toBe(true);
  });

  it('marks every visual milestone active when closed', () => {
    const steps = getWorkerReportTimelineSteps(
      report({
        status: 'closed',
      }),
    );

    expect(
      steps.every(step => step.active),
    ).toBe(true);

    expect(
      steps.at(-1)?.current,
    ).toBe(true);
  });

  it('does not invent timestamps for derived milestones', () => {
    const steps = getWorkerReportTimelineSteps(
      report({
        status: 'en_proceso',
      }),
    );

    expect(
      steps.find(step => step.key === 'reviewing')
        ?.timestamp,
    ).toBeUndefined();

    expect(
      steps.find(step => step.key === 'assigned')
        ?.timestamp,
    ).toBeUndefined();
  });

  it('formats an explicit UTC timestamp for display', () => {
    expect(
      formatWorkerReportTimelineTimestamp(
        '2026-10-03T15:57:15.212598Z',
        'UTC',
      ),
    ).toBe('03-10-2026 15:57');
  });

  it('treats legacy timestamps without timezone as UTC', () => {
    const legacy =
      formatWorkerReportTimelineTimestamp(
        '2026-10-03T15:57:15.212598',
        'UTC',
      );

    const explicitUtc =
      formatWorkerReportTimelineTimestamp(
        '2026-10-03T15:57:15.212598Z',
        'UTC',
      );

    expect(legacy).toBe(explicitUtc);
    expect(legacy).toBe('03-10-2026 15:57');
  });

  it('converts timestamps using the requested timezone', () => {
    expect(
      formatWorkerReportTimelineTimestamp(
        '2026-10-03T15:57:15.212598Z',
        'America/Santiago',
      ),
    ).toBe('03-10-2026 12:57');
  });

  it('keeps an invalid timestamp readable', () => {
    expect(
      formatWorkerReportTimelineTimestamp(
        'timestamp-legacy-invalido',
        'UTC',
      ),
    ).toBe('timestamp-legacy-invalido');
  });

  it('returns empty text when timestamp is absent', () => {
    expect(
      formatWorkerReportTimelineTimestamp(),
    ).toBe('');
  });

});
