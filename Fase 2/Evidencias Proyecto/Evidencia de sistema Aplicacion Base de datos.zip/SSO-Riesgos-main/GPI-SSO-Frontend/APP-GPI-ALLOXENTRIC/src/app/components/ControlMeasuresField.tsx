import { useState } from 'react';

import {
  CONTROL_MEASURE_OPTIONS,
  toggleControlMeasure,
} from '../utils/incidentControlMeasures';

interface ControlMeasuresFieldProps {
  value: string[];
  onChange: (measures: string[]) => void;
  disabled?: boolean;
}

export default function ControlMeasuresField({
  value,
  onChange,
  disabled = false,
}: ControlMeasuresFieldProps) {
  const [open, setOpen] = useState(false);

  return (
    <div>
      <p className="text-sm font-medium mb-1">
        Medidas de control
      </p>

      {value.length > 0 && (
        <div className="flex flex-wrap gap-2 mb-2">
          {value.map(measure => (
            <button
              key={measure}
              type="button"
              disabled={disabled}
              onClick={() =>
                onChange(toggleControlMeasure(value, measure))
              }
              className="text-xs px-3 py-1.5 rounded-full"
              style={{
                background: '#00E5FF20',
                color: '#00E5FF',
                border: '1px solid rgba(0,229,255,0.3)',
              }}
              title="Quitar medida"
            >
              {measure} ×
            </button>
          ))}
        </div>
      )}

      <button
        type="button"
        disabled={disabled}
        onClick={() => setOpen(current => !current)}
        className="w-full rounded-xl px-4 py-3 text-sm text-left flex items-center justify-between"
        style={{
          background: '#0B2E36',
          border: '1px solid rgba(0,229,255,0.3)',
          color: 'white',
        }}
      >
        <span>
          {value.length === 0
            ? 'Seleccionar medidas de control'
            : `${value.length} medida(s) seleccionada(s)`}
        </span>

        <span>{open ? '▲' : '▼'}</span>
      </button>

      {open && !disabled && (
        <div
          className="rounded-xl overflow-hidden mt-2"
          style={{
            border: '1px solid rgba(0,229,255,0.2)',
            background: '#08252C',
            maxHeight: '240px',
            overflowY: 'auto',
          }}
        >
          {CONTROL_MEASURE_OPTIONS.map(measure => (
            <label
              key={measure}
              className="flex items-start gap-3 px-4 py-3 cursor-pointer"
              style={{
                borderBottom: '1px solid rgba(255,255,255,0.06)',
              }}
            >
              <input
                type="checkbox"
                checked={value.includes(measure)}
                onChange={() =>
                  onChange(toggleControlMeasure(value, measure))
                }
                className="mt-0.5"
              />

              <span className="text-sm">
                {measure}
              </span>
            </label>
          ))}
        </div>
      )}

      <p
        className="text-xs mt-2"
        style={{ color: '#888' }}
      >
        {value.length} medida(s) seleccionada(s)
      </p>
    </div>
  );
}
