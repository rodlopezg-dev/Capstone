export function normalizeIncidentRole(
  role: string | null | undefined,
): string {
  return (role ?? '')
    .trim()
    .toLowerCase()
    .replace(/_/g, ' ');
}

const CHANGE_TO_PROCESS_ROLES = new Set([
  'supervisor',
  'jefe de area',
]);

export function canChangeIncidentToProcess(
  status: string,
  role: string | null | undefined,
): boolean {
  return (
    status === 'open' &&
    CHANGE_TO_PROCESS_ROLES.has(
      normalizeIncidentRole(role),
    )
  );
}

const REQUEST_CLOSURE_ROLES = new Set([
  'supervisor',
  'jefe de area',
]);

export function canRequestIncidentClosure(
  status: string,
  role: string | null | undefined,
): boolean {
  return (
    status === 'en_proceso' &&
    REQUEST_CLOSURE_ROLES.has(
      normalizeIncidentRole(role),
    )
  );
}

const APPROVE_CLOSURE_ROLES = new Set([
  'admin',
  'sso manager',
]);

export function canApproveIncidentClosure(
  status: string,
  role: string | null | undefined,
): boolean {
  return (
    status === 'pending_closure' &&
    APPROVE_CLOSURE_ROLES.has(
      normalizeIncidentRole(role),
    )
  );
}


export function incidentStatusSuccessMessage(
  status: string,
): string {
  switch (status) {
    case 'en_proceso':
      return 'Incidente cambiado a proceso correctamente.';

    case 'pending_closure':
      return 'Solicitud de cierre enviada correctamente.';

    case 'closed':
      return 'Cierre del incidente aprobado correctamente.';

    default:
      return 'Estado actualizado correctamente.';
  }
}

export function incidentStatusErrorMessage(
  statusCode: number,
  detail?: unknown,
): string {
  if (
    typeof detail === 'string'
    && detail.trim()
  ) {
    return detail.trim();
  }

  if (statusCode === 403) {
    return 'No tiene permisos para realizar esta acción.';
  }

  if (statusCode === 409) {
    return (
      'El incidente no se encuentra en un estado '
      + 'válido para realizar esta acción.'
    );
  }

  return 'No fue posible cambiar el estado del incidente.';
}
