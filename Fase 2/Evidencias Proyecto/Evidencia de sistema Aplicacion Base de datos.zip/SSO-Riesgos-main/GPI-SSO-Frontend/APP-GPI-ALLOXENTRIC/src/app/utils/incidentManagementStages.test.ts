import {
  describe,
  expect,
  it,
} from 'vitest';

import {
  getIncidentManagementStageState,
  isIncidentManagementStageAccessible,
} from './incidentManagementStages';

describe('incidentManagementStages', () => {
  it('opens a new open report in review', () => {
    const state = getIncidentManagementStageState({
      status: 'open',
    });

    expect(state).toEqual({
      workflowStage: 'review',
      maxAccessibleIndex: 1,
      completedThroughIndex: -1,
      readOnly: false,
    });
  });

  it('opens an analysed open report in analysis', () => {
    const state = getIncidentManagementStageState({
      status: 'open',
      causes: ['Procedimiento no aplicado'],
      analysis: 'Se revisó el hallazgo.',
    });

    expect(state.workflowStage).toBe('analysis');
    expect(state.completedThroughIndex).toBe(0);
  });

  it('opens an en_proceso report in treatment', () => {
    const state = getIncidentManagementStageState({
      status: 'en_proceso',
    });

    expect(state.workflowStage).toBe('treatment');
    expect(state.maxAccessibleIndex).toBe(2);
    expect(state.completedThroughIndex).toBe(1);
    expect(state.readOnly).toBe(false);
  });

  it('does not complete treatment from closure evidence alone', () => {
    const state = getIncidentManagementStageState({
      status: 'en_proceso',
      closure_evidence: {
        url: '/evidence/test.pdf',
      },
    });

    expect(state.workflowStage).toBe('treatment');
    expect(state.maxAccessibleIndex).toBe(2);
    expect(state.completedThroughIndex).toBe(1);
  });

  it('marks treatment complete before opening closure', () => {
    const state = getIncidentManagementStageState({
      status: 'en_proceso',
      control_measures: [
        'Actualizar procedimiento',
      ],
      training: 'Capacitación realizada',
      deadline: '2026-10-11',
      feedback: 'Trabajador informado',
    });

    expect(state.workflowStage).toBe('closure');
    expect(state.maxAccessibleIndex).toBe(3);
    expect(state.completedThroughIndex).toBe(2);
    expect(state.readOnly).toBe(false);
  });

  it('opens pending_closure in validation', () => {
    const state = getIncidentManagementStageState({
      status: 'pending_closure',
    });

    expect(state.workflowStage).toBe('validation');
    expect(state.maxAccessibleIndex).toBe(4);
    expect(state.completedThroughIndex).toBe(3);
    expect(state.readOnly).toBe(true);
  });

  it('marks the complete flow read-only when closed', () => {
    const state = getIncidentManagementStageState({
      status: 'closed',
    });

    expect(state.workflowStage).toBe('validation');
    expect(state.completedThroughIndex).toBe(4);
    expect(state.readOnly).toBe(true);
  });

  it('limits unknown statuses to review in read-only mode', () => {
    const state = getIncidentManagementStageState({
      status: 'legacy-status',
    });

    expect(state.workflowStage).toBe('review');
    expect(state.maxAccessibleIndex).toBe(0);
    expect(state.readOnly).toBe(true);
  });

  it('allows navigation only to stages enabled by state', () => {
    const state = getIncidentManagementStageState({
      status: 'open',
    });

    expect(
      isIncidentManagementStageAccessible(
        state,
        'review',
      ),
    ).toBe(true);

    expect(
      isIncidentManagementStageAccessible(
        state,
        'analysis',
      ),
    ).toBe(true);

    expect(
      isIncidentManagementStageAccessible(
        state,
        'treatment',
      ),
    ).toBe(false);
  });

  it(
    'keeps previous stages manually accessible while blocking future stages',
    () => {
      const state = getIncidentManagementStageState({
        status: 'en_proceso',
      });

      expect(
        isIncidentManagementStageAccessible(
          state,
          'review',
        ),
      ).toBe(true);

      expect(
        isIncidentManagementStageAccessible(
          state,
          'analysis',
        ),
      ).toBe(true);

      expect(
        isIncidentManagementStageAccessible(
          state,
          'treatment',
        ),
      ).toBe(true);

      expect(
        isIncidentManagementStageAccessible(
          state,
          'closure',
        ),
      ).toBe(false);

      expect(
        isIncidentManagementStageAccessible(
          state,
          'validation',
        ),
      ).toBe(false);
    },
  );

});
