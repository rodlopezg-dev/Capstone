import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routers import users
from app.routers import internal
from app.routers import profile
from dotenv import load_dotenv

load_dotenv()

app = FastAPI(
    title="Users Service - SSO Alloxentric",
    description="Microservicio para la gestión de usuarios y roles Multi-tenant",
    version="1.0.0",
)

# 🌟 Definimos los orígenes explícitos para que funcione con allow_credentials=True
origins = [
    "http://localhost:5173",
        "http://localhost:5174",
        "http://localhost:5175",
        "http://localhost:5176",          # Tu entorno local con Vite
    "http://127.0.0.1:5173",
    "https://gpi-websso.vercel.app"   # Tu app desplegada en Vercel
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://sso-dashboard.alloxentric.com", "https://sso-app.alloxentric.com", "http://localhost:5173", "http://localhost:5174", "http://localhost", "https://localhost", "capacitor://localhost"] + [origin.strip() for origin in os.getenv("CORS_ORIGINS", "").split(",") if origin.strip()],            # 🌟 Usamos la lista explícita aquí
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(users.router)
app.include_router(internal.router)
app.include_router(profile.router)

@app.get("/health", tags=["System"])
def health_check():
    return {"status": "ok", "service": "users-service"}