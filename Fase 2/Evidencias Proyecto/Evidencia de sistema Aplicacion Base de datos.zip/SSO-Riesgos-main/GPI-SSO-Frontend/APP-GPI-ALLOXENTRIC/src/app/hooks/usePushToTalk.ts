/**
 * usePushToTalk.ts
 * Hook de reconocimiento de voz para Android (Capacitor) y web.
 *
 * Android: usa @capacitor-community/speech-recognition (motor nativo Google)
 * Web:     usa la Web Speech API como fallback (Chrome/Edge)
 *
 * Instalación del plugin nativo:
 *   npm install @capacitor-community/speech-recognition
 *   npx cap sync android
 *
 * AndroidManifest.xml — ya incluido en el archivo generado:
 *   <uses-permission android:name="android.permission.RECORD_AUDIO" />
 */

import { useState, useRef, useCallback } from 'react';
import { Capacitor }                     from '@capacitor/core';

// Importación dinámica para evitar error si el plugin no está instalado aún
let SpeechRecognitionPlugin: any = null;
if (Capacitor.isNativePlatform()) {
  try {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    SpeechRecognitionPlugin = require('@capacitor-community/speech-recognition').SpeechRecognition;
  } catch {
    console.warn('[PushToTalk] Plugin nativo no instalado, usando fallback web');
  }
}

type Language = 'es' | 'en' | 'fr';

const LANG_MAP: Record<Language, string> = {
  es: 'es-ES',
  en: 'en-US',
  fr: 'fr-FR',
};

interface UsePushToTalkOptions {
  language:    Language;
  onTranscript: (text: string) => void;  // recibe el texto para agregarlo
  onError?:    (msg: string) => void;
}

interface UsePushToTalkReturn {
  isRecording:  boolean;
  startRecording: () => Promise<void>;
  stopRecording:  () => Promise<void>;
  // Handlers para botón push-to-talk (onPointerDown / onPointerUp)
  pressHandlers: {
    onPointerDown: (e: React.PointerEvent) => void;
    onPointerUp:   (e: React.PointerEvent) => void;
    onPointerLeave:(e: React.PointerEvent) => void; // seguridad: suelta si el dedo sale
  };
}

export function usePushToTalk({
  language,
  onTranscript,
  onError,
}: UsePushToTalkOptions): UsePushToTalkReturn {

  const [isRecording, setIsRecording]   = useState(false);
  const webRecognitionRef               = useRef<any>(null);
  const isNative                        = Capacitor.isNativePlatform() && !!SpeechRecognitionPlugin;

  // ── Android nativo ────────────────────────────────────────────────────────
  const startNative = useCallback(async () => {
    try {
      // Solicitar permiso de micrófono
      const perm = await SpeechRecognitionPlugin.requestPermissions();
      if (perm.speechRecognition !== 'granted') {
        onError?.('Permiso de micrófono denegado. Habilítalo en Configuración > Apps > Vigía Industrial.');
        return;
      }

      setIsRecording(true);
      await SpeechRecognitionPlugin.start({
        language:          LANG_MAP[language],
        maxResults:        5,
        prompt:            'Describe el hallazgo...',
        partialResults:    true,   // muestra texto mientras habla
        popup:             false,  // sin diálogo del sistema (más limpio)
      });

      // Escuchar resultados parciales en tiempo real
      await SpeechRecognitionPlugin.addListener('partialResults', (data: { matches: string[] }) => {
        // No agregamos aún — esperamos al resultado final para no duplicar
      });

      // Resultado final
      await SpeechRecognitionPlugin.addListener('listeningState', (state: { status: string }) => {
        if (state.status === 'stopped') {
          setIsRecording(false);
        }
      });

    } catch (err: any) {
      setIsRecording(false);
      onError?.(err?.message ?? 'Error al iniciar reconocimiento de voz');
    }
  }, [language, onError]);

  const stopNative = useCallback(async () => {
    try {
      const result = await SpeechRecognitionPlugin.stop();
      // El plugin devuelve { matches: string[] } — tomamos el de mayor confianza
      const matches: string[] = result?.matches ?? [];
      if (matches.length > 0 && matches[0].trim()) {
        onTranscript(matches[0].trim());
      }
      await SpeechRecognitionPlugin.removeAllListeners();
    } catch (err: any) {
      onError?.(err?.message ?? 'Error al detener reconocimiento');
    } finally {
      setIsRecording(false);
    }
  }, [onTranscript, onError]);

  // ── Web fallback (Chrome / Edge) ──────────────────────────────────────────
  const startWeb = useCallback(() => {
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SR) {
      onError?.('Tu navegador no soporta reconocimiento de voz. Usa Chrome o Edge.');
      return;
    }

    const recognition = new SR();
    recognition.lang           = LANG_MAP[language];
    recognition.continuous     = true;
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    recognition.onresult = (event: any) => {
      const transcript = Array.from(event.results as SpeechRecognitionResultList)
        .map((r: any) => (r as SpeechRecognitionResult)[0].transcript)
        .join(' ')
        .trim();
      if (transcript) onTranscript(transcript);
    };

    recognition.onerror = (event: any) => {
      if (event.error !== 'aborted') {
        onError?.(event.error === 'not-allowed'
          ? 'Permiso de micrófono denegado'
          : `Error de voz: ${event.error}`
        );
      }
      setIsRecording(false);
    };

    recognition.onend = () => setIsRecording(false);

    webRecognitionRef.current = recognition;
    recognition.start();
    setIsRecording(true);
  }, [language, onTranscript, onError]);

  const stopWeb = useCallback(() => {
    webRecognitionRef.current?.stop();
    webRecognitionRef.current = null;
    setIsRecording(false);
  }, []);

  // ── API pública ───────────────────────────────────────────────────────────
  const startRecording = useCallback(async () => {
    if (isRecording) return;
    isNative ? await startNative() : startWeb();
  }, [isRecording, isNative, startNative, startWeb]);

  const stopRecording = useCallback(async () => {
    if (!isRecording) return;
    isNative ? await stopNative() : stopWeb();
  }, [isRecording, isNative, stopNative, stopWeb]);

  // ── Push-to-talk handlers ────────────────────────────────────────────────
  const pressHandlers = {
    onPointerDown: (e: React.PointerEvent) => {
      e.preventDefault(); // evita scroll accidental en mobile
      (e.target as HTMLElement).setPointerCapture(e.pointerId);
      startRecording();
    },
    onPointerUp: (e: React.PointerEvent) => {
      e.preventDefault();
      stopRecording();
    },
    onPointerLeave: (e: React.PointerEvent) => {
      // Si el dedo se va del botón mientras graba, detener
      if (isRecording) stopRecording();
    },
  };

  return { isRecording, startRecording, stopRecording, pressHandlers };
}
