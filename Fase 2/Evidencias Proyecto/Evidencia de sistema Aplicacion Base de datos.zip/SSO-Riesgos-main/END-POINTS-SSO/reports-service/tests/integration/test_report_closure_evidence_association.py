"""Integration tests for SCRUM-86 evidence association."""

import pytest
from fastapi.testclient import TestClient

from app.main import app
from app.routers import rt_reports
from tests.integration.test_report_category import FakeDB


REPORT_ID = "report_scrum86"
TENANT_A = "tenant_a"
TENANT_B = "tenant_b"
SUPERVISOR_ID = "supervisor_scrum86"

ORIGINAL_EVIDENCE = (
    "https://example.test/original.jpg"
)



@pytest.fixture(autouse=True)
def stable_evidence_read_url(
    monkeypatch,
):
    """
    Estos tests validan asociación e idempotencia.

    La generación criptográfica del SAS se prueba de forma
    aislada en test_azure_blob_service.py.
    """
    monkeypatch.setattr(
        rt_reports,
        "generate_read_url",
        lambda reference, client_id, report_id: reference,
    )


def report_fixture():
    return {
        "report_id": REPORT_ID,
        "client_id": TENANT_A,
        "status": "en_proceso",
        "evidences": [ORIGINAL_EVIDENCE],
        "image_url": ORIGINAL_EVIDENCE,
    }


def evidence_fixture(
    *,
    client_id=TENANT_A,
    report_id=REPORT_ID,
    uploaded_by=SUPERVISOR_ID,
):
    base = rt_reports.BLOB_BASE_URL.rstrip("/")

    return {
        "url": (
            f"{base}/reports/"
            f"{client_id}/{report_id}/"
            "closure-evidence/test.pdf"
        ),
        "filename": "cierre.pdf",
        "content_type": "application/pdf",
        "size": 1024,
        "uploaded_by": uploaded_by,
        "uploaded_at": (
            "2026-09-21T20:00:00+00:00"
        ),
    }


@pytest.fixture
def fake_db():
    return FakeDB([report_fixture()])


@pytest.fixture
def client_factory(fake_db, monkeypatch):
    clients = []

    def _factory(
        *,
        role="supervisor",
        client_id=TENANT_A,
        user_id=SUPERVISOR_ID,
    ):
        app.dependency_overrides[
            rt_reports.get_db
        ] = lambda: fake_db

        monkeypatch.setattr(
            rt_reports,
            "get_current_user",
            lambda credentials: {
                "user_id": user_id,
                "client_id": client_id,
                "role": role,
            },
        )

        client = TestClient(app)
        clients.append(client)
        return client

    yield _factory

    for client in clients:
        client.close()

    app.dependency_overrides.clear()


def associate(client, evidence=None):
    return client.put(
        (
            f"/v1/reports/{REPORT_ID}"
            "/closure-evidence"
        ),
        headers={
            "Authorization": "Bearer fake_token",
        },
        json=evidence or evidence_fixture(),
    )


def test_associates_reference_without_changing_report(
    client_factory,
    fake_db,
):
    response = associate(client_factory())

    assert response.status_code == 200

    body = response.json()
    assert body["ok"] is True

    evidence = body["closure_evidence"]
    assert evidence == evidence_fixture()

    saved = fake_db["reports"].documents[0]

    assert saved["closure_evidence"] == evidence

    assert saved["status"] == "en_proceso"
    assert saved["evidences"] == [
        ORIGINAL_EVIDENCE
    ]
    assert saved["image_url"] == ORIGINAL_EVIDENCE

    logs = fake_db["activity_log"].documents

    assert len(logs) == 1
    assert (
        logs[0]["action"]
        == "closure_evidence_associated"
    )
    assert logs[0]["client_id"] == TENANT_A
    assert logs[0]["report_id"] == REPORT_ID
    assert logs[0]["user_id"] == SUPERVISOR_ID


def test_association_is_idempotent(
    client_factory,
    fake_db,
):
    client = client_factory()
    evidence = evidence_fixture()

    first = associate(client, evidence)
    second = associate(client, evidence)

    assert first.status_code == 200
    assert second.status_code == 200

    assert (
        fake_db["reports"]
        .documents[0]["closure_evidence"]
        == evidence
    )

    logs = fake_db["activity_log"].documents
    assert len(logs) == 1


def test_worker_cannot_associate(
    client_factory,
):
    response = associate(
        client_factory(role="worker")
    )

    assert response.status_code == 403


def test_other_tenant_cannot_associate(
    client_factory,
):
    evidence = evidence_fixture(
        client_id=TENANT_B
    )

    response = associate(
        client_factory(client_id=TENANT_B),
        evidence,
    )

    assert response.status_code == 404


def test_rejects_reference_from_other_tenant(
    client_factory,
):
    evidence = evidence_fixture(
        client_id=TENANT_B
    )

    response = associate(
        client_factory(client_id=TENANT_A),
        evidence,
    )

    assert response.status_code == 422


def test_rejects_reference_from_other_report(
    client_factory,
):
    evidence = evidence_fixture(
        report_id="other_report"
    )

    response = associate(
        client_factory(),
        evidence,
    )

    assert response.status_code == 422


def test_rejects_different_uploader(
    client_factory,
):
    evidence = evidence_fixture(
        uploaded_by="other_user"
    )

    response = associate(
        client_factory(),
        evidence,
    )

    assert response.status_code == 422


def test_rejects_invalid_metadata(
    client_factory,
):
    evidence = evidence_fixture()
    evidence["size"] = 0

    response = associate(
        client_factory(),
        evidence,
    )

    assert response.status_code == 422
