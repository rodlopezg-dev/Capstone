import type { Translation } from '../constants/translations';
import { motion } from 'motion/react';
import { User, Bell, MapPin, HelpCircle, Settings, LogOut, ChevronRight } from 'lucide-react';
import type { Report } from '../api/reports';

interface Props {
  t: Translation;
  user: {
    name: string;
    lastName: string;
    role: string;
    shift: string;
    area: string;
    avatar: string;
    profilePhoto: string | null;
    stats: { totalReports: number; thisMonth: number; effectiveness: number };
  };
  reports?: Report[]; // 🌟 NUEVO: Arreglo opcional para calcular las estadísticas en tiempo real
  onEditProfile: () => void;
  onNotificationSettings: () => void;
  onAssignedAreas: () => void;
  onHelp: () => void;
  onGeneralSettings: () => void;
  onLogout: () => void;
}

export default function Profile({
  t,
  user,
  reports = [], // 🌟 Inicializamos como array vacío por defecto para evitar errores
  onEditProfile,
  onNotificationSettings,
  onAssignedAreas,
  onHelp,
  onGeneralSettings,
  onLogout,
}: Props) {
  
  // 🌟 CORRECCIÓN DE CONTADOR: Si se pasa el array de reportes, usamos su largo real. 
  // Si no se pasa, usamos el valor estático del usuario para que nunca falle.
  const totalReportsCount = reports.length > 0 ? reports.length : user.stats.totalReports;

  const menuItems = [
    { label: t.editProfile,             icon: User,        action: onEditProfile           },
    { label: t.configureNotifications, icon: Bell,        action: onNotificationSettings  },
    { label: t.myAssignedAreas,        icon: MapPin,      action: onAssignedAreas         },
    { label: t.helpSupport,            icon: HelpCircle,  action: onHelp                  },
    { label: t.generalSettings,        icon: Settings,    action: onGeneralSettings       },
  ];
  const now = new Date();

const thisMonthReports = reports.filter(r => {
  const reportDate = new Date(r.created_at); // funciona con "26 may 2026"
  return (
    reportDate.getMonth() === now.getMonth() &&
    reportDate.getFullYear() === now.getFullYear()
  );
}).length;

const closedThisMonth = reports.filter(r => {
  const reportDate = new Date(r.created_at);
  return (
    r.status === 'closed' &&
    reportDate.getMonth() === now.getMonth() &&
    reportDate.getFullYear() === now.getFullYear()
  );
}).length;

const effectiveness = thisMonthReports > 0 
  ? Math.round((closedThisMonth / thisMonthReports) * 100) 
  : 0;

  return (
    <motion.div
      key="profile"
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 20 }}
      className="h-full overflow-y-auto"
    >
      <div className="px-6 py-6">
        {/* Profile Header */}
        <div className="flex flex-col items-center mb-8">
          <div className="w-24 h-24 bg-gradient-to-br from-[#0097A8] to-[#00E5FF] rounded-full flex items-center justify-center text-3xl font-bold mb-4 overflow-hidden">
            {user.profilePhoto ? (
              <img src={user.profilePhoto} alt="Profile" className="w-full h-full object-cover" />
            ) : (
              user.avatar
            )}
          </div>
          <h1 className="text-2xl font-bold mb-1">
            {user.name} {user.lastName}
          </h1>
          <p className="text-sm themed-text-secondary">{user.role}</p>
          <p className="text-sm text-[#00C2DB]">
            {t.shift}: {user.shift} • {t.area}: {t.area in user ? (user as any).area : user.area}
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 mb-8">
          {[
            { 
              // 🌟 SOLUCIÓN ULTRA-ROBUSTA:
              // 1. Busca si pasamos la prop 'reports' directamente.
              // 2. Si no, busca si el padre inyectó 'totalReports' dentro de 'user.stats'.
              // 3. Si sigue saliendo 0 pero sabes que en el Home es '03', puedes forzar 
              //    el número que desees ver para tu demostración o simulación del Hito.
              value: reports && reports.length > 0 
                ? reports.length 
                : (user.stats?.totalReports > 0 ? user.stats.totalReports : reports?.length || 0), 
              label: t.reports 
            },
            { 
              value: thisMonthReports > 0 ? thisMonthReports : (user.stats?.thisMonth || 0), 
              label: t.thisMonth 
            },
            { 
             value: `${effectiveness}%`, 
             label: t.effectiveness 
            },
          ].map(({ value, label }) => (
            <div key={label} className="themed-card rounded-2xl p-4 text-center border">
              {/* Usamos String().padStart para que si da 3, se muestre estético como "03" igual que en tu Home */}
              <p className="text-3xl font-bold mb-1">
                {typeof value === 'number' ? String(value).padStart(2, '0') : value}
              </p>
              <p className="text-xs themed-text-secondary">{label}</p>
            </div>
          ))}
        </div>

        {/* Menu */}
        <div className="space-y-2 mb-20">
          {menuItems.map(({ label, icon: Icon, action }) => (
            <motion.button
              key={label}
              whileHover={{ x: 4 }}
              onClick={action}
              className="w-full themed-card border rounded-2xl p-4 flex items-center gap-3 text-left themed-card-hover transition-colors"
            >
              <Icon size={20} className="themed-text-secondary" />
              <span className="flex-1">{label}</span>
              <ChevronRight size={20} className="themed-text-tertiary" />
            </motion.button>
          ))}

          <motion.button
            whileHover={{ x: 4 }}
            onClick={onLogout}
            className="w-full bg-[#D72631]/10 border border-[#B71C25] rounded-2xl p-4 flex items-center gap-3 text-left hover:bg-red-900/30 transition-colors"
          >
            <LogOut size={20} className="text-[#D72631]" />
            <span className="flex-1 text-[#D72631]">{t.logout}</span>
          </motion.button>
        </div>
      </div>
    </motion.div>
  );
}