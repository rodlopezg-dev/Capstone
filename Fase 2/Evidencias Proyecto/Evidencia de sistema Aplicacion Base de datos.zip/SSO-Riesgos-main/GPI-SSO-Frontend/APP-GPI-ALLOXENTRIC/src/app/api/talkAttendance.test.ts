import {
  beforeEach,
  describe,
  expect,
  it,
  vi,
} from 'vitest';

import {
  authenticatedFetch,
} from './client';

import {
  fetchAttendanceSheetBlob,
  uploadAttendanceSheetRequest,
} from './talkAttendance';

vi.mock('./client', () => ({
  authenticatedFetch: vi.fn(),
}));

const mockedFetch = vi.mocked(
  authenticatedFetch,
);

describe('talk attendance sheet API', () => {
  beforeEach(() => {
    mockedFetch.mockReset();
  });

  it('uploads sheet with talk metadata', async () => {
    mockedFetch.mockResolvedValue(
      new Response(
        JSON.stringify({
          ok: true,
          attendance_id: 'att-1',
        }),
        {
          status: 200,
          headers: {
            'Content-Type': 'application/json',
          },
        },
      ),
    );

    const file = new File(
      ['imagen'],
      'asistencia.jpg',
      {
        type: 'image/jpeg',
      },
    );

    await uploadAttendanceSheetRequest({
      apiBase: '/api/talks',
      talkId: 'talk-1',
      topic: 'Charla uno',
      date: '2026-09-28',
      file,
    });

    expect(mockedFetch).toHaveBeenCalledTimes(1);

    const [url, options] =
      mockedFetch.mock.calls[0];

    expect(url).toBe(
      '/api/talks/v1/attendance',
    );

    expect(options?.method).toBe('POST');

    const body = options?.body as FormData;

    expect(body.get('talk_id')).toBe('talk-1');
    expect(body.get('topic')).toBe('Charla uno');
    expect(body.get('date')).toBe('2026-09-28');

    const uploaded = body.get('file');

    expect(uploaded).toBeInstanceOf(File);
  });

  it('surfaces backend duplicate message', async () => {
    mockedFetch.mockResolvedValue(
      new Response(
        JSON.stringify({
          detail:
            'Esta charla ya tiene una hoja de asistencia adjunta.',
        }),
        {
          status: 409,
          headers: {
            'Content-Type': 'application/json',
          },
        },
      ),
    );

    const file = new File(
      ['imagen'],
      'asistencia.jpg',
      {
        type: 'image/jpeg',
      },
    );

    await expect(
      uploadAttendanceSheetRequest({
        apiBase: '/api/talks',
        talkId: 'talk-1',
        topic: 'Charla uno',
        date: '2026-09-28',
        file,
      }),
    ).rejects.toThrow(
      'Esta charla ya tiene una hoja de asistencia adjunta.',
    );
  });

  it('downloads attendance sheet through authenticated fetch', async () => {
    const blob = new Blob(
      ['imagen'],
      {
        type: 'image/jpeg',
      },
    );

    mockedFetch.mockResolvedValue(
      new Response(blob, {
        status: 200,
      }),
    );

    const result =
      await fetchAttendanceSheetBlob(
        '/api/talks',
        'att 1',
      );

    expect(mockedFetch).toHaveBeenCalledWith(
      '/api/talks/v1/attendance/att%201/file',
    );

    expect(result.type).toBe('image/jpeg');
  });
});
