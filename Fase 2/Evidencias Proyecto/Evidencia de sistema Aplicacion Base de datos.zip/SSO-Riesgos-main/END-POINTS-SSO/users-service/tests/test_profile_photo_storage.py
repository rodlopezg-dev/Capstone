import unittest

from app.services.profile_photo_storage import (
    EmptyProfilePhoto,
    MAX_PROFILE_PHOTO_BYTES,
    ProfilePhotoTooLarge,
    UnsupportedProfilePhotoType,
    validate_profile_photo,
)


class ProfilePhotoStorageTests(
    unittest.TestCase
):
    def test_accepts_valid_jpeg(self):
        data = (
            b"\xff\xd8\xff"
            + b"jpeg-data"
        )

        self.assertEqual(
            validate_profile_photo(
                "image/jpeg",
                data,
            ),
            "jpg",
        )

    def test_accepts_valid_png(self):
        data = (
            b"\x89PNG\r\n\x1a\n"
            + b"png-data"
        )

        self.assertEqual(
            validate_profile_photo(
                "image/png",
                data,
            ),
            "png",
        )

    def test_accepts_valid_webp(self):
        data = (
            b"RIFF"
            + b"\x00\x00\x00\x00"
            + b"WEBP"
            + b"webp-data"
        )

        self.assertEqual(
            validate_profile_photo(
                "image/webp",
                data,
            ),
            "webp",
        )

    def test_rejects_unsupported_type(self):
        with self.assertRaises(
            UnsupportedProfilePhotoType
        ):
            validate_profile_photo(
                "application/pdf",
                b"%PDF-test",
            )

    def test_rejects_spoofed_content_type(self):
        with self.assertRaises(
            UnsupportedProfilePhotoType
        ):
            validate_profile_photo(
                "image/png",
                b"this-is-not-a-png",
            )

    def test_rejects_empty_photo(self):
        with self.assertRaises(
            EmptyProfilePhoto
        ):
            validate_profile_photo(
                "image/png",
                b"",
            )

    def test_rejects_too_large_photo(self):
        data = (
            b"\x89PNG\r\n\x1a\n"
            + b"x"
            * MAX_PROFILE_PHOTO_BYTES
        )

        with self.assertRaises(
            ProfilePhotoTooLarge
        ):
            validate_profile_photo(
                "image/png",
                data,
            )


if __name__ == "__main__":
    unittest.main()
