"""Integration tests for SCRUM-85 evidence upload."""

import pytest
from fastapi.testclient import TestClient

from app.main import app
from app.routers import rt_reports
from tests.integration.test_report_category import FakeDB


REPORT_ID = "report_scrum85"
TENANT_A = "tenant_a"
TENANT_B = "tenant_b"
SUPERVISOR_ID = "supervisor_scrum85"


def report_fixture():
    return {
        "report_id": REPORT_ID,
        "client_id": TENANT_A,
        "status": "open",
        "evidences": [],
    }


@pytest.fixture
def fake_db():
    return FakeDB([report_fixture()])


@pytest.fixture
def client_factory(fake_db, monkeypatch):
    clients = []

    def _factory(
        *,
        role="supervisor",
        client_id=TENANT_A,
        user_id=SUPERVISOR_ID,
    ):
        app.dependency_overrides[
            rt_reports.get_db
        ] = lambda: fake_db

        monkeypatch.setattr(
            rt_reports,
            "get_current_user",
            lambda credentials: {
                "user_id": user_id,
                "client_id": client_id,
                "role": role,
            },
        )

        client = TestClient(app)
        clients.append(client)
        return client

    yield _factory

    for client in clients:
        client.close()

    app.dependency_overrides.clear()


def test_uploads_jpeg_without_persisting_report(
    client_factory,
    fake_db,
    monkeypatch,
):
    captured = {}

    async def fake_upload(
        file_bytes,
        client_id,
        report_id,
        content_type,
    ):
        captured.update({
            "file_bytes": file_bytes,
            "client_id": client_id,
            "report_id": report_id,
            "content_type": content_type,
        })
        return (
            "/local-evidence/reports/"
            "tenant_a/report_scrum85/"
            "closure-evidence/test.jpg"
        )

    monkeypatch.setattr(
        rt_reports,
        "upload_closure_evidence",
        fake_upload,
    )

    client = client_factory()

    response = client.post(
        (
            f"/v1/reports/{REPORT_ID}"
            "/closure-evidence/upload"
        ),
        headers={
            "Authorization": "Bearer fake_token",
        },
        files={
            "file": (
                "evidencia.jpg",
                b"jpeg-test",
                "image/jpeg",
            )
        },
    )

    assert response.status_code == 200

    data = response.json()
    upload = data["evidence_upload"]

    assert data["ok"] is True
    assert upload["content_type"] == "image/jpeg"
    assert upload["filename"] == "evidencia.jpg"
    assert upload["size"] == len(b"jpeg-test")
    assert upload["url"].endswith(".jpg")

    assert captured == {
        "file_bytes": b"jpeg-test",
        "client_id": TENANT_A,
        "report_id": REPORT_ID,
        "content_type": "image/jpeg",
    }

    report = fake_db["reports"].documents[0]

    assert "closure_evidence" not in report
    assert report["status"] == "open"
    assert report["evidences"] == []


def test_uploads_pdf(
    client_factory,
    monkeypatch,
):
    async def fake_upload(
        file_bytes,
        client_id,
        report_id,
        content_type,
    ):
        assert file_bytes == b"%PDF-test"
        assert client_id == TENANT_A
        assert report_id == REPORT_ID
        assert content_type == "application/pdf"

        return (
            "/local-evidence/reports/"
            "tenant_a/report_scrum85/"
            "closure-evidence/test.pdf"
        )

    monkeypatch.setattr(
        rt_reports,
        "upload_closure_evidence",
        fake_upload,
    )

    response = client_factory().post(
        (
            f"/v1/reports/{REPORT_ID}"
            "/closure-evidence/upload"
        ),
        headers={
            "Authorization": "Bearer fake_token",
        },
        files={
            "file": (
                "cierre.pdf",
                b"%PDF-test",
                "application/pdf",
            )
        },
    )

    assert response.status_code == 200

    upload = response.json()["evidence_upload"]

    assert upload["content_type"] == "application/pdf"
    assert upload["filename"] == "cierre.pdf"
    assert upload["url"].endswith(".pdf")


def test_rejects_unsupported_type(
    client_factory,
):
    response = client_factory().post(
        (
            f"/v1/reports/{REPORT_ID}"
            "/closure-evidence/upload"
        ),
        headers={
            "Authorization": "Bearer fake_token",
        },
        files={
            "file": (
                "evidencia.txt",
                b"not allowed",
                "text/plain",
            )
        },
    )

    assert response.status_code == 415


def test_rejects_empty_file(
    client_factory,
):
    response = client_factory().post(
        (
            f"/v1/reports/{REPORT_ID}"
            "/closure-evidence/upload"
        ),
        headers={
            "Authorization": "Bearer fake_token",
        },
        files={
            "file": (
                "empty.jpg",
                b"",
                "image/jpeg",
            )
        },
    )

    assert response.status_code == 422


def test_rejects_file_over_10_mb(
    client_factory,
):
    oversized = b"x" * (
        rt_reports.MAX_CLOSURE_EVIDENCE_BYTES
        + 1
    )

    response = client_factory().post(
        (
            f"/v1/reports/{REPORT_ID}"
            "/closure-evidence/upload"
        ),
        headers={
            "Authorization": "Bearer fake_token",
        },
        files={
            "file": (
                "large.jpg",
                oversized,
                "image/jpeg",
            )
        },
    )

    assert response.status_code == 413


def test_rejects_worker_role(
    client_factory,
):
    response = client_factory(
        role="worker"
    ).post(
        (
            f"/v1/reports/{REPORT_ID}"
            "/closure-evidence/upload"
        ),
        headers={
            "Authorization": "Bearer fake_token",
        },
        files={
            "file": (
                "evidencia.jpg",
                b"jpeg-test",
                "image/jpeg",
            )
        },
    )

    assert response.status_code == 403


def test_does_not_expose_other_tenant_report(
    client_factory,
):
    response = client_factory(
        client_id=TENANT_B
    ).post(
        (
            f"/v1/reports/{REPORT_ID}"
            "/closure-evidence/upload"
        ),
        headers={
            "Authorization": "Bearer fake_token",
        },
        files={
            "file": (
                "evidencia.jpg",
                b"jpeg-test",
                "image/jpeg",
            )
        },
    )

    assert response.status_code == 404
