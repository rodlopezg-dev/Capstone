from fastapi import APIRouter, Depends, File, HTTPException, UploadFile

from app.dependencies import (
    CurrentUser,
    get_current_user,
    get_db,
)
from app.repositories.user_repo import UserRepository
from app.schemas.user import (
    UserProfileResponse,
    UserProfileUpdate,
)
from app.services.user_service import UserService
from app.services.profile_photo_storage import (
    EmptyProfilePhoto,
    MAX_PROFILE_PHOTO_BYTES,
    ProfilePhotoTooLarge,
    UnsupportedProfilePhotoType,
    delete_profile_photo,
    upload_profile_photo,
    validate_profile_photo,
)


router = APIRouter(
    prefix="/v1/users",
    tags=["User Profile"],
)


def get_user_service(db=Depends(get_db)) -> UserService:
    return UserService(UserRepository(db))


@router.get(
    "/me",
    response_model=UserProfileResponse,
)
async def get_my_profile(
    service: UserService = Depends(get_user_service),
    current_user: CurrentUser = Depends(get_current_user),
):
    return await service.get_user(
        client_id=current_user.client_id,
        user_id=current_user.id,
    )


@router.patch(
    "/me",
    response_model=UserProfileResponse,
)
async def update_my_profile(
    profile_in: UserProfileUpdate,
    service: UserService = Depends(get_user_service),
    current_user: CurrentUser = Depends(get_current_user),
):
    return await service.update_profile(
        client_id=current_user.client_id,
        user_id=current_user.id,
        profile_in=profile_in,
    )

@router.put(
    "/me/photo",
    response_model=UserProfileResponse,
)
async def update_my_profile_photo(
    file: UploadFile = File(...),
    service: UserService = Depends(
        get_user_service
    ),
    current_user: CurrentUser = Depends(
        get_current_user
    ),
):
    content_type = (
        file.content_type or ""
    ).strip().lower()

    if content_type not in {
        "image/jpeg",
        "image/png",
        "image/webp",
    }:
        raise HTTPException(
            status_code=415,
            detail=(
                "La foto debe ser JPEG, "
                "PNG o WebP."
            ),
        )

    file_bytes = await file.read(
        MAX_PROFILE_PHOTO_BYTES + 1
    )

    try:
        validate_profile_photo(
            content_type,
            file_bytes,
        )
    except UnsupportedProfilePhotoType as exc:
        raise HTTPException(
            status_code=415,
            detail=str(exc),
        ) from exc
    except EmptyProfilePhoto as exc:
        raise HTTPException(
            status_code=422,
            detail=str(exc),
        ) from exc
    except ProfilePhotoTooLarge as exc:
        raise HTTPException(
            status_code=413,
            detail=str(exc),
        ) from exc

    current = await service.get_user(
        client_id=current_user.client_id,
        user_id=current_user.id,
    )

    try:
        storage_ref = await upload_profile_photo(
            file_bytes=file_bytes,
            client_id=current_user.client_id,
            user_id=current_user.id,
            content_type=content_type,
        )
    except Exception as exc:
        raise HTTPException(
            status_code=502,
            detail=(
                "No se pudo almacenar "
                "la fotografía de perfil."
            ),
        ) from exc

    try:
        updated = (
            await service.update_profile_photo(
                client_id=current_user.client_id,
                user_id=current_user.id,
                photo_url=storage_ref["url"],
                storage_ref=storage_ref,
            )
        )
    except Exception:
        try:
            await delete_profile_photo(
                storage_ref
            )
        except Exception:
            pass

        raise

    previous_storage = current.get(
        "profile_photo_storage"
    )

    if previous_storage:
        try:
            await delete_profile_photo(
                previous_storage
            )
        except Exception:
            pass

    return updated
