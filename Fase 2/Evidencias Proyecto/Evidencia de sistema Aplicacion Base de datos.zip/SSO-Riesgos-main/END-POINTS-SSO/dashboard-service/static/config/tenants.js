window.VIGIA_TENANTS = [
  {
    name: "Empresa A",
    client_id: "cliente_prueba_123"
  },
  {
    name: "Empresa B",
    client_id: "cliente_prueba_b_123"
  }
];
