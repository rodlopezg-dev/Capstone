"""ASGI contracts for EP-04 without a Mongo connection."""

import os
import unittest
from datetime import datetime, timedelta, timezone

os.environ.setdefault("JWT_SECRET", "ep04-test-secret-0123456789abcdef")
os.environ.setdefault("INTERNAL_API_KEY", "ep04-internal-test-key")

import jwt
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient

from app.config import settings
from app.dependencies import get_db
from app.routers import internal, users


class FakeUsersCollection:
    def __init__(self):
        self.calls = []
        self.user = {
            "user_id": "admin_a", "client_id": "empresa_a",
            "role": "admin", "status": "active",
            "assigned_areas": ["Planta"], "area": "Planta",
            "hashed_password": "must-not-leak",
        }

    async def find_one(self, query, projection=None):
        self.calls.append((query, projection))
        if query != {"user_id": "admin_a", "client_id": "empresa_a"}:
            return None
        return {key: value for key, value in self.user.items()
                if projection is None or projection.get(key) == 1}


class FakeListService:
    def __init__(self):
        self.calls = []

    async def get_all_users(self, client_id):
        self.calls.append(client_id)
        return [{
            "user_id": "admin_a", "client_id": client_id,
            "name": "Admin", "email": "admin@example.com", "role": "admin",
            "assigned_areas": [], "status": "active",
        }]


def bearer(role, client_id="empresa_a"):
    token = jwt.encode({
        "sub": "actor_a", "role": role, "client_id": client_id,
        "type": "access", "exp": datetime.now(timezone.utc) + timedelta(minutes=5),
    }, settings.JWT_SECRET, algorithm=settings.JWT_ALGORITHM)
    return {"Authorization": f"Bearer {token}"}


class Ep04UsersSecurityTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.collection = FakeUsersCollection()
        self.service = FakeListService()
        self.app = FastAPI()
        self.app.include_router(internal.router)
        self.app.include_router(users.router)
        async def inert_db():
            return {"users": self.collection}

        async def inert_list_service():
            return self.service

        self.app.dependency_overrides[get_db] = inert_db
        self.app.dependency_overrides[users.get_user_service] = inert_list_service
        self.client = AsyncClient(transport=ASGITransport(app=self.app), base_url="http://test")

    async def asyncTearDown(self):
        await self.client.aclose()

    async def test_internal_lookup_requires_service_credential_and_scopes_tenant(self):
        body = {"client_id": "empresa_a", "user_id": "admin_a"}
        path = "/v1/internal/users/by-id"
        missing = await self.client.post(path, json=body)
        denied = await self.client.post(path, json=body, headers={"X-Internal-Token": "wrong"})
        self.assertIn(missing.status_code, (401, 422))
        self.assertEqual(denied.status_code, 403)
        self.assertEqual(self.collection.calls, [])

        headers = {"X-Internal-Token": settings.INTERNAL_API_KEY}
        allowed = await self.client.post(path, json=body, headers=headers)
        self.assertEqual(allowed.status_code, 200)
        self.assertEqual(allowed.json()["status"], "active")
        self.assertEqual(self.collection.calls[0][0], body)
        self.assertNotIn("hashed_password", allowed.json())

        foreign = await self.client.post(path, json={"client_id": "empresa_b", "user_id": "admin_a"}, headers=headers)
        self.assertEqual(foreign.status_code, 404)
        self.assertEqual(self.collection.calls[-1][0]["client_id"], "empresa_b")

    async def test_global_list_denies_unscoped_roles_before_repository(self):
        for role in ("jefe de area", "jefe_de_area", "supervisor", "worker", "analyst"):
            with self.subTest(role=role):
                response = await self.client.get("/v1/admin/users/", headers=bearer(role))
                self.assertEqual(response.status_code, 403)
        self.assertEqual(self.service.calls, [])

    async def test_global_list_allows_tenant_administrators(self):
        for role, tenant in (("admin", "empresa_a"), ("sso_manager", "empresa_b")):
            response = await self.client.get("/v1/admin/users/", headers=bearer(role, tenant))
            self.assertEqual(response.status_code, 200)
            self.assertEqual(response.json()[0]["client_id"], tenant)
        self.assertEqual(self.service.calls, ["empresa_a", "empresa_b"])
