"""Integration tests for Reports Service authentication."""

from copy import deepcopy
from datetime import datetime, timedelta, timezone

import jwt
import pytest
from fastapi.testclient import TestClient

from app import dep_reports
from app.main import app
from app.routers import rt_reports


TEST_SECRET = "reports-integration-auth-secret-32-bytes-minimum"
TEST_ALGORITHM = "HS256"
TEST_CLIENT_ID = "tenant_auth_test"


class FakeCursor:
    def __init__(self, documents):
        self.documents = deepcopy(documents)

    def sort(self, field, direction):
        self.documents.sort(
            key=lambda item: item.get(field, ""),
            reverse=direction < 0,
        )
        return self

    def limit(self, amount):
        self.documents = self.documents[:amount]
        return self

    def __aiter__(self):
        self._iterator = iter(self.documents)
        return self

    async def __anext__(self):
        try:
            return next(self._iterator)
        except StopIteration:
            raise StopAsyncIteration


class FakeCollection:
    def __init__(self, documents=None):
        self.documents = deepcopy(documents or [])

    @staticmethod
    def _matches(document, query):
        return all(
            document.get(key) == value
            for key, value in query.items()
        )

    def find(self, query):
        return FakeCursor([
            document
            for document in self.documents
            if self._matches(document, query)
        ])


class FakeDB:
    def __init__(self):
        self.collections = {
            "reports": FakeCollection([
                {
                    "report_id": "report_auth_test",
                    "client_id": TEST_CLIENT_ID,
                    "area_id": "Linea 1",
                    "type": "Acto Inseguro",
                    "description": "Reporte de prueba",
                    "status": "open",
                    "is_iap": False,
                    "reported_by": "user_auth_test",
                    "created_at": "2026-09-28T20:00:00+00:00",
                    "shift": "Dia",
                },
            ]),
            "notifications": FakeCollection(),
            "activity_log": FakeCollection(),
        }

    def __getitem__(self, name):
        if name not in self.collections:
            self.collections[name] = FakeCollection()

        return self.collections[name]


@pytest.fixture
def client(monkeypatch):
    fake_db = FakeDB()

    app.dependency_overrides[
        rt_reports.get_db
    ] = lambda: fake_db

    monkeypatch.setattr(
        dep_reports,
        "JWT_SECRET",
        TEST_SECRET,
    )
    monkeypatch.setattr(
        dep_reports,
        "JWT_ALGORITHM",
        TEST_ALGORITHM,
    )

    with TestClient(app) as test_client:
        yield test_client

    app.dependency_overrides.clear()


def make_access_token(
    expires_delta=timedelta(minutes=5),
):
    return jwt.encode(
        {
            "sub": "user_auth_test",
            "client_id": TEST_CLIENT_ID,
            "role": "admin",
            "exp": datetime.now(timezone.utc)
            + expires_delta,
        },
        TEST_SECRET,
        algorithm=TEST_ALGORITHM,
    )


def test_admin_reports_without_token_returns_401(client):
    response = client.get(
        "/v1/admin/reports",
    )

    assert response.status_code == 401
    assert response.json() == {
        "detail": "Token requerido"
    }


def test_admin_reports_with_invalid_token_returns_401(
    client,
):
    response = client.get(
        "/v1/admin/reports",
        headers={
            "Authorization": "Bearer token-invalido"
        },
    )

    assert response.status_code == 401
    assert response.json() == {
        "detail": "Token requerido"
    }


def test_admin_reports_with_valid_token_returns_200(
    client,
):
    response = client.get(
        "/v1/admin/reports",
        headers={
            "Authorization": (
                "Bearer "
                + make_access_token()
            )
        },
    )

    assert response.status_code == 200

    reports = response.json()

    assert len(reports) == 1
    assert reports[0]["report_id"] == (
        "report_auth_test"
    )
    assert reports[0]["client_id"] == (
        TEST_CLIENT_ID
    )


def test_csv_export_without_token_returns_401(client):
    response = client.get(
        "/v1/export/csv",
    )

    assert response.status_code == 401
    assert response.json() == {
        "detail": "Token requerido"
    }


def test_csv_export_with_valid_token_returns_200(
    client,
):
    response = client.get(
        "/v1/export/csv",
        headers={
            "Authorization": (
                "Bearer "
                + make_access_token()
            )
        },
    )

    assert response.status_code == 200
    assert response.headers[
        "content-type"
    ].startswith("text/csv")
    assert "report_auth_test" in response.text
