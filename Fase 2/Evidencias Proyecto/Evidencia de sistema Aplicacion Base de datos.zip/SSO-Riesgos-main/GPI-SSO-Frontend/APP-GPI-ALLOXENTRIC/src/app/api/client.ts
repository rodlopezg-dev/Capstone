// ─── BASE URLS ────────────────────────────────────────────────────────────────
const AUTH_BASE =
  import.meta.env.VITE_AUTH_API_URL ||
  'http://localhost:8000';

const REPORTS_BASE =
  import.meta.env.VITE_REPORTS_API_URL ||
  'http://localhost:8001';

const INCIDENTS_BASE =
  import.meta.env.VITE_INCIDENTS_API_URL ||
  'http://localhost:8002';

const WORKERS_BASE =
  import.meta.env.VITE_WORKERS_API_URL ||
  'http://localhost:8005';

const ALERTS_BASE =
  import.meta.env.VITE_ALERTS_API_URL ||
  'http://localhost:8007';

const USERS_BASE =
  import.meta.env.VITE_USERS_API_URL ||
  'http://localhost:8082';

// ─── AUTH STORAGE ─────────────────────────────────────────────────────────────
const ACCESS_TOKEN_KEY =
  'sso_token';

const REFRESH_TOKEN_KEY =
  'sso_refresh_token';

const SESSION_KEY =
  'vigia_session';

export const
  AUTH_SESSION_INVALIDATED_EVENT =
    'vigia:session-invalidated';

export const getToken = (): string | null =>
  localStorage.getItem(
    ACCESS_TOKEN_KEY,
  );

export const getRefreshToken =
  (): string | null =>
    localStorage.getItem(
      REFRESH_TOKEN_KEY,
    );

export const setToken = (
  token: string,
): void => {
  localStorage.setItem(
    ACCESS_TOKEN_KEY,
    token,
  );
};

export const setRefreshToken = (
  token: string,
): void => {
  localStorage.setItem(
    REFRESH_TOKEN_KEY,
    token,
  );
};

export const setAuthTokens = (
  accessToken: string,
  refreshToken: string,
): void => {
  setToken(accessToken);
  setRefreshToken(refreshToken);
};

export const clearToken = (): void => {
  localStorage.removeItem(
    ACCESS_TOKEN_KEY,
  );
};

export const clearRefreshToken =
  (): void => {
    localStorage.removeItem(
      REFRESH_TOKEN_KEY,
    );
  };

export const clearAuthTokens =
  (): void => {
    clearToken();
    clearRefreshToken();
  };

export function invalidateAuthSession(): void {
  clearAuthTokens();

  localStorage.removeItem(
    SESSION_KEY,
  );

  if (
    typeof window !== 'undefined'
  ) {
    window.dispatchEvent(
      new Event(
        AUTH_SESSION_INVALIDATED_EVENT,
      ),
    );
  }
}

// ─── TIPOS ────────────────────────────────────────────────────────────────────
interface FetchOptions
  extends RequestInit {
  base?:
    | 'auth'
    | 'reports'
    | 'incidents'
    | 'workers'
    | 'alerts'
    | 'users';

  /**
   * false para endpoints públicos como login.
   */
  auth?: boolean;
}

interface RefreshResponse {
  access_token: string;
  refresh_token?: string;
}

type RefreshResult =
  | 'refreshed'
  | 'invalid'
  | 'unavailable';

export class ApiError
  extends Error {
  constructor(
    public status: number,
    message: string,
  ) {
    super(message);
  }
}

// ─── REFRESH SINGLE-FLIGHT ────────────────────────────────────────────────────
let refreshPromise:
  Promise<RefreshResult> | null =
    null;

async function performRefresh():
Promise<RefreshResult> {
  const refreshToken =
    getRefreshToken();

  if (!refreshToken) {
    invalidateAuthSession();
    return 'invalid';
  }

  try {
    const response = await fetch(
      AUTH_BASE + '/v1/auth/refresh',
      {
        method: 'POST',
        headers: {
          'Content-Type':
            'application/json',
        },
        body: JSON.stringify({
          refresh_token:
            refreshToken,
        }),
      },
    );

    if (!response.ok) {
      // Un 4xx desde el endpoint de
      // refresh significa que la
      // credencial ya no sirve.
      if (
        response.status === 400 ||
        response.status === 401 ||
        response.status === 403 ||
        response.status === 422
      ) {
        invalidateAuthSession();
        return 'invalid';
      }

      // Un 5xx no demuestra que la
      // sesión sea inválida.
      return 'unavailable';
    }

    const data = (
      await response
        .json()
        .catch(() => null)
    ) as RefreshResponse | null;

    if (!data?.access_token) {
      return 'unavailable';
    }

    setToken(
      data.access_token,
    );

    if (data.refresh_token) {
      setRefreshToken(
        data.refresh_token,
      );
    }

    return 'refreshed';
  } catch {
    // Una falla de red NO invalida
    // automáticamente la sesión.
    return 'unavailable';
  }
}

async function refreshSession():
Promise<RefreshResult> {
  if (refreshPromise) {
    return refreshPromise;
  }

  const current =
    performRefresh();

  refreshPromise =
    current;

  try {
    return await current;
  } finally {
    if (
      refreshPromise === current
    ) {
      refreshPromise = null;
    }
  }
}

function withAuthorization(
  options: RequestInit,
  token: string | null,
  force = false,
): RequestInit {
  const headers =
    new Headers(
      options.headers,
    );

  if (token) {
    if (
      force ||
      !headers.has(
        'Authorization',
      )
    ) {
      headers.set(
        'Authorization',
        `Bearer ${token}`,
      );
    }
  } else if (force) {
    headers.delete(
      'Authorization',
    );
  }

  return {
    ...options,
    headers,
  };
}

// ─── AUTHENTICATED FETCH ──────────────────────────────────────────────────────
export async function authenticatedFetch(
  input: RequestInfo | URL,
  options: RequestInit = {},
): Promise<Response> {
  const tokenBefore =
    getToken();

  const initialResponse =
    await fetch(
      input,
      withAuthorization(
        options,
        tokenBefore,
        true,
      ),
    );

  if (
    initialResponse.status !== 401
  ) {
    return initialResponse;
  }

  /*
   * Otra request pudo haber renovado
   * el JWT mientras esta estaba en
   * vuelo. Si ya cambió, reintentamos
   * directamente sin pedir otro refresh.
   */
  const latestToken =
    getToken();

  if (
    latestToken &&
    latestToken !== tokenBefore
  ) {
    const retryResponse =
      await fetch(
        input,
        withAuthorization(
          options,
          latestToken,
          true,
        ),
      );

    if (
      retryResponse.status === 401
    ) {
      invalidateAuthSession();
    }

    return retryResponse;
  }

  const refreshResult =
    await refreshSession();

  if (
    refreshResult !==
    'refreshed'
  ) {
    return initialResponse;
  }

  const retryResponse =
    await fetch(
      input,
      withAuthorization(
        options,
        getToken(),
        true,
      ),
    );

  /*
   * Si incluso el access token recién
   * emitido recibe 401, la sesión ya
   * no es recuperable.
   */
  if (
    retryResponse.status === 401
  ) {
    invalidateAuthSession();
  }

  return retryResponse;
}

// ─── API FETCH ────────────────────────────────────────────────────────────────
export async function apiFetch<T>(
  path: string,
  options: FetchOptions = {},
): Promise<T> {
  const {
    base = 'reports',
    auth = true,
    ...fetchOptions
  } = options;

  const baseUrl =
    base === 'auth'
      ? AUTH_BASE
      : base === 'incidents'
        ? INCIDENTS_BASE
        : base === 'workers'
          ? WORKERS_BASE
          : base === 'alerts'
            ? ALERTS_BASE
            : base === 'users'
              ? USERS_BASE
              : REPORTS_BASE;

  const headers =
    new Headers(
      fetchOptions.headers,
    );

  if (
    !(
      fetchOptions.body
      instanceof FormData
    ) &&
    !headers.has(
      'Content-Type',
    )
  ) {
    headers.set(
      'Content-Type',
      'application/json',
    );
  }

  const requestOptions = {
    ...fetchOptions,
    headers,
  };

  const response =
    auth
      ? await authenticatedFetch(
          `${baseUrl}${path}`,
          requestOptions,
        )
      : await fetch(
          `${baseUrl}${path}`,
          requestOptions,
        );

  if (!response.ok) {
    const detail =
      await response
        .json()
        .catch(() => ({
          detail:
            response.statusText,
        }));

    throw new ApiError(
      response.status,
      detail?.detail ??
        response.statusText,
    );
  }

  if (
    response.status === 204
  ) {
    return undefined as T;
  }

  return response.json() as Promise<T>;
}
