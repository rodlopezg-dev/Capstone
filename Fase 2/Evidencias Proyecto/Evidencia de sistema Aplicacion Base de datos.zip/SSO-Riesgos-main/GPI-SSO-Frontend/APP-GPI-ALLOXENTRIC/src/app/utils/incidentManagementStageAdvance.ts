import {
  isIncidentManagementStageAccessible,
  type IncidentManagementStageId,
  type IncidentManagementStageState,
} from './incidentManagementStages';

export function getIncidentManagementStageAfterSave(
  currentStage: IncidentManagementStageId,
  successful: boolean,
  state: IncidentManagementStageState,
): IncidentManagementStageId {
  if (!successful) {
    return currentStage;
  }

  let nextStage = currentStage;

  switch (currentStage) {
    case 'review':
      nextStage = 'analysis';
      break;

    case 'analysis':
      nextStage = 'treatment';
      break;

    case 'treatment':
      nextStage = 'closure';
      break;

    default:
      return currentStage;
  }

  return isIncidentManagementStageAccessible(
    state,
    nextStage,
  )
    ? nextStage
    : currentStage;
}
