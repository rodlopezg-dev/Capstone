export const SpeechRecognition = {
  available: () => Promise.resolve({ available: false }),
  start: () => Promise.resolve(),
  stop: () => Promise.resolve(),
  addListener: () => ({ remove: () => {} }),
};
