
  # WEB (copia)

  This is a code bundle for WEB (copia). The original project is available at https://www.figma.com/design/AGkUlN7mEaonN8ACKnh5WI/WEB--copia-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  