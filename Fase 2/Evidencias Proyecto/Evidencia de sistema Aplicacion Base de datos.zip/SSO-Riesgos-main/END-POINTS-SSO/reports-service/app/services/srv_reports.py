import ulid
from datetime import datetime
from app.repositories.rep_reports import ReportRepository
from app.schemas.scm_reports import ReportCreate
from app.services.azure_blob_service import upload_image
import httpx, os
from pymongo.errors import DuplicateKeyError

STATUS_LABELS = {
    "open":      "Enviado",
    "reviewing": "En Revisión",
    "assigned":  "Acción Asignada",
    "en_proceso": "En Proceso",
    "pending_closure": "Petición de Cierre",
    "closed":    "Cerrado",
}


class ReportService:
    def __init__(
        self,
        repository: ReportRepository,
        manager_repository=None,
    ):
        self.repository = repository
        self.manager_repository = manager_repository

    # ─── REPORTS ──────────────────────────────────────────────────────────────

    async def create_report(
        self,
        client_id: str,
        report_in: ReportCreate,
        user_id: str,
        file_bytes: bytes,
        idempotency_key: str | None = None,
    ) -> str:
        if idempotency_key:
            await self.repository.ensure_indexes()

            existing = await self.repository.get_by_idempotency_key(
                client_id,
                user_id,
                idempotency_key,
            )

            if existing:
                return existing["report_id"]

        # ID incremental
        last = await self.repository.db["reports"].find_one(
            {"client_id": client_id},
            sort=[("seq_id", -1)],
            projection={"seq_id": 1}
        )
        seq = (last.get("seq_id", 0) if last else 0) + 1
        report_id = str(seq)
        
        image_url = None
        if file_bytes and len(file_bytes) > 0:
            image_url = await upload_image(
                file_bytes,
                client_id,
                report_id,
            )

        report_data = report_in.model_dump()
        current_time_iso = datetime.utcnow().isoformat()

        report_data.update({
            "report_id":   report_id,
            "seq_id":      seq,
            "client_id":   client_id,
            "reported_by": user_id,
            "image_url":   image_url,
            "evidences":   [image_url] if image_url else [],
            "created_at":  current_time_iso,
            "status":      "open",
            "timeline": {
                "sent": current_time_iso,
            },
        })

        if idempotency_key:
            report_data["idempotency_key"] = idempotency_key

        try:
            await self.repository.save(
                client_id,
                report_id,
                report_data,
            )
        except DuplicateKeyError:
            if not idempotency_key:
                raise

            existing = await self.repository.get_by_idempotency_key(
                client_id,
                user_id,
                idempotency_key,
            )

            if existing:
                return existing["report_id"]

            raise

        await self.repository.add_activity_log(client_id, report_id, {
            "action":  "created",
            "user_id": user_id,
            "detail":  f"Reporte creado en {report_in.area_id} - {'IAP' if report_in.is_iap else report_in.type}",
        })

        # ── Trigger alerta IAP ────────────────────────────────────────────────
        if report_in.is_iap:
            alerts_url = os.getenv("ALERTS_SERVICE_URL", "https://gpi-alerts-service.onrender.com")
            try:
                async with httpx.AsyncClient(timeout=5.0) as client:
                    await client.post(
                        f"{alerts_url}/v1/alerts/iap",
                        json={
                            "client_id": client_id,
                            "report_id": report_id,
                            "area_id":   report_in.area_id,
                            "user_id":   user_id,
                        }
                    )
            except Exception as e:
                print(f"Warning: no se pudo crear alerta IAP: {e}")
        # ─────────────────────────────────────────────────────────────────────

        await self.repository.create_notification(client_id, user_id, {
            "type":      "actualizacion",
            "title":     "Reporte recibido",
            "body":      "Tu reporte fue enviado y está siendo revisado.",
            "report_id": report_id,
        })

        await self._notify_report_managers(
            client_id=client_id,
            report_id=report_id,
            area_id=report_in.area_id,
            creator_user_id=user_id,
        )

        return report_id

    async def _notify_report_managers(
        self,
        *,
        client_id: str,
        report_id: str,
        area_id: str,
        creator_user_id: str,
    ) -> None:
        if self.manager_repository is None:
            return

        try:
            managers = (
                await self.manager_repository
                .get_report_managers(
                    client_id=client_id,
                    area_id=area_id,
                    exclude_user_id=creator_user_id,
                )
            )
        except Exception as exc:
            print(
                "Warning: no se pudieron resolver "
                f"gestores del reporte: {exc}"
            )
            return

        seen_user_ids = set()

        for manager in managers:
            target_user_id = str(
                manager.get("user_id") or ""
            ).strip()

            if not target_user_id:
                continue

            if target_user_id == creator_user_id:
                continue

            if target_user_id in seen_user_ids:
                continue

            seen_user_ids.add(target_user_id)

            try:
                await self.repository.create_notification(
                    client_id,
                    target_user_id,
                    {
                        "type": "actualizacion",
                        "title": "Nuevo reporte recibido",
                        "body": (
                            f"Se creó el reporte "
                            f"#{report_id} en {area_id}."
                        ),
                        "report_id": report_id,
                    },
                )
            except Exception as exc:
                print(
                    "Warning: no se pudo notificar "
                    f"al gestor {target_user_id}: {exc}"
                )

    async def get_all(self, client_id: str, user_id: str) -> list:
        return await self.repository.get_all(client_id, user_id)

    async def get_by_id(self, client_id: str, report_id: str) -> dict | None:
        return await self.repository.get_by_id(client_id, report_id)

    async def update_status(
        self,
        client_id: str,
        report_id: str,
        status: str,
        feedback: str = "",
    ) -> bool:
        report = await self.repository.get_by_id(client_id, report_id)
        if not report:
            return False

        ok = await self.repository.update_status(client_id, report_id, status, feedback)
        if not ok:
            return False

        await self.repository.add_activity_log(client_id, report_id, {
            "action":  "status_change",
            "detail":  f"Estado cambiado a {STATUS_LABELS.get(status, status)}",
            "feedback": feedback or "",
        })

        user_id = report.get("reported_by", "")
        if user_id:
            label = STATUS_LABELS.get(status, status)
            body  = f"Tu reporte cambió a: {label}"
            if feedback:
                body += f"\n\nComentario del supervisor: {feedback}"

            await self.repository.create_notification(client_id, user_id, {
                "type":      "actualizacion",
                "title":     f"Reporte actualizado → {label}",
                "body":      body,
                "report_id": report_id,
            })

        return True

    async def associate_closure_evidence(
        self,
        client_id: str,
        report_id: str,
        user_id: str,
        evidence: dict,
    ) -> dict | None:
        report = await self.repository.get_by_id(
            client_id,
            report_id,
        )

        if not report:
            return None

        current_evidence = report.get(
            "closure_evidence"
        )

        if current_evidence == evidence:
            return evidence

        updated = (
            await self.repository
            .update_closure_evidence(
                client_id,
                report_id,
                evidence,
            )
        )

        if not updated:
            return None

        await self.repository.add_activity_log(
            client_id,
            report_id,
            {
                "action": (
                    "closure_evidence_associated"
                ),
                "user_id": user_id,
                "detail": (
                    "Evidencia de cierre asociada "
                    "al incidente"
                ),
            },
        )

        return evidence

    # ─── WORKER STATS ─────────────────────────────────────────────────────────

    async def get_worker_stats(self, client_id: str, user_id: str, period: str = "month") -> dict:
        reports = await self.repository.get_all(client_id, user_id)
        total        = len(reports)
        closed       = sum(1 for r in reports if r.get("status") == "closed")
        open_reports = total - closed
        iap          = sum(1 for r in reports if r.get("is_iap"))
        effectiveness = round((closed / total * 100), 1) if total > 0 else 0.0

        return {
            "period":              period,
            "total_reports":       total,
            "reports_this_period": open_reports,
            "closed_reports":      closed,
            "effectiveness_rate":  effectiveness,
            "iap_reports":         iap,
        }

    # ─── NOTIFICATIONS ────────────────────────────────────────────────────────

    async def get_notifications(self, client_id: str, user_id: str) -> dict:
        notifs = await self.repository.get_notifications(client_id, user_id)
        unread = sum(1 for n in notifs if not n.get("read", False))
        return {"data": notifs, "unread_count": unread}

    async def mark_notification_read(
        self, client_id: str, notification_id: str, user_id: str
    ) -> bool:
        return await self.repository.mark_notification_read(client_id, notification_id, user_id)