/**
 * DATOS MOCK PARA TESTING
 *
 * Usa estos datos mientras configuras tu base de datos real.
 * Útil para desarrollo y pruebas de interfaz.
 */

import type {
  Reporte,
  Zona,
  Alerta,
  Usuario,
  Notificacion,
  EstadisticasGlobales,
  EstadisticasArea,
} from './types';

// ============================================
// USUARIOS MOCK
// ============================================

export const usuariosMock: Usuario[] = [
  {
    id: 'user-001',
    nombre_completo: 'Juan Pérez López',
    email: 'juan.perez@empresa.com',
    rol: 'empleado',
    turno: 'manana',
    area_asignada: 'Línea 3',
    total_reportes: 24,
    reportes_mes_actual: 5,
    efectividad_porcentaje: 87.5,
    created_at: new Date('2026-01-15'),
    updated_at: new Date('2026-07-17'),
  },
  {
    id: 'user-002',
    nombre_completo: 'María González',
    email: 'maria.gonzalez@empresa.com',
    rol: 'supervisor',
    area_asignada: 'Producción',
    created_at: new Date('2026-01-15'),
    updated_at: new Date('2026-07-17'),
  },
  {
    id: 'user-003',
    nombre_completo: 'Carlos Ramírez',
    email: 'carlos.ramirez@empresa.com',
    rol: 'gerente_sso',
    created_at: new Date('2026-01-15'),
    updated_at: new Date('2026-07-17'),
  },
];

// ============================================
// REPORTES MOCK
// ============================================

export const reportesMock: Reporte[] = [
  {
    id: 'rep-001',
    fecha: new Date('2026-07-17T09:30:00'),
    area: 'Línea 3',
    linea: 'L3-001',
    proceso: 'Ensamblaje',
    tipo: 'condicion_insegura',
    es_iap: true,
    descripcion: 'Cable eléctrico expuesto cerca de zona de trabajo',
    evidencia_foto_url: 'https://placehold.co/400x300/red/white?text=IAP+Cable',
    reportador_id: 'user-001',
    reportador_nombre: 'Juan Pérez López',
    reportador_turno: 'manana',
    reportador_area_asignada: 'Línea 3',
    estado: 'en_revision',
    responsable_asignado: 'María González',
    tiempo_sin_remediacion_horas: 2,
    sla_vencido: false,
    created_at: new Date('2026-07-17T09:30:00'),
    updated_at: new Date('2026-07-17T09:30:00'),
  },
  {
    id: 'rep-002',
    fecha: new Date('2026-07-17T08:15:00'),
    area: 'Almacén',
    linea: 'ALM-002',
    proceso: 'Almacenamiento',
    tipo: 'acto_inseguro',
    es_iap: false,
    descripcion: 'Operario sin casco en zona de montacargas',
    evidencia_foto_url: 'https://placehold.co/400x300/orange/white?text=Sin+EPP',
    reportador_id: 'user-001',
    reportador_nombre: 'Juan Pérez López',
    reportador_turno: 'manana',
    reportador_area_asignada: 'Línea 3',
    estado: 'accion_asignada',
    responsable_asignado: 'Pedro Sánchez',
    feedback_supervisor: 'Se ha programado capacitación para el operario',
    fecha_revision: new Date('2026-07-17T10:00:00'),
    fecha_asignacion: new Date('2026-07-17T10:30:00'),
    tiempo_sin_remediacion_horas: 4,
    sla_vencido: false,
    created_at: new Date('2026-07-17T08:15:00'),
    updated_at: new Date('2026-07-17T10:30:00'),
  },
  {
    id: 'rep-003',
    fecha: new Date('2026-07-16T14:20:00'),
    area: 'Línea 5',
    linea: 'L5-003',
    proceso: 'Control de Calidad',
    tipo: 'condicion_insegura',
    es_iap: false,
    descripcion: 'Derrame de aceite en piso',
    evidencia_foto_url: 'https://placehold.co/400x300/yellow/black?text=Derrame',
    reportador_id: 'user-001',
    reportador_nombre: 'Juan Pérez López',
    reportador_turno: 'tarde',
    reportador_area_asignada: 'Línea 3',
    estado: 'cerrado',
    responsable_asignado: 'María González',
    feedback_supervisor: 'Derrame limpiado. Se instaló señalización preventiva.',
    fecha_revision: new Date('2026-07-16T15:00:00'),
    fecha_asignacion: new Date('2026-07-16T15:15:00'),
    fecha_cierre: new Date('2026-07-16T16:30:00'),
    tiempo_sin_remediacion_horas: 2,
    sla_vencido: false,
    created_at: new Date('2026-07-16T14:20:00'),
    updated_at: new Date('2026-07-16T16:30:00'),
  },
  {
    id: 'rep-004',
    fecha: new Date('2026-07-15T11:45:00'),
    area: 'Bodega Química',
    linea: 'BQ-001',
    proceso: 'Almacenamiento',
    tipo: 'condicion_insegura',
    es_iap: true,
    descripcion: 'Tanque de químico con fuga menor',
    evidencia_foto_url: 'https://placehold.co/400x300/red/white?text=Fuga+Quimica',
    reportador_id: 'user-001',
    reportador_nombre: 'Juan Pérez López',
    reportador_turno: 'manana',
    reportador_area_asignada: 'Línea 3',
    estado: 'vencido',
    responsable_asignado: 'Jorge Martínez',
    feedback_supervisor: 'En proceso de reparación',
    fecha_revision: new Date('2026-07-15T12:00:00'),
    fecha_asignacion: new Date('2026-07-15T13:00:00'),
    tiempo_sin_remediacion_horas: 50,
    sla_vencido: true,
    created_at: new Date('2026-07-15T11:45:00'),
    updated_at: new Date('2026-07-17T10:00:00'),
  },
];

// ============================================
// ZONAS MOCK
// ============================================

export const zonasMock: Zona[] = [
  {
    id: 'zona-001',
    nombre: 'Línea 3',
    proceso_asociado: 'Ensamblaje',
    coordenadas: [
      { x: 100, y: 100 },
      { x: 300, y: 100 },
      { x: 300, y: 250 },
      { x: 100, y: 250 },
    ],
    score_riesgo: 85,
    nivel_riesgo: 'alto',
    color_identificacion: '#ef4444',
    plano_base_url: 'https://placehold.co/1200x800/e5e7eb/6b7280?text=Plano+de+Planta',
    created_at: new Date('2026-01-01'),
    updated_at: new Date('2026-07-17'),
  },
  {
    id: 'zona-002',
    nombre: 'Almacén',
    proceso_asociado: 'Almacenamiento',
    coordenadas: [
      { x: 320, y: 100 },
      { x: 500, y: 100 },
      { x: 500, y: 250 },
      { x: 320, y: 250 },
    ],
    score_riesgo: 55,
    nivel_riesgo: 'medio',
    color_identificacion: '#f59e0b',
    plano_base_url: 'https://placehold.co/1200x800/e5e7eb/6b7280?text=Plano+de+Planta',
    created_at: new Date('2026-01-01'),
    updated_at: new Date('2026-07-17'),
  },
  {
    id: 'zona-003',
    nombre: 'Línea 5',
    proceso_asociado: 'Control de Calidad',
    coordenadas: [
      { x: 100, y: 270 },
      { x: 300, y: 270 },
      { x: 300, y: 400 },
      { x: 100, y: 400 },
    ],
    score_riesgo: 25,
    nivel_riesgo: 'bajo',
    color_identificacion: '#10b981',
    plano_base_url: 'https://placehold.co/1200x800/e5e7eb/6b7280?text=Plano+de+Planta',
    created_at: new Date('2026-01-01'),
    updated_at: new Date('2026-07-17'),
  },
  {
    id: 'zona-004',
    nombre: 'Bodega Química',
    proceso_asociado: 'Almacenamiento',
    coordenadas: [
      { x: 320, y: 270 },
      { x: 500, y: 270 },
      { x: 500, y: 400 },
      { x: 320, y: 400 },
    ],
    score_riesgo: 92,
    nivel_riesgo: 'alto',
    color_identificacion: '#dc2626',
    plano_base_url: 'https://placehold.co/1200x800/e5e7eb/6b7280?text=Plano+de+Planta',
    created_at: new Date('2026-01-01'),
    updated_at: new Date('2026-07-17'),
  },
];

// ============================================
// ALERTAS MOCK
// ============================================

export const alertasMock: Alerta[] = [
  {
    id: 'alert-001',
    tipo: 'iap',
    titulo: 'Nuevo IAP en Línea 3',
    descripcion: 'Cable eléctrico expuesto requiere atención inmediata',
    area_afectada: 'Línea 3',
    activa: true,
    resuelta: false,
    reporte_id: 'rep-001',
    created_at: new Date('2026-07-17T09:30:00'),
    updated_at: new Date('2026-07-17T09:30:00'),
  },
  {
    id: 'alert-002',
    tipo: 'sla',
    titulo: 'SLA Vencido',
    descripcion: 'Reporte #rep-004 excedió el tiempo de resolución',
    area_afectada: 'Bodega Química',
    activa: true,
    resuelta: false,
    reporte_id: 'rep-004',
    created_at: new Date('2026-07-17T08:00:00'),
    updated_at: new Date('2026-07-17T08:00:00'),
  },
  {
    id: 'alert-003',
    tipo: 'zona',
    titulo: 'Zona Crítica: Bodega Química',
    descripcion: 'Área alcanzó score de riesgo crítico (92)',
    area_afectada: 'Bodega Química',
    activa: true,
    resuelta: false,
    zona_id: 'zona-004',
    created_at: new Date('2026-07-17T07:00:00'),
    updated_at: new Date('2026-07-17T07:00:00'),
  },
];

// ============================================
// NOTIFICACIONES MOCK
// ============================================

export const notificacionesMock: Notificacion[] = [
  {
    id: 'notif-001',
    tipo: 'actualizacion',
    titulo: 'Reporte actualizado',
    mensaje: 'Tu reporte #rep-002 fue revisado por el supervisor',
    usuario_id: 'user-001',
    leida: false,
    reporte_id: 'rep-002',
    created_at: new Date('2026-07-17T10:30:00'),
  },
  {
    id: 'notif-002',
    tipo: 'alerta',
    titulo: 'Zona en riesgo alto',
    mensaje: 'Bodega Química requiere atención inmediata',
    usuario_id: 'user-002',
    leida: false,
    alerta_id: 'alert-003',
    created_at: new Date('2026-07-17T07:00:00'),
  },
  {
    id: 'notif-003',
    tipo: 'resuelto',
    titulo: 'Reporte cerrado',
    mensaje: 'Tu reporte #rep-003 ha sido cerrado exitosamente',
    usuario_id: 'user-001',
    leida: true,
    reporte_id: 'rep-003',
    created_at: new Date('2026-07-16T16:30:00'),
  },
];

// ============================================
// ESTADÍSTICAS MOCK
// ============================================

export const estadisticasGlobalesMock: EstadisticasGlobales = {
  total_reportes: 127,
  iap_activos: 2,
  variacion_porcentual: 12.5,
  reportes_cerrados_mes: 89,
  promedio_tiempo_resolucion_horas: 6.3,
};

export const estadisticasAreasMock: EstadisticasArea[] = [
  {
    area: 'Bodega Química',
    score_riesgo: 92,
    total_incidentes: 15,
    incidentes_abiertos: 3,
    tendencia: 'subiendo',
  },
  {
    area: 'Línea 3',
    score_riesgo: 85,
    total_incidentes: 28,
    incidentes_abiertos: 5,
    tendencia: 'estable',
  },
  {
    area: 'Almacén',
    score_riesgo: 55,
    total_incidentes: 12,
    incidentes_abiertos: 2,
    tendencia: 'bajando',
  },
  {
    area: 'Línea 5',
    score_riesgo: 25,
    total_incidentes: 8,
    incidentes_abiertos: 1,
    tendencia: 'bajando',
  },
  {
    area: 'Área de Empaque',
    score_riesgo: 18,
    total_incidentes: 5,
    incidentes_abiertos: 0,
    tendencia: 'estable',
  },
];

export const tendenciaRiesgoMock = [
  { fecha: '2026-07-11', score: 45 },
  { fecha: '2026-07-12', score: 52 },
  { fecha: '2026-07-13', score: 48 },
  { fecha: '2026-07-14', score: 55 },
  { fecha: '2026-07-15', score: 67 },
  { fecha: '2026-07-16', score: 62 },
  { fecha: '2026-07-17', score: 71 },
];
