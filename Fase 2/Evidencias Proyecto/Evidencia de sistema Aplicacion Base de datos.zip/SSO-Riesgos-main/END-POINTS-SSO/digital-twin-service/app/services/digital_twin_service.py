"""Service — lógica de negocio para el digital-twin-service."""

from __future__ import annotations
from datetime import datetime, timezone
from ulid import ULID
import os
import asyncio
from azure.storage.blob import BlobServiceClient, ContentSettings

from app.repositories.digital_twin_repository import DigitalTwinRepository
from app.schemas.digital_twin import (
    DeleteResponse,
    FloorPlanResponse,
    FloorPlanUploadResponse,
    ZoneCreateRequest,
    ZoneListResponse,
    ZoneResponse,
    ZoneUpdateRequest,
)

AZURE_CONN_STR = os.getenv("AZURE_STORAGE_CONNECTION_STRING", "")
AZURE_CONTAINER = os.getenv("AZURE_STORAGE_CONTAINER", "sso-evidencias")
BLOB_BASE_URL = os.getenv(
    "AZURE_STORAGE_PUBLIC_BASE_URL",
    f"https://ssoevidencias.blob.core.windows.net/{AZURE_CONTAINER}",
)


def _to_zone_response(data: dict) -> ZoneResponse:
    polygon_raw = data.get("polygon", [])
    polygon = [
        {"x": p["x"], "y": p["y"]}
        if isinstance(p, dict)
        else {"x": p.x, "y": p.y}
        for p in polygon_raw
    ]
    return ZoneResponse(
        zone_id        = data["zone_id"],
        client_id      = data.get("client_id", ""),
        name           = data.get("name", ""),
        process        = data.get("process", ""),
        color          = data.get("color", "#000000"),
        polygon        = polygon,
        floor_plan_url = data.get("floor_plan_url"),
        created_at     = data.get("created_at"),
        updated_at     = data.get("updated_at"),
    )


class DigitalTwinService:

    def __init__(self, repo: DigitalTwinRepository) -> None:
        self._repo = repo

    async def upload_floor_plan(
        self, client_id: str, file_bytes: bytes, content_type: str, filename: str,
    ) -> FloorPlanUploadResponse:
        blob_name = f"floor-plans/{client_id}/floor_plan.png"
        blob_service = BlobServiceClient.from_connection_string(AZURE_CONN_STR)
        blob_client = blob_service.get_blob_client(container=AZURE_CONTAINER, blob=blob_name)
        blob_client.upload_blob(file_bytes, overwrite=True, content_settings=ContentSettings(content_type=content_type))
        public_url = f"{BLOB_BASE_URL}/{blob_name}" 
        await self._repo.save_floor_plan(client_id, {
            "floor_plan_url": public_url,
            "updated_at": datetime.now(tz=timezone.utc).isoformat(),
        })
        return FloorPlanUploadResponse(
            client_id=client_id,
            floor_plan_url=public_url,
            uploaded_at=datetime.now(tz=timezone.utc).isoformat(),
        )

    async def get_floor_plan(self, client_id: str) -> FloorPlanResponse:
        doc = await self._repo.get_floor_plan(client_id)
        url = doc.get("floor_plan_url") if doc else None
        return FloorPlanResponse(
            client_id=client_id,
            floor_plan_url=url,
            has_floor_plan=url is not None,
        )

    async def list_zones(self, client_id: str) -> ZoneListResponse:
        zones = await self._repo.get_zones(client_id)
        items = [_to_zone_response(z) for z in zones]
        return ZoneListResponse(data=items, total=len(items))

    async def create_zone(self, client_id: str, payload: ZoneCreateRequest) -> ZoneResponse:
        zone_id = f"zone_{ULID()}"
        now = datetime.now(tz=timezone.utc).isoformat()
        data = {
            "zone_id":        zone_id,
            "name":           payload.name,
            "process":        payload.process,
            "color":          payload.color,
            "polygon":        [p.model_dump() for p in payload.polygon],
            "floor_plan_url": payload.floor_plan_url,
            "created_at":     now,
            "updated_at":     now,
        }
        await self._repo.save_zone(client_id, data)
        data["client_id"] = client_id
        return _to_zone_response(data)

    async def update_zone(self, client_id: str, zone_id: str, payload: ZoneUpdateRequest) -> ZoneResponse:
        data: dict = {"updated_at": datetime.now(tz=timezone.utc).isoformat()}
        if payload.name is not None:
            data["name"] = payload.name
        if payload.process is not None:
            data["process"] = payload.process
        if payload.color is not None:
            data["color"] = payload.color
        if payload.polygon is not None:
            data["polygon"] = [p.model_dump() for p in payload.polygon]
        if payload.floor_plan_url is not None:
            data["floor_plan_url"] = payload.floor_plan_url
        data["zone_id"] = zone_id
        await self._repo.save_zone(client_id, data)
        doc = await self._repo.get_zones(client_id)
        zone = next((z for z in doc if z.get("zone_id") == zone_id), data)
        zone["client_id"] = client_id
        return _to_zone_response(zone)

    async def delete_zone(self, client_id: str, zone_id: str, requesting_role: str) -> DeleteResponse:
        if requesting_role not in ("admin", "supervisor", "sso_manager"):
            from app.exceptions import ForbiddenError
            raise ForbiddenError("Solo administradores pueden eliminar zonas.")
        await self._repo.delete_zone(client_id, zone_id)
        return DeleteResponse(zone_id=zone_id, deleted=True, message=f"Zona \'{zone_id}\' eliminada.")
