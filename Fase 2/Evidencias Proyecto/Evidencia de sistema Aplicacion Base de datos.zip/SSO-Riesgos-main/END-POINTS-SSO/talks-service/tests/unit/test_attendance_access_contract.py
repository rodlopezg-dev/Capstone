"""EP-04 security contract over ASGI, with inert Mongo collections."""

from datetime import datetime, timedelta, timezone

import jwt
import pytest
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient

from app.dep_talks import JWT_SECRET, get_db
from app.repositories.rep_talks import TalksRepository
from app.routers import rt_talks


PATHS = [
    "/v1/attendance/stats/areas",
    "/v1/attendance/stats/months?year=2026",
    "/v1/attendance/export/pdf?month=9&year=2026",
    "/v1/attendance/export/xlsx?month=9&year=2026",
    "/v1/talks/talk_a/expected-workers",
    "/v1/talks/talk_a/attendance-comparison",
    "/v1/talks/talk_a/absent-workers",
]


def bearer(**changes):
    claims = {
        "sub": "user_a",
        "client_id": "empresa_a",
        "role": "worker",
        "exp": datetime.now(timezone.utc) + timedelta(minutes=10),
    }
    claims.update(changes)
    claims = {key: value for key, value in claims.items() if value is not None}
    return {"Authorization": "Bearer " + jwt.encode(
        claims, JWT_SECRET, algorithm="HS256"
    )}


@pytest.fixture
def isolated_api(monkeypatch):
    calls = []
    database = {name: object() for name in (
        "talks", "attendance", "attendance_participants", "talk_qr_sessions", "attendance_scans", "users"
    )}

    async def inert_db():
        return database

    async def areas(_repo, client_id):
        calls.append(("areas", client_id))
        return [{"area": "Planta", "active_workers": 1,
                 "attendance_count": 0, "attendance_percentage": 0}]

    async def months(_repo, client_id, year=None):
        calls.append(("months", client_id, year))
        return [{"year": year, "month": "9", "active_workers": 1,
                 "attendance_count": 0, "attendance_percentage": 0}]

    async def export(_repo, client_id, month=None, year=None):
        calls.append(("export", client_id, month, year))
        return [{"source": "manual", "topic": "Prueba",
                 "date": "2026-09-01", "attendees": []}]

    async def list_attendance(_repo, client_id, talk_id=None):
        calls.append(("list_attendance", client_id, talk_id))
        return [{"attendance_id": "att_a", "client_id": client_id}]

    async def list_talks(_repo, client_id, month=None, year=None):
        calls.append(("list_talks", client_id, month, year))
        return [{"talk_id": "talk_a", "client_id": client_id,
                 "expected_user_ids": ["worker_private"]}]

    async def list_own_attendance(_repo, client_id, user_id, talk_id=None):
        calls.append(("list_own_attendance", client_id, user_id, talk_id))
        return [{"attendance_id": "att_own", "attended_user_ids": [user_id]}]

    async def get_talk(_repo, client_id, talk_id):
        calls.append(("get_talk", client_id, talk_id))
        if client_id == "empresa_a" and talk_id == "talk_a":
            return {"talk_id": talk_id, "client_id": client_id}
        return None

    async def create_attendance(_repo, client_id, data):
        calls.append(("create_attendance", client_id, data))
        return "att_a"

    def detail(name):
        async def result(_repo, client_id, talk_id):
            calls.append((name, client_id, talk_id))
            return {"talk_id": talk_id, "client_id": client_id}
        return result

    monkeypatch.setattr(TalksRepository, "attendance_stats_by_area", areas)
    monkeypatch.setattr(TalksRepository, "attendance_stats_by_month", months)
    monkeypatch.setattr(TalksRepository, "list_attendance_for_export", export)
    monkeypatch.setattr(TalksRepository, "list_attendance", list_attendance)
    monkeypatch.setattr(TalksRepository, "list_talks", list_talks)
    monkeypatch.setattr(TalksRepository, "list_own_attendance", list_own_attendance)
    monkeypatch.setattr(TalksRepository, "get_talk", get_talk)
    monkeypatch.setattr(TalksRepository, "create_attendance", create_attendance)
    for method in (
        "expected_workers_for_talk", "attendance_comparison_for_talk",
        "absent_workers_for_talk",
    ):
        monkeypatch.setattr(TalksRepository, method, detail(method))
    monkeypatch.setattr(rt_talks, "build_attendance_pdf", lambda *_a, **_k: b"%PDF-test")
    monkeypatch.setattr(rt_talks, "build_attendance_xlsx", lambda *_a, **_k: b"xlsx-test")

    app = FastAPI()
    app.include_router(rt_talks.router)
    app.dependency_overrides[get_db] = inert_db
    return app, calls


@pytest.mark.asyncio
@pytest.mark.parametrize("path", PATHS)
@pytest.mark.parametrize("role", [
    "worker", "usuario", "supervisor", "jefe de area", "jefe_de_area",
    "sso_manager", "admin", "analyst", "unknown",
])
async def test_administrative_routes_require_tenant_admin(isolated_api, role, path):
    app, calls = isolated_api
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.get(path, headers=bearer(role=role))
    if role in ("admin", "sso_manager"):
        assert response.status_code == 200
        assert calls[-1][1] == "empresa_a"
    else:
        assert response.status_code == 403
        assert calls == []


@pytest.mark.asyncio
@pytest.mark.parametrize("path", PATHS)
@pytest.mark.parametrize("claims", [
    {"type": "refresh"},
    {"type": "unknown"},
    {"type": ""},
    {"sub": None},
    {"role": None},
    {"exp": None},
    {"sub": "   "},
    {"role": "   "},
])
async def test_refresh_and_incomplete_claims_are_rejected(isolated_api, claims, path):
    app, calls = isolated_api
    token_claims = {"role": "admin", **claims}
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.get(path, headers=bearer(**token_claims))
    assert response.status_code == 401
    assert calls == []


@pytest.mark.asyncio
@pytest.mark.parametrize("path", PATHS)
@pytest.mark.parametrize("headers, expected_status", [
    ({}, 401),
    ({"Authorization": "Bearer invalid"}, 401),
    (bearer(exp=datetime.now(timezone.utc) - timedelta(minutes=1)), 401),
    (bearer(client_id="", role="admin"), 401),
    (bearer(client_id=None, role="admin"), 401),
])
async def test_current_authentication_failures(
    isolated_api, headers, expected_status, path
):
    app, calls = isolated_api
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.get(path, headers=headers)
    assert response.status_code == expected_status
    assert calls == []


@pytest.mark.asyncio
@pytest.mark.parametrize("path", PATHS)
async def test_client_id_always_comes_from_jwt(isolated_api, path):
    app, calls = isolated_api
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.get(
            path + ("&" if "?" in path else "?") + "client_id=empresa_b",
            headers=bearer(client_id="empresa_a", role="admin"),
        )
    assert response.status_code == 200
    assert calls[-1][1] == "empresa_a"


@pytest.mark.asyncio
@pytest.mark.parametrize("path", PATHS)
async def test_whitespace_client_id_is_rejected(isolated_api, path):
    app, calls = isolated_api
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.get(path, headers=bearer(client_id="   ", role="admin"))
    assert response.status_code == 401
    assert calls == []


@pytest.mark.asyncio
@pytest.mark.parametrize("role", ["worker", "usuario"])
async def test_worker_receives_only_own_qr_status(isolated_api, role):
    app, calls = isolated_api
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.get("/v1/attendance", headers=bearer(role=role))
    assert response.status_code == 200
    assert response.json() == [{"attendance_id": "att_own", "attended_user_ids": ["user_a"]}]
    assert calls == [("list_own_attendance", "empresa_a", "user_a", None)]


@pytest.mark.asyncio
@pytest.mark.parametrize("role, expected", [
    ("admin", 200), ("sso_manager", 200), ("supervisor", 403),
    ("jefe_de_area", 403), ("analyst", 403), ("unknown", 403),
])
async def test_attendance_list_role_matrix(isolated_api, role, expected):
    app, calls = isolated_api
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.get("/v1/attendance", headers=bearer(role=role))
    assert response.status_code == expected
    assert calls == ([("list_attendance", "empresa_a", None)] if expected == 200 else [])


@pytest.mark.asyncio
@pytest.mark.parametrize("type_claim", [None, "access"])
async def test_legacy_and_explicit_access_are_accepted(isolated_api, type_claim):
    app, calls = isolated_api
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.get(PATHS[0], headers=bearer(role="admin", type=type_claim))
    assert response.status_code == 200
    assert calls == [("areas", "empresa_a")]


@pytest.mark.asyncio
@pytest.mark.parametrize("client_id", ["empresa_a", "empresa_b"])
async def test_tenant_is_taken_from_signed_access(isolated_api, client_id):
    app, calls = isolated_api
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.get(PATHS[1] + "&client_id=other", headers=bearer(role="admin", client_id=client_id))
    assert response.status_code == 200
    assert calls == [("months", client_id, "2026")]


@pytest.mark.asyncio
async def test_invalid_manual_post_cannot_write(isolated_api):
    app, calls = isolated_api
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.post(
            "/v1/attendance",
            headers=bearer(role="worker", client_id=None),
            data={"topic": "Prueba", "date": "2026-09-01",
                  "talk_id": "talk_otro_cliente", "attendees": "Ana Prueba"},
        )
    assert response.status_code == 401
    assert calls == []


@pytest.mark.asyncio
@pytest.mark.parametrize("talk_id, expected", [
    ("talk_otro_cliente", 404), ("talk_inexistente", 404),
    ("   ", 422), ("talk_a", 200), (None, 200),
])
async def test_manual_post_validates_explicit_talk_before_writing(isolated_api, talk_id, expected):
    app, calls = isolated_api
    data = {"topic": "Prueba", "date": "2026-09-01"}
    if talk_id is not None:
        data["talk_id"] = talk_id
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.post(
            "/v1/attendance", headers=bearer(role="admin"),
            data=data,
        )
    assert response.status_code == expected
    assert any(call[0] == "create_attendance" for call in calls) is (expected == 200)


@pytest.mark.asyncio
@pytest.mark.parametrize("talk_id, expected", [
    (None, 200), ("", 422), ("   ", 422),
    ("talk_a", 200), ("talk_inexistente", 404), ("talk_b", 404),
])
@pytest.mark.parametrize("with_file", [False, True])
async def test_talk_id_presence_and_upload_side_effects(
    isolated_api, monkeypatch, talk_id, expected, with_file,
):
    app, calls = isolated_api

    async def store(*_args, **_kwargs):
        calls.append(("store_blob",))
        return {"file_id": "file_a", "file_storage": {"blob_name": "fake"}}

    monkeypatch.setattr(rt_talks, "_store_attachment", store)
    async def no_existing_file(_repo, client_id, selected_talk_id):
        calls.append(("talk_has_attendance_file", client_id, selected_talk_id))
        return False

    monkeypatch.setattr(TalksRepository, "talk_has_attendance_file", no_existing_file)
    data = {"topic": "Prueba", "date": "2026-09-01"}
    if talk_id is not None:
        data["talk_id"] = talk_id
    files = {"file": ("hoja.png", b"x", "image/png")} if with_file else None
    status = 422 if with_file and talk_id is None else expected
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.post(
            "/v1/attendance", headers=bearer(role="admin"), data=data, files=files,
        )
    assert response.status_code == status
    if status != 200:
        assert not any(call[0] in {"store_blob", "create_attendance"} for call in calls)
    elif with_file:
        assert [call[0] for call in calls] == [
            "get_talk", "talk_has_attendance_file", "store_blob", "create_attendance",
        ]
    else:
        assert any(call[0] == "create_attendance" for call in calls)


@pytest.mark.asyncio
@pytest.mark.parametrize("role", ["worker", "usuario", "supervisor", "jefe_de_area", "analyst"])
async def test_manual_post_denies_unscoped_roles_before_repository(isolated_api, role):
    app, calls = isolated_api
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.post(
            "/v1/attendance", headers=bearer(role=role),
            data={"topic": "Prueba", "date": "2026-09-01", "talk_id": "talk_a"},
        )
    assert response.status_code == 403
    assert calls == []


@pytest.mark.asyncio
async def test_area_claim_alone_does_not_grant_unscoped_supervisor_access(isolated_api):
    app, calls = isolated_api
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.get(
            "/v1/talks/talk_a/absent-workers",
            headers=bearer(role="supervisor", areas=["Planta"], area="Planta"),
        )
    assert response.status_code == 403
    assert calls == []


@pytest.mark.asyncio
async def test_other_tenant_cannot_attach_manual_attendance_to_talk(isolated_api):
    app, calls = isolated_api
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.post(
            "/v1/attendance", headers=bearer(role="admin", client_id="empresa_b"),
            data={"topic": "Prueba", "date": "2026-09-01", "talk_id": "talk_a"},
        )
    assert response.status_code == 404
    assert calls == [("get_talk", "empresa_b", "talk_a")]


@pytest.mark.asyncio
async def test_worker_talk_list_does_not_expose_expected_population(isolated_api):
    app, calls = isolated_api
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.get("/v1/talks", headers=bearer(role="worker"))
    assert response.status_code == 200
    assert response.json() == [{"talk_id": "talk_a", "client_id": "empresa_a"}]
    assert calls == [("list_talks", "empresa_a", None, None)]


@pytest.mark.asyncio
async def test_worker_cannot_download_attendance_sheet(isolated_api):
    app, calls = isolated_api
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.get("/v1/attendance/att_a/file", headers=bearer(role="worker"))
    assert response.status_code == 403
    assert calls == []


@pytest.mark.asyncio
async def test_foreign_talk_sheet_is_rejected_before_blob_or_mongo_write(isolated_api, monkeypatch):
    app, calls = isolated_api

    async def store(*_args, **_kwargs):
        calls.append(("store_blob",))
        raise AssertionError("No debe almacenar una hoja para charla ajena")

    monkeypatch.setattr(rt_talks, "_store_attachment", store)
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.post(
            "/v1/attendance", headers=bearer(role="admin"),
            data={"topic": "Prueba", "date": "2026-09-01", "talk_id": "talk_b"},
            files={"file": ("hoja.png", b"x", "image/png")},
        )
    assert response.status_code == 404
    assert calls == [("get_talk", "empresa_a", "talk_b")]


@pytest.mark.asyncio
@pytest.mark.parametrize("changes", [
    {"type": "refresh"}, {"type": "unknown"}, {"client_id": " "},
    {"client_id": None}, {"role": None}, {"sub": " "}, {"exp": None},
])
async def test_manual_post_rejects_invalid_identity_before_repository(isolated_api, changes):
    app, calls = isolated_api
    claims = {"role": "admin", **changes}
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.post(
            "/v1/attendance", headers=bearer(**claims),
            data={"topic": "Prueba", "date": "2026-09-01", "talk_id": "talk_a"},
        )
    assert response.status_code == 401
    assert calls == []


@pytest.mark.asyncio
@pytest.mark.parametrize("path", ["/v1/talks/talk_a/qr", "/v1/attendance/ocr"])
async def test_unscoped_supervisor_cannot_reach_qr_or_ocr_repository(isolated_api, path):
    app, calls = isolated_api
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        if path.endswith("/ocr"):
            response = await client.post(path, headers=bearer(role="supervisor"),
                                         data={"talk_id": "talk_a"}, files={"file": ("a.png", b"x", "image/png")})
        else:
            response = await client.get(path, headers=bearer(role="supervisor"))
    assert response.status_code == 403
    assert calls == []
