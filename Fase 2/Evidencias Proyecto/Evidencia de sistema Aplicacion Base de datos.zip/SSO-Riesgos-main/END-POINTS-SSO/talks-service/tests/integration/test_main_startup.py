import os

import pytest

os.environ.setdefault("CORS_ORIGINS", "http://localhost")
os.environ.setdefault("CORS_ORIGIN_REGEX", "")

from app import main


@pytest.mark.asyncio
async def test_lifespan_creates_qr_session_ttl_index(db, monkeypatch):
    monkeypatch.setattr(main, "get_db", lambda: db)

    async with main.lifespan(main.app):
        indexes = await db["talk_qr_sessions"].index_information()

    ttl_index = indexes["qr_sessions_expires_at_ttl"]

    assert ttl_index["key"] == [("expires_at", 1)]
    assert ttl_index["expireAfterSeconds"] == 0