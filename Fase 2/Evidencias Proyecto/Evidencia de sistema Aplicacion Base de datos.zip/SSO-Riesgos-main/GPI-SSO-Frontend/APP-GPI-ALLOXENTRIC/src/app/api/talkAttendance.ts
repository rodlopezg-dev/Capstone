import {
  authenticatedFetch,
} from './client';

interface UploadAttendanceSheetInput {
  apiBase: string;
  talkId: string;
  topic: string;
  date: string;
  file: File;
}

async function responseError(
  response: Response,
  fallback: string,
): Promise<string> {
  const data = await response
    .json()
    .catch(() => ({}));

  return data?.detail || data?.message || fallback;
}

export async function uploadAttendanceSheetRequest({
  apiBase,
  talkId,
  topic,
  date,
  file,
}: UploadAttendanceSheetInput): Promise<void> {
  const form = new FormData();

  form.append('talk_id', talkId);
  form.append('topic', topic);
  form.append('date', date);
  form.append('file', file, file.name);

  const response = await authenticatedFetch(
    apiBase + '/v1/attendance',
    {
      method: 'POST',
      body: form,
    },
  );

  if (!response.ok) {
    throw new Error(
      await responseError(
        response,
        'No se pudo guardar la hoja de asistencia.',
      ),
    );
  }
}

export async function fetchAttendanceSheetBlob(
  apiBase: string,
  attendanceId: string,
): Promise<Blob> {
  const response = await authenticatedFetch(
    apiBase +
      '/v1/attendance/' +
      encodeURIComponent(attendanceId) +
      '/file',
  );

  if (!response.ok) {
    throw new Error(
      await responseError(
        response,
        'No se pudo obtener la hoja de asistencia.',
      ),
    );
  }

  return response.blob();
}


export type AttendanceOcrPreview = {
  talk_id: string;
  detected_count: number;
  recognized_workers: Array<{
    local_id: string;
    row: number | null;
    name: string;
    email: string | null;
    user_id: string | null;
    suggested_user_id: string | null;
    match_status: string;
    needs_review: boolean;
  }>;
  pending_confirmation: boolean;
};

export type AttendanceCandidate = {
  id: string;
  name: string;
  email?: string | null;
};

export async function listAttendanceCandidates(
  apiBase: string,
): Promise<AttendanceCandidate[]> {
  const response = await authenticatedFetch(
    `${apiBase}/v1/attendance/candidates`,
  );

  if (!response.ok) {
    throw new Error(
      await responseError(
        response,
        'No se pudo cargar el listado de trabajadores.',
      ),
    );
  }

  return response.json() as Promise<AttendanceCandidate[]>;
}




export async function requestAttendanceOcrPreview(
  apiBase: string,
  talkId: string,
  file: File
): Promise<AttendanceOcrPreview> {
  const formData = new FormData();

  formData.append('talk_id', talkId);
  formData.append('file', file);

  const response = await authenticatedFetch(
    `${apiBase}/v1/attendance/ocr/preview`,
    {
      method: 'POST',
      body: formData,
    }
  );

  if (!response.ok) {
    const error = await response.json()
      .catch(() => ({}));

    throw new Error(
      typeof error.detail === 'string'
        ? error.detail
        : 'No fue posible analizar la hoja de asistencia.'
    );
  }

  return response.json() as Promise<AttendanceOcrPreview>;
}