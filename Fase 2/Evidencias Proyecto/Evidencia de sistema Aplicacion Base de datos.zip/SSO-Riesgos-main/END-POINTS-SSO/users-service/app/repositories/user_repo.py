from typing import Optional, Dict, Any, List
import logging
logger = logging.getLogger(__name__)

class UserRepository:
    def __init__(self, db):
        self.db = db
        self.collection = db["users"]

    async def get_by_email(self, client_id: str, email: str) -> Optional[Dict[str, Any]]:
        doc = await self.collection.find_one({"email": email.strip().lower(), "client_id": client_id})
        if doc:
            doc["id"] = doc.get("user_id", str(doc["_id"]))
            doc.pop("_id", None)
        return doc

    async def get_all(self, client_id: str) -> List[Dict[str, Any]]:
        users = []
        async for doc in self.collection.find({"client_id": client_id}):
            doc["id"] = doc.get("user_id", str(doc["_id"]))
            doc.pop("_id", None)
            doc.pop("hashed_password", None)
            users.append(doc)
        return users

    async def get(self, client_id: str, user_id: str) -> Optional[Dict[str, Any]]:
        doc = await self.collection.find_one({"user_id": user_id, "client_id": client_id})
        if doc:
            doc["id"] = doc.get("user_id", str(doc["_id"]))
            doc.pop("_id", None)
        return doc

    async def create(self, client_id: str, user_id: str, user_data: dict) -> dict:
        user_data["user_id"] = user_id
        user_data["client_id"] = client_id
        await self.collection.insert_one(user_data)
        result = user_data.copy()
        result.pop("hashed_password", None)
        result.pop("_id", None)
        return result

    async def update(self, client_id: str, user_id: str, update_data: dict) -> None:
        await self.collection.update_one({"user_id": user_id, "client_id": client_id}, {"$set": update_data})

    async def delete(self, client_id: str, user_id: str) -> None:
        await self.collection.delete_one({"user_id": user_id, "client_id": client_id})
