import unicodedata


GLOBAL_REPORT_MANAGER_ROLES = {
    "admin",
    "sso manager",
}

AREA_REPORT_MANAGER_ROLES = {
    "supervisor",
    "jefe de area",
}


def normalize_value(value) -> str:
    text = str(value or "").strip().lower().replace("_", " ")
    return "".join(
        char
        for char in unicodedata.normalize("NFD", text)
        if unicodedata.category(char) != "Mn"
    )


def _assigned_areas(user: dict) -> list[str]:
    areas = user.get("assigned_areas") or []

    if isinstance(areas, str):
        areas = [areas]
    else:
        areas = list(areas)

    legacy_area = user.get("area")
    if legacy_area:
        areas.append(legacy_area)

    return [
        normalize_value(area)
        for area in areas
        if normalize_value(area)
    ]


def is_report_manager_for_area(
    user: dict,
    area_id: str,
) -> bool:
    role = normalize_value(user.get("role"))

    if role in GLOBAL_REPORT_MANAGER_ROLES:
        return True

    if role not in AREA_REPORT_MANAGER_ROLES:
        return False

    normalized_area = normalize_value(area_id)
    if not normalized_area:
        return False

    return normalized_area in _assigned_areas(user)


def select_report_managers(
    users: list[dict],
    *,
    client_id: str,
    area_id: str,
    exclude_user_id: str | None = None,
) -> list[dict]:
    selected = []
    seen_user_ids = set()

    for user in users:
        user_id = str(user.get("user_id") or "").strip()

        if not user_id:
            continue

        if user_id == exclude_user_id:
            continue

        if user_id in seen_user_ids:
            continue

        if user.get("client_id") != client_id:
            continue

        if normalize_value(user.get("status")) != "active":
            continue

        if not is_report_manager_for_area(user, area_id):
            continue

        seen_user_ids.add(user_id)

        selected.append(
            {
                "user_id": user_id,
                "role": user.get("role", ""),
            }
        )

    return selected
