# EP-04 / TT-17 (SCRUM-326): auditoría de asistencia

Fecha de revisión: 2026-10-07. Base local: `main` en `95a2d92` (igual al `origin/main` registrado). El árbol estaba limpio al inicio. No se pudo contrastar con el remoto en vivo: `git ls-remote` falló por DNS (`github.com`). Esta revisión cubre el código de este checkout, no datos de producción. No se cambió ninguna base de datos, migración, `.env` ni artefacto compilado.

## Fuentes reales e identidad

| Dato | Fuente mantenida | Uso efectivo |
| --- | --- | --- |
| Trabajadores | colección Mongo `users`, escrita por `users-service/app/repositories/user_repo.py`; esquema `users-service/app/schemas/user.py` | `talks-service/app/repositories/rep_talks.py` filtra por `client_id`, `status=active` y rol `worker`/`usuario` para estadísticas. `expected_workers_for_talk` resuelve IDs históricos del mismo cliente aunque el usuario ya no esté activo. |
| Áreas | `users.assigned_areas` (lista de IDs/cadenas), no un catálogo de áreas consultado por estas rutas | Denominador por área. El texto `attendance.area` aporta contexto para atribución manual o QR; no crea población. Comparación sensible a mayúsculas/espacios salvo `strip()` en estadísticas. |
| Charlas | colección `talks`: `talk_id`, `client_id`, `title`, `month`, `year`, `mandatory`, `expected_user_ids` | `mandatory` y `expected_user_ids` se guardan en creación/edición; IDs esperados se validan como trabajadores activos del cliente al configurar. La comparación y ausencias usan estos campos por charla. Las estadísticas agregadas no los usan. |
| Asistencia | colección `attendance`: `client_id`, `talk_id`, `source`, `attendees`, `attended_user_ids`, `date`, `area`, adjunto | QR acumula IDs y nombres en un documento por cliente/charla; manual y hoja son documentos separados. `source=sheet` registra la hoja adjunta y, si se enviaron, nombres; el archivo no se interpreta automáticamente. |
| OCR | colección `attendance_scans` y Azure Blob/Azurite para imagen | `POST /v1/attendance/ocr` ejecuta Tesseract en español y devuelve coincidencias propuestas; persiste metadata del scan. **No** escribe `attendance` ni confirma asistentes automáticamente. |

El `client_id` de lectura/escritura en `talks-service` procede del JWT (`app/dep_talks.py`), no de parámetros enviados por el cliente. Las búsquedas de `talks`, `attendance` y `users` auditadas incluyen `client_id`. QR comprueba además que el token del QR, la sesión, la charla y el usuario activo pertenecen al mismo cliente. OCR comprueba usuario privilegiado activo y charla del cliente antes de subir la imagen. Las pruebas de integración existentes cubren aislamiento en estadísticas, exportaciones, ausencias y OCR; aquí no se ejecutaron porque requieren escritura en Mongo de prueba.

## Inventario de endpoints

Todos están declarados en `END-POINTS-SSO/talks-service/app/routers/rt_talks.py`; la implementación y las colecciones están en `app/repositories/rep_talks.py`, y la serialización PDF/XLSX en `app/attendance_export.py`.

| Ruta | Datos y comportamiento |
| --- | --- |
| `GET /v1/talks` | Lista charlas del cliente; filtros opcionales `month`, `year`. |
| `POST /v1/talks`, `PATCH /v1/talks/{talk_id}`, `DELETE /v1/talks/{talk_id}` | Configuran `mandatory` y `expected_user_ids`; edición/borrado bloqueados si hay asistencia de la charla. |
| `GET /v1/talks/{talk_id}/expected-workers` | Devuelve configuración, trabajadores resueltos e IDs faltantes del cliente. |
| `GET /v1/talks/{talk_id}/attendance-comparison` | Cruza IDs esperados y asistencia de esa charla, con coincidencia única de nombre para registros legacy sin IDs. |
| `GET /v1/talks/{talk_id}/absent-workers` | Deriva ausentes de la comparación; distingue `absences_found`, `no_absences`, `no_expected_workers` e `insufficient_data`. |
| `GET /v1/talks/{talk_id}/qr`, `POST /v1/attendance/scan` | Emisión de QR temporal y registro idempotente por trabajador/charla/cliente. |
| `GET /v1/attendance`, `POST /v1/attendance`, `GET /v1/attendance/{attendance_id}/file` | Lista y registra manual/hoja; descarga adjunto. Hoja exige charla del cliente y solo un adjunto por cliente/charla. Un registro manual sin archivo puede carecer de charla. |
| `POST /v1/attendance/ocr` | Extrae candidatos OCR y guarda metadata, sin generar asistencia confirmada. |
| `GET /v1/attendance/stats/areas` | Cobertura observada por área, sin filtro temporal. |
| `GET /v1/attendance/stats/months?year=...` | Cobertura observada por mes, con filtro opcional de año. |
| `GET /v1/attendance/export/pdf`, `GET /v1/attendance/export/xlsx` | Exportan filas crudas de asistencia, filtradas por período; 404 si no hay filas. |

Los endpoints de adjunto de charla (`GET /v1/talks/{talk_id}/file`) y de salud (`GET /`, `GET /health`) quedan fuera de los cálculos, aunque el primero usa la misma comprobación de propiedad de la charla.

## Fórmulas y casos límite

**Área `a`:** denominador `D_a = |{user_id: users.client_id=C, status=active, role∈{worker, usuario}, a∈assigned_areas}|`. Numerador `N_a` es el número de IDs distintos de ese conjunto identificados en al menos un documento `attendance` del cliente. Para un registro con `attended_user_ids`, cada ID se atribuye a `attendance.area` si coincide con un área asignada; si el área del registro está vacía, solo se atribuye a trabajadores de área única. Para registros sin IDs y no QR, un nombre se acepta únicamente si corresponde a un solo trabajador activo **dentro del área declarada**. Resultado `round(clamp(100·N_a/D_a, 0, 100), 2)`. No se devuelve un área sin trabajadores activos. Un trabajador multiárea puede integrar varios denominadores, pero una asistencia sin contexto de área no se reparte arbitrariamente.

**Mes `(año, mes)`:** denominador `D_m` es el número actual de trabajadores activos del cliente con rol `worker`/`usuario`, sin usar una plantilla histórica. Numerador `N_m` son IDs distintos que aparecen en asistencia del período: se prioriza `talks.month/year` de una charla del mismo cliente y se usa `attendance.date` como respaldo si no hay período válido de charla. IDs persistidos son autoritativos; solo registros sin IDs y no QR admiten nombre único entre trabajadores activos del cliente. Resultado `round(clamp(100·N_m/D_m, 0, 100), 2)`. Se devuelven únicamente períodos presentes en `attendance`; una charla programada sin asistencia no crea fila mensual. Cambios posteriores en `users.status`, rol o áreas pueden alterar retrospectivamente ambas coberturas.

**Charla `t`:** `expected_user_ids` es la lista configurada y deduplicada. `attended_user_ids` de comparación es la intersección de esa lista con los IDs en `attendance` del mismo cliente y charla, más nombres legacy inequívocos entre los trabajadores esperados resueltos. `absent_user_ids = resolved_expected_user_ids − attended_user_ids`. IDs esperados que ya no se resuelven dentro del cliente se muestran en `missing_expected_user_ids`, sin clasificarlos como ausentes, y producen `insufficient_data`. Si el campo esperado no existe, también hay `insufficient_data`; si existe vacío, `no_expected_workers`. `mandatory` se expone, pero no altera esta resta. Por ello, cobertura observada de área/mes **no equivale** a cumplimiento de charlas obligatorias ni tiene el mismo denominador que las ausencias por charla.

**Exportaciones:** PDF y XLSX usan la misma lista de documentos `attendance`; cada fila representa un documento, `Cantidad` cuenta elementos de `attendees` y `Tipo` distingue `QR`, `Hoja` y `Manual`. No calculan personas únicas ni ausencias. El filtro de período usa charla asociada y luego `attendance.date`; las estadísticas mensuales aplican el mismo orden. El área de una fila es el texto capturado en `attendance.area`, que puede estar vacío aunque la estadística atribuya un QR a un trabajador de área única. No se debe reconciliar sumando filas o cantidades de exportación con `N_a`/`N_m`.

## Deduplicación, coexistencia y coherencia

- QR usa un documento determinístico por `client_id`/`talk_id` y un `$push` condicionado a `attended_user_ids: {$ne: user_id}`. Un segundo scan de la misma persona no duplica su entrada; scans de personas distintas coexisten. La suite de integración existente prueba también concurrencia, pero no se ejecutó en esta auditoría.
- Manual y hoja quedan en documentos independientes del QR. La hoja con archivo usa `_id` determinístico por cliente/charla y responde 409 ante duplicación; OCR conserva solo metadata y requiere confirmación externa que aquí no se encontró implementada.
- Comparación y ausencias ya priorizaban IDs para QR. Se corrigió estadísticas de área/mes para aplicar la misma regla. Una prueba en memoria con nombre QR contradictorio reproduce la sobrecuenta anterior (2 frente a 1) y confirma ahora `N=1` y un ausente. Otra comprueba QR + manual, nombres repetidos y metadata OCR sin doble cuenta.
- Los PDF/XLSX antes mostraban una hoja (`source=sheet`) como `Manual`; ambos usan ahora una etiqueta común `Hoja`. Se verificó el contenido XLSX y que el PDF se genera; la misma función alimenta las dos etiquetas.

## Frontend real

`GPI-SSO-Frontend/APP-GPI-ALLOXENTRIC/src/app/pages/SafetyTalksMobile.tsx` consume estadísticas, QR, exportaciones, hojas y ausencias. El proyecto tiene Capacitor y directorio Android: esta implementación corresponde a la **aplicación móvil**, aunque Vite también permita ejecutarla en navegador. `GPI-SSO-Frontend/WebSSO` contiene configuración y `dist/` compilado, sin `src/` ni `package.json` mantenidos en este checkout; `dashboard-dist/` y `dashboard-service/static/assets/` también son artefactos compilados. No hay evidencia aquí de componentes fuente de Dashboard Web para estas vistas. No se editó ningún bundle ni se supuso una integración WebSSO ausente.

## Pruebas y límites de ejecución

| Comprobación | Resultado |
| --- | --- |
| Pruebas unitarias de `talks-service`, con `TEST_MONGO_URI` ficticia solo para satisfacer la guarda de importación y sin fixture de DB | `8 passed`, incluidas 3 nuevas de coherencia. Ninguna conexión ni escritura Mongo. |
| `npm test -- --run` en `APP-GPI-ALLOXENTRIC` | `33` archivos, `249 passed`. |
| `git diff --check` | Correcto. |
| Suite de integración de `talks-service` | No ejecutada: el fixture crea/elimina bases Mongo temporales. El usuario prohibió modificar bases de datos; tampoco existe `.env.test` en este checkout. |
| Comprobación del remoto | No disponible por fallo de resolución DNS para `github.com`; `main` y el `origin/main` local coinciden. |

## Hallazgos pendientes y relación con subtareas

| Subtarea | Evidencia y estado de esta auditoría |
| --- | --- |
| ST-251 | Inventario de fuentes, endpoints y tenant realizado; pendiente contraste con datos reales y remoto actualizado. |
| ST-252 | Fórmulas de cobertura y separación de `mandatory`/`expected_user_ids` documentadas; sobrecuenta QR corregida con prueba. |
| ST-253 | Deduplicación/coexistencia revisadas en código y pruebas en memoria; suite de concurrencia Mongo pendiente por restricción de datos. OCR no registra asistencia confirmada. |
| ST-254 | Exportaciones, comparación, ausencias y frontend revisados; etiqueta de hoja corregida. Verificación integral HTTP/Mongo y fuente Dashboard Web pendientes. |

La correspondencia ST-251–ST-254 es una organización de los objetivos recibidos: las descripciones originales de las subtareas no están en este checkout. No se cambió el estado de ningún ticket.

Pendientes técnicos concretos: (1) `POST /v1/attendance` valida pertenencia de `talk_id` para hojas, pero no para un registro manual sin archivo; conviene definir si los registros manuales con `talk_id` deben exigir una charla existente del cliente, preservando los legacy sin charla. (2) Las cadenas de año aceptan dígitos de cualquier longitud y la fecha de respaldo se reconoce por prefijo, no como fecha calendario completa; exportación y estadística pueden divergir para datos inválidos de mes. (3) La identidad por nombre legacy puede quedar ambigua si hay homónimos; se omite en lugar de adivinar. (4) El PDF/XLSX muestra nombres capturados y no una auditoría de identidad; comparar con ausencias requiere IDs por charla. Estas decisiones requieren reglas de producto o pruebas integrales antes de ampliar la corrección.

## Archivos modificados

- `docs/ep04-auditoria.md` (este informe).
- `END-POINTS-SSO/talks-service/app/repositories/rep_talks.py` (identidad QR en estadísticas y aclaración de alcance).
- `END-POINTS-SSO/talks-service/app/attendance_export.py` (etiqueta `Hoja` compartida).
- `END-POINTS-SSO/talks-service/tests/unit/test_attendance_consistency.py` (regresiones sin Mongo).

No se hizo commit, merge ni push; no se marcaron tareas como finalizadas.
