import {
  beforeEach,
  describe,
  expect,
  it,
  vi,
} from 'vitest';

const mocks = vi.hoisted(() => ({
  authenticatedFetch: vi.fn(),
}));

vi.mock('./client', () => ({
  authenticatedFetch:
    mocks.authenticatedFetch,
}));

import {
  createReportWithPhoto,
  REPORT_CREATE_TIMEOUT_MS,
  ReportNetworkError,
  ReportRequestError,
} from './reports';

const payload = {
  area_id: 'Linea 1',
  type: 'Acto Inseguro',
  is_iap: false,
  description: 'Prueba',
  causes: [],
  shift: 'Dia',
  worker_type: 'planta',
};

describe('createReportWithPhoto', () => {
  beforeEach(() => {
    mocks.authenticatedFetch
      .mockReset();
  });

  it(
    'envía Idempotency-Key sin fijar Content-Type',
    async () => {
      mocks.authenticatedFetch
        .mockResolvedValue(
          new Response(
            JSON.stringify({
              report_id: '15',
            }),
            {
              status: 200,
              headers: {
                'Content-Type':
                  'application/json',
              },
            },
          ),
        );

      const reportId =
        await createReportWithPhoto(
          payload,
          undefined,
          'Dia',
          'worker-a',
          'idem-123',
        );

      expect(reportId).toBe('15');

      const [, options] =
        mocks.authenticatedFetch
          .mock.calls[0];

      const headers =
        new Headers(options.headers);

      expect(
        headers.get('Idempotency-Key'),
      ).toBe('idem-123');

      expect(
        headers.has('Content-Type'),
      ).toBe(false);
    },
  );

  it(
    'clasifica un fallo de fetch como error de red',
    async () => {
      mocks.authenticatedFetch
        .mockRejectedValue(
          new TypeError(
            'Failed to fetch',
          ),
        );

      await expect(
        createReportWithPhoto(
          payload,
          undefined,
          'Dia',
          'worker-a',
          'idem-network',
        ),
      ).rejects.toBeInstanceOf(
        ReportNetworkError,
      );
    },
  );

  it(
    'mantiene los HTTP errors fuera del flujo offline',
    async () => {
      mocks.authenticatedFetch
        .mockResolvedValue(
          new Response(
            'validation failed',
            { status: 422 },
          ),
        );

      try {
        await createReportWithPhoto(
          payload,
          undefined,
          'Dia',
          'worker-a',
          'idem-http',
        );

        throw new Error(
          'Expected request to fail',
        );
      } catch (error) {
        expect(error).toBeInstanceOf(
          ReportRequestError,
        );

        expect(
          (error as ReportRequestError)
            .status,
        ).toBe(422);
      }
    },
  );
});


describe('createReportWithPhoto timeout', () => {
  it(
    'convierte timeout en error de red',
    async () => {
      vi.useFakeTimers();

      try {
        mocks.authenticatedFetch
          .mockImplementation(
            (
              _input:
                RequestInfo | URL,
              options?: RequestInit,
            ) =>
              new Promise<Response>(
                (_resolve, reject) => {
                  options?.signal
                    ?.addEventListener(
                      'abort',
                      () => {
                        const error =
                          new Error(
                            'aborted',
                          );

                        error.name =
                          'AbortError';

                        reject(error);
                      },
                      { once: true },
                    );
                },
              ),
          );

        const request =
          createReportWithPhoto(
            payload,
            undefined,
            'Dia',
            'worker-a',
            'idem-timeout',
          );

        const assertion =
          expect(request)
            .rejects
            .toBeInstanceOf(
              ReportNetworkError,
            );

        await vi.advanceTimersByTimeAsync(
          REPORT_CREATE_TIMEOUT_MS,
        );

        await assertion;
      } finally {
        vi.useRealTimers();
      }
    },
  );
});
