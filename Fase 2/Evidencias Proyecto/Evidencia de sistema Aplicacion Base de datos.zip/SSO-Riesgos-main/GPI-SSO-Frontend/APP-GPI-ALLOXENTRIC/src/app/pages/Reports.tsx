import type { Translation } from '../constants/translations';
import { motion } from 'motion/react';
import { Filter, Camera } from 'lucide-react';
import type { Report, ReportStatus } from '../api/reports';
import {
  formatReportDate,
  getReportDisplayId,
  getReportEvidenceUrl,
} from '../utils/reportPresentation';

interface Props {
  t: Translation;
  reports: Report[];
  filteredReports: Report[];
  reportFilter: 'all' | 'open' | 'closed';
  openReportsCount: number;
  onFilterChange: (f: 'all' | 'open' | 'closed') => void;
  onSelectReport: (r: Report) => void;
  onOpenCreateReport: () => void;
  getStatusLabel: (s: ReportStatus) => string | undefined;
}

export default function Reports({
  t, reports, filteredReports, reportFilter, openReportsCount,
  onFilterChange, onSelectReport, onOpenCreateReport, getStatusLabel,
}: Props) {
  return (
    <motion.div
      key="reports"
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 20 }}
      // CAMBIO AQUÍ: Cambiamos h-full por h-screen para congelar el viewport general
      className="h-screen w-full overflow-y-auto"
    >
      {/* CAMBIO AQUÍ: Añadimos pb-32 para que el scroll deje ver el último elemento sin tapar el botón flotante */}
      <div className="px-6 py-6 pb-32">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold">{t.myReports}</h1>
          <Filter size={20} className="themed-text-secondary" />
        </div>

        {/* Filter Tabs */}
        <div className="flex gap-3 mb-6">
          {(['all', 'open', 'closed'] as const).map((filter) => {
            let count = 0;
            if (filter === 'all') {
              count = reports.length;
            } else if (filter === 'open') {
              count = reports.filter(r => r.status !== 'closed').length;
            } else if (filter === 'closed') {
              count = reports.filter(r => r.status === 'closed').length;
            }

            return (
              <button
                key={filter}
                onClick={() => onFilterChange(filter)}
                className={`px-5 py-2 rounded-full text-sm font-semibold transition-all ${
                  reportFilter === filter ? 'bg-[#00E5FF] text-[#0B1E36]' : 'themed-btn-inactive themed-text-secondary'
                }`}
              >
                {filter === 'all'
                  ? `${t.all} (${count})`
                  : filter === 'open'
                  ? `${t.open} (${count})`
                  : `${t.closed} (${count})`}
              </button>
            );
          })}
        </div>

        {/* Reports List */}
        <div className="space-y-3">
          {filteredReports.map((report, i) => {
            const reportPhoto = getReportEvidenceUrl(report);

            return (
              <motion.div
                key={report.report_id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                onClick={() => onSelectReport(report)}
                className="themed-card border rounded-2xl p-4 flex gap-3 cursor-pointer themed-card-hover transition-colors"
              >
                {/* Contenedor de la Imagen / Emoji */}
                <div className="w-16 h-16 themed-card rounded-lg flex items-center justify-center text-2xl overflow-hidden themed-photo-placeholder themed-border border">
                  {reportPhoto ? (
                    <img 
                      src={reportPhoto} 
                      alt="Evidence" 
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        (e.target as HTMLImageElement).style.display = 'none';
                        const parent = (e.target as HTMLImageElement).parentElement;
                        if (parent) parent.innerText = '📸';
                      }}
                    />
                  ) : (
                    '📸'
                  )}
                </div>

                {/* Información del Reporte */}
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-1">
                    <span className="font-bold">#{getReportDisplayId(report)}</span>
                    {report.is_iap && (
                      <span className="bg-[#D72631] text-[10px] px-2 py-0.5 rounded-full font-bold">IAP</span>
                    )}
                  </div>
                  <p className="text-sm themed-text-secondary">{report.area_id} • {formatReportDate(report.created_at)}</p>
                  <span className={`inline-block mt-2 text-xs px-3 py-1 rounded-full ${
                    report.status === 'open' ? 'bg-[#3b82f6]/20 text-[#3b82f6]' :
                    report.status === 'reviewing' || report.status === 'en_proceso' ? 'bg-[#E8941A]/20 text-[#E8941A]' :
                    report.status === 'assigned' ? 'bg-[#1A5276]/20 text-[#1A5276]' :
                    report.status === 'pending_closure' ? 'bg-[#8b5cf6]/20 text-[#8b5cf6]' :
                    report.status === 'closed' ? 'bg-[#16A34A]/20 text-[#16A34A]' :
                    'bg-[#7E8A94]/20 themed-text-tertiary'
                  }`}>
                    {getStatusLabel(report.status)}
                  </span>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Floating Add Button */}
        {/* EXPLICACIÓN: "fixed bottom-6" saca el botón del flujo del overflow anterior */}
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={onOpenCreateReport}
          className="fixed bottom-24 left-1/2 -translate-x-1/2 bg-gradient-to-r from-[#0097A8] to-[#00E5FF] text-white rounded-full w-14 h-14 shadow-2xl flex items-center justify-center z-50"
        >
          <span className='text-xl font-bold'>+</span>
        </motion.button>
      </div>
    </motion.div>
  );
}