export function canManageTalkAttendance(role: string | null | undefined): boolean {
  const normalized = role?.trim().toLowerCase().replaceAll('_', ' ');
  return normalized === 'admin' || normalized === 'sso manager';
}
