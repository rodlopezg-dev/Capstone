from datetime import datetime, timezone
import ulid as ulid_lib

def _now_iso():
    return datetime.now(timezone.utc).isoformat()

class IncidentRepository:
    def __init__(self, db):
        self.incidents = db["incidents"]

    async def get_all(self, client_id):
        results = []
        async for doc in self.incidents.find({"client_id": client_id}).sort("created_at", -1):
            doc.pop("_id", None)
            results.append(doc)
        return results

    async def get_by_id(self, client_id, incident_id):
        doc = await self.incidents.find_one({"incident_id": incident_id, "client_id": client_id})
        if doc:
            doc.pop("_id", None)
        return doc

    async def create(self, client_id, incident_data):
        incident_id = f"inc_{ulid_lib.ULID()}"
        incident_data.update({"incident_id": incident_id, "client_id": client_id, "created_at": _now_iso()})
        await self.incidents.insert_one(incident_data)
        return incident_id

    async def update_status(self, client_id, incident_id, status, feedback=""):
        update = {"$set": {"status": status, f"timeline.{status}": _now_iso()}}
        if feedback:
            update["$set"]["feedback"] = feedback
        result = await self.incidents.update_one({"incident_id": incident_id, "client_id": client_id}, update)
        return result.modified_count > 0
