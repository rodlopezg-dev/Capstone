export interface LocalNotificationItem {
  id: string;
  title: string;
  description: string;
  enabled?: boolean;
}

export interface LocalNotificationState {
  initialized: true;
  seenIds: string[];
}

const MAX_SEEN_IDS = 500;
const STORAGE_PREFIX = 'vigia_local_notification_state:v1';

export type LocalNotificationChannel =
  | 'reports'
  | 'alerts';

export function buildLocalNotificationStorageKey(
  clientId: string,
  userId: string,
  channel: LocalNotificationChannel,
): string {
  return `${STORAGE_PREFIX}:${channel}:${encodeURIComponent(clientId)}:${encodeURIComponent(userId)}`;
}

export function parseLocalNotificationState(
  raw: string | null,
): LocalNotificationState | null {
  if (!raw) return null;

  try {
    const parsed = JSON.parse(raw);

    if (
      parsed?.initialized !== true ||
      !Array.isArray(parsed.seenIds)
    ) {
      return null;
    }

    const seenIds = Array.from(
      new Set(
        parsed.seenIds.filter(
          (id: unknown): id is string =>
            typeof id === 'string' && id.length > 0,
        ),
      ),
    ).slice(0, MAX_SEEN_IDS);

    return {
      initialized: true,
      seenIds,
    };
  } catch {
    return null;
  }
}

export function reconcileLocalNotificationState(
  state: LocalNotificationState | null,
  items: LocalNotificationItem[],
): {
  newItems: LocalNotificationItem[];
  nextState: LocalNotificationState;
} {
  const validItems = items.filter(
    item => typeof item.id === 'string' && item.id.length > 0,
  );

  const currentIds = Array.from(
    new Set(validItems.map(item => item.id)),
  );

  // Primera carga real del backend:
  // todo lo existente se considera histórico y forma el baseline.
  if (!state?.initialized) {
    return {
      newItems: [],
      nextState: {
        initialized: true,
        seenIds: currentIds.slice(0, MAX_SEEN_IDS),
      },
    };
  }

  const seen = new Set(state.seenIds);
  const emitted = new Set<string>();

  const newItems = validItems.filter(item => {
    if (item.enabled === false) return false;
    if (seen.has(item.id)) return false;
    if (emitted.has(item.id)) return false;

    emitted.add(item.id);
    return true;
  });

  // Se conservan tanto los IDs actuales como los ya vistos anteriormente.
  // Así, si un elemento desaparece temporalmente y vuelve después,
  // no se interpreta nuevamente como nuevo.
  const seenIds = Array.from(
    new Set([
      ...currentIds,
      ...state.seenIds,
    ]),
  ).slice(0, MAX_SEEN_IDS);

  return {
    newItems,
    nextState: {
      initialized: true,
      seenIds,
    },
  };
}
